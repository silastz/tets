import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:geolocator/geolocator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'api_service.dart';
import 'session_manager.dart';

/// Reads the phone's GPS (only when location permission is already granted) and keeps the
/// user's coordinates up to date in the database so "nearby services" can be ranked by distance.
///
/// - Runs on app start, whenever the app comes back to the foreground, and right after sign-in.
/// - Uploads are throttled: only when the user moved ~200 m or 30 minutes have passed.
/// - Guests: GPS is used on the phone only (distance + sorting); it is never sent to the server.
/// - Never asks for permission itself (the start-up permission screen does that).
class GpsService {
  static const double _minMoveMeters = 200;
  static const Duration _minInterval = Duration(minutes: 30);

  static const _kLat = 'gps_lat';
  static const _kLng = 'gps_lng';
  static const _kSyncLat = 'gps_sync_lat';
  static const _kSyncLng = 'gps_sync_lng';
  static const _kSyncAt = 'gps_sync_at';
  static const _kSyncUser = 'gps_sync_user';

  /// Last known position of this device (null until the first fix).
  static double? lat;
  static double? lng;

  /// Bumped whenever a new position is read, so lists can re-rank.
  static final ValueNotifier<int> changed = ValueNotifier<int>(0);

  static bool get hasFix => lat != null && lng != null;

  /// Only signed-in accounts (buyers and providers) are saved to the database.
  /// Guests use the GPS on the phone for nearby results but nothing is uploaded.
  static bool get _canUpload => SessionManager.isLoggedIn();

  static SharedPreferences? _prefs;
  static AppLifecycleListener? _lifecycle;
  static bool _busy = false;

  static Future<void> start() async {
    _prefs ??= await SharedPreferences.getInstance();
    lat = _prefs!.getDouble(_kLat);
    lng = _prefs!.getDouble(_kLng);
    _lifecycle ??= AppLifecycleListener(onResume: () => refresh());
    // On sign-out the next sign-in (any account) uploads again.
    // A different account signed in: upload this device's position for it.
    SessionManager.sessionNotifier.addListener(() {
      if (SessionManager.isLoggedIn() &&
          _prefs?.getInt(_kSyncUser) != SessionManager.getUserIdValue()) {
        refresh(forceSync: true);
      }
    });
    refresh();
  }

  /// Distance in km between the device and a point, or null when either is unknown.
  static double? distanceKmTo(double? toLat, double? toLng) {
    if (!hasFix || toLat == null || toLng == null) return null;
    return Geolocator.distanceBetween(lat!, lng!, toLat, toLng) / 1000.0;
  }

  static Future<void> refresh({bool forceSync = false}) async {
    if (_busy) return;
    _busy = true;
    try {
      _prefs ??= await SharedPreferences.getInstance();
      if (!await Geolocator.isLocationServiceEnabled()) return;
      final perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) return;

      final pos = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.medium,
          timeLimit: Duration(seconds: 10),
        ),
      );
      lat = pos.latitude;
      lng = pos.longitude;
      await _prefs!.setDouble(_kLat, pos.latitude);
      await _prefs!.setDouble(_kLng, pos.longitude);
      changed.value++;

      await _syncIfNeeded(forceSync);
    } catch (e) {
      debugPrint('GPS refresh error: $e');
    } finally {
      _busy = false;
    }
  }

  static Future<void> _syncIfNeeded(bool force) async {
    if (!_canUpload || !hasFix) return; // guests: local GPS only, never uploaded
    final p = _prefs!;
    final lastAt = p.getInt(_kSyncAt) ?? 0;
    final lastLat = p.getDouble(_kSyncLat);
    final lastLng = p.getDouble(_kSyncLng);
    final sameUser = p.getInt(_kSyncUser) == SessionManager.getUserIdValue();

    var due = force || !sameUser || lastLat == null || lastLng == null;
    if (!due) {
      final moved = Geolocator.distanceBetween(lastLat!, lastLng!, lat!, lng!);
      final age = DateTime.now().difference(DateTime.fromMillisecondsSinceEpoch(lastAt));
      due = moved >= _minMoveMeters || age >= _minInterval;
    }
    if (!due) return;

    final ok = await ApiService.updateUserLocation(lat!, lng!);
    if (ok) {
      await p.setInt(_kSyncAt, DateTime.now().millisecondsSinceEpoch);
      await p.setDouble(_kSyncLat, lat!);
      await p.setDouble(_kSyncLng, lng!);
      await p.setInt(_kSyncUser, SessionManager.getUserIdValue());
    }
  }
}

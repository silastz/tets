import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/session_manager.dart';
import '../widgets/skeleton_loader.dart';
import '../widgets/guest_state_placeholder.dart';
import '../widgets/cancel_booking_sheet.dart';
import 'booking_details_screen.dart';
import '../services/data_sync.dart';

class RequestsScreen extends StatefulWidget {
  const RequestsScreen({super.key});

  @override
  State<RequestsScreen> createState() => _RequestsScreenState();
}

class _RequestsScreenState extends State<RequestsScreen> {
  // Navigation tabs: 'My Requests' (Buyer) vs 'Incoming' (Seller) vs 'Outgoing' (Seller Outgoing)
  String _activeTab = 'My Requests'; 
  String _statusFilter = 'All'; // 'All', 'Pending', 'Accepted', 'Completed'
  bool _isLoading = true;
  List<dynamic> _transactions = [];

  // Something was written to the server elsewhere (booking, accept, wallet, review...): re-fetch.
  void _onDataChanged() {
    if (mounted) _loadData();
  }

  @override
  void dispose() {
    DataSync.changed.removeListener(_onDataChanged);
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    DataSync.changed.addListener(_onDataChanged);
    final role = SessionManager.getRole();
    if (role == 'ROLE_SELLER') {
      _activeTab = 'Incoming';
    } else {
      _activeTab = 'My Requests';
    }
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    List<dynamic> list;
    if (_activeTab == 'Incoming') {
      list = await ApiService.fetchSellerOrders();
    } else {
      list = await ApiService.fetchBuyerTransactions();
    }
    if (mounted) {
      setState(() {
        _transactions = list;
        _isLoading = false;
      });
    }
  }

  Future<void> _acceptOrder(String ref) async {
    final res = await ApiService.acceptEscrowRequest(ref);
    if (res != null && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(AppStrings.requestsAcceptedNotice),
          backgroundColor: AppColors.success,
        ),
      );
      _loadData();
    }
  }

  Future<void> _cancelBooking(String ref, String serviceTitle, String status) async {
    if (ref.isEmpty) return;
    final done = await CancelBookingSheet.show(
      context,
      transactionRef: ref,
      serviceTitle: serviceTitle,
      status: status,
    );
    if (done == true && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(AppStrings.isEnglish ? 'Booking cancelled' : 'Oda imeghairiwa'),
          backgroundColor: AppColors.danger,
        ),
      );
      _loadData();
    }
  }

  Future<void> _rejectOrder(String ref) async {
    final res = await ApiService.rejectEscrowRequest(ref);
    if (res != null && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(AppStrings.requestsRejectedNotice),
          backgroundColor: AppColors.danger,
        ),
      );
      _loadData();
    }
  }



  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppLanguage>(
      valueListenable: AppStrings.currentLanguage,
      builder: (context, _, _) {
        final isSeller = SessionManager.getRole() == 'ROLE_SELLER';

        return Scaffold(
          backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        title: Text(
          isSeller && _activeTab == 'Incoming'
              ? 'Incoming Requests'
              : (isSeller && _activeTab == 'Outgoing'
                  ? 'Outgoing Requests'
                  : AppStrings.requestsTitle),
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: !SessionManager.isLoggedIn()
          ? GuestStatePlaceholder(
              icon: Icons.receipt_long_outlined,
              title: AppStrings.guestTitle,
              description: AppStrings.guestRequestsDesc,
              onLoginSuccess: () {
                _loadData();
                setState(() {});
              },
            )
          : Column(
              children: [
                // 1. Primary Segmented Tabs
                Container(
                  color: AppColors.surface,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  child: Row(
                    children: isSeller
                        ? [
                            Expanded(
                              child: _buildTopTab(
                                label: 'Incoming',
                                isSelected: _activeTab == 'Incoming',
                                onTap: () {
                                  if (_activeTab != 'Incoming') {
                                    setState(() => _activeTab = 'Incoming');
                                    _loadData();
                                  }
                                },
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _buildTopTab(
                                label: 'Outgoing',
                                isSelected: _activeTab == 'Outgoing',
                                onTap: () {
                                  if (_activeTab != 'Outgoing') {
                                    setState(() => _activeTab = 'Outgoing');
                                    _loadData();
                                  }
                                },
                              ),
                            ),
                          ]
                        : [
                            Expanded(
                              child: _buildTopTab(
                                label: 'My Requests',
                                isSelected: _activeTab == 'My Requests',
                                onTap: () {
                                  if (_activeTab != 'My Requests') {
                                    setState(() => _activeTab = 'My Requests');
                                    _loadData();
                                  }
                                },
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _buildTopTab(
                                label: 'Incoming',
                                isSelected: _activeTab == 'Incoming',
                                onTap: () {
                                  if (_activeTab != 'Incoming') {
                                    setState(() => _activeTab = 'Incoming');
                                    _loadData();
                                  }
                                },
                              ),
                            ),
                          ],
                  ),
                ),

                // 2. Status Filter Pills Bar (Buyer 'My Requests' mode - matches Screen 1)
                if (_activeTab == 'My Requests')
                  Container(
                    color: AppColors.surface,
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: ['All', 'Pending', 'Accepted', 'Completed', 'Cancelled'].map((filter) {
                          final isSelected = _statusFilter == filter;
                          return Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: GestureDetector(
                              onTap: () => setState(() => _statusFilter = filter),
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                                decoration: BoxDecoration(
                                  color: isSelected ? AppColors.primary : AppColors.borderLight,
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: Text(
                                  filter,
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                    color: isSelected ? Colors.white : AppColors.textSecondary,
                                  ),
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ),

                const Divider(height: 1, color: AppColors.borderLight),

                // 3. Requests List
                Expanded(
                  child: _isLoading
                      ? ListView.separated(
                          padding: const EdgeInsets.all(16),
                          itemCount: 3,
                          separatorBuilder: (_, _) => const SizedBox(height: 14),
                          itemBuilder: (_, _) => const VerticalListCardSkeleton(),
                        )
                      : _filteredTransactions.isEmpty
                          ? Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Icon(Icons.inbox_outlined, size: 48, color: AppColors.textMuted),
                                  const SizedBox(height: 12),
                                  Text(
                                    AppStrings.requestsNoRequests,
                                    style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
                                  ),
                                  const SizedBox(height: 12),
                                  OutlinedButton.icon(
                                    onPressed: _loadData,
                                    icon: const Icon(Icons.refresh_rounded, size: 16),
                                    label: Text(AppStrings.retry),
                                    style: OutlinedButton.styleFrom(
                                      foregroundColor: AppColors.primary,
                                      side: const BorderSide(color: AppColors.primary),
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : RefreshIndicator(
                              onRefresh: _loadData,
                              child: ListView.separated(
                                padding: const EdgeInsets.all(16),
                                itemCount: _filteredTransactions.length,
                                separatorBuilder: (_, _) => const SizedBox(height: 14),
                                itemBuilder: (context, index) {
                                  final tx = _filteredTransactions[index] as Map<String, dynamic>;
                                  if (_activeTab == 'My Requests') {
                                    return _buildBuyerRequestCard(tx, index);
                                  } else if (_activeTab == 'Incoming') {
                                    return _buildSellerIncomingCard(tx, index);
                                  } else {
                                    return _buildSellerOutgoingCard(tx, index);
                                  }
                                },
                              ),
                            ),
                ),
              ],
            ),
    );
      },
    );
  }

  List<dynamic> get _filteredTransactions {
    if (_activeTab != 'My Requests' || _statusFilter == 'All') {
      return _transactions;
    }
    return _transactions.where((tx) {
      final status = (tx['status'] ?? '').toString().toUpperCase();
      if (_statusFilter == 'Pending') return status.contains('PENDING');
      if (_statusFilter == 'Accepted') return status.contains('ACCEPTED');
      if (_statusFilter == 'Completed') return status.contains('COMPLETED');
      if (_statusFilter == 'Cancelled') return status.contains('CANCEL');
      return true;
    }).toList();
  }

  Widget _buildTopTab({
    required String label,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.primary : AppColors.borderLight,
          borderRadius: BorderRadius.circular(20),
        ),
        alignment: Alignment.center,
        child: Text(
          label,
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w700,
            color: isSelected ? Colors.white : AppColors.textSecondary,
          ),
        ),
      ),
    );
  }

  // SCREEN 1: Buyer Request Card (Matches Photo 1)
  Widget _buildBuyerRequestCard(Map<String, dynamic> tx, int index) {
    final seller = tx['seller'] ?? {};
    final providerName = seller['stageName'] ?? 'Asha Wellness';
    final serviceTitle = tx['serviceTitle'] ?? 'Massage Therapy';
    final status = (tx['status'] ?? 'PENDING_ACCEPTANCE').toString().toUpperCase();
    final amount = (tx['amount'] as num?)?.toDouble() ?? 50000.0;
    final amountFormatted = 'TSh ${amount.toInt().toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]},')}';
    final image = index % 2 == 0 ? 'assets/images/banner.jpg' : 'assets/images/provider1.jpg';

    Color statusBg = const Color(0xFFFFF7ED);
    Color statusColor = const Color(0xFFF97316);
    String statusLabel = 'Pending';

    if (status.contains('ACCEPTED')) {
      statusBg = const Color(0xFFF0FDF4);
      statusColor = AppColors.success;
      statusLabel = 'Accepted';
    } else if (status.contains('COMPLETED')) {
      statusBg = const Color(0xFFEFF6FF);
      statusColor = AppColors.primary;
      statusLabel = 'Completed';
    } else if (status.contains('CANCEL')) {
      statusBg = const Color(0xFFFEF2F2);
      statusColor = AppColors.danger;
      statusLabel = 'Cancelled';
    } else if (status.contains('REJECT')) {
      statusBg = const Color(0xFFFEF2F2);
      statusColor = AppColors.danger;
      statusLabel = 'Rejected';
    }
    final bookingRef = (tx['transactionRef'] ?? '').toString();
    final canCancel = BookingCancel.canCancel(status) && bookingRef.isNotEmpty;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.asset(
                  image,
                  width: 60,
                  height: 60,
                  fit: BoxFit.cover,
                  errorBuilder: (ctx, err, stack) => Container(
                    width: 60,
                    height: 60,
                    color: AppColors.borderLight,
                    child: const Icon(Icons.spa_rounded, color: AppColors.textMuted),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      serviceTitle,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      providerName,
                      style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '$amountFormatted • 60 min',
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: const [
                        Icon(Icons.calendar_today_outlined, size: 12, color: AppColors.textMuted),
                        SizedBox(width: 4),
                        Text(
                          'Today, 10:00 AM',
                          style: TextStyle(fontSize: 11, color: AppColors.textMuted),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: statusBg,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  statusLabel,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: statusColor,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: SizedBox(
                  height: 36,
                  child: OutlinedButton(
                    onPressed: () async {
                      final changed = await Navigator.push<bool>(
                        context,
                        MaterialPageRoute(
                          builder: (_) => BookingDetailsScreen(
                            bookingData: {
                              'serviceTitle': serviceTitle,
                              'providerName': providerName,
                              'price': amountFormatted,
                              'status': statusLabel,
                              'ref': bookingRef,
                              'image': image,
                              'providerLat': seller['latitude'] ?? tx['latitude'],
                              'providerLng': seller['longitude'] ?? tx['longitude'],
                            },
                          ),
                        ),
                      );
                      if (changed == true && mounted) _loadData();
                    },
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.primary,
                      side: const BorderSide(color: AppColors.primary),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                    child: const Text('View', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: SizedBox(
                  height: 36,
                  child: OutlinedButton(
                    onPressed: canCancel ? () => _cancelBooking(bookingRef, serviceTitle, status) : null,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.danger,
                      disabledForegroundColor: AppColors.textDisabled,
                      side: BorderSide(color: canCancel ? AppColors.danger : AppColors.border),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                    child: const Text('Cancel', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // SCREEN 2: Seller Incoming Request Card (Matches Photo 2)
  Widget _buildSellerIncomingCard(Map<String, dynamic> tx, int index) {
    final buyer = tx['buyer'] ?? {};
    final buyerName = buyer['stageName'] ?? 'Neema J. (Buyer)';
    final serviceTitle = tx['serviceTitle'] ?? 'Massage Therapy';
    final amount = (tx['amount'] as num?)?.toDouble() ?? 50000.0;
    final amountFormatted = 'TSh ${amount.toInt().toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]},')}';
    final ref = (tx['transactionRef'] ?? '').toString();
    final incomingStatus = (tx['status'] ?? 'PENDING_ACCEPTANCE').toString().toUpperCase();
    final message = tx['customerNote'] ?? 'Nahitaji huduma ya massage, naweza kuja au unafika?';

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                radius: 20,
                backgroundImage: const AssetImage('assets/images/provider1.jpg'),
                backgroundColor: AppColors.borderLight,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          buyerName,
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        const SizedBox(width: 4),
                        Container(
                          width: 6,
                          height: 6,
                          decoration: const BoxDecoration(
                            color: AppColors.success,
                            shape: BoxShape.circle,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Wants: $serviceTitle',
                      style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '$amountFormatted • 60 min',
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Row(
                      children: const [
                        Icon(Icons.location_on_outlined, size: 12, color: AppColors.textMuted),
                        SizedBox(width: 2),
                        Text(
                          '2.1 km • Today, 10:00 AM',
                          style: TextStyle(fontSize: 11, color: AppColors.textMuted),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: AppColors.primary,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Text(
                  'New',
                  style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.white),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),

          // Message bubble
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.borderLight.withValues(alpha: 0.5),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              message,
              style: const TextStyle(
                fontSize: 12,
                color: AppColors.textPrimary,
                fontStyle: FontStyle.italic,
              ),
            ),
          ),
          const SizedBox(height: 12),

          if (incomingStatus.contains('PENDING'))
            // Accept / Reject Buttons
            Row(
              children: [
                Expanded(
                  child: SizedBox(
                    height: 36,
                    child: ElevatedButton(
                      onPressed: () => _acceptOrder(ref),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.success,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                      child: const Text('Accept', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: SizedBox(
                    height: 36,
                    child: OutlinedButton(
                      onPressed: () => _rejectOrder(ref),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: AppColors.danger,
                        side: const BorderSide(color: AppColors.danger),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                      child: const Text('Reject', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                    ),
                  ),
                ),
              ],
            ),
          else if (BookingCancel.canCancel(incomingStatus) && ref.isNotEmpty)
            SizedBox(
              width: double.infinity,
              height: 36,
              child: OutlinedButton(
                onPressed: () => _cancelBooking(ref, serviceTitle.toString(), incomingStatus),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.danger,
                  side: const BorderSide(color: AppColors.danger),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: Text(AppStrings.isEnglish ? 'Cancel Booking' : 'Ghairi Oda', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
              ),
            )
          else
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 8),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: incomingStatus.contains('CANCEL') || incomingStatus.contains('REJECT') ? const Color(0xFFFEF2F2) : AppColors.borderLight,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                incomingStatus.contains('CANCEL')
                    ? (AppStrings.isEnglish ? 'Cancelled' : 'Imeghairiwa')
                    : incomingStatus.contains('REJECT')
                        ? (AppStrings.isEnglish ? 'Rejected' : 'Imekataliwa')
                        : incomingStatus.contains('COMPLETE')
                            ? (AppStrings.isEnglish ? 'Completed' : 'Imekamilika')
                            : incomingStatus,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: incomingStatus.contains('CANCEL') || incomingStatus.contains('REJECT') ? AppColors.danger : AppColors.textSecondary,
                ),
              ),
            ),
        ],
      ),
    );
  }

  // SCREEN 3: Seller Outgoing Request Card (Matches Photo 3)
  Widget _buildSellerOutgoingCard(Map<String, dynamic> tx, int index) {
    final buyer = tx['buyer'] ?? {};
    final name = buyer['stageName'] ?? (index == 0 ? 'Asha W.' : (index == 1 ? 'Juma K.' : (index == 2 ? 'Fatuma S.' : 'Ali H.')));
    final serviceTitle = tx['serviceTitle'] ?? (index == 0 ? 'Massage Therapy' : (index == 1 ? 'Barber Shop' : (index == 2 ? 'Cleaning Services' : 'Electrical Repair')));
    final amount = (tx['amount'] as num?)?.toDouble() ?? (index == 0 ? 50000.0 : (index == 1 ? 30000.0 : 40000.0));
    final amountFormatted = 'TSh ${amount.toInt().toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]},')}';
    
    // Status badges matching Screen 3 (Pending, Accepted, Completed, Rejected)
    String statusLabel = 'Pending';
    Color statusBg = const Color(0xFFFFF7ED);
    Color statusColor = const Color(0xFFF97316);

    if (index == 1) {
      statusLabel = 'Accepted';
      statusBg = const Color(0xFFF0FDF4);
      statusColor = AppColors.success;
    } else if (index == 2) {
      statusLabel = 'Completed';
      statusBg = const Color(0xFFEFF6FF);
      statusColor = AppColors.primary;
    } else if (index == 3) {
      statusLabel = 'Rejected';
      statusBg = const Color(0xFFFEF2F2);
      statusColor = AppColors.danger;
    }

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                radius: 20,
                backgroundImage: AssetImage(index % 2 == 0 ? 'assets/images/zeen_avatar.jpg' : 'assets/images/provider2.jpg'),
                backgroundColor: AppColors.borderLight,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      serviceTitle,
                      style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '$amountFormatted • 60 min',
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Row(
                      children: const [
                        Icon(Icons.access_time_rounded, size: 12, color: AppColors.textMuted),
                        SizedBox(width: 2),
                        Text(
                          'Today, 10:00 AM',
                          style: TextStyle(fontSize: 11, color: AppColors.textMuted),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: statusBg,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  statusLabel,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: statusColor,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // View Details Single Full-Width Button matching Screen 3
          SizedBox(
            width: double.infinity,
            height: 36,
            child: OutlinedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => BookingDetailsScreen(
                      bookingData: {
                        'serviceTitle': serviceTitle,
                        'providerName': name,
                        'price': amountFormatted,
                        'status': statusLabel,
                        'image': index % 2 == 0 ? 'assets/images/banner.jpg' : 'assets/images/provider1.jpg',
                        'providerLat': buyer['latitude'] ?? tx['latitude'],
                        'providerLng': buyer['longitude'] ?? tx['longitude'],
                      },
                    ),
                  ),
                );
              },
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.primary,
                side: const BorderSide(color: AppColors.primary),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              ),
              child: const Text('View Details', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../widgets/app_ui.dart';
import 'permission_service.dart';

/// One place for "pick a photo" so every upload screen behaves the same:
///   1. ask camera or gallery,
///   2. ask for the OS permission (with a Settings shortcut if it was blocked),
///   3. open the picker, and report a readable error if it fails.
///
/// With [cameraOnly] the camera opens straight away (used for face checks).
///
/// Returns the chosen file, or null when the user cancelled or access was
/// refused (the explanation has already been shown in a snackbar).
///
/// Uploading is separate: pass the result's `path` to an `ApiService.upload...`
/// method, which shares one multipart/auth/error path as well.
class MediaPicker {
  MediaPicker._();

  static final ImagePicker _picker = ImagePicker();

  static Future<XFile?> pickImage(
    BuildContext context, {
    required String title,
    String? subtitle,
    double maxWidth = 1800,
    int imageQuality = 85,
    CameraDevice preferredCamera = CameraDevice.rear,
    bool cameraOnly = false,
    ImageSource? source,
  }) async {
    // [source] skips the chooser when the caller already asked (e.g. a full-page options screen).
    final preset = source;
    final en = AppStrings.isEnglish;

    // Face checks must be taken live, so they skip the gallery choice.
    final chosen = preset ?? (cameraOnly ? ImageSource.camera : await AppSheet.show<ImageSource>(
      context,
      title: title,
      subtitle: subtitle ?? (en ? 'Choose how to add the photo.' : 'Chagua njia ya kuongeza picha.'),
      builder: (ctx) => Column(
        children: [
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.photo_camera_outlined, color: AppColors.textPrimary),
            title: Text(en ? 'Take a photo' : 'Piga picha',
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
            onTap: () => Navigator.pop(ctx, ImageSource.camera),
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.photo_library_outlined, color: AppColors.textPrimary),
            title: Text(en ? 'Choose from gallery' : 'Chagua kwenye picha',
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
            onTap: () => Navigator.pop(ctx, ImageSource.gallery),
          ),
        ],
      ),
    ));
    if (chosen == null || !context.mounted) return null;
    final source0 = chosen;

    final messenger = ScaffoldMessenger.of(context);
    final camera = source0 == ImageSource.camera;
    final access = camera ? await MediaPermissions.camera() : await MediaPermissions.library();
    if (!context.mounted) return null;
    if (access != MediaAccess.granted) {
      messenger.showSnackBar(SnackBar(
        backgroundColor: AppColors.danger,
        content: Text(camera
            ? (en ? 'Allow camera access to take a photo.' : 'Ruhusu kamera ili kupiga picha.')
            : (en ? 'Allow photo access to choose a picture.' : 'Ruhusu picha ili kuchagua picha.')),
        action: access == MediaAccess.permanentlyDenied
            ? SnackBarAction(
                label: en ? 'Settings' : 'Mipangilio',
                textColor: Colors.white,
                onPressed: PermissionService.openSettings,
              )
            : null,
      ));
      return null;
    }

    try {
      return await _picker.pickImage(
        source: source0,
        maxWidth: maxWidth,
        imageQuality: imageQuality,
        preferredCameraDevice: preferredCamera,
      );
    } catch (_) {
      messenger.showSnackBar(SnackBar(
        backgroundColor: AppColors.danger,
        content: Text(en ? 'Could not open the camera or gallery.' : 'Imeshindwa kufungua kamera au picha.'),
      ));
      return null;
    }
  }
}

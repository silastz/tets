import 'dart:async';
import 'package:flutter/widgets.dart';
import '../services/attempt_limiter.dart';

/// Live "Resend (28s)" countdown for OTP screens.
/// Every code that is sent starts a wait: 30s, then 60s, then 120s for each further resend
/// (per phone/email), so a number cannot be flooded with SMS.
///
/// Use: `with ResendCountdown` on the State, call [startResend] after each code is sent,
/// [disposeResend] in dispose(), and show [resendLabel] on the button (disabled while [resendLeft] > 0).
mixin ResendCountdown<T extends StatefulWidget> on State<T> {
  Timer? _resendTimer;
  String _resendContact = '';
  final Map<String, int> _resendSends = {};

  /// Seconds left before another code may be requested (0 = allowed now).
  int resendLeft = 0;

  /// Starts the wait for [contact] after a code was actually sent.
  void startResend(String contact) {
    final n = _resendSends[contact] ?? 0;
    _resendSends[contact] = n + 1;
    final seconds = 30 * (1 << (n > 2 ? 2 : n)); // 30, 60, 120, 120...
    AttemptLimiter.startCooldown('resend:$contact', seconds: seconds);
    watchResend(contact);
  }

  /// Follow the cool-down of [contact] (also use when a screen is re-opened).
  void watchResend(String contact) {
    _resendContact = contact;
    _resendTimer?.cancel();
    _syncResend();
    if (resendLeft > 0) {
      _resendTimer = Timer.periodic(const Duration(seconds: 1), (t) {
        if (!mounted) {
          t.cancel();
          return;
        }
        _syncResend();
        if (resendLeft <= 0) t.cancel();
      });
    }
  }

  void _syncResend() {
    final left = AttemptLimiter.cooldownLeft('resend:$_resendContact');
    if (!mounted) return;
    if (left != resendLeft) setState(() => resendLeft = left);
  }

  String resendLabel(String base) => resendLeft > 0 ? '$base (${resendLeft}s)' : base;

  void disposeResend() => _resendTimer?.cancel();
}

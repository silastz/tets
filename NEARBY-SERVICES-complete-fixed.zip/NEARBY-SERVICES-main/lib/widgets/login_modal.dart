import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../security/password_policy.dart';
import '../security/input_validation.dart';
import '../services/api_service.dart';
import '../services/attempt_limiter.dart';
import '../services/location_service.dart';
import '../services/session_manager.dart';
import '../screens/register_provider_screen.dart';
import 'app_ui.dart' show LoadingTextButton;
import 'resend_countdown.dart';

class LoginModal extends StatefulWidget {
  final VoidCallback? onLoginSuccess;
  final String? initialPhone;

  const LoginModal({super.key, this.onLoginSuccess, this.initialPhone});

  static Future<bool?> show(
    BuildContext context, {
    VoidCallback? onLoginSuccess,
    String? initialPhone,
  }) {
    return showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => LoginModal(
        onLoginSuccess: onLoginSuccess,
        initialPhone: initialPhone,
      ),
    );
  }

  @override
  State<LoginModal> createState() => _LoginModalState();
}

class _LoginModalState extends State<LoginModal> with ResendCountdown<LoginModal> {
  bool _isSignUpMode = false;
  bool _isLoading = false;
  bool _resending = false; // spinner on the Resend button only
  String? _errorMessage;

  // Controllers
  final _identifierController = TextEditingController(); // Phone or Email
  final _passwordController = TextEditingController();
  final _fullNameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _emailController = TextEditingController();
  final _otpController = TextEditingController();
  final _resetNewPasswordController = TextEditingController();

  final bool _isSeller = false;
  bool _awaitingOtp = false;
  bool _isPhoneOtp = true;
  String _registeredContact = '';
  Map<String, dynamic>? _pendingAuthData;

  // Forgot password flow states
  bool _isForgotPasswordMode = false;
  bool _awaitingResetOtp = false;

  // Password visibility toggles
  bool _obscurePassword = true;
  bool _obscureResetPassword = true;

  // No country picker in the UI: the code comes from the country detected when the app
  // launched (Tanzania +255 by default, Kenya +254 in Kenya, ...). The list below is also
  // used to recognise a code the user types themselves.
  String get _selectedCountryCode => LocationService.dialCode;
  final List<Map<String, String>> _countryCodes = [
    {'code': '+255', 'country': 'Tanzania', 'flag': '🇹🇿'},
    {'code': '+254', 'country': 'Kenya', 'flag': '🇰🇪'},
    {'code': '+256', 'country': 'Uganda', 'flag': '🇺🇬'},
    {'code': '+250', 'country': 'Rwanda', 'flag': '🇷🇼'},
    {'code': '+257', 'country': 'Burundi', 'flag': '🇧🇮'},
    {'code': '+243', 'country': 'DRC', 'flag': '🇨🇩'},
  ];

  @override
  void initState() {
    super.initState();
    if (widget.initialPhone != null && widget.initialPhone!.isNotEmpty) {
      _identifierController.text = widget.initialPhone!;
      _phoneController.text = widget.initialPhone!;
    }
    _phoneController.addListener(_validateFormSilently);
    _fullNameController.addListener(_validateFormSilently);
    _passwordController.addListener(_validateFormSilently);
    _identifierController.addListener(_validateFormSilently);
  }

  void _validateFormSilently() {
    if (_errorMessage != null) {
      setState(() => _errorMessage = null);
    }
  }

  String _cleanFormattedPhoneNumber(String input) {
    String clean = input.replaceAll(RegExp(r'\D'), '');
    if (input.trim().startsWith('+')) {
      return '+$clean';
    }
    // Check if user already typed an international code (e.g. 254 for Kenya, 256 Uganda, 255 Tanzania, 250 Rwanda, etc.)
    for (final item in _countryCodes) {
      final codeDigits = item['code']!.replaceAll(RegExp(r'\D'), '');
      if (clean.startsWith(codeDigits)) {
        return '+$clean';
      }
    }
    if (clean.startsWith('0')) {
      clean = clean.substring(1);
    }
    return '$_selectedCountryCode$clean';
  }

  @override
  void dispose() {
    disposeResend();
    _phoneController.removeListener(_validateFormSilently);
    _fullNameController.removeListener(_validateFormSilently);
    _passwordController.removeListener(_validateFormSilently);
    _identifierController.removeListener(_validateFormSilently);
    _identifierController.dispose();
    _passwordController.dispose();
    _fullNameController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    _otpController.dispose();
    _resetNewPasswordController.dispose();
    super.dispose();
  }

  /// Returns true (and shows the wait time) when [key] is temporarily locked.
  bool _blockedByLimiter(String key) {
    final wait = AttemptLimiter.secondsLocked(key);
    if (wait > 0) {
      setState(() => _errorMessage = '${AppStrings.authTooManyAttempts} ${wait}s');
      return true;
    }
    return false;
  }

  /// A real answer from the server (right OR wrong) vs. no answer (offline / 5xx / 429).
  /// Only real wrong answers may count toward a lock-out.
  bool get _gotRealAnswer => ApiService.lastAuthProblem == null;

  void _snack(String text, {Color? color}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(backgroundColor: color ?? AppColors.primary, content: Text(text)),
    );
  }

  Future<void> _submitOtp() async {
    final otp = _otpController.text.trim();
    if (otp.length != 6) {
      setState(() => _errorMessage = AppStrings.authOtpHint);
      return;
    }

    final otpKey = 'otp:$_registeredContact';
    if (_blockedByLimiter(otpKey)) return;

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    Map<String, dynamic>? phoneVerifyResult;
    bool emailSuccess = false;

    if (_isPhoneOtp) {
      phoneVerifyResult = await ApiService.verifyPhoneOtp(_registeredContact, otp);
    } else {
      emailSuccess = await ApiService.verifyEmailOtp(_registeredContact, otp);
    }
    if (!mounted) return;
    setState(() => _isLoading = false);

    final bool isVerified = _isPhoneOtp ? (phoneVerifyResult != null) : emailSuccess;

    if (!isVerified && !_gotRealAnswer) {
      // Offline / server busy: tell the truth and do NOT count it as a wrong code.
      setState(() => _errorMessage = ApiService.authProblemMessage());
      return;
    }

    if (isVerified) {
      AttemptLimiter.recordSuccess(otpKey);
    } else {
      AttemptLimiter.recordFailure(otpKey);
    }

    if (isVerified) {
      // Session issued strictly by backend upon successful OTP verification
      final authData = (_isPhoneOtp && phoneVerifyResult?['data'] is Map)
          ? Map<String, dynamic>.from(phoneVerifyResult!['data'] as Map)
          : _pendingAuthData;

      final token = authData?['token'];
      if (authData != null && token is String && token.isNotEmpty) {
        final idRaw = authData['id'];
        await SessionManager.saveSession(
          token: token,
          userId: idRaw is int ? idRaw : (int.tryParse('${idRaw ?? ''}') ?? 0),
          username: (authData['username'] ?? '').toString(),
          stageName: (authData['stageName'] ?? '').toString(),
          role: (authData['role'] ?? (_isSeller ? 'ROLE_SELLER' : 'ROLE_BUYER')).toString(),
          badge: (authData['verificationBadge'] ?? 'NONE').toString(),
        );
      }
      _pendingAuthData = null; // do not keep the token in memory after use

      if (mounted) {
        Navigator.pop(context, true);
        widget.onLoginSuccess?.call();
        _snack(AppStrings.authRegisterSuccess, color: AppColors.success);
      }
    } else {
      setState(() => _errorMessage = AppStrings.authInvalidOtpError);
    }
  }

  Future<void> _resendOtp() async {
    final cdKey = 'resend:$_registeredContact';
    final wait = AttemptLimiter.cooldownLeft(cdKey);
    if (wait > 0) {
      setState(() => _errorMessage = '${AppStrings.authTooManyAttempts} ${wait}s');
      return;
    }
    setState(() {
      _resending = true;
      _errorMessage = null;
    });

    if (_isForgotPasswordMode) {
      final res = await ApiService.forgotPassword(_registeredContact);
      if (!mounted) return;
      setState(() => _resending = false);
      if (res['success'] == true) {
        startResend(_registeredContact);
        _snack('${AppStrings.authResetIfExists} $_registeredContact');
      } else {
        setState(() => _errorMessage = res['message']?.toString() ?? AppStrings.error);
      }
      return;
    }

    final sent = _isPhoneOtp
        ? await ApiService.resendPhoneOtp(_registeredContact)
        : await ApiService.resendEmailOtp(_registeredContact);

    if (!mounted) return;
    setState(() => _resending = false);
    if (sent) {
      startResend(_registeredContact);
      _snack('${AppStrings.authOtpSentSubtitle} $_registeredContact');
    } else {
      setState(() => _errorMessage =
          _gotRealAnswer ? AppStrings.error : ApiService.authProblemMessage());
    }
  }

  Future<void> _submitForgotPasswordRequest() async {
    final identifier = _identifierController.text.trim();
    if (identifier.isEmpty) {
      setState(() => _errorMessage = AppStrings.authPhoneLabel);
      return;
    }

    String cleanIdentifier = identifier;
    if (RegExp(r'^[0-9+ ]+$').hasMatch(identifier)) {
      cleanIdentifier = _cleanFormattedPhoneNumber(identifier);
    }

    // Wait between code requests (starts only after a request really went out).
    final forgotKey = 'forgot:$cleanIdentifier';
    final forgotWait = AttemptLimiter.cooldownLeft(forgotKey);
    if (forgotWait > 0) {
      setState(() => _errorMessage = '${AppStrings.authTooManyAttempts} ${forgotWait}s');
      return;
    }

    setState(() => _isLoading = true);
    final res = await ApiService.forgotPassword(cleanIdentifier);
    if (!mounted) return;
    setState(() => _isLoading = false);

    if (res['success'] == true) {
      AttemptLimiter.startCooldown(forgotKey);
      // Same screen and same message whether the account exists or not (no account enumeration).
      setState(() {
        _awaitingResetOtp = true;
        _registeredContact = cleanIdentifier;
        _errorMessage = null;
        _otpController.clear();
        _resetNewPasswordController.clear();
      });
      startResend(cleanIdentifier);
      _snack('${AppStrings.authResetIfExists} $cleanIdentifier');
    } else {
      setState(() => _errorMessage = res['message']?.toString() ?? AppStrings.error);
    }
  }

  Future<void> _submitResetPassword() async {
    final otp = _otpController.text.trim();
    final newPassword = _resetNewPasswordController.text.trim();

    if (otp.length != 6) {
      setState(() => _errorMessage = AppStrings.authOtpHint);
      return;
    }
    final weak = PasswordPolicy.validate(newPassword, phoneOrId: _registeredContact);
    if (weak != null) {
      setState(() => _errorMessage = weak);
      return;
    }

    final resetKey = 'reset:$_registeredContact';
    if (_blockedByLimiter(resetKey)) return;

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    final res = await ApiService.resetPassword(_registeredContact, otp, newPassword);
    if (!mounted) return;
    setState(() => _isLoading = false);

    if (res['success'] == true) {
      AttemptLimiter.recordSuccess(resetKey);
      _snack(AppStrings.authResetSuccess, color: AppColors.success);
      final contact = _registeredContact;
      setState(() {
        _isForgotPasswordMode = false;
        _awaitingResetOtp = false;
        // Never copy the new password into the login box: the user types it once more.
        _identifierController.text = contact;
        _passwordController.clear();
        _otpController.clear();
        _resetNewPasswordController.clear();
        _errorMessage = null;
      });
    } else {
      if (_gotRealAnswer) AttemptLimiter.recordFailure(resetKey);
      setState(() => _errorMessage = res['message']?.toString() ?? AppStrings.authInvalidOtpError);
    }
  }

  Future<void> _submit() async {
    if (_isLoading) return; // ignore double taps / Enter while a request runs
    setState(() => _errorMessage = null);

    if (_isForgotPasswordMode) {
      if (_awaitingResetOtp) {
        return _submitResetPassword();
      } else {
        return _submitForgotPasswordRequest();
      }
    }

    if (_awaitingOtp) {
      return _submitOtp();
    }

    if (_isSignUpMode) {
      final name = InputValidation.cleanText(_fullNameController.text);
      final phone = _phoneController.text.trim();
      final email = InputValidation.normalizeEmail(_emailController.text);
      final password = _passwordController.text; // not trimmed: edge spaces are rejected below

      if (name.isEmpty || phone.isEmpty || password.isEmpty) {
        setState(() => _errorMessage = '${AppStrings.authFullNameLabel}, ${AppStrings.authPhoneLabel}');
        return;
      }
      final nameErr = InputValidation.name(name);
      if (nameErr != null) {
        setState(() => _errorMessage = nameErr);
        return;
      }
      // Brake on repeated failed sign-up attempts from this device (spam / probing).
      const regKey = 'register:device';
      final regWait = AttemptLimiter.secondsLocked(regKey);
      if (regWait > 0) {
        setState(() => _errorMessage = '${AppStrings.authTooManyAttempts} ${regWait}s');
        return;
      }
      final formattedForCheck = _cleanFormattedPhoneNumber(phone);
      final codeDigits = _countryCodes
          .map((c) => c['code']!)
          .firstWhere((c) => formattedForCheck.startsWith(c), orElse: () => '');
      final nine = codeDigits == '+255' || codeDigits == '+254'; // TZ / KE: 9 digits after the code
      final localDigits = formattedForCheck.replaceAll(RegExp(r'\D'), '').length - codeDigits.replaceAll(RegExp(r'\D'), '').length;
      if (nine ? localDigits != 9 : (localDigits < 8 || localDigits > 15)) {
        setState(() => _errorMessage = AppStrings.authInvalidPhoneError);
        return;
      }
      final phoneErr = InputValidation.phoneE164(formattedForCheck);
      if (phoneErr != null) {
        setState(() => _errorMessage = phoneErr);
        return;
      }
      final emailErr = InputValidation.emailOptional(email);
      if (emailErr != null) {
        setState(() => _errorMessage = emailErr);
        return;
      }
      final shapeErr = InputValidation.passwordShape(password);
      if (shapeErr != null) {
        setState(() => _errorMessage = shapeErr);
        return;
      }
      final weak = PasswordPolicy.validate(password, phoneOrId: formattedForCheck);
      if (weak != null) {
        setState(() => _errorMessage = weak);
        return;
      }

      setState(() => _isLoading = true);
      final formattedPhone = _cleanFormattedPhoneNumber(phone);
      final cleanDigits = formattedPhone.replaceAll(RegExp(r'\D'), '');
      // Generate clean unique username so phone collision reports true phone error, not username conflict
      final uniqueUsername = 'u_${cleanDigits.length >= 9 ? cleanDigits.substring(cleanDigits.length - 9) : cleanDigits}';

      final res = await ApiService.register(
        username: uniqueUsername,
        phone: formattedPhone,
        email: email.isNotEmpty ? email : null,
        password: password,
        stageName: name,
        role: _isSeller ? 'ROLE_SELLER' : 'ROLE_BUYER',
      );

      if (!mounted) return;
      setState(() => _isLoading = false);

      if (res != null && res['success'] == true) {
        AttemptLimiter.recordSuccess(regKey);
        setState(() {
          _awaitingOtp = true;
          _isPhoneOtp = true;
          _registeredContact = formattedPhone;
          _pendingAuthData = res['data'] is Map ? Map<String, dynamic>.from(res['data'] as Map) : null;
          _errorMessage = null;
        });
        startResend(formattedPhone); // SMS was just sent: count down before "Resend" unlocks
      } else {
        // Offline / server busy is not the user's fault: only real rejections count.
        if (res?['problem'] == null) AttemptLimiter.recordFailure(regKey);
        setState(() => _errorMessage = InputValidation.safeServerMessage(res?['error']));
      }
    } else {
      // Login mode
      final identifier = _identifierController.text.trim();
      final password = _passwordController.text.trim();

      if (identifier.isEmpty || password.isEmpty) {
        setState(() => _errorMessage = '${AppStrings.authPhoneLabel} / ${AppStrings.authPasswordLabel}');
        return;
      }

      // If identifier looks like a phone number, normalize it with country code
      String cleanIdentifier = identifier;
      if (RegExp(r'^[0-9+]+$').hasMatch(identifier.replaceAll(' ', ''))) {
        cleanIdentifier = _cleanFormattedPhoneNumber(identifier);
      }
      final loginKey = 'login:${cleanIdentifier.toLowerCase()}';
      if (_blockedByLimiter(loginKey)) return;

      setState(() => _isLoading = true);
      final res = await ApiService.login(cleanIdentifier, password);
      if (!mounted) return;
      setState(() => _isLoading = false);

      final ok = res != null && res['success'] == true;
      final rawCode = res?['rawCode'] ?? '';
      final isUnverified = rawCode == 'ACCOUNT_NOT_VERIFIED';
      if (ok) {
        AttemptLimiter.recordSuccess(loginKey);
      } else if (_gotRealAnswer && !isUnverified) {
        // Only a genuine "wrong login" counts - never a dropped connection or a busy server.
        AttemptLimiter.recordFailure(loginKey);
      }

      if (ok) {
        _passwordController.clear();
        Navigator.pop(context, true);
        widget.onLoginSuccess?.call();
        _snack('${AppStrings.authLoginSuccess}${SessionManager.getStageName()}!', color: AppColors.success);
        return;
      }

      if (isUnverified) {
        // Unverified account: send OTP automatically and take them straight to verification!
        final isPhone = RegExp(r'^[0-9+]+$').hasMatch(cleanIdentifier.replaceAll(' ', ''));
        setState(() {
          _isLoading = true;
          _errorMessage = null;
        });

        final sent = isPhone
            ? await ApiService.resendPhoneOtp(cleanIdentifier)
            : await ApiService.resendEmailOtp(cleanIdentifier);
        if (!mounted) return;

        setState(() {
          _isLoading = false;
          if (sent || _gotRealAnswer) {
            _awaitingOtp = true;
            _isPhoneOtp = isPhone;
            _registeredContact = cleanIdentifier;
            _errorMessage = null;
            _otpController.clear();
          } else {
            _errorMessage = ApiService.authProblemMessage();
          }
        });
        if (sent) {
          startResend(cleanIdentifier);
          _snack(isPhone
              ? '${AppStrings.authPhoneOtpSentSubtitle} $cleanIdentifier'
              : '${AppStrings.authOtpSentSubtitle} $cleanIdentifier');
        }
        return;
      }

      final serverErr = res?['error'];
      setState(() => _errorMessage = serverErr != null
          ? (serverErr is String ? serverErr : '$serverErr')
          : AppStrings.error);
    }
  }

  /// True when the modal is on an inner step (sign-up, OTP, forgot/reset password),
  /// so system back / swipe-back must step back instead of dismissing the sheet.
  bool get _canDismissDirectly =>
      !_isSignUpMode && !_awaitingOtp && !_isForgotPasswordMode && !_awaitingResetOtp;

  /// Goes back exactly one step. Returns true if a step was consumed.
  bool _goBackOneStep() {
    if (_isLoading) return true; // swallow back while a request is running
    if (_isForgotPasswordMode) {
      setState(() {
        if (_awaitingResetOtp) {
          // Reset form -> back to "enter phone/email"
          _awaitingResetOtp = false;
          _otpController.clear();
          _resetNewPasswordController.clear();
        } else {
          // Forgot password -> back to login
          _isForgotPasswordMode = false;
        }
        _errorMessage = null;
      });
      return true;
    }
    if (_awaitingOtp) {
      // OTP -> back to whichever form led here (sign-up or login)
      setState(() {
        _awaitingOtp = false;
        _otpController.clear();
        _errorMessage = null;
      });
      return true;
    }
    if (_isSignUpMode) {
      // Create account -> back to login
      setState(() {
        _isSignUpMode = false;
        _errorMessage = null;
      });
      return true;
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: _canDismissDirectly && !_isLoading,
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) return;
        _goBackOneStep();
      },
      child: _buildSheet(context),
    );
  }

  Widget _buildSheet(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        top: 20,
        left: 20,
        right: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      decoration: const BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Drag handle
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: AppColors.border,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                if (!_canDismissDirectly)
                  IconButton(
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
                    icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18, color: AppColors.textPrimary),
                    onPressed: _isLoading ? null : _goBackOneStep,
                  ),
                Expanded(
                  child: Text(
                    _isForgotPasswordMode
                        ? (_awaitingResetOtp ? AppStrings.authResetPasswordTitle : AppStrings.authForgotPasswordTitle)
                        : (_isSignUpMode ? AppStrings.authCreateAccount : AppStrings.authWelcomeBack),
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close_rounded, size: 20, color: AppColors.textSecondary),
                  onPressed: () => Navigator.pop(context, false),
                ),
              ],
            ),
            Text(
              _isForgotPasswordMode
                  ? (_awaitingResetOtp
                      ? '${AppStrings.authOtpSentSubtitle} $_registeredContact'
                      : AppStrings.authForgotPasswordSubtitle)
                  : (_isSignUpMode
                      ? AppStrings.authCreateSubtitle
                      : AppStrings.authWelcomeSubtitle),
              style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
            ),
            const SizedBox(height: 20),

            if (_isForgotPasswordMode && _awaitingResetOtp) ...[
              // Reset Password step: enter OTP and new password
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.primaryLight,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.primary.withValues(alpha: 0.3)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(
                          Icons.lock_reset_rounded,
                          color: AppColors.primary,
                          size: 22,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          AppStrings.authResetPasswordTitle,
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: AppColors.primary),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '${AppStrings.authOtpSentSubtitle} $_registeredContact',
                      style: const TextStyle(fontSize: 12, color: AppColors.textPrimary),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              _buildInputField(
                controller: _otpController,
                hint: AppStrings.authOtpHint,
                icon: Icons.key_outlined,
                keyboardType: TextInputType.number,
                isOtp: true,
              ),
              const SizedBox(height: 12),
              _buildInputField(
                controller: _resetNewPasswordController,
                hint: AppStrings.authNewPasswordLabel,
                icon: Icons.lock_outline_rounded,
                obscureText: _obscureResetPassword,
                isNewPassword: true,
                suffixIcon: IconButton(
                  icon: Icon(
                    _obscureResetPassword ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                    color: AppColors.textSecondary,
                    size: 20,
                  ),
                  onPressed: () => setState(() => _obscureResetPassword = !_obscureResetPassword),
                ),
              ),
              const SizedBox(height: 10),
              Align(
                alignment: Alignment.centerRight,
                child: LoadingTextButton(
                  label: resendLabel(AppStrings.authResendOtp),
                  loading: _resending,
                  onPressed: (_isLoading || resendLeft > 0) ? null : _resendOtp,
                ),
              ),
            ] else if (_isForgotPasswordMode) ...[
              // Step 1: Identifier entry for forgot password
              _buildSmartLoginIdentifierField(),
            ] else if (_awaitingOtp) ...[
              // OTP Verification step
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.successLight,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.success.withValues(alpha: 0.3)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          _isPhoneOtp ? Icons.sms_outlined : Icons.mark_email_read_outlined,
                          color: AppColors.successDark,
                          size: 22,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          _isPhoneOtp
                              ? AppStrings.authVerifyPhoneOtpTitle
                              : AppStrings.authVerifyOtpTitle,
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: AppColors.successDark),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      _isPhoneOtp
                          ? '${AppStrings.authPhoneOtpSentSubtitle} $_registeredContact'
                          : '${AppStrings.authOtpSentSubtitle} $_registeredContact',
                      style: const TextStyle(fontSize: 12, color: AppColors.textPrimary),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              _buildInputField(
                controller: _otpController,
                hint: AppStrings.authOtpHint,
                icon: Icons.key_outlined,
                keyboardType: TextInputType.number,
                isOtp: true,
              ),
              const SizedBox(height: 10),
              Align(
                alignment: Alignment.centerRight,
                child: LoadingTextButton(
                  label: resendLabel(AppStrings.authResendOtp),
                  loading: _resending,
                  onPressed: (_isLoading || resendLeft > 0) ? null : _resendOtp,
                ),
              ),
            ] else if (_isSignUpMode) ...[
              // Full Name / Stage Name
              _buildInputField(
                controller: _fullNameController,
                hint: AppStrings.authFullNameHint,
                icon: Icons.person_outline_rounded,
                keyboardType: TextInputType.name,
              ),
              const SizedBox(height: 12),

              // Phone Number with Country Code Dropdown
              _buildPhoneInputField(),
              const SizedBox(height: 12),

              // Optional Email
              _buildInputField(
                controller: _emailController,
                hint: AppStrings.authEmailHint,
                icon: Icons.mail_outline_rounded,
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 12),

              // Provider Switch / Registration Link
              InkWell(
                onTap: () async {
                  // Keep the modal open underneath: back from the registration
                  // screen returns to this create-account step instead of closing it.
                  final registered = await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const RegisterProviderScreen(isUpgradeFromBuyer: false),
                    ),
                  );
                  if (registered == true) {
                    if (!context.mounted) return;
                    Navigator.pop(context, true);
                    widget.onLoginSuccess?.call();
                  }
                },
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: AppColors.primaryLight,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.primary.withValues(alpha: 0.3)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.storefront_rounded, size: 20, color: AppColors.primary),
                          const SizedBox(width: 10),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                AppStrings.authSellerAccountSwitch,
                                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.primaryDark),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                'Fungua fomu kamili ya usajili wa biashara (Hatua 4)',
                                style: TextStyle(fontSize: 10, color: AppColors.primaryDark.withValues(alpha: 0.8)),
                              ),
                            ],
                          ),
                        ],
                      ),
                      const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: AppColors.primary),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),

              // Password Field
              _buildInputField(
                controller: _passwordController,
                hint: AppStrings.authPasswordLabel,
                icon: Icons.lock_outline_rounded,
                obscureText: _obscurePassword,
                isNewPassword: true,
                suffixIcon: IconButton(
                  icon: Icon(
                    _obscurePassword ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                    color: AppColors.textSecondary,
                    size: 20,
                  ),
                  onPressed: () => setState(() => _obscurePassword = !_obscurePassword),
                ),
              ),
            ] else ...[
              // Login: Smart Identifier (Phone, Email, or Username)
              _buildSmartLoginIdentifierField(),
              const SizedBox(height: 12),

              // Password Field
              _buildInputField(
                controller: _passwordController,
                hint: AppStrings.authPasswordLabel,
                icon: Icons.lock_outline_rounded,
                obscureText: _obscurePassword,
                suffixIcon: IconButton(
                  icon: Icon(
                    _obscurePassword ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                    color: AppColors.textSecondary,
                    size: 20,
                  ),
                  onPressed: () => setState(() => _obscurePassword = !_obscurePassword),
                ),
              ),
              const SizedBox(height: 8),

              // Forgot Password link
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  style: TextButton.styleFrom(
                    padding: EdgeInsets.zero,
                    minimumSize: Size.zero,
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                  onPressed: () {
                    setState(() {
                      _isForgotPasswordMode = true;
                      _awaitingResetOtp = false;
                      _errorMessage = null;
                    });
                  },
                  child: Text(
                    AppStrings.authForgotPasswordLink,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: AppColors.primary,
                    ),
                  ),
                ),
              ),
            ],

            if (_errorMessage != null) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: AppColors.dangerLight,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppColors.danger.withValues(alpha: 0.3)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.error_outline_rounded, size: 16, color: AppColors.danger),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        _errorMessage!,
                        style: const TextStyle(fontSize: 12, color: AppColors.danger, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
              ),
            ],

            const SizedBox(height: 20),

            // Submit Button
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _submit,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: _isLoading
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                      )
                    : Text(
                        _isForgotPasswordMode
                            ? (_awaitingResetOtp
                                ? AppStrings.authResetPasswordButton
                                : AppStrings.authSendResetCodeButton)
                            : (_awaitingOtp
                                ? AppStrings.authVerifyButton
                                : (_isSignUpMode ? AppStrings.authRegisterButton : AppStrings.authSignInButton)),
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: Colors.white),
                      ),
              ),
            ),
            const SizedBox(height: 14),

            if (_isForgotPasswordMode)
              Center(
                child: TextButton(
                  onPressed: () {
                    setState(() {
                      _isForgotPasswordMode = false;
                      _awaitingResetOtp = false;
                      _otpController.clear();
                      _resetNewPasswordController.clear();
                      _errorMessage = null;
                    });
                  },
                  child: Text(
                    AppStrings.authBackToLogin,
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: AppColors.primary,
                    ),
                  ),
                ),
              )
            else if (!_awaitingOtp)
              Center(
                child: TextButton(
                  onPressed: () {
                    setState(() {
                      _isSignUpMode = !_isSignUpMode;
                      _errorMessage = null;
                    });
                  },
                  child: Text(
                    _isSignUpMode
                        ? '${AppStrings.authLoginTab}?'
                        : '${AppStrings.authCreateAccount}?',
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: AppColors.primary,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    bool obscureText = false,
    TextInputType keyboardType = TextInputType.text,
    Widget? suffixIcon,
    bool isOtp = false,
    bool isNewPassword = false,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: AppColors.background,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: TextField(
        controller: controller,
        obscureText: obscureText,
        keyboardType: keyboardType,
        // Secrets: no keyboard learning / suggestions; OTP: digits only, 6 max, SMS auto-fill.
        enableSuggestions: !obscureText && !isOtp,
        autocorrect: !obscureText && !isOtp,
        enableInteractiveSelection: !obscureText,
        autofillHints: isOtp
            ? const [AutofillHints.oneTimeCode]
            : obscureText
                ? (isNewPassword ? const [AutofillHints.newPassword] : const [AutofillHints.password])
                : null,
        inputFormatters: isOtp
            ? [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(InputValidation.otpLength)]
            : [
                // Hard length caps stop huge pastes; login keeps a roomy cap so older passwords still work.
                LengthLimitingTextInputFormatter(
                  obscureText ? (isNewPassword ? InputValidation.passwordMax : 128) : InputValidation.emailMax,
                ),
              ],
        decoration: InputDecoration(
          icon: Icon(icon, color: AppColors.textMuted, size: 20),
          suffixIcon: suffixIcon,
          hintText: hint,
          hintStyle: const TextStyle(fontSize: 13, color: AppColors.textMuted),
          border: InputBorder.none,
        ),
      ),
    );
  }

  Widget _buildPhoneInputField() {
    final field = Container(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: AppColors.background,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          const Icon(Icons.phone_outlined, color: AppColors.textMuted, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: TextField(
              controller: _phoneController,
              keyboardType: TextInputType.phone,
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r'[0-9+ ]')),
                LengthLimitingTextInputFormatter(18),
              ],
              decoration: const InputDecoration(
                hintText: '0678 364 343',
                hintStyle: TextStyle(fontSize: 13, color: AppColors.textMuted),
                border: InputBorder.none,
              ),
            ),
          ),
        ],
      ),
    );

    return ValueListenableBuilder<String>(
      valueListenable: LocationService.dialCodeNotifier,
      builder: (context, code, _) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          field,
          Padding(
            padding: const EdgeInsets.only(left: 4, top: 4),
            child: Text(
              AppStrings.isEnglish
                  ? '$code (${LocationService.countryName}) is added automatically'
                  : '$code (${LocationService.countryName}) huwekwa yenyewe',
              style: const TextStyle(fontSize: 11, color: AppColors.textMuted),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSmartLoginIdentifierField() {
    final text = _identifierController.text.trim();
    final isEmail = text.contains('@');
    final isDigitsOnly = text.isNotEmpty && RegExp(r'^[0-9+ ]+$').hasMatch(text);

    IconData leadingIcon = Icons.account_circle_outlined;
    if (isEmail) {
      leadingIcon = Icons.mail_outline_rounded;
    } else if (isDigitsOnly) {
      leadingIcon = Icons.phone_outlined;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: AppColors.background,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Icon(leadingIcon, color: AppColors.textMuted, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: TextField(
              controller: _identifierController,
              keyboardType: TextInputType.emailAddress,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(
                hintText: 'Namba ya Simu, Barua Pepe au Jina',
                hintStyle: TextStyle(fontSize: 13, color: AppColors.textMuted),
                border: InputBorder.none,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

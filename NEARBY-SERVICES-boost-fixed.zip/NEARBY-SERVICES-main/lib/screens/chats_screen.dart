import 'package:flutter/material.dart';
import '../services/block_service.dart';
import '../services/chat_prefs.dart';
import '../widgets/verification_badge.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import '../services/session_manager.dart';
import '../widgets/guest_state_placeholder.dart';
import 'chat_thread_screen.dart';
import '../services/data_sync.dart';
import '../widgets/online_indicator.dart';

class ChatsScreen extends StatefulWidget {
  const ChatsScreen({super.key});

  @override
  State<ChatsScreen> createState() => _ChatsScreenState();
}

class _ChatsScreenState extends State<ChatsScreen> {
  String _activeTab = 'All'; // 'All', 'Bookings', 'Requests'
  bool _isLoading = false;

  List<ChatMessage> _chats = [];

  final List<ChatMessage> _defaultChats = [
    ChatMessage(
      id: 'c1',
      senderName: 'Zeen Spa & Wellness',
      lastMessage: 'Your booking is confirmed...',
      timestamp: '10:24 AM',
      unreadCount: 1,
      isVerified: true,
    ),
    ChatMessage(
      id: 'c2',
      senderName: 'Juma Barber',
      lastMessage: 'Okay, see you tomorrow...',
      timestamp: 'Yesterday',
      unreadCount: 0,
      isVerified: true,
    ),
    ChatMessage(
      id: 'c3',
      senderName: 'CleanPro Services',
      lastMessage: '📷 Image',
      timestamp: 'Yesterday',
      unreadCount: 0,
      isVerified: true,
    ),
  ];

  // Something was written to the server elsewhere (booking, accept, wallet, review...): re-fetch.
  void _onDataChanged() {
    if (mounted) _loadLiveConversations();
  }

  // Mute marks only change what is drawn, no need to re-fetch.
  void _onPrefsChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    DataSync.changed.removeListener(_onDataChanged);
    BlockService.changed.removeListener(_onDataChanged);
    ChatPrefs.changed.removeListener(_onPrefsChanged);
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    DataSync.changed.addListener(_onDataChanged);
    BlockService.changed.addListener(_onDataChanged);
    ChatPrefs.changed.addListener(_onPrefsChanged);
    _chats = List.from(_defaultChats);
    _loadLiveConversations();
  }

  Future<void> _loadLiveConversations() async {
    if (!SessionManager.isLoggedIn()) return;
    setState(() => _isLoading = true);
    final convs = await ApiService.fetchConversations();
    if (mounted) {
      if (convs.isNotEmpty) {
        final liveList = convs.map((item) {
          final otherUser = item['recipient'] ?? item['sender'] ?? {};
          final name = otherUser['stageName'] ?? otherUser['username'] ?? 'User';
          return ChatMessage(
            id: (item['id'] ?? item['conversationId'] ?? '').toString(),
            otherUserId: (otherUser['id'] ?? item['otherUserId'])?.toString(),
            isOnline: ApiService.parseOnline(otherUser['isOnline'] ?? otherUser['online'] ?? item['isOnline']),
            senderName: name,
            lastMessage: ApiService.chatPreview((item['lastMessage'] ?? item['content'] ?? 'Chat started').toString()),
            timestamp: (item['time'] ?? 'Recent').toString(),
            unreadCount: (item['unreadCount'] as num?)?.toInt() ?? 0,
            isVerified: true,
          );
        }).where((c) => !BlockService.isBlocked(int.tryParse(c.otherUserId ?? ''))).toList();
        setState(() {
          _chats = liveList;
          _isLoading = false;
        });
      } else {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppLanguage>(
      valueListenable: AppStrings.currentLanguage,
      builder: (context, _, _) {
        return Scaffold(
          backgroundColor: AppColors.background,
          appBar: AppBar(
            backgroundColor: AppColors.surface,
            elevation: 0,
        title: Text(
          AppStrings.chatsTitle,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.border, height: 1),
        ),
      ),
      body: ValueListenableBuilder<int>(
        valueListenable: SessionManager.sessionNotifier,
        builder: (context, _, _) {
          if (!SessionManager.isLoggedIn()) {
            return GuestStatePlaceholder(
              icon: Icons.chat_bubble_outline_rounded,
              title: AppStrings.guestTitle,
              description: AppStrings.guestChatsDesc,
              onLoginSuccess: () => setState(() {}),
            );
          }
          return Column(
              children: [
                // Search & Filter header
          Container(
            color: AppColors.surface,
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
            child: Column(
              children: [
                // Search Input
                Container(
                  height: 44,
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  decoration: BoxDecoration(
                    color: AppColors.borderLight,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.search_rounded, color: AppColors.textMuted, size: 20),
                      const SizedBox(width: 8),
                      Expanded(
                        child: TextField(
                          decoration: InputDecoration(
                            hintText: AppStrings.chatsSearchHint,
                            hintStyle: const TextStyle(fontSize: 13, color: AppColors.textMuted),
                            border: InputBorder.none,
                            isDense: true,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                // Filter Tabs (All, Bookings, Requests)
                Row(
                  children: [
                    {'key': 'All', 'label': AppStrings.chatsTabAll},
                    {'key': 'Bookings', 'label': AppStrings.chatsTabBookings},
                    {'key': 'Requests', 'label': AppStrings.chatsTabRequests},
                  ].map((tab) {
                    final isSelected = _activeTab == tab['key'];
                    return Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: Text(
                          tab['label']!,
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: isSelected ? Colors.white : AppColors.slateMuted,
                          ),
                        ),
                        selected: isSelected,
                        selectedColor: AppColors.primary,
                        backgroundColor: AppColors.background,
                        side: BorderSide(
                          color: isSelected ? AppColors.primary : AppColors.border,
                        ),
                        onSelected: (val) {
                          if (val) setState(() => _activeTab = tab['key']!);
                        },
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),

          // Conversation List
          Expanded(
            child: _isLoading
                ? const Center(
                    child: CircularProgressIndicator(color: AppColors.primary),
                  )
                : ListView.separated(
                    itemCount: _chats.length,
                    separatorBuilder: (_, _) => const Divider(height: 1, indent: 72, color: AppColors.borderLight),
                    itemBuilder: (context, index) {
                      final chat = _chats[index];
                      return ListTile(
                        onTap: () {
                          final other = int.tryParse(chat.otherUserId ?? '');
                          if (other != null) {
                            ChatThreadScreen.open(context, recipientId: other, name: chat.senderName, isOnline: chat.isOnline);
                          } else {
                            // demo / placeholder rows have no real user behind them
                            _showChatDetailSheet(context, chat);
                          }
                        },
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  leading: Stack(
                    clipBehavior: Clip.none,
                    children: [
                      CircleAvatar(
                        radius: 24,
                        backgroundColor: AppColors.primaryLight,
                        child: Text(
                          chat.senderName.substring(0, 1),
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: AppColors.primary,
                          ),
                        ),
                      ),
                      if (chat.isOnline)
                        const Positioned(top: 0, right: 0, child: OnlineDot(size: 13)),
                      if (chat.isVerified)
                        Positioned(
                          bottom: -2,
                          right: -2,
                          child: Container(
                            decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                            child: VerificationBadge(level: chat.verificationLevel, size: 15),
                          ),
                        ),
                    ],
                  ),
                  title: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        chat.senderName,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      Text(
                        chat.timestamp,
                        style: TextStyle(
                          fontSize: 11,
                          color: chat.unreadCount > 0 ? AppColors.primary : AppColors.textMuted,
                          fontWeight: chat.unreadCount > 0 ? FontWeight.w600 : FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                  subtitle: Row(
                    children: [
                      if (chat.isVoiceNote)
                        const Padding(
                          padding: EdgeInsets.only(right: 4),
                          child: Icon(Icons.mic_rounded, size: 14, color: AppColors.primary),
                        ),
                      Expanded(
                        child: Text(
                          chat.lastMessage,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 12,
                            color: chat.unreadCount > 0 ? AppColors.slateDark : AppColors.textSecondary,
                            fontWeight: chat.unreadCount > 0 ? FontWeight.w600 : FontWeight.w400,
                          ),
                        ),
                      ),
                      if (ChatPrefs.isMuted(int.tryParse(chat.otherUserId ?? '')))
                        const Padding(
                          padding: EdgeInsets.only(left: 6),
                          child: Icon(Icons.notifications_off_outlined, size: 14, color: AppColors.textMuted),
                        ),
                      if (chat.unreadCount > 0)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: const BoxDecoration(
                            color: AppColors.onlineGreen,
                            shape: BoxShape.circle,
                          ),
                          child: Text(
                            '${chat.unreadCount}',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      );
    },
  ),
);
      },
    );
  }

  void _showChatDetailSheet(BuildContext context, ChatMessage chat) {
    final textController = TextEditingController();
    final List<Map<String, dynamic>> messages = [
      {'isMe': false, 'text': 'Habari! Karibu sana.', 'time': '10:00 AM'},
      {'isMe': true, 'text': 'Asante! Ningependa kupata taarifa za huduma.', 'time': '10:05 AM'},
      {'isMe': false, 'text': chat.lastMessage, 'time': chat.timestamp},
    ];

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheetState) => Container(
          height: MediaQuery.of(context).size.height * 0.85,
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Column(
            children: [
              // Chat Header
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: const BoxDecoration(
                  border: Border(bottom: BorderSide(color: AppColors.borderLight)),
                ),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 18,
                      backgroundColor: AppColors.primaryLight,
                      child: Text(
                        chat.senderName.substring(0, 1),
                        style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.primary),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            chat.senderName,
                            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                          ),
                          if (chat.isOnline)
                            Text(
                              AppStrings.chatsOnline,
                              style: const TextStyle(fontSize: 11, color: AppColors.onlineGreen, fontWeight: FontWeight.w600),
                            ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, color: AppColors.textSecondary),
                      onPressed: () => Navigator.pop(ctx),
                    ),
                  ],
                ),
              ),

              // Chat Messages
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: messages.length,
                  itemBuilder: (ctx, idx) {
                    final msg = messages[idx];
                    final isMe = msg['isMe'] == true;
                    return Align(
                      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
                        decoration: BoxDecoration(
                          color: isMe ? AppColors.primary : AppColors.borderLight,
                          borderRadius: BorderRadius.circular(16).copyWith(
                            bottomRight: isMe ? const Radius.circular(0) : const Radius.circular(16),
                            bottomLeft: !isMe ? const Radius.circular(0) : const Radius.circular(16),
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              msg['text'],
                              style: TextStyle(
                                fontSize: 13,
                                color: isMe ? Colors.white : AppColors.textPrimary,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              msg['time'],
                              style: TextStyle(
                                fontSize: 9,
                                color: isMe ? Colors.white70 : AppColors.textMuted,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),

              // Chat Input Bar
              Container(
                padding: EdgeInsets.fromLTRB(16, 8, 16, MediaQuery.of(ctx).viewInsets.bottom + 12),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  border: Border(top: BorderSide(color: AppColors.borderLight)),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Container(
                        height: 44,
                        padding: const EdgeInsets.symmetric(horizontal: 14),
                        decoration: BoxDecoration(
                          color: AppColors.background,
                          borderRadius: BorderRadius.circular(22),
                          border: Border.all(color: AppColors.border),
                        ),
                        child: TextField(
                          controller: textController,
                          decoration: InputDecoration(
                            hintText: AppStrings.chatsTypePlaceholder,
                            hintStyle: const TextStyle(fontSize: 13, color: AppColors.textMuted),
                            border: InputBorder.none,
                            isDense: true,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton(
                      icon: const Icon(Icons.send_rounded, color: AppColors.primary),
                      onPressed: () async {
                        final val = textController.text.trim();
                        if (val.isNotEmpty) {
                          setSheetState(() {
                            messages.add({'isMe': true, 'text': val, 'time': 'Now'});
                            textController.clear();
                          });
                          // Dispatch to backend API asynchronously
                          ApiService.sendMessage(
                            recipientId: chat.id,
                            message: val,
                          );
                        }
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

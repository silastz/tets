import 'package:flutter_test/flutter_test.dart';
import 'package:jamiiapp/security/input_validation.dart';
import 'package:jamiiapp/services/payment_methods_service.dart';

const _supported = ['+255', '+254', '+256', '+250', '+257', '+243'];

void main() {
  group('InputValidation.toInternational (sign-in + registration)', () {
    test('every way of typing a Tanzanian number gives the same result', () {
      for (final typed in ['0712345678', '712345678', '255712345678', '+255712345678', '0712 345 678', '00255712345678']) {
        expect(InputValidation.toInternational(typed, '+255'), '+255712345678', reason: typed);
      }
    });

    test('never produces +255255...', () {
      expect(InputValidation.toInternational('255712345678', '+255'), isNot(contains('255255')));
    });

    test('empty or non-numeric input stays empty', () {
      expect(InputValidation.toInternational('', '+255'), '');
      expect(InputValidation.toInternational('abc', '+255'), '');
    });

    test('a number with another supported country code keeps it', () {
      expect(InputValidation.toInternational('254712345678', '+255', otherDials: _supported), '+254712345678');
      expect(InputValidation.toInternational('0712345678', '+254', otherDials: _supported), '+254712345678');
    });

    test('a short number that merely starts like a country code is not treated as one', () {
      // Used to become "+2557123" with no length check.
      expect(InputValidation.phoneE164(InputValidation.toInternational('2557123', '+255', otherDials: _supported)), isNotNull);
    });
  });

  group('PaymentMethodsService.normalizeTzNumber (every payment screen)', () {
    test('accepts the usual ways of typing a mobile number', () {
      for (final typed in ['0712345678', '712345678', '255712345678', '+255712345678', '0712 345 678']) {
        expect(PaymentMethodsService.normalizeTzNumber(typed), '255712345678', reason: typed);
      }
    });

    test('rejects numbers the old "9+ digits" check let through', () {
      expect(PaymentMethodsService.normalizeTzNumber('123456789'), isNull);
      expect(PaymentMethodsService.normalizeTzNumber('0812345678'), isNull); // not a 6/7 mobile prefix
      expect(PaymentMethodsService.normalizeTzNumber('07123456789012'), isNull);
      expect(PaymentMethodsService.normalizeTzNumber(''), isNull);
    });
  });
}

import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/block_service.dart';
import '../services/session_manager.dart';
import 'login_modal.dart';

/// What is being reported.
enum ReportTarget { service, user, general }

/// What happened in the sheet: the report went out, and/or the user was blocked too.
class ReportOutcome {
  final bool sent;
  final bool blocked;
  const ReportOutcome({this.sent = false, this.blocked = false});
}

/// One bottom sheet used everywhere a report can be sent: pick a reason,
/// add details, submit to the server. Signed-in users only.
class ReportSheet {
  static bool get _en => AppStrings.isEnglish;

  /// Opens the sheet. For a user or service report the person can also block the
  /// provider in the same step. Returns what was done.
  static Future<ReportOutcome> show(
    BuildContext context, {
    required ReportTarget target,
    String? serviceId,
    int? userId,
    String? name,
  }) async {
    if (!SessionManager.isLoggedIn()) {
      final ok = await LoginModal.show(context);
      if (ok != true || !context.mounted) return const ReportOutcome();
    }
    final res = await showModalBottomSheet<ReportOutcome>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => _ReportBody(target: target, serviceId: serviceId, userId: userId, name: name),
    );
    final out = res ?? const ReportOutcome();
    if (out.sent && context.mounted) {
      final who = (name ?? '').trim().isEmpty ? (_en ? 'User' : 'Mtumiaji') : name!.trim();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        backgroundColor: AppColors.success,
        content: Text(out.blocked
            ? (_en ? 'Report sent and $who blocked.' : 'Ripoti imetumwa na $who amezuiwa.')
            : (_en ? 'Report sent. Our safety team will review it.' : 'Ripoti imetumwa. Timu yetu ya usalama itaipitia.')),
      ));
    }
    return out;
  }
}

class _ReportBody extends StatefulWidget {
  final ReportTarget target;
  final String? serviceId;
  final int? userId;
  final String? name;
  const _ReportBody({required this.target, this.serviceId, this.userId, this.name});

  @override
  State<_ReportBody> createState() => _ReportBodyState();
}

class _ReportBodyState extends State<_ReportBody> {
  final _details = TextEditingController();
  String? _reason;
  bool _sending = false;
  bool _alsoBlock = false;
  String? _error;

  /// Blocking needs a real user id and is not offered on general reports or your own account.
  bool get _canBlock =>
      widget.target != ReportTarget.general &&
      widget.userId != null &&
      widget.userId != 0 &&
      widget.userId != SessionManager.getUserIdValue();

  bool get _en => AppStrings.isEnglish;

  // code (sent to server) -> label
  List<MapEntry<String, String>> get _reasons => [
        MapEntry('SCAM', _en ? 'Scam or fraud' : 'Utapeli'),
        MapEntry('FAKE', _en ? 'Fake profile or service' : 'Wasifu au huduma ya uongo'),
        MapEntry('INAPPROPRIATE', _en ? 'Inappropriate content' : 'Maudhui yasiyofaa'),
        MapEntry('HARASSMENT', _en ? 'Harassment or abuse' : 'Unyanyasaji au matusi'),
        MapEntry('OFF_PLATFORM_PAYMENT', _en ? 'Asks for payment outside the app' : 'Anaomba malipo nje ya app'),
        if (widget.target == ReportTarget.general) MapEntry('BUG', _en ? 'App problem / bug' : 'Tatizo la app'),
        MapEntry('OTHER', _en ? 'Something else' : 'Jingine'),
      ];

  String get _title {
    final n = (widget.name ?? '').trim();
    switch (widget.target) {
      case ReportTarget.service:
        return _en ? 'Report this service' : 'Ripoti huduma hii';
      case ReportTarget.user:
        return n.isEmpty ? (_en ? 'Report this user' : 'Ripoti mtumiaji huyu') : (_en ? 'Report $n' : 'Ripoti $n');
      case ReportTarget.general:
        return _en ? 'Report a problem or abuse' : 'Ripoti tatizo au unyanyasaji';
    }
  }

  Future<void> _submit() async {
    if (_reason == null) {
      setState(() => _error = _en ? 'Please choose a reason.' : 'Tafadhali chagua sababu.');
      return;
    }
    setState(() {
      _sending = true;
      _error = null;
    });
    final type = widget.target == ReportTarget.service
        ? 'SERVICE'
        : widget.target == ReportTarget.user
            ? 'USER'
            : 'GENERAL';
    final ok = await ApiService.submitReport(
      type: type,
      reason: _reason!,
      details: _details.text,
      serviceId: widget.serviceId,
      reportedUserId: widget.userId,
    );
    if (!mounted) return;
    if (ok) {
      var blocked = false;
      if (_alsoBlock && _canBlock) {
        final n = (widget.name ?? '').trim();
        // The report already says why, so reuse it (map to the closest block reason).
        const map = {
          'SCAM': 'SCAM',
          'FAKE': 'SCAM',
          'OFF_PLATFORM_PAYMENT': 'SCAM',
          'INAPPROPRIATE': 'INAPPROPRIATE',
          'HARASSMENT': 'HARASSMENT',
        };
        await BlockService.block(widget.userId!, n.isEmpty ? 'User' : n, reason: map[_reason] ?? 'OTHER', details: _details.text);
        blocked = true;
      }
      if (!mounted) return;
      Navigator.pop(context, ReportOutcome(sent: true, blocked: blocked));
    } else {
      setState(() {
        _sending = false;
        _error = _en
            ? "Couldn't send the report. Check your connection and try again."
            : 'Imeshindwa kutuma ripoti. Angalia mtandao kisha ujaribu tena.';
      });
    }
  }

  @override
  void dispose() {
    _details.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: EdgeInsets.fromLTRB(16, 20, 16, MediaQuery.of(context).viewInsets.bottom + 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(_title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
            const SizedBox(height: 6),
            Text(
              _en ? 'What is the problem? Your report is private.' : 'Tatizo ni nini? Ripoti yako ni siri.',
              style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final r in _reasons)
                  ChoiceChip(
                    label: Text(r.value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                    selected: _reason == r.key,
                    selectedColor: AppColors.primary.withValues(alpha: 0.15),
                    onSelected: _sending ? null : (_) => setState(() => _reason = r.key),
                  ),
              ],
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _details,
              enabled: !_sending,
              maxLines: 4,
              maxLength: 500,
              decoration: InputDecoration(
                hintText: _en ? 'Add details (optional)...' : 'Ongeza maelezo (si lazima)...',
                filled: true,
                fillColor: AppColors.background,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            if (_canBlock)
              CheckboxListTile(
                value: _alsoBlock,
                onChanged: _sending ? null : (v) => setState(() => _alsoBlock = v ?? false),
                contentPadding: EdgeInsets.zero,
                controlAffinity: ListTileControlAffinity.leading,
                activeColor: AppColors.danger,
                dense: true,
                title: Text(
                  _en
                      ? 'Also block ${(widget.name ?? '').trim().isEmpty ? 'this user' : widget.name!.trim()}'
                      : 'Mzuie pia ${(widget.name ?? '').trim().isEmpty ? 'mtumiaji huyu' : widget.name!.trim()}',
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                ),
                subtitle: Text(
                  _en
                      ? "They can't message you and you won't see their services."
                      : 'Hataweza kukutumia ujumbe na hutaona huduma zake.',
                  style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                ),
              ),
            if (_error != null) ...[
              const SizedBox(height: 6),
              Text(_error!, style: const TextStyle(fontSize: 12, color: AppColors.danger, fontWeight: FontWeight.w600)),
            ],
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                onPressed: _sending ? null : _submit,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: _sending
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : Text(_en ? 'Submit report' : 'Tuma ripoti',
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

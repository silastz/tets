import 'dart:async';
import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/call_service.dart';
import '../services/media_picker.dart';
import '../services/session_manager.dart';
import '../services/block_service.dart';
import '../widgets/app_image.dart';
import '../widgets/block_user_dialog.dart';
import '../widgets/fullscreen_image_viewer.dart';
import '../widgets/login_modal.dart';
import '../services/data_sync.dart';

/// One-to-one conversation with a provider / client.
/// Open it with [ChatThreadScreen.open] - it asks the user to sign in first.
class ChatThreadScreen extends StatefulWidget {
  /// User id of the person being chatted with (the seller's user id).
  final String otherUserId;
  final String otherName;

  const ChatThreadScreen({
    super.key,
    required this.otherUserId,
    required this.otherName,
  });

  /// Opens a chat with [recipientId]. Guests get the login sheet first.
  static Future<void> open(
    BuildContext context, {
    required int? recipientId,
    required String name,
  }) async {
    final isEn = AppStrings.isEnglish;
    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);

    if (recipientId == null || recipientId == 0) {
      messenger.showSnackBar(SnackBar(
        content: Text(isEn ? 'Chat is not available for this provider yet.' : 'Mazungumzo hayapatikani kwa mtoa huduma huyu bado.'),
      ));
      return;
    }

    if (!SessionManager.isLoggedIn()) {
      final ok = await LoginModal.show(context);
      if (ok != true || !SessionManager.isLoggedIn()) return;
    }

    if (SessionManager.getUserIdValue() == recipientId) {
      messenger.showSnackBar(SnackBar(
        content: Text(isEn ? "You can't chat with yourself." : 'Huwezi kuzungumza na wewe mwenyewe.'),
      ));
      return;
    }

    await navigator.push(MaterialPageRoute(
      builder: (_) => ChatThreadScreen(otherUserId: recipientId.toString(), otherName: name),
    ));
    // Messages were read/sent in the thread: refresh the Chats list and the Home bell badge.
    DataSync.bump();
  }

  @override
  State<ChatThreadScreen> createState() => _ChatThreadScreenState();
}

class _Msg {
  final bool isMe;
  final String text;
  final String time;
  final bool pending;

  /// Picture shown in the bubble (a link on our own server), if any.
  final String? imageUrl;

  /// A picture that is still being uploaded (no link yet).
  final bool uploadingPhoto;

  _Msg({
    required this.isMe,
    required this.text,
    required this.time,
    this.pending = false,
    this.imageUrl,
    this.uploadingPhoto = false,
  });
}

class _ChatThreadScreenState extends State<ChatThreadScreen> {
  final _input = TextEditingController();
  final _scroll = ScrollController();
  List<_Msg> _messages = [];
  bool _loading = true;
  bool _sending = false;
  Timer? _poll;

  bool get _isEn => AppStrings.isEnglish;
  int? get _otherId => int.tryParse(widget.otherUserId);
  bool get _isBlocked => BlockService.isBlocked(_otherId);
  int get _myId => SessionManager.getUserIdValue();

  @override
  void initState() {
    super.initState();
    BlockService.changed.addListener(_onBlockChanged);
    _load();
    // Light polling so new replies show up while the screen is open.
    _poll = Timer.periodic(const Duration(seconds: 8), (_) => _load(silent: true));
  }

  void _onBlockChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    BlockService.changed.removeListener(_onBlockChanged);
    _poll?.cancel();
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  String _fmtTime(dynamic raw) {
    final d = DateTime.tryParse(raw?.toString() ?? '')?.toLocal();
    if (d == null) return '';
    final h = d.hour.toString().padLeft(2, '0');
    final m = d.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }

  _Msg _parse(Map<String, dynamic> m) {
    dynamic senderId = m['senderId'];
    final sender = m['sender'];
    if (senderId == null && sender is Map) senderId = sender['id'];
    final isMe = m['isMe'] == true ||
        (senderId != null && senderId.toString() == _myId.toString());
    final text = (m['content'] ?? m['message'] ?? m['text'] ?? '').toString();
    // A picture arrives either as its own field or as a link in the text
    // (that is how this app sends one, like call links).
    var image = (m['imageUrl'] ?? m['attachmentUrl'] ?? m['mediaUrl'])?.toString().trim();
    if (image != null && (image.isEmpty || image == 'null')) image = null;
    final textIsImage = ApiService.isOwnImageUrl(text);
    if (image == null && textIsImage) image = text.trim();
    return _Msg(
      isMe: isMe,
      text: textIsImage ? '' : text,
      imageUrl: image == null ? null : ApiService.absoluteUrl(image),
      time: _fmtTime(m['createdAt'] ?? m['timestamp'] ?? m['sentAt'] ?? m['time']),
    );
  }

  Future<void> _load({bool silent = false}) async {
    final raw = await ApiService.fetchMessages(widget.otherUserId);
    if (!mounted) return;
    final parsed = raw
        .whereType<Map>()
        .map((e) => _parse(Map<String, dynamic>.from(e)))
        .where((m) => m.text.isNotEmpty || m.imageUrl != null)
        .toList();
    final changed = parsed.length != _messages.where((m) => !m.pending).length;
    setState(() {
      _loading = false;
      // keep any message still being sent
      _messages = [...parsed, ..._messages.where((m) => m.pending)];
    });
    if (changed || !silent) _scrollToEnd();
  }

  void _scrollToEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _send() async {
    final text = _input.text.trim();
    if (text.isEmpty || _sending || _isBlocked) return;
    _input.clear();
    setState(() {
      _sending = true;
      _messages.add(_Msg(isMe: true, text: text, time: _fmtTime(DateTime.now().toIso8601String()), pending: true));
    });
    _scrollToEnd();

    final res = await ApiService.sendMessage(recipientId: widget.otherUserId, message: text);
    if (!mounted) return;
    setState(() => _sending = false);

    if (res == null) {
      setState(() => _messages.removeWhere((m) => m.pending && m.text == text));
      _input.text = text;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        backgroundColor: AppColors.danger,
        content: Text(_isEn ? 'Message not sent. Try again.' : 'Ujumbe haujatumwa. Jaribu tena.'),
      ));
      return;
    }
    await _load(silent: true);
    _scrollToEnd();
  }

  /// Pick a photo, upload it, then send its link as the message.
  Future<void> _attachImage() async {
    if (_sending || _isBlocked) return;
    final messenger = ScaffoldMessenger.of(context);
    final file = await MediaPicker.pickImage(
      context,
      title: _isEn ? 'Send a photo' : 'Tuma picha',
      maxWidth: 1600,
    );
    if (file == null || !mounted) return;

    setState(() {
      _sending = true;
      _messages.add(_Msg(
        isMe: true,
        text: '',
        time: _fmtTime(DateTime.now().toIso8601String()),
        pending: true,
        uploadingPhoto: true,
      ));
    });
    _scrollToEnd();

    void fail(String text) {
      if (!mounted) return;
      setState(() {
        _sending = false;
        _messages.removeWhere((m) => m.uploadingPhoto);
      });
      messenger.showSnackBar(SnackBar(backgroundColor: AppColors.danger, content: Text(text)));
    }

    final up = await ApiService.uploadChatImage(file.path);
    if (!mounted) return;
    final url = up.url;
    if (!up.ok || url == null) {
      fail(up.error ?? (_isEn ? 'Photo not sent. Try again.' : 'Picha haijatumwa. Jaribu tena.'));
      return;
    }
    final res = await ApiService.sendMessage(recipientId: widget.otherUserId, message: url);
    if (!mounted) return;
    if (res == null) {
      fail(_isEn ? 'Photo not sent. Try again.' : 'Picha haijatumwa. Jaribu tena.');
      return;
    }
    setState(() {
      _sending = false;
      _messages.removeWhere((m) => m.uploadingPhoto);
    });
    await _load(silent: true);
    _scrollToEnd();
  }

  Widget _blockedBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: AppColors.borderLight)),
      ),
      child: Row(
        children: [
          const Icon(Icons.block_rounded, size: 18, color: AppColors.danger),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              _isEn ? 'You blocked this user. Unblock to send messages.' : 'Umemzuia mtumiaji huyu. Mfungulie ili utume ujumbe.',
              style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
            ),
          ),
          TextButton(
            onPressed: () {
              final id = _otherId;
              if (id != null) BlockUserDialog.confirmUnblock(context, userId: id, name: widget.otherName);
            },
            child: Text(_isEn ? 'Unblock' : 'Fungulia', style: const TextStyle(fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        titleSpacing: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            CircleAvatar(
              radius: 17,
              backgroundColor: AppColors.primaryLight,
              child: Text(
                widget.otherName.isNotEmpty ? widget.otherName.substring(0, 1).toUpperCase() : '?',
                style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.primary),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                widget.otherName,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
              ),
            ),
          ],
        ),
        actions: [
          if (_otherId != null && _otherId != 0)
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_vert_rounded, color: AppColors.textPrimary),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              onSelected: (v) {
                final id = _otherId!;
                if (v == 'block') {
                  BlockUserDialog.confirmBlock(context, userId: id, name: widget.otherName);
                } else {
                  BlockUserDialog.confirmUnblock(context, userId: id, name: widget.otherName);
                }
              },
              itemBuilder: (_) => [
                PopupMenuItem(
                  value: _isBlocked ? 'unblock' : 'block',
                  child: Row(
                    children: [
                      Icon(_isBlocked ? Icons.lock_open_rounded : Icons.block_rounded,
                          size: 18, color: _isBlocked ? AppColors.primary : AppColors.danger),
                      const SizedBox(width: 10),
                      Text(
                        _isBlocked ? (_isEn ? 'Unblock user' : 'Mfungulie mtumiaji') : (_isEn ? 'Block user' : 'Mzuie mtumiaji'),
                        style: TextStyle(fontWeight: FontWeight.w600, color: _isBlocked ? AppColors.primary : AppColors.danger),
                      ),
                    ],
                  ),
                ),
              ],
            ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.border, height: 1),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: _loading
                  ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
                  : _messages.isEmpty
                      ? Center(
                          child: Padding(
                            padding: const EdgeInsets.all(32),
                            child: Text(
                              _isEn
                                  ? 'Say hello to ${widget.otherName} 👋'
                                  : 'Mwambie ${widget.otherName} habari 👋',
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontSize: 14, color: AppColors.textSecondary),
                            ),
                          ),
                        )
                      : ListView.builder(
                          controller: _scroll,
                          padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
                          itemCount: _messages.length,
                          itemBuilder: (_, i) => _bubble(_messages[i]),
                        ),
            ),
            if (_isBlocked)
              _blockedBar()
            else
            Container(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
              decoration: const BoxDecoration(
                color: Colors.white,
                border: Border(top: BorderSide(color: AppColors.borderLight)),
              ),
              child: Row(
                children: [
                  IconButton(
                    tooltip: _isEn ? 'Send a photo' : 'Tuma picha',
                    onPressed: _sending ? null : _attachImage,
                    icon: const Icon(Icons.add_photo_alternate_outlined, color: AppColors.primary),
                  ),
                  Expanded(
                    child: TextField(
                      controller: _input,
                      minLines: 1,
                      maxLines: 4,
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => _send(),
                      decoration: InputDecoration(
                        hintText: _isEn ? 'Type a message...' : 'Andika ujumbe...',
                        hintStyle: const TextStyle(fontSize: 13, color: AppColors.textMuted),
                        filled: true,
                        fillColor: AppColors.background,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(22),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Material(
                    color: AppColors.primary,
                    shape: const CircleBorder(),
                    child: InkWell(
                      customBorder: const CircleBorder(),
                      onTap: _send,
                      child: const Padding(
                        padding: EdgeInsets.all(11),
                        child: Icon(Icons.send_rounded, color: Colors.white, size: 20),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Our own call-room link inside a message, if any.
  String? _callLink(String text) {
    final m = RegExp(r'https://meet\.jit\.si/[^\s]+').firstMatch(text);
    return m?.group(0);
  }

  Widget _bubble(_Msg m) {
    return Align(
      alignment: m.isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 3),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
        decoration: BoxDecoration(
          color: m.isMe ? AppColors.primary : Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(14),
            topRight: const Radius.circular(14),
            bottomLeft: Radius.circular(m.isMe ? 14 : 3),
            bottomRight: Radius.circular(m.isMe ? 3 : 14),
          ),
          border: m.isMe ? null : Border.all(color: AppColors.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            if (m.uploadingPhoto)
              Container(
                width: 160,
                height: 120,
                alignment: Alignment.center,
                decoration: BoxDecoration(color: Colors.black12, borderRadius: BorderRadius.circular(10)),
                child: const SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
              )
            else if (m.imageUrl != null)
              GestureDetector(
                onTap: () {
                  final all = [for (final x in _messages) if (x.imageUrl != null) x.imageUrl!];
                  final at = all.indexOf(m.imageUrl!);
                  FullscreenImageViewer.open(context, images: all, initialIndex: at < 0 ? 0 : at);
                },
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: AppImage(
                    m.imageUrl!,
                    width: 220,
                    height: 160,
                    fit: BoxFit.cover,
                    errorBuilder: (_, _, _) => Container(
                      width: 220,
                      height: 120,
                      alignment: Alignment.center,
                      color: Colors.black12,
                      child: const Icon(Icons.broken_image_outlined, color: AppColors.textMuted),
                    ),
                  ),
                ),
              ),
            if (m.text.isNotEmpty)
              Padding(
                padding: EdgeInsets.only(top: m.imageUrl != null ? 6 : 0),
                child: Text(
                  m.text,
                  style: TextStyle(fontSize: 14, color: m.isMe ? Colors.white : AppColors.textPrimary),
                ),
              ),
            if (_callLink(m.text) != null) ...[
              const SizedBox(height: 8),
              SizedBox(
                height: 34,
                child: ElevatedButton.icon(
                  onPressed: () => CallService.joinCall(context, _callLink(m.text)!),
                  icon: const Icon(Icons.call_rounded, size: 16),
                  label: Text(_isEn ? 'Join call' : 'Jiunge na simu'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: m.isMe ? Colors.white : AppColors.success,
                    foregroundColor: m.isMe ? AppColors.primary : Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                ),
              ),
            ],
            const SizedBox(height: 2),
            Text(
              m.pending ? '…' : m.time,
              style: TextStyle(fontSize: 10, color: m.isMe ? Colors.white70 : AppColors.textMuted),
            ),
          ],
        ),
      ),
    );
  }
}

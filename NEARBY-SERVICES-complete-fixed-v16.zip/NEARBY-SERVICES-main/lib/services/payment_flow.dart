import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';

/// Where a booking is in the "pay first" flow.
enum PayState { none, awaitingPayment, paymentSent, disputed }

/// Status vocabulary + helpers for the pay-first / offline-payment flow.
///
/// Server statuses used by this flow (in addition to PENDING_ACCEPTANCE,
/// ACCEPTED, COMPLETED, REJECTED, CANCELLED):
///   AWAITING_PAYMENT   provider asked the buyer to pay before the booking is accepted
///   PAYMENT_SENT       buyer says they paid (offline); provider must confirm
///   PAYMENT_DISPUTED   provider says the money did not arrive
class PaymentFlow {
  PaymentFlow._();

  static String _up(dynamic v) => (v ?? '').toString().toUpperCase();

  static PayState stateOf(dynamic status) {
    final s = _up(status).replaceAll(' ', '_');
    if (s.contains('PAYMENT_DISPUTED') || s.contains('PAYMENT_NOT_RECEIVED')) return PayState.disputed;
    if (s.contains('PAYMENT_SENT')) return PayState.paymentSent;
    if (s.contains('AWAITING_PAYMENT')) return PayState.awaitingPayment;
    return PayState.none;
  }

  /// True while the booking is somewhere in the pay-first flow.
  static bool isOpen(dynamic status) => stateOf(status) != PayState.none;

  static bool isOfflineMethod(Map tx) => _up(tx['paymentMethod']).contains('OFFLINE');

  /// How the provider wants to be paid: 'ONLINE' (in the app) or 'OFFLINE' (directly).
  static String payMode(Map tx) {
    final explicit = _up(tx['paymentMode']);
    if (explicit == 'ONLINE' || explicit == 'OFFLINE') return explicit;
    return isOfflineMethod(tx) ? 'OFFLINE' : 'ONLINE';
  }

  /// An online booking (Pocket Fund / mobile money / card) the server says is not paid yet.
  /// Only true when the server actually sends a payment status.
  static bool isUnpaidOnline(Map tx) {
    if (isOfflineMethod(tx)) return false;
    final p = _up(tx['paymentStatus']);
    if (p.isEmpty) return false;
    return p == 'UNPAID' || p == 'NOT_PAID' || p == 'FAILED' || p == 'PENDING_PAYMENT';
  }

  static String label(dynamic status) {
    final en = AppStrings.isEnglish;
    switch (stateOf(status)) {
      case PayState.awaitingPayment:
        return en ? 'Awaiting payment' : 'Inasubiri malipo';
      case PayState.paymentSent:
        return en ? 'Payment sent' : 'Malipo yametumwa';
      case PayState.disputed:
        return en ? 'Payment issue' : 'Tatizo la malipo';
      case PayState.none:
        return '';
    }
  }

  static Color color(dynamic status) {
    switch (stateOf(status)) {
      case PayState.awaitingPayment:
        return AppColors.warning;
      case PayState.paymentSent:
        return AppColors.primary;
      case PayState.disputed:
        return AppColors.danger;
      case PayState.none:
        return AppColors.textSecondary;
    }
  }

  static String money(num v) =>
      'TSh ${v.toInt().toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},')}';
}

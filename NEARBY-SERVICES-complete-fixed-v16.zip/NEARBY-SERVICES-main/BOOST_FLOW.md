# Boost service

The app side is done; the backend needs the endpoints and fields below.

A provider pays to have one service ranked first (Home, Category, Search) and tagged
"Boosted" for a number of days. Entry point: **My Services -> bolt icon** (or the 3-dots
menu -> "Boost Service") -> `BoostServiceSheet` (a short bottom sheet).

## Endpoints
| Call | Effect |
|---|---|
| `GET /boosts/plans` -> `[{id, days, price}]` | Packages and prices (TZS). The app falls back to 1 day 2,000 / 3 days 5,000 / 7 days 10,000 if this fails, but **the server must price from its own plan table, never from the app's amount.** |
| `POST /payments/mobile/request` `{amount, purpose: "SERVICE_BOOST", reference, phone}` | Existing endpoint, new purpose. Reference looks like `BOOST-{serviceId}-{userId}-{millis}`. |
| `POST /payments/card/checkout` `{amount, purpose: "SERVICE_BOOST", reference, description, phone?}` | Existing endpoint, new purpose. |
| `GET /payments/status/{ref}` and `/payments/card/status/{ref}` | Existing polling (PAID / PENDING / FAILED / CANCELLED). |
| `POST /boosts/activate` `{serviceId, planId, days, paymentMethod: MOBILE_MONEY \| CARD \| POCKET_FUND, reference?}` -> `{boostedUntil, ...}` | Starts or extends the boost. |

## Rules the server must enforce (the app cannot)
- Caller must own `serviceId` and be a provider with an active account.
- `MOBILE_MONEY` / `CARD`: the `reference` must be a PAID payment with purpose `SERVICE_BOOST`, made by this user, whose amount equals the plan's price. A reference can only be used once, so repeating the same `activate` call must return the same result and **not** add days twice (the app retries after a network drop without charging again).
- `POCKET_FUND`: debit the wallet atomically with starting the boost; fail with a readable `message` if the balance is too low.
- Boosting a service that is already boosted adds the new days after the current `boostedUntil`.
- Boost ends by itself at `boostedUntil`; no app call is needed.
- Optional but recommended: also activate on the payment webhook for purpose `SERVICE_BOOST`, so a boost still starts if the app is closed after paying. `activate` then just returns the existing result.

## Fields the service JSON should carry
`boostedUntil` (ISO-8601; the app treats the service as boosted only while this is in the future).
If you only send a flag, `isBoosted: true` also works (the app then trusts the flag).
Both `GET /services` (listing) and `GET /services/seller/my-services` should include it.

## Ranking (server side)
The app puts boosted services first inside each page it receives, but a boosted service on
page 2 can't jump to page 1 from the client. **`GET /services` should sort boosted first across
all pages**, then by distance as it does today. Banner on Home still ranks by popularity and
only uses boosted as a tie-break.

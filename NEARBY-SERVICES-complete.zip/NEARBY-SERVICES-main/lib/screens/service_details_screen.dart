import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import '../services/call_service.dart';
import '../services/data_sync.dart';
import '../services/session_manager.dart';
import '../services/share_service.dart';
import '../widgets/app_image.dart';
import '../widgets/call_options_sheet.dart';
import '../widgets/fullscreen_image_viewer.dart';
import '../widgets/login_modal.dart';
import '../widgets/make_offer_sheet.dart';
import '../widgets/sensitive_tag.dart';
import '../widgets/social_links_row.dart';
import '../widgets/verification_badge.dart';
import '../widgets/video_player_screen.dart';
import 'booking_request_screen.dart';
import 'chat_thread_screen.dart';
import 'seller_profile_screen.dart';

class ServiceDetailsScreen extends StatefulWidget {
  final ServiceItem service;

  const ServiceDetailsScreen({
    super.key,
    required this.service,
  });

  @override
  State<ServiceDetailsScreen> createState() => _ServiceDetailsScreenState();
}

class _ServiceDetailsScreenState extends State<ServiceDetailsScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  int _selectedDurationIndex = 0;
  int _selectedThumbnailIndex = 0;
  final PageController _heroController = PageController();
  final ScrollController _thumbScroll = ScrollController();
  static const double _thumbW = 84;
  static const double _thumbGap = 8;
  bool get _isFavorite => SessionManager.isFavorite(widget.service.id);
  int _selectedVideoIndex = 0;

  // Fallback demo stream used while a service has no uploaded videos.
  static const String _sampleVideoUrl =
      'https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4';

  // Opens the share sheet: WhatsApp, Messages, any other app, or copy.
  Future<void> _shareService(ServiceItem service) async {
    await ShareService.showServiceSheet(
      context,
      title: service.title,
      priceText: service.priceText,
      providerName: service.providerName,
      category: service.category,
      serviceId: service.id,
    );
  }

  // Keeps the big image, the counter and the thumbnail strip on the same image.
  void _selectImage(int i, {bool animateHero = false}) {
    if (i == _selectedThumbnailIndex && !animateHero) return;
    setState(() => _selectedThumbnailIndex = i);
    if (animateHero && _heroController.hasClients) {
      _heroController.animateToPage(i, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
    }
    if (_thumbScroll.hasClients) {
      final viewport = _thumbScroll.position.viewportDimension;
      final target = i * (_thumbW + _thumbGap) - (viewport - _thumbW) / 2;
      _thumbScroll.animateTo(target.clamp(0.0, _thumbScroll.position.maxScrollExtent),
          duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
    }
  }

  void _openGallery(int index) {
    FullscreenImageViewer.open(
      context,
      images: _galleryImages,
      initialIndex: index,
      onIndexChanged: (i) {
        // Back from full screen on the image the person last looked at.
        if (!mounted) return;
        setState(() => _selectedThumbnailIndex = i);
        if (_heroController.hasClients) _heroController.jumpToPage(i);
      },
      onShare: () => _shareService(widget.service),
      initialSaved: _isFavorite,
      onSavedChanged: (v) {
        if (v != _isFavorite) SessionManager.toggleFavorite(widget.service.id);
      },
    );
  }

  void _playVideo(int index) {
    final video = _videos[index];
    VideoPlayerScreen.open(context, url: video['url'] ?? _sampleVideoUrl, title: video['title']!);
  }

  // Placeholder video entries (used until real video metadata is available).
  // Uploaded videos when present; otherwise demo entries.
  List<Map<String, String>> get _videos {
    final urls = widget.service.videoUrls;
    if (urls.isEmpty) return _fallbackVideos;
    return [
      for (int i = 0; i < urls.length; i++)
        {
          'title': 'Video ${i + 1}',
          'subtitle': widget.service.title,
          'duration': '',
          'thumb': i.isEven ? 'assets/images/zeen_cover.jpg' : 'assets/images/provider1.jpg',
          'url': urls[i],
        },
    ];
  }

  final List<Map<String, String>> _fallbackVideos = const [
    {
      'title': 'Relaxing Massage Session',
      'subtitle': 'See how we make you feel relaxed and refreshed.',
      'duration': '01:24',
      'thumb': 'assets/images/zeen_cover.jpg',
    },
    {
      'title': 'Customer Experience',
      'subtitle': 'Our happy clients share their experience.',
      'duration': '00:58',
      'thumb': 'assets/images/provider1.jpg',
    },
    {
      'title': 'Spa Environment',
      'subtitle': 'Take a tour of our clean and relaxing environment.',
      'duration': '01:15',
      'thumb': 'assets/images/provider2.jpg',
    },
    {
      'title': 'Massage Techniques',
      'subtitle': 'Professional techniques for better wellness.',
      'duration': '02:10',
      'thumb': 'assets/images/banner.jpg',
    },
  ];

  // Uploaded images when the provider has them; otherwise bundled demo images.
  List<String> get _galleryImages =>
      widget.service.imageUrls.isNotEmpty ? widget.service.imageUrls : _fallbackImages;

  final List<String> _fallbackImages = [
    'assets/images/banner.jpg',
    'assets/images/provider1.jpg',
    'assets/images/provider2.jpg',
    'assets/images/zeen_cover.jpg',
    'assets/images/zeen_avatar.jpg',
  ];

  // The listed duration/price of THIS service (the same price Home and Category
  // show), so what the buyer sees here is what the booking screen charges.
  List<Map<String, dynamic>> get _durations => [
        {
          'duration': widget.service.durationText,
          'price': widget.service.priceText,
          'priceVal': widget.service.priceAmount,
        },
      ];

  Widget _videoThumb(String path, {BorderRadius? radius}) {
    return ClipRRect(
      borderRadius: radius ?? BorderRadius.circular(12),
      child: AppImage(
        path,
        fit: BoxFit.cover,
        width: double.infinity,
        height: double.infinity,
        errorBuilder: (c, e, s) => Container(color: AppColors.slateDark),
      ),
    );
  }

  Widget _buildVideosSection() {
    final videos = _videos;
    final selected = videos[_selectedVideoIndex.clamp(0, videos.length - 1)];
    // Remaining videos shown in the list below the featured one.
    final others = <int>[
      for (int i = 0; i < videos.length; i++)
        if (i != _selectedVideoIndex) i,
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Service Videos',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
          ),
          const SizedBox(height: 12),

          // Featured (big) video
          GestureDetector(
            onTap: () => _playVideo(_selectedVideoIndex),
            child: AspectRatio(
            aspectRatio: 16 / 10,
            child: Stack(
              fit: StackFit.expand,
              children: [
                _videoThumb(selected['thumb']!, radius: BorderRadius.circular(14)),
                Center(
                  child: Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.55),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 34),
                  ),
                ),
                if (selected['duration']!.isNotEmpty)
                Positioned(
                  right: 10,
                  bottom: 10,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.65),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      selected['duration']!,
                      style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
              ],
            ),
          ),
          ),
          const SizedBox(height: 10),
          Text(
            selected['title']!,
            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
          ),
          const SizedBox(height: 2),
          Text(
            selected['subtitle']!,
            style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
          ),
          const SizedBox(height: 14),

          // Other videos as a vertical list
          ...others.map((i) {
            final v = videos[i];
            return InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () {
                setState(() => _selectedVideoIndex = i);
                _playVideo(i);
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Row(
                  children: [
                    SizedBox(
                      width: 96,
                      height: 66,
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          _videoThumb(v['thumb']!, radius: BorderRadius.circular(10)),
                          Center(
                            child: Container(
                              width: 28,
                              height: 28,
                              decoration: BoxDecoration(
                                color: Colors.black.withValues(alpha: 0.55),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 20),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            v['title']!,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                          ),
                          if (v['duration']!.isNotEmpty) ...[
                            const SizedBox(height: 2),
                            Text(
                              v['duration']!,
                              style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.primary),
                            ),
                          ],
                          const SizedBox(height: 2),
                          Text(
                            v['subtitle']!,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted),
                  ],
                ),
              ),
            );
          }),
        ],
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    SessionManager.sessionNotifier.addListener(_onSessionChanged);
    DataSync.changed.addListener(_checkAccepted);
    _checkAccepted();
  }

  /// True once the provider accepted this buyer's booking for this service.
  bool _bookingAccepted = false;

  Future<void> _checkAccepted() async {
    if (!SessionManager.isLoggedIn()) {
      if (_bookingAccepted && mounted) setState(() => _bookingAccepted = false);
      return;
    }
    final txs = await ApiService.fetchBuyerTransactions();
    final svc = widget.service;
    final accepted = txs.any((tx) {
      if ((tx['status'] ?? '').toString().toUpperCase() != 'ACCEPTED') return false;
      final sid = (tx['serviceId'] ?? (tx['service'] is Map ? tx['service']['id'] : null))?.toString();
      if (sid != null && sid.isNotEmpty) return sid == svc.id;
      final seller = tx['seller'];
      final sellerId = (seller is Map ? seller['id'] : tx['sellerId'])?.toString();
      return sellerId != null && sellerId == svc.sellerId?.toString();
    });
    if (mounted && accepted != _bookingAccepted) setState(() => _bookingAccepted = accepted);
  }

  void _onSessionChanged() {
    if (mounted) setState(() {}); // favorite toggled (here or elsewhere)
  }

  @override
  void dispose() {
    DataSync.changed.removeListener(_checkAccepted);
    SessionManager.sessionNotifier.removeListener(_onSessionChanged);
    _tabController.dispose();
    _heroController.dispose();
    _thumbScroll.dispose();
    super.dispose();
  }

  // After the provider accepts the booking, "Book Now" is replaced by navigation
  // to the provider (opens the maps app with directions).
  Widget _navigateButton(ServiceItem service) {
    return ElevatedButton.icon(
      onPressed: () => CallService.navigate(
        context,
        lat: service.latitude,
        lng: service.longitude,
        query: [service.stageName, service.city ?? service.distance].join(' '),
      ),
      icon: const Icon(Icons.navigation_rounded, size: 18, color: Colors.white),
      label: Text(
        AppStrings.isEnglish ? 'Navigate' : 'Elekea Mahali',
        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: Colors.white),
      ),
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.success,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        padding: const EdgeInsets.symmetric(vertical: 14),
      ),
    );
  }

  Widget _contactLine(IconData icon, Color color, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        children: [
          Icon(icon, size: 14, color: color),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final service = widget.service;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: false,
        leading: Padding(
          padding: const EdgeInsets.all(8.0),
          child: InkWell(
            onTap: () => Navigator.pop(context),
            borderRadius: BorderRadius.circular(20),
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.border),
              ),
              child: const Icon(Icons.arrow_back_ios_new_rounded, size: 16, color: AppColors.textPrimary),
            ),
          ),
        ),
        title: Text(
          AppStrings.detailsAboutService,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: InkWell(
              onTap: () => SessionManager.toggleFavorite(widget.service.id),
              borderRadius: BorderRadius.circular(20),
              child: Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.border),
                ),
                child: Icon(
                  _isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                  size: 19,
                  color: _isFavorite ? AppColors.danger : AppColors.slateDark,
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Padding(
            padding: const EdgeInsets.only(top: 8, bottom: 8, right: 16),
            child: InkWell(
              onTap: () => _shareService(service),
              borderRadius: BorderRadius.circular(20),
              child: Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.border),
                ),
                child: const Icon(
                  Icons.share_outlined,
                  size: 19,
                  color: AppColors.slateDark,
                ),
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.only(bottom: 110),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 1. Hero Image with Badges & Counter
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: GestureDetector(
                  onTap: () => _openGallery(_selectedThumbnailIndex),
                  child: Stack(
                  children: [
                    SizedBox(
                      height: 220,
                      width: double.infinity,
                      child: PageView.builder(
                        controller: _heroController,
                        itemCount: _galleryImages.length,
                        onPageChanged: (i) => _selectImage(i),
                        itemBuilder: (ctx, i) => AppImage(
                          _galleryImages[i],
                          height: 220,
                          width: double.infinity,
                          fit: BoxFit.cover,
                          errorBuilder: (ctx, err, stack) => Container(
                            height: 220,
                            color: AppColors.borderLight,
                            child: const Icon(Icons.spa_rounded, size: 64, color: AppColors.textMuted),
                          ),
                        ),
                      ),
                    ),
                    // Verification pill top left (only for verified providers; colour follows their level)
                    if (service.isVerified)
                      Positioned(
                        top: 12,
                        left: 12,
                        child: VerificationPill(level: service.verificationLevel),
                      ),
                    // 1/5 counter bottom right
                    Positioned(
                      bottom: 12,
                      right: 12,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.65),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          '${_selectedThumbnailIndex + 1}/${_galleryImages.length}',
                          style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                  ],
                  ),
                ),
              ),
            ),

            // 2. Thumbnails: scrollable, so any number of images works
            if (_galleryImages.length > 1)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: SizedBox(
                  height: 60,
                  child: ListView.separated(
                    controller: _thumbScroll,
                    scrollDirection: Axis.horizontal,
                    itemCount: _galleryImages.length,
                    separatorBuilder: (_, _) => const SizedBox(width: _thumbGap),
                    itemBuilder: (context, index) {
                      final isSelected = _selectedThumbnailIndex == index;
                      return GestureDetector(
                        onTap: () => _selectImage(index, animateHero: true),
                        child: Container(
                          width: _thumbW,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: isSelected ? AppColors.primary : Colors.transparent,
                              width: 2,
                            ),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: AppImage(
                              _galleryImages[index],
                              fit: BoxFit.cover,
                              errorBuilder: (ctx, err, stack) => Container(color: AppColors.border),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),

            const SizedBox(height: 8),

            // 3. Title, Category, Price & Duration Row
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          service.title,
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        if (service.is18Plus) ...[
                          const SizedBox(height: 6),
                          const Align(alignment: Alignment.centerLeft, child: SensitiveTag()),
                        ],
                        const SizedBox(height: 4),
                        Text(
                          service.subtitle.isNotEmpty ? service.subtitle : 'Professional ${service.category} Services',
                          style: const TextStyle(
                            fontSize: 14,
                            color: AppColors.textSecondary,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        _durations[_selectedDurationIndex]['price'] as String,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                          color: AppColors.primary,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        AppStrings.detailsPerSession,
                        style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 10),

            // Rating & Location row
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  const Icon(Icons.star_rounded, color: AppColors.goldStar, size: 18),
                  const SizedBox(width: 4),
                  Text(
                    '${service.rating}',
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    '(${service.reviewsCount} reviews)',
                    style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
                  ),
                  const Spacer(),
                  const Icon(Icons.location_on_outlined, color: AppColors.primary, size: 15),
                  const SizedBox(width: 4),
                  Text(
                    'Dar es Salaam  •  ${service.distance}',
                    style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontWeight: FontWeight.w500),
                  ),
                  if (service.hasDuration) ...[
                    const SizedBox(width: 10),
                    const Icon(Icons.access_time_rounded, color: AppColors.textSecondary, size: 14),
                    const SizedBox(width: 4),
                    Text(
                      _durations[_selectedDurationIndex]['duration'] as String,
                      style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontWeight: FontWeight.w500),
                    ),
                  ],
                ],
              ),
            ),

            // Social media icons (WhatsApp, Instagram, Facebook, X, TikTok, YouTube)
            SocialLinksRow(service: service),

            const SizedBox(height: 16),

            // 4. Feature Badges Row (Professional, Clean & Safe, NIDA Verified, Available Now)
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  _buildFeaturePill(
                    icon: Icons.check_circle_rounded,
                    iconColor: AppColors.success,
                    bgColor: AppColors.successLight,
                    label: AppStrings.detailsProfessional,
                  ),
                  const SizedBox(width: 8),
                  _buildFeaturePill(
                    icon: Icons.auto_awesome_rounded,
                    iconColor: AppColors.primary,
                    bgColor: AppColors.primaryLight,
                    label: AppStrings.detailsCleanSafe,
                  ),
                  const SizedBox(width: 8),
                  if (service.isVerified) ...[
                    _buildFeaturePill(
                      icon: Icons.verified_user_rounded,
                      iconColor: service.hasBlueTick ? AppColors.primary : AppColors.success,
                      bgColor: service.hasBlueTick ? AppColors.primaryLight : AppColors.successLight,
                      label: service.hasBlueTick ? AppStrings.badgeBlueTick : AppStrings.badgeGreenBadge,
                    ),
                    const SizedBox(width: 8),
                  ],
                  _buildFeaturePill(
                    icon: Icons.circle,
                    iconColor: AppColors.success,
                    bgColor: AppColors.borderLight,
                    label: AppStrings.detailsAvailableNow,
                    iconSize: 8,
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // 5. About This Service Section
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    AppStrings.detailsAboutService,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Enjoy a relaxing and therapeutic massage session designed to reduce stress, relieve muscle tension and improve your overall well-being. Our professional therapists provide a clean, safe and comfortable environment for your comfort.',
                    style: TextStyle(
                      fontSize: 13,
                      height: 1.5,
                      color: AppColors.slateMuted,
                    ),
                  ),
                  const SizedBox(height: 12),
                  if (widget.service.features.isNotEmpty)
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: widget.service.features
                          .map((f) => _buildFeaturePill(
                                icon: Icons.check_circle_rounded,
                                iconColor: AppColors.success,
                                bgColor: AppColors.successLight,
                                label: f,
                                iconSize: 14,
                              ))
                          .toList(),
                    )
                  else ...[
                    _buildCheckBullet('Swedish Massage'),
                    _buildCheckBullet('Deep Tissue Massage'),
                    _buildCheckBullet('Back, Neck & Shoulder Massage'),
                    _buildCheckBullet('Full Body Relaxation'),
                  ],
                ],
              ),
            ),

            const SizedBox(height: 20),

            // 6. Seller Card (Asha Wellness + Blue badge + View Profile button)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.border),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.03),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Stack(
                      clipBehavior: Clip.none,
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(25),
                          child: AppImage(
                            (widget.service.sellerAvatar ?? '').isNotEmpty
                                ? widget.service.sellerAvatar!
                                : 'assets/images/zeen_avatar.jpg',
                            width: 50,
                            height: 50,
                            fit: BoxFit.cover,
                            errorBuilder: (ctx, err, stack) => const CircleAvatar(
                              radius: 25,
                              backgroundColor: AppColors.primary,
                              child: Icon(Icons.person, color: Colors.white),
                            ),
                          ),
                        ),
                        if (service.isVerified)
                          Positioned(
                            bottom: -2,
                            right: -2,
                            child: VerificationBadge(level: service.verificationLevel, size: 18),
                          ),
                      ],
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                service.stageName,
                                style: const TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w800,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                              if (service.isVerified) ...[
                                const SizedBox(width: 4),
                                VerificationBadge(level: service.verificationLevel, size: 15),
                              ],
                            ],
                          ),
                          const SizedBox(height: 2),
                          const Text(
                            'Massage Therapist',
                            style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              const Icon(Icons.star_rounded, color: AppColors.goldStar, size: 14),
                              const SizedBox(width: 3),
                              Text(
                                '${service.rating}',
                                style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                              ),
                              Text(
                                ' (${service.reviewsCount} reviews)',
                                style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Wrap(
                            spacing: 8,
                            children: [
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(Icons.person_outline, size: 12, color: AppColors.textMuted),
                                  const SizedBox(width: 3),
                                  Text('${AppStrings.detailsMemberSince} Jan 2024', style: const TextStyle(fontSize: 10, color: AppColors.textMuted)),
                                ],
                              ),
                              const Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.calendar_month_outlined, size: 12, color: AppColors.textMuted),
                                  SizedBox(width: 3),
                                  Text('256 completed', style: TextStyle(fontSize: 10, color: AppColors.textMuted)),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    OutlinedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => SellerProfileScreen(provider: service),
                          ),
                        );
                      },
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: AppColors.primary),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            AppStrings.detailsViewProfile,
                            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.primary),
                          ),
                          const Icon(Icons.chevron_right_rounded, size: 14, color: AppColors.primary),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 20),

            // 7. Tab Bar (Overview, Portfolio, Reviews, Availability, Location)
            TabBar(
              controller: _tabController,
              isScrollable: true,
              labelColor: AppColors.primary,
              unselectedLabelColor: AppColors.textSecondary,
              labelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
              unselectedLabelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
              indicatorColor: AppColors.primary,
              indicatorWeight: 3,
              tabAlignment: TabAlignment.start,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              onTap: (index) => setState(() {}),
              tabs: [
                Tab(text: AppStrings.detailsTabOverview),
                Tab(text: AppStrings.detailsTabReviews),
                Tab(text: AppStrings.detailsTabAvailability),
                Tab(text: AppStrings.detailsTabLocation),
              ],
            ),

            const Divider(height: 1, color: AppColors.borderLight),

            const SizedBox(height: 16),

            // Tab-specific content
            if (_tabController.index == 0) ...[
              // Overview Tab Content:
              // 1. Service Videos Gallery (Item 2: Videos will be in overview tab)
              _buildVideosSection(),

              const SizedBox(height: 20),

              // 2. Direct Contact & Social Media Info (Locked / Unlocked)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: service.isContactLocked ? AppColors.background : AppColors.primaryLight.withValues(alpha: 0.3),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: service.isContactLocked ? AppColors.border : AppColors.primary.withValues(alpha: 0.3),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Icon(
                                service.isContactLocked ? Icons.lock_outline_rounded : Icons.lock_open_rounded,
                                size: 16,
                                color: service.isContactLocked ? AppColors.textSecondary : AppColors.primary,
                              ),
                              const SizedBox(width: 6),
                              Text(
                                service.isContactLocked ? 'Mawasiliano Yamefungwa (Locked)' : 'Mawasiliano Yako Wazi (Unlocked)',
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w700,
                                  color: service.isContactLocked ? AppColors.textPrimary : AppColors.primary,
                                ),
                              ),
                            ],
                          ),
                          if (service.isContactLocked)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: AppColors.borderLight,
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: const Text('Book to Unlock', style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold)),
                            ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      if (service.isContactLocked)
                        Text(
                          'Mawasiliano na mitandao ya kijamii ya mtoa huduma itafunguliwa mara tu baada ya ombi lako la huduma kuthibitishwa.',
                          style: TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.4),
                        )
                      else ...[
                        if ((service.phone ?? '').trim().isNotEmpty)
                          _contactLine(Icons.phone_outlined, AppColors.primary, service.phone!.trim()),
                        if ((service.whatsappPhone ?? '').trim().isNotEmpty)
                          _contactLine(Icons.chat_bubble_outline_rounded, AppColors.success, service.whatsappPhone!.trim()),
                        if ((service.email ?? '').trim().isNotEmpty)
                          _contactLine(Icons.email_outlined, AppColors.textSecondary, service.email!.trim()),
                        if ((service.instagramUsername ?? '').trim().isNotEmpty)
                          _contactLine(Icons.camera_alt_outlined, const Color(0xFFE1306C), service.instagramUsername!.trim()),
                        if ([service.phone, service.whatsappPhone, service.email, service.instagramUsername]
                            .every((v) => (v ?? '').trim().isEmpty))
                          Text(
                            AppStrings.isEnglish
                                ? 'This provider has not added contact details yet.'
                                : 'Mtoa huduma bado hajaweka mawasiliano.',
                            style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                          ),
                      ],
                    ],
                  ),
                ),
              ),

              if (widget.service.hasDuration) ...[
              const SizedBox(height: 20),

              // 3. Service Duration & Price Section (only when the provider priced by duration)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      AppStrings.detailsServiceDurationPrice,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: List.generate(_durations.length, (index) {
                        final item = _durations[index];
                        final isSelected = _selectedDurationIndex == index;
                        return Expanded(
                          child: GestureDetector(
                            onTap: () => setState(() => _selectedDurationIndex = index),
                            child: Container(
                              margin: EdgeInsets.only(right: index == _durations.length - 1 ? 0 : 8),
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: isSelected ? AppColors.primaryLight : Colors.white,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: isSelected ? AppColors.primary : AppColors.border,
                                  width: isSelected ? 1.8 : 1,
                                ),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        item['duration'] as String,
                                        style: TextStyle(
                                          fontSize: 13,
                                          fontWeight: FontWeight.w700,
                                          color: isSelected ? AppColors.primary : AppColors.textPrimary,
                                        ),
                                      ),
                                      Icon(
                                        isSelected ? Icons.radio_button_checked : Icons.radio_button_off,
                                        size: 16,
                                        color: isSelected ? AppColors.primary : AppColors.textDisabled,
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    item['price'] as String,
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w800,
                                      color: isSelected ? AppColors.primary : AppColors.slateMuted,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      }),
                    ),
                  ],
                ),
              ),
              ],
            ] else if (_tabController.index == 1) ...[
              // Reviews Tab
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Text(
                          '${service.rating}',
                          style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: AppColors.textPrimary),
                        ),
                        const SizedBox(width: 8),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: List.generate(
                                5,
                                (i) => Icon(
                                  i < service.rating.round() ? Icons.star_rounded : Icons.star_outline_rounded,
                                  size: 16,
                                  color: AppColors.goldStar,
                                ),
                              ),
                            ),
                            Text(
                              '${service.reviewsCount} verified reviews',
                              style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ] else if (_tabController.index == 2) ...[
              // Availability Tab
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppColors.background,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text('Saa za Kazi (Working Hours)', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                      SizedBox(height: 8),
                      Text('Jumatatu - Jumamosi: 08:00 AM - 08:00 PM', style: TextStyle(fontSize: 12, color: AppColors.slateMuted)),
                      SizedBox(height: 4),
                      Text('Jumapili: 10:00 AM - 04:00 PM', style: TextStyle(fontSize: 12, color: AppColors.slateMuted)),
                    ],
                  ),
                ),
              ),
            ] else ...[
              // Location Tab
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppColors.background,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.location_pin, color: AppColors.primary, size: 28),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Dar es Salaam, Tanzania', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                            const SizedBox(height: 2),
                            Text('Umbali wa takriban ${service.distance} kutoka ulipo sasa', style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),

      // 9. Bottom Action Bar: Chat | Call | Book Now
      bottomSheet: Container(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.08),
              blurRadius: 16,
              offset: const Offset(0, -4),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (!_bookingAccepted && !(SessionManager.isLoggedIn() && service.sellerId == SessionManager.getUserIdValue()))
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: () async {
                      if (!SessionManager.isLoggedIn()) {
                        final loggedIn = await LoginModal.show(context);
                        if (loggedIn != true) return;
                      }
                      if (!context.mounted) return;
                      final sent = await MakeOfferSheet.show(context, service);
                      if (sent == true && context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            backgroundColor: AppColors.success,
                            content: Text(AppStrings.isEnglish
                                ? 'Offer sent. The seller will respond soon.'
                                : 'Ofa imetumwa. Muuzaji atajibu hivi karibuni.'),
                          ),
                        );
                      }
                    },
                    icon: const Icon(Icons.local_offer_outlined, size: 18, color: AppColors.primary),
                    label: Text(
                      AppStrings.isEnglish ? 'Make an Offer' : 'Toa Ofa',
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.primary),
                    ),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: AppColors.primary),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
              ),
            Row(
          children: [
            // Chat Button
            Expanded(
              flex: 3,
              child: OutlinedButton.icon(
                onPressed: () => ChatThreadScreen.open(
                  context,
                  recipientId: service.sellerId,
                  name: service.stageName,
                ),
                icon: const Icon(Icons.chat_bubble_outline_rounded, size: 18, color: AppColors.textPrimary),
                label: Text(
                  AppStrings.detailsChat,
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                ),
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: AppColors.border),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
              ),
            ),
            const SizedBox(width: 8),

            // Call Button: opens the call options pop-up
            // (locked contacts -> in-app audio only; unlocked -> audio, video, mobile)
            Expanded(
              flex: 3,
              child: OutlinedButton.icon(
                onPressed: () => CallOptionsSheet.show(context, service),
                icon: const Icon(Icons.phone_outlined, size: 18, color: AppColors.primary),
                label: Text(
                  AppStrings.isEnglish ? 'Call' : 'Piga Simu',
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.primary),
                ),
                style: OutlinedButton.styleFrom(
                  backgroundColor: AppColors.primaryLight,
                  side: const BorderSide(color: AppColors.border),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
              ),
            ),
            const SizedBox(width: 8),

            // Book Now Button
            Expanded(
              flex: 5,
              child: _bookingAccepted ? _navigateButton(service) : ElevatedButton.icon(
                onPressed: () async {
                  if (!SessionManager.isLoggedIn()) {
                    final loggedIn = await LoginModal.show(context);
                    if (loggedIn != true) return;
                  }

                  if (context.mounted) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => BookingRequestScreen(
                          provider: service,
                          serviceTitle: service.title,
                          priceText: _durations[_selectedDurationIndex]['price'] as String,
                          durationText: _durations[_selectedDurationIndex]['duration'] as String,
                        ),
                      ),
                    );
                  }
                },
                icon: const Icon(Icons.calendar_month_rounded, size: 18, color: Colors.white),
                label: Text(
                  AppStrings.detailsBookNow,
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: Colors.white),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
              ),
            ),
          ],
        ),
          ],
        ),
      ),
    );
  }

  Widget _buildFeaturePill({
    required IconData icon,
    required Color iconColor,
    required Color bgColor,
    required String label,
    double iconSize = 14,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: iconColor, size: iconSize),
          const SizedBox(width: 6),
          Text(
            label,
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: AppColors.slateMuted,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCheckBullet(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        children: [
          const Icon(Icons.check_circle_rounded, color: AppColors.success, size: 16),
          const SizedBox(width: 8),
          Text(
            text,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w500,
              color: AppColors.slateMuted,
            ),
          ),
        ],
      ),
    );
  }
}

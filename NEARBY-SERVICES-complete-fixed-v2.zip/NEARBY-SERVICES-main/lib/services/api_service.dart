import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../security/attestation.dart';
import '../security/secure_http.dart';
import '../security/security_config.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/boost.dart';
import '../models/models.dart';
import 'block_service.dart';
import 'data_sync.dart';
import 'gps_service.dart';
import 'security_settings.dart';
import 'session_manager.dart';

/// Debug-only logging; never prints in release builds and callers must not pass
/// response bodies, tokens, OTPs or phone numbers.
void _log(String message) {
  if (kDebugMode) debugPrint(message);
}

/// What a chat message carries besides text. Attachments travel as a link to our
/// own server in the message text, so /chats/send needs no change.
enum ChatAttachmentKind { image, audio, file }

/// Result of a media upload: [ok] with the file's public [url] (when the
/// endpoint returns one), or a readable [error].
class UploadResult {
  final String? url;
  final String? error;
  const UploadResult({this.url, this.error});
  bool get ok => error == null;
}

/// Result of an invitation call: [ok] with the server's [data], or a readable
/// [error] already worded for the user.
class InviteResult {
  final Map<String, dynamic> data;
  final String? error;
  const InviteResult({this.data = const {}, this.error});
  bool get ok => error == null;
}

/// Thin wrapper over package:http that signs the user out when the server says
/// the token is invalid/expired (401), so a stolen/expired token is not kept.
class _Http {
  static Future<http.Response> get(Uri url, {Map<String, String>? headers}) async =>
      _check(headers, await SecureHttp.client.get(url, headers: headers));

  static Future<http.Response> post(Uri url, {Map<String, String>? headers, Object? body}) async {
    final h = await Attestation.attach(url, headers); // Play Integrity token on sensitive calls
    return _written(_check(h, await SecureHttp.client.post(url, headers: h, body: body)));
  }

  static Future<http.Response> put(Uri url, {Map<String, String>? headers, Object? body}) async =>
      _written(_check(headers, await SecureHttp.client.put(url, headers: headers, body: body)));

  static Future<http.Response> delete(Uri url, {Map<String, String>? headers}) async =>
      _written(_check(headers, await SecureHttp.client.delete(url, headers: headers)));

  /// A successful write means server data changed: tell every listening screen.
  static http.Response _written(http.Response r) {
    if (r.statusCode >= 200 && r.statusCode < 300) DataSync.bump();
    return r;
  }

  static http.Response _check(Map<String, String>? headers, http.Response r) {
    final hadToken = headers?.containsKey('Authorization') ?? false;
    if (r.statusCode == 401 && hadToken) {
      SessionManager.clearSession();
    }
    return r;
  }
}

class ApiService {
  static String get baseUrl => SecurityConfig.apiBase;

  /// Converts backend error code or message into dynamically localized text based on AppStrings
  static String normalizeError(dynamic rawError) {
    if (rawError == null) return AppStrings.error;
    final msg = rawError.toString().trim();
    if (msg.isEmpty) return AppStrings.error;

    if (msg.contains('ACCOUNT_NOT_VERIFIED') || msg.toLowerCase().contains('haijathibitishwa') || msg.toLowerCase().contains('not verified')) {
      return AppStrings.authAccountNotVerifiedError;
    }
    if (msg.contains('INVALID_CREDENTIALS') || msg.toLowerCase().contains('bad credentials') || msg.toLowerCase().contains('invalid login credentials')) {
      return AppStrings.authInvalidCredentialsError;
    }
    if (msg.contains('PHONE_ALREADY_REGISTERED') || msg.toLowerCase().contains('phone number is already registered')) {
      return AppStrings.authPhoneExistsError;
    }
    if (msg.contains('EMAIL_ALREADY_REGISTERED') || msg.toLowerCase().contains('email is already registered')) {
      return AppStrings.authEmailExistsError;
    }
    if (msg.contains('USERNAME_ALREADY_TAKEN') || msg.toLowerCase().contains('username is already taken')) {
      return AppStrings.authUsernameExistsError;
    }
    if (msg.contains('USER_NOT_FOUND') || msg.toLowerCase().contains('user not found') || msg.toLowerCase().contains('hajapatikana')) {
      return AppStrings.authUserNotFoundError;
    }
    if (msg.contains('INVALID_PHONE_NUMBER') || msg.toLowerCase().contains('invalid phone')) {
      return AppStrings.authInvalidPhoneError;
    }
    if (msg.contains('INVALID_OR_EXPIRED_OTP') || msg.contains('INVALID_OTP_FORMAT') || msg.toLowerCase().contains('invalid or expired otp')) {
      return AppStrings.authInvalidOtpError;
    }
    if (msg.contains('SocketException') || msg.contains('TimeoutException') || msg.toLowerCase().contains('network') || msg.toLowerCase().contains('haikuweza kuunganisha')) {
      return AppStrings.authNetworkError;
    }
    return msg;
  }

  static Map<String, String> _getHeaders() {
    final headers = <String, String>{
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };
    final token = SessionManager.getToken();
    if (token != null && token.isNotEmpty) {
      headers['Authorization'] = 'Bearer $token';
    }
    return headers;
  }

  // ---------------------------------------------------------------------------
  // AUTH (register / OTP / forgot + reset password / login)
  // ---------------------------------------------------------------------------

  /// Why the LAST auth call did not get a real answer from the server:
  /// 'network' (offline / timeout), 'server' (5xx / unreadable reply), 'ratelimit' (429), or null.
  /// Screens use it to show the right message and NOT to count it as a wrong password / OTP.
  static String? lastAuthProblem;

  /// The user-facing text for [lastAuthProblem].
  static String authProblemMessage([String? problem]) {
    switch (problem ?? lastAuthProblem) {
      case 'ratelimit':
        return AppStrings.authRateLimitedError;
      case 'server':
        return AppStrings.authServerBusyError;
      default:
        return AppStrings.authNetworkError;
    }
  }

  /// Decodes a JSON object body; returns null (never throws) for HTML / empty / non-object replies.
  static Map<String, dynamic>? _decodeObj(String body) {
    try {
      final d = json.decode(body);
      if (d is Map<String, dynamic>) return d;
      if (d is Map) return Map<String, dynamic>.from(d);
    } catch (_) {}
    return null;
  }

  /// Sets [lastAuthProblem] from a status code; true when the reply is NOT a real answer.
  static bool _flagProblem(http.Response r) {
    if (r.statusCode == 429) {
      lastAuthProblem = 'ratelimit';
      return true;
    }
    if (r.statusCode >= 500) {
      lastAuthProblem = 'server';
      return true;
    }
    return false;
  }

  static bool _isOk(int code) => code == 200 || code == 201;

  static String _msgOf(Map<String, dynamic>? d, String fallback) {
    final v = d?['message'] ?? d?['error'];
    return (v is String && v.trim().isNotEmpty) ? v : fallback;
  }

  static const Duration _authTimeout = Duration(seconds: 25);

  /// Register a new user
  static Future<Map<String, dynamic>?> register({
    required String username,
    required String phone,
    String? email,
    required String password,
    required String stageName,
    String role = 'ROLE_BUYER',
  }) async {
    lastAuthProblem = null;
    // Last line of defence (the screens validate first): refuse impossible input
    // instead of sending it, and never let a caller pick any role but these two.
    if (phone.trim().isEmpty ||
        password.isEmpty ||
        password.length > 128 ||
        stageName.trim().isEmpty ||
        stageName.length > 120 ||
        username.length > 60 ||
        (role != 'ROLE_BUYER' && role != 'ROLE_SELLER')) {
      return {'success': false, 'error': AppStrings.error};
    }
    try {
      final payload = <String, dynamic>{
        'username': username,
        'phone': phone,
        'password': password,
        'stageName': stageName,
        'role': role,
      };
      if (email != null && email.trim().isNotEmpty) {
        payload['email'] = email.trim();
      }

      final response = await _Http.post(
        Uri.parse('$baseUrl/auth/register'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(payload),
      ).timeout(_authTimeout);

      if (_flagProblem(response)) {
        return {'success': false, 'error': authProblemMessage(), 'problem': lastAuthProblem};
      }
      final data = _decodeObj(response.body);
      if (_isOk(response.statusCode)) {
        // Do NOT establish session here. User must verify OTP first!
        return {'success': true, 'data': data ?? <String, dynamic>{}};
      }
      return {'success': false, 'error': normalizeError(_msgOf(data, 'Registration failed (${response.statusCode})'))};
    } catch (e) {
      _log('Registration error: ${e.runtimeType}');
      lastAuthProblem = 'network';
      return {'success': false, 'error': AppStrings.authNetworkError, 'problem': 'network'};
    }
  }

  /// Shared body of the four "send / verify a code" calls.
  static Future<Map<String, dynamic>?> _otpCall(String path, Map<String, String> body) async {
    lastAuthProblem = null;
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl$path'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(body),
      ).timeout(_authTimeout);
      if (_flagProblem(response)) return null;
      final data = _decodeObj(response.body);
      if (_isOk(response.statusCode) && data != null && data['success'] == true) return data;
      return null;
    } catch (e) {
      _log('OTP call error: ${e.runtimeType}');
      lastAuthProblem = 'network';
      return null;
    }
  }

  /// Verify 6-digit OTP sent to user's email
  static Future<bool> verifyEmailOtp(String email, String otp) async =>
      await _otpCall('/auth/verify-otp', {'email': email.trim(), 'otp': otp.trim()}) != null;

  /// Resend 6-digit OTP code to user's email
  static Future<bool> resendEmailOtp(String email) async =>
      await _otpCall('/auth/resend-otp', {'email': email.trim()}) != null;

  /// Verify 6-digit OTP sent to user's phone via SMS Gateway Pro.
  /// Returns null on failure; check [lastAuthProblem] to tell "wrong code" from "no connection".
  static Future<Map<String, dynamic>?> verifyPhoneOtp(String phone, String otp) =>
      _otpCall('/auth/phone/verify-otp', {'phone': phone.trim(), 'otp': otp.trim()});

  /// Resend 6-digit OTP code to user's phone via SMS Gateway Pro
  static Future<bool> resendPhoneOtp(String phone) async =>
      await _otpCall('/auth/phone/resend-otp', {'phone': phone.trim()}) != null;

  /// Request OTP for password reset (via SMS or Email).
  ///
  /// Anti-enumeration: "no such account" and "account not verified" are reported exactly like
  /// success ("if this account exists, a code was sent"), so nobody can use this screen to find
  /// out which phone numbers or emails are registered.
  static Future<Map<String, dynamic>> forgotPassword(String identifier) async {
    lastAuthProblem = null;
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/auth/forgot-password'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'identifier': identifier.trim()}),
      ).timeout(_authTimeout);

      if (_flagProblem(response)) {
        return {'success': false, 'message': authProblemMessage(), 'problem': lastAuthProblem};
      }
      final data = _decodeObj(response.body);
      if (_isOk(response.statusCode) && data?['success'] == true) {
        return {'success': true, 'message': AppStrings.authResetIfExists};
      }
      final raw = _msgOf(data, '');
      if (raw.contains('USER_NOT_FOUND') ||
          raw.contains('ACCOUNT_NOT_VERIFIED') ||
          response.statusCode == 404) {
        return {'success': true, 'message': AppStrings.authResetIfExists, 'generic': true};
      }
      return {'success': false, 'message': normalizeError(raw.isEmpty ? AppStrings.error : raw), 'rawCode': raw};
    } catch (e) {
      _log('Forgot Password error: ${e.runtimeType}');
      lastAuthProblem = 'network';
      return {'success': false, 'message': AppStrings.authNetworkError, 'problem': 'network'};
    }
  }

  /// Reset password using OTP
  static Future<Map<String, dynamic>> resetPassword(String identifier, String otp, String newPassword) async {
    lastAuthProblem = null;
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/auth/reset-password'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'identifier': identifier.trim(),
          'otp': otp.trim(),
          'newPassword': newPassword,
        }),
      ).timeout(_authTimeout);

      if (_flagProblem(response)) {
        return {'success': false, 'message': authProblemMessage(), 'problem': lastAuthProblem};
      }
      final data = _decodeObj(response.body);
      if (_isOk(response.statusCode) && data?['success'] == true) {
        return {'success': true, 'message': _msgOf(data, 'Password reset successfully')};
      }
      // Any server-side refusal (wrong/expired code, unknown account, weak password) -> one safe message,
      // unless the server clearly says the password itself is the problem.
      final raw = _msgOf(data, 'INVALID_OR_EXPIRED_OTP');
      final weak = raw.toLowerCase().contains('password');
      return {
        'success': false,
        'message': weak ? raw : AppStrings.authInvalidOtpError,
      };
    } catch (e) {
      _log('Reset Password error: ${e.runtimeType}');
      lastAuthProblem = 'network';
      return {'success': false, 'message': AppStrings.authNetworkError, 'problem': 'network'};
    }
  }

  /// Authenticate user via username or phone and password
  static Future<Map<String, dynamic>?> login(String login, String password) async {
    lastAuthProblem = null;
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/auth/login'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'login': login, 'password': password}),
      ).timeout(_authTimeout);

      if (_flagProblem(response)) {
        return {'success': false, 'error': authProblemMessage(), 'problem': lastAuthProblem};
      }
      final data = _decodeObj(response.body);
      if (_isOk(response.statusCode)) {
        final token = data?['token'];
        if (data == null || token is! String || token.isEmpty) {
          // 200 without a usable token: never half-login.
          lastAuthProblem = 'server';
          return {'success': false, 'error': AppStrings.authServerBusyError, 'problem': 'server'};
        }
        final idRaw = data['id'];
        await SessionManager.saveSession(
          token: token,
          userId: idRaw is int ? idRaw : (int.tryParse('${idRaw ?? ''}') ?? 0),
          username: (data['username'] ?? login).toString(),
          stageName: (data['stageName'] ?? 'User').toString(),
          role: (data['role'] ?? 'ROLE_BUYER').toString(),
          badge: (data['verificationBadge'] ?? 'NONE').toString(),
        );
        // Restore the profile photo on a new phone (when the server sends it).
        final avatar = (data['avatarUrl'] ?? data['profileImage'] ?? data['profilePhoto'])?.toString().trim() ?? '';
        if (avatar.isNotEmpty && avatar != 'null') await SessionManager.saveAvatarUrl(absoluteUrl(avatar));
        // Do not hand the raw token back to screens.
        return {'success': true, 'data': ({...data}..remove('token'))};
      }

      final rawCode = (data?['message'] is String) ? data!['message'] as String : '';
      final msg = _msgOf(data, 'Login failed (${response.statusCode})');
      // Anti-enumeration: "unknown user" and "wrong password" look the same. Only the
      // "not verified" state keeps its own message because the app must guide the user to verify.
      final notVerified = rawCode.contains('ACCOUNT_NOT_VERIFIED') || msg.toLowerCase().contains('not verified');
      final generic = !notVerified &&
          (response.statusCode == 400 ||
              response.statusCode == 401 ||
              response.statusCode == 404 ||
              rawCode.contains('USER_NOT_FOUND') ||
              rawCode.contains('INVALID_CREDENTIALS') ||
              msg.toLowerCase().contains('bad credentials'));
      return {
        'success': false,
        'error': generic ? AppStrings.authInvalidCredentialsError : normalizeError(msg),
        'rawCode': notVerified ? 'ACCOUNT_NOT_VERIFIED' : rawCode,
      };
    } catch (e) {
      _log('Login error: ${e.runtimeType}');
      lastAuthProblem = 'network';
      return {'success': false, 'error': AppStrings.authNetworkError, 'problem': 'network'};
    }
  }

  /// Fetch wallet balance for the authenticated user
  static Future<Map<String, dynamic>?> getWallet() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/wallet'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body);
      }
      return null;
    } catch (e) {
      _log('Wallet fetch error: $e');
      return null;
    }
  }

  /// Deposit funds into Pocket Fund
  static Future<Map<String, dynamic>?> depositWallet(double amount) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/wallet/deposit'),
        headers: _getHeaders(),
        body: json.encode({'amount': amount}),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body);
      }
      return null;
    } catch (e) {
      _log('Deposit error: $e');
      return null;
    }
  }

  /// Withdraw funds from Pocket Fund
  static Future<Map<String, dynamic>?> withdrawWallet(double amount, String phone) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/wallet/withdraw'),
        headers: _getHeaders(),
        body: json.encode({'amount': amount, 'phone': phone}),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body);
      }
      return null;
    } catch (e) {
      _log('Withdraw error: $e');
      return null;
    }
  }

  /// Apply for Green Badge with 20-digit NIDA number
  static Future<Map<String, dynamic>?> applyGreenBadge({
    required String nidaNumber,
    String? officialFirstName,
    String? officialLastName,
  }) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/verification/green-badge'),
        headers: _getHeaders(),
        body: json.encode({
          'nidaNumber': nidaNumber.trim(),
          'officialFirstName': officialFirstName?.trim(),
          'officialLastName': officialLastName?.trim(),
        }),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body);
      }
      return null;
    } catch (e) {
      _log('Apply green badge error: $e');
      return null;
    }
  }

  /// Apply for Blue Tick with ID photos or Guarantor Invitation
  static Future<Map<String, dynamic>?> applyBlueTick({
    String? nidaNumber,
    String? idPhotoUrl,
    String? selfieWithIdUrl,
    int? inviterUserId,
  }) async {
    try {
      final payload = <String, dynamic>{};
      if (nidaNumber != null) payload['nidaNumber'] = nidaNumber.trim();
      if (idPhotoUrl != null) payload['idPhotoUrl'] = idPhotoUrl;
      if (selfieWithIdUrl != null) payload['selfieWithIdUrl'] = selfieWithIdUrl;
      if (inviterUserId != null) payload['inviterUserId'] = inviterUserId;

      final response = await _Http.post(
        Uri.parse('$baseUrl/verification/blue-tick'),
        headers: _getHeaders(),
        body: json.encode(payload),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body);
      }
      return null;
    } catch (e) {
      _log('Apply blue tick error: $e');
      return null;
    }
  }

  // ---------------------------------------------------------------------------
  // Trusted invitations (a Blue Tick provider vouches for someone they know)
  // ---------------------------------------------------------------------------
  // Backend contract: docs/invitation_api_contract.md. The server decides who
  // may invite and who gets the tick; the app only shows the outcome.

  /// Worded, localized message for an invitation error code from the server.
  static String _inviteError(int status, dynamic body) {
    final isEn = AppStrings.isEnglish;
    var raw = '';
    if (body is Map) raw = (body['message'] ?? body['error'] ?? body['code'] ?? '').toString();
    final up = raw.toUpperCase();
    if (up.contains('INVITER_NOT_BLUE_TICK') || status == 403) {
      return isEn ? 'Only providers with a Blue Tick can invite others.' : 'Ni watoa huduma wenye Blue Tick pekee wanaoweza kualika wengine.';
    }
    if (up.contains('INVITE_LIMIT')) {
      return isEn ? 'You have reached your invitation limit for now.' : 'Umefikia kikomo cha mialiko kwa sasa.';
    }
    if (up.contains('ALREADY_INVITED')) {
      return isEn ? 'You already invited this number.' : 'Umeshamwalika namba hii.';
    }
    if (up.contains('ALREADY_VERIFIED')) {
      return isEn ? 'This person already has a verification badge.' : 'Mtu huyu tayari ana beji ya uthibitisho.';
    }
    if (up.contains('SELF_INVITE')) {
      return isEn ? 'You cannot invite yourself.' : 'Huwezi kujialika mwenyewe.';
    }
    if (up.contains('INVALID_NIN')) {
      return isEn ? 'The NIN must be exactly 20 digits.' : 'NIN lazima iwe na tarakimu 20.';
    }
    if (up.contains('NIN_ALREADY_USED')) {
      return isEn ? 'This NIN is already used on another account.' : 'NIN hii tayari inatumika kwenye akaunti nyingine.';
    }
    if (up.contains('INVITE_PHONE_MISMATCH')) {
      return isEn ? 'This invitation was sent to a different phone number.' : 'Mwaliko huu ulitumwa kwa namba nyingine ya simu.';
    }
    if (up.contains('INVITE_INVALID') || up.contains('INVITE_EXPIRED') || up.contains('INVITE_NOT_FOUND') || status == 404) {
      return isEn ? 'This invitation code is not valid or has expired.' : 'Msimbo wa mwaliko si sahihi au umeisha muda.';
    }
    if (raw.isNotEmpty && !RegExp(r'^[A-Z_]+$').hasMatch(raw)) return raw;
    return isEn ? 'Something went wrong. Please try again.' : 'Kuna tatizo. Tafadhali jaribu tena.';
  }

  static Future<InviteResult> _inviteCall(Future<http.Response> Function() send, String tag) async {
    try {
      final response = await send().timeout(const Duration(seconds: 15));
      dynamic body;
      try {
        body = json.decode(response.body);
      } catch (_) {}
      if (response.statusCode >= 200 && response.statusCode < 300) {
        return InviteResult(data: body is Map ? Map<String, dynamic>.from(body) : const {});
      }
      return InviteResult(error: _inviteError(response.statusCode, body));
    } catch (e) {
      _log('$tag error: $e');
      return InviteResult(error: AppStrings.authNetworkError);
    }
  }

  /// Blue Tick provider invites someone by phone. Returns {code, ...}.
  /// POST /verification/invitations  {inviteePhone}
  static Future<InviteResult> createInvitation({required String inviteePhone}) {
    return _inviteCall(
      () => _Http.post(
        Uri.parse('$baseUrl/verification/invitations'),
        headers: _getHeaders(),
        body: json.encode({'inviteePhone': inviteePhone.trim()}),
      ),
      'Create invitation',
    );
  }

  /// Invitations I sent (and received); each {code, status, direction, name?, phone?}.
  /// Returns null when the list could not be loaded.
  /// GET /verification/invitations
  static Future<List<dynamic>?> fetchInvitations() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/verification/invitations'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final d = json.decode(response.body);
        if (d is List) return d;
        if (d is Map && d['invitations'] is List) return d['invitations'] as List;
      }
      return null;
    } catch (e) {
      _log('Fetch invitations error: $e');
      return null;
    }
  }

  /// Invitations addressed to me that are still waiting: {code, inviterName?}.
  /// Empty when none or when the list could not be loaded.
  static Future<List<Map<String, dynamic>>> fetchPendingReceivedInvitations() async {
    final raw = await fetchInvitations();
    if (raw == null) return const [];
    return [
      for (final e in raw)
        if (e is Map &&
            e['direction']?.toString().toUpperCase() == 'RECEIVED' &&
            (e['status'] ?? 'PENDING').toString().toUpperCase() == 'PENDING')
          Map<String, dynamic>.from(e),
    ];
  }

  /// The invited person accepts with the code and their own 20-digit NIN.
  /// On success the server grants the Blue Tick and records both people as
  /// knowing and trusting each other. POST /verification/invitations/accept
  static Future<InviteResult> acceptInvitation({required String code, required String nidaNumber}) async {
    final res = await _inviteCall(
      () => _Http.post(
        Uri.parse('$baseUrl/verification/invitations/accept'),
        headers: _getHeaders(),
        body: json.encode({'code': code.trim(), 'nidaNumber': nidaNumber.trim()}),
      ),
      'Accept invitation',
    );
    if (res.ok) await SessionManager.saveBadge('BLUE_TICK');
    return res;
  }

  /// Optional service fields; only sent when filled in.
  static Map<String, dynamic> _serviceExtras({
    String? area,
    int? serviceRadiusKm,
    String? priceType,
    int? durationMinutes,
    List<String> availableDays = const [],
    String? availableFrom,
    String? availableTo,
    String? instagramUsername,
    String? facebookUsername,
    String? tiktokUsername,
    String? xUsername,
    String? youtubeUsername,
    List<String> features = const [],
    String? featuredImageUrl,
  }) {
    String? clean(String? v) {
      final t = v?.trim().replaceFirst(RegExp(r'^@'), '') ?? '';
      return t.isEmpty ? null : t;
    }

    final m = <String, dynamic>{};
    final a = area?.trim() ?? '';
    if (a.isNotEmpty) m['area'] = a;
    if (serviceRadiusKm != null) m['serviceRadiusKm'] = serviceRadiusKm;
    if (priceType != null && priceType.isNotEmpty) m['priceType'] = priceType;
    // Always sent: a number = price per that duration, null = price only (also clears an old duration on edit).
    m['durationMinutes'] = (durationMinutes != null && durationMinutes > 0) ? durationMinutes : null;
    if (availableDays.isNotEmpty) m['availableDays'] = availableDays;
    if (availableFrom != null) m['availableFrom'] = availableFrom;
    if (availableTo != null) m['availableTo'] = availableTo;
    // Always sent (even empty) so removing every feature on edit clears them.
    m['features'] = features;
    if (featuredImageUrl != null && featuredImageUrl.isNotEmpty) m['featuredImageUrl'] = featuredImageUrl;
    final socials = {
      'instagramUsername': clean(instagramUsername),
      'facebookUsername': clean(facebookUsername),
      'tiktokUsername': clean(tiktokUsername),
      'xUsername': clean(xUsername),
      'youtubeUsername': clean(youtubeUsername),
    };
    socials.forEach((k, v) {
      if (v != null) m[k] = v;
    });
    return m;
  }

  /// Create a new Service Post (Seller)
  static Future<Map<String, dynamic>?> createServicePost({
    required String title,
    required String description,
    required String category,
    required double price,
    String? city,
    String? phone,
    String? whatsappPhone,
    String? email,
    bool isInfoLocked = true,
    List<String> imageUrls = const [],
    List<String> videoUrls = const [],
    bool is18Plus = false,
    String? area,
    int? serviceRadiusKm,
    String? priceType,
    int? durationMinutes,
    List<String> availableDays = const [],
    String? availableFrom,
    String? availableTo,
    String? instagramUsername,
    String? facebookUsername,
    String? tiktokUsername,
    String? xUsername,
    String? youtubeUsername,
    List<String> features = const [],
    String? featuredImageUrl,
    Map<String, dynamic> pricing = const {}, // discount + offer settings (see NEGOTIATION_FLOW.md)
  }) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/services'),
        headers: _getHeaders(),
        body: json.encode({
          'title': title.trim(),
          'description': description.trim(),
          'category': category.trim(),
          'price': price,
          'city': city?.trim() ?? 'Dar es Salaam',
          'phone': phone?.trim(),
          'whatsappPhone': whatsappPhone?.trim(),
          'email': email?.trim(),
          'isInfoLocked': isInfoLocked,
          'imageUrls': imageUrls,
          'videoUrls': videoUrls,
          'is18Plus': is18Plus,
          ..._serviceExtras(
            area: area,
            serviceRadiusKm: serviceRadiusKm,
            priceType: priceType,
            durationMinutes: durationMinutes,
            availableDays: availableDays,
            availableFrom: availableFrom,
            availableTo: availableTo,
            instagramUsername: instagramUsername,
            facebookUsername: facebookUsername,
            tiktokUsername: tiktokUsername,
            xUsername: xUsername,
            youtubeUsername: youtubeUsername,
            features: features,
            featuredImageUrl: featuredImageUrl,
          ),
          ...pricing,
        }),
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200 || response.statusCode == 201) {
        lastServiceError = null;
        return _decodeMap(response.body);
      }
      lastServiceError = _httpErrorText(response.statusCode, response.body);
      _log('Create service failed: ${response.statusCode}');
      return null;
    } catch (e) {
      lastServiceError = _exceptionText(e);
      _log('Create service error: $e');
      return null;
    }
  }

  /// Update an existing Service Post (Seller) - used by the Edit Service page
  static Future<Map<String, dynamic>?> updateServicePost({
    required String id,
    required String title,
    required String description,
    required String category,
    required double price,
    String? city,
    String? phone,
    String? whatsappPhone,
    String? email,
    bool isInfoLocked = true,
    List<String> imageUrls = const [],
    List<String> videoUrls = const [],
    bool is18Plus = false,
    String? area,
    int? serviceRadiusKm,
    String? priceType,
    int? durationMinutes,
    List<String> availableDays = const [],
    String? availableFrom,
    String? availableTo,
    String? instagramUsername,
    String? facebookUsername,
    String? tiktokUsername,
    String? xUsername,
    String? youtubeUsername,
    List<String> features = const [],
    String? featuredImageUrl,
    Map<String, dynamic> pricing = const {},
  }) async {
    try {
      final response = await _Http.put(
        Uri.parse('$baseUrl/services/$id'),
        headers: _getHeaders(),
        body: json.encode({
          'title': title.trim(),
          'description': description.trim(),
          'category': category.trim(),
          'price': price,
          'city': city?.trim() ?? 'Dar es Salaam',
          'phone': phone?.trim(),
          'whatsappPhone': whatsappPhone?.trim(),
          'email': email?.trim(),
          'isInfoLocked': isInfoLocked,
          'imageUrls': imageUrls,
          'videoUrls': videoUrls,
          'is18Plus': is18Plus,
          ..._serviceExtras(
            area: area,
            serviceRadiusKm: serviceRadiusKm,
            priceType: priceType,
            durationMinutes: durationMinutes,
            availableDays: availableDays,
            availableFrom: availableFrom,
            availableTo: availableTo,
            instagramUsername: instagramUsername,
            facebookUsername: facebookUsername,
            tiktokUsername: tiktokUsername,
            xUsername: xUsername,
            youtubeUsername: youtubeUsername,
            features: features,
            featuredImageUrl: featuredImageUrl,
          ),
          ...pricing,
        }),
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200 || response.statusCode == 201) {
        lastServiceError = null;
        return _decodeMap(response.body);
      }
      lastServiceError = _httpErrorText(response.statusCode, response.body);
      _log('Update service failed: ${response.statusCode}');
      return null;
    } catch (e) {
      lastServiceError = _exceptionText(e);
      _log('Update service error: $e');
      return null;
    }
  }

  /// Fetch Seller's published services
  static Future<List<dynamic>> fetchSellerServices() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/services/seller/my-services'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body) as List;
      }
      return [];
    } catch (e) {
      _log('Fetch seller services error: $e');
      return [];
    }
  }

  // ---- Card payments (hosted checkout) --------------------------------------
  // The app NEVER sees or stores card numbers: the backend creates a checkout
  // session with the payment gateway and the customer pays on the gateway's own
  // https page. NOTE: these two endpoints must exist on the backend:
  //   POST /payments/card/checkout        {amount, purpose, reference, description, phone?}
  //                                       -> {checkoutUrl, reference}
  //   GET  /payments/card/status/{ref}    -> {status: PAID | PENDING | FAILED | CANCELLED}
  static Future<Map<String, dynamic>?> createCardCheckout({
    required double amount,
    required String purpose, // e.g. PROVIDER_REGISTRATION, BOOKING
    required String reference,
    String? description,
    String? phone,
  }) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/payments/card/checkout'),
        headers: _getHeaders(),
        body: json.encode({
          'amount': amount,
          'purpose': purpose,
          'reference': reference,
          'description': description,
          'phone': phone,
        }),
      ).timeout(const Duration(seconds: 15));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data is Map<String, dynamic> && (data['checkoutUrl'] ?? '').toString().isNotEmpty) {
          return data;
        }
      }
      _log('Card checkout failed: ${response.statusCode}');
      return null;
    } catch (e) {
      _log('Card checkout error: $e');
      return null;
    }
  }

  /// Returns PAID, PENDING, FAILED or CANCELLED (PENDING on any network problem).
  static Future<String> getCardPaymentStatus(String reference) async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/payments/card/status/${Uri.encodeComponent(reference)}'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return (data['status'] ?? 'PENDING').toString().toUpperCase();
      }
    } catch (e) {
      _log('Card status error: $e');
    }
    return 'PENDING';
  }

  /// Create an Escrow booking transaction (lock funds)
  static Future<Map<String, dynamic>?> createEscrow({
    required int sellerId,
    int? serviceId,
    required double amount,
    required String paymentMethod, // 'POCKET_FUND', 'DIRECT' or 'OFFLINE'
    String? notes,
    String? directChannel, // mobile_money | card | lipa (when paymentMethod is DIRECT)
    String? offlineChannel, // cash | transfer (when paymentMethod is OFFLINE)
    String? offerId, // an AGREED offer: the server then takes the price from the offer
  }) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/escrow/create'),
        headers: _getHeaders(),
        body: json.encode({
          'sellerId': sellerId,
          'serviceId': serviceId,
          'amount': amount,
          'paymentMethod': paymentMethod,
          'notes': notes,
          if (directChannel != null) 'directChannel': directChannel,
          if (offlineChannel != null) 'offlineChannel': offlineChannel,
          if (offerId != null && offerId.isNotEmpty) 'offerId': offerId,
        }),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        _log('Failed to create escrow: ${response.statusCode}');
        return null;
      }
    } catch (e) {
      _log('Create escrow error: $e');
      return null;
    }
  }

  /// Why the last offer call failed (shown to the user), or null after a success.
  static String? lastOfferError;

  /// Buyer proposes their own price for a service.
  /// Backend: POST /offers {serviceId, sellerId, amount, listedPrice, message}
  /// The reply is the offer: {id, status: OFFERED | AGREED (seller's auto-accept price), agreedAmount,
  /// expiresAt ...}. An offer below the seller's private minimum fails with a message
  /// (the minimum itself is never sent to the app).
  static Future<Map<String, dynamic>?> makeOffer({
    int? serviceId,
    int? sellerId,
    required double amount,
    required double listedPrice,
    String? message,
  }) =>
      _offerCall(
        '/offers',
        {
          'serviceId': serviceId,
          'sellerId': sellerId,
          'amount': amount,
          'listedPrice': listedPrice,
          if (message != null && message.isNotEmpty) 'message': message,
        },
      );

  /// Seller accepts the buyer's price -> AGREED.   POST /offers/{id}/accept
  static Future<Map<String, dynamic>?> acceptOffer(String id) => _offerCall('/offers/${Uri.encodeComponent(id)}/accept');

  /// Seller turns the offer down.                  POST /offers/{id}/reject {reason}
  static Future<Map<String, dynamic>?> rejectOffer(String id, {String? reason}) => _offerCall(
        '/offers/${Uri.encodeComponent(id)}/reject',
        {if (reason != null && reason.trim().isNotEmpty) 'reason': reason.trim()},
      );

  /// Buyer takes the offer back.                   POST /offers/{id}/withdraw
  static Future<Map<String, dynamic>?> withdrawOffer(String id) => _offerCall('/offers/${Uri.encodeComponent(id)}/withdraw');

  static Future<Map<String, dynamic>?> _offerCall(String path, [Map<String, dynamic>? body]) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl$path'),
        headers: _getHeaders(),
        body: json.encode(body ?? const <String, dynamic>{}),
      ).timeout(const Duration(seconds: 12));
      if (response.statusCode == 200 || response.statusCode == 201 || response.statusCode == 204) {
        lastOfferError = null;
        if (response.body.isEmpty) return <String, dynamic>{};
        return _decodeMap(response.body);
      }
      lastOfferError = _httpErrorText(response.statusCode, response.body);
      _log('Offer call $path failed: ${response.statusCode}');
      return null;
    } catch (e) {
      lastOfferError = _exceptionText(e);
      _log('Offer call $path error: $e');
      return null;
    }
  }

  /// Offers the signed-in user sent as a buyer.      GET /offers/mine
  static Future<List<dynamic>> fetchMyOffers() => _offerList('/offers/mine');

  /// Offers buyers sent on the signed-in seller's services.   GET /offers/incoming
  static Future<List<dynamic>> fetchIncomingOffers() => _offerList('/offers/incoming');

  static Future<List<dynamic>> _offerList(String path) async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl$path'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final d = json.decode(response.body);
        if (d is List) return d;
        if (d is Map && d['content'] is List) return d['content'] as List;
      }
      return [];
    } catch (e) {
      _log('Fetch offers $path error: $e');
      return [];
    }
  }

  /// Seller accepts a booking request (unlocks contact details)
  static Future<Map<String, dynamic>?> acceptEscrowRequest(String transactionRef) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/escrow/accept/$transactionRef'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body);
      }
      return null;
    } catch (e) {
      _log('Accept escrow error: $e');
      return null;
    }
  }

  /// Seller rejects a booking request (refunds Buyer)
  static Future<Map<String, dynamic>?> rejectEscrowRequest(String transactionRef) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/escrow/reject/$transactionRef'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body);
      }
      return null;
    } catch (e) {
      _log('Reject escrow error: $e');
      return null;
    }
  }

  /// Cancel a booking / request (buyer, or provider after accepting).
  /// Backend: POST /escrow/cancel/{transactionRef}  {reason}
  static Future<Map<String, dynamic>?> cancelEscrowRequest(String transactionRef, {String? reason}) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/escrow/cancel/$transactionRef'),
        headers: _getHeaders(),
        body: json.encode({if (reason != null && reason.isNotEmpty) 'reason': reason}),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200 || response.statusCode == 201 || response.statusCode == 204) {
        if (response.body.isEmpty) return <String, dynamic>{};
        final d = json.decode(response.body);
        return d is Map<String, dynamic> ? d : <String, dynamic>{};
      }
      _log('Cancel escrow failed: ${response.statusCode}');
      return null;
    } catch (e) {
      _log('Cancel escrow error: $e');
      return null;
    }
  }

  // ---- Pay-first / offline payment flow (Remitano-style) ---------------------
  // NOTE: these endpoints must exist on the backend. Statuses they move a booking through:
  //   PENDING_ACCEPTANCE -> AWAITING_PAYMENT   POST /escrow/request-payment/{ref}
  //                           {mode: ONLINE|OFFLINE, instructions, deadlineMinutes}
  //   AWAITING_PAYMENT   -> PAYMENT_SENT       POST /escrow/mark-paid/{ref}   {reference, note}
  //   PAYMENT_SENT       -> ACCEPTED           POST /escrow/confirm-payment/{ref}   (provider)
  //   PAYMENT_SENT       -> PAYMENT_DISPUTED   POST /escrow/payment-not-received/{ref} {reason}
  //   AWAITING_PAYMENT   -> ACCEPTED           POST /escrow/pay/{ref} {paymentMethod}  (online, paid in app)
  // The server must only unlock contacts / accept once payment is confirmed, and must only let
  // the provider confirm (never the buyer). The booking JSON should carry paymentMode,
  // paymentInstructions, paymentDeadline (ISO-8601), paymentReference, paymentNote, paymentStatus.

  /// Last error text from a pay-first call (null after a success).
  static String? lastPaymentError;

  static Future<Map<String, dynamic>?> _escrowAction(String path, [Map<String, dynamic>? body]) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl$path'),
        headers: _getHeaders(),
        body: json.encode(body ?? const <String, dynamic>{}),
      ).timeout(const Duration(seconds: 15));
      if (response.statusCode == 200 || response.statusCode == 201 || response.statusCode == 204) {
        lastPaymentError = null;
        if (response.body.isEmpty) return <String, dynamic>{};
        final d = json.decode(response.body);
        return d is Map<String, dynamic> ? d : <String, dynamic>{};
      }
      lastPaymentError = _httpErrorText(response.statusCode, response.body);
      _log('Escrow action $path failed: ${response.statusCode}');
      return null;
    } catch (e) {
      lastPaymentError = _exceptionText(e);
      _log('Escrow action $path error: $e');
      return null;
    }
  }

  /// Provider asks the buyer to pay before the booking is accepted.
  static Future<Map<String, dynamic>?> requestPayment(
    String transactionRef, {
    required String mode, // 'ONLINE' (pay in the app) or 'OFFLINE' (pay the provider directly)
    String? instructions,
    int? deadlineMinutes,
  }) =>
      _escrowAction('/escrow/request-payment/${Uri.encodeComponent(transactionRef)}', {
        'mode': mode,
        if (instructions != null && instructions.trim().isNotEmpty) 'instructions': instructions.trim(),
        if (deadlineMinutes != null) 'deadlineMinutes': deadlineMinutes,
      });

  /// Buyer tells the provider they have paid offline ("I have paid").
  static Future<Map<String, dynamic>?> markPaymentSent(
    String transactionRef, {
    String? reference,
    String? note,
  }) =>
      _escrowAction('/escrow/mark-paid/${Uri.encodeComponent(transactionRef)}', {
        if (reference != null && reference.trim().isNotEmpty) 'reference': reference.trim(),
        if (note != null && note.trim().isNotEmpty) 'note': note.trim(),
      });

  /// Provider confirms the money arrived; the booking becomes ACCEPTED.
  static Future<Map<String, dynamic>?> confirmPaymentReceived(String transactionRef) =>
      _escrowAction('/escrow/confirm-payment/${Uri.encodeComponent(transactionRef)}');

  /// Provider says the money did not arrive.
  static Future<Map<String, dynamic>?> reportPaymentNotReceived(String transactionRef, {String? reason}) =>
      _escrowAction('/escrow/payment-not-received/${Uri.encodeComponent(transactionRef)}', {
        if (reason != null && reason.trim().isNotEmpty) 'reason': reason.trim(),
      });

  /// Buyer pays an existing booking online (Pocket Fund). Mobile money and card go through
  /// [requestMobilePayment] / the card checkout against the booking reference instead.
  static Future<Map<String, dynamic>?> payEscrow(String transactionRef, {required String paymentMethod}) =>
      _escrowAction('/escrow/pay/${Uri.encodeComponent(transactionRef)}', {'paymentMethod': paymentMethod});

  /// Buyer marks satisfied / releases funds to Seller
  static Future<Map<String, dynamic>?> releaseEscrowFunds(String transactionRef) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/escrow/release/$transactionRef'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body);
      }
      return null;
    } catch (e) {
      _log('Release escrow error: $e');
      return null;
    }
  }

  /// Fetch Buyer's booking transactions
  static Future<List<dynamic>> fetchBuyerTransactions() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/escrow/buyer/my-transactions'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body) as List;
      }
      return [];
    } catch (e) {
      _log('Fetch buyer transactions error: $e');
      return [];
    }
  }

  /// Fetch Seller's incoming orders
  static Future<List<dynamic>> fetchSellerOrders() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/escrow/seller/my-orders'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body) as List;
      }
      return [];
    } catch (e) {
      _log('Fetch seller orders error: $e');
      return [];
    }
  }

  // ---------------------------------------------------------------------------
  // Provider one-time registration fee
  // ---------------------------------------------------------------------------
  // NOTE: these endpoints must exist on the backend:
  //   GET  /payments/registration-fee   -> {paid: bool, amount: number}
  //   POST /payments/mobile/request     {amount, purpose, reference, phone}
  //                                     -> {reference}   (sends a payment prompt to the phone)
  //   GET  /payments/status/{ref}       -> {status: PAID | PENDING | FAILED | CANCELLED}

  /// Server view of the provider's registration fee. Null when it can't be loaded.
  static Future<Map<String, dynamic>?> getRegistrationFeeStatus() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/payments/registration-fee'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data is Map<String, dynamic>) return data;
      }
      return null;
    } catch (e) {
      _log('Registration fee status error: $e');
      return null;
    }
  }

  /// Sends a mobile-money payment prompt to [phone]. Returns {reference} or null.
  static Future<Map<String, dynamic>?> requestMobilePayment({
    required double amount,
    required String purpose,
    required String reference,
    required String phone,
  }) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/payments/mobile/request'),
        headers: _getHeaders(),
        body: json.encode({'amount': amount, 'purpose': purpose, 'reference': reference, 'phone': phone}),
      ).timeout(const Duration(seconds: 15));
      if (response.statusCode == 200 || response.statusCode == 201) {
        final data = json.decode(response.body);
        if (data is Map<String, dynamic>) return data;
      }
      return null;
    } catch (e) {
      _log('Mobile payment request error: $e');
      return null;
    }
  }

  /// PAID, PENDING, FAILED or CANCELLED (PENDING on any network problem).
  static Future<String> getPaymentStatus(String reference) async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/payments/status/${Uri.encodeComponent(reference)}'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return (data['status'] ?? 'PENDING').toString().toUpperCase();
      }
    } catch (e) {
      _log('Payment status error: $e');
    }
    return 'PENDING';
  }

  // ---------------------------------------------------------------------------
  // Service boost (provider pays to rank a service higher)
  // ---------------------------------------------------------------------------
  // NOTE: these endpoints must exist on the backend (see BOOST_FLOW.md):
  //   GET  /boosts/plans              -> [{id, days, price}]
  //   POST /boosts/activate           {serviceId, planId, days, paymentMethod, reference?}
  //                                   -> {boostedUntil, ...}   (idempotent per reference)
  // Mobile money / card are paid first through the normal payment endpoints with
  // purpose SERVICE_BOOST, then /boosts/activate is called with that reference.

  /// Boost packages from the server, or null when they cannot be loaded.
  static Future<List<BoostPlan>?> fetchBoostPlans() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/boosts/plans'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final raw = data is List ? data : (data is Map ? (data['plans'] ?? data['content']) : null);
        if (raw is List) {
          final plans = raw.map(BoostPlan.tryParse).whereType<BoostPlan>().toList()
            ..sort((a, b) => a.days.compareTo(b.days));
          if (plans.isNotEmpty) return plans;
        }
      }
      return null;
    } catch (e) {
      _log('Boost plans error: $e');
      return null;
    }
  }

  /// Why the last [activateBoost] failed (shown to the user), or null.
  static String? lastBoostError;

  /// Starts (or extends) the boost once the payment is done. [paymentMethod] is
  /// MOBILE_MONEY, CARD or POCKET_FUND; [reference] is the payment reference for
  /// mobile money / card. Returns the server's JSON (with `boostedUntil`) or null.
  static Future<Map<String, dynamic>?> activateBoost({
    required String serviceId,
    required BoostPlan plan,
    required String paymentMethod,
    String? reference,
  }) async {
    lastBoostError = null;
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/boosts/activate'),
        headers: _getHeaders(),
        body: json.encode({
          'serviceId': int.tryParse(serviceId) ?? serviceId,
          'planId': plan.id,
          'days': plan.days,
          'paymentMethod': paymentMethod,
          if (reference != null) 'reference': reference,
        }),
      ).timeout(const Duration(seconds: 15));
      if (response.statusCode == 200 || response.statusCode == 201) {
        final data = json.decode(response.body);
        return data is Map<String, dynamic> ? data : <String, dynamic>{};
      }
      try {
        final body = json.decode(response.body);
        if (body is Map) lastBoostError = (body['message'] ?? body['error'])?.toString();
      } catch (_) {}
      _log('Activate boost failed: ${response.statusCode}');
      return null;
    } catch (e) {
      lastBoostError = _exceptionText(e);
      _log('Activate boost error: $e');
      return null;
    }
  }

  // ---------------------------------------------------------------------------
  // Verification documents (provider)
  // ---------------------------------------------------------------------------

  /// Documents the provider already uploaded, each {type, status, reason?}.
  /// Returns null when the list could not be loaded.
  static Future<List<dynamic>?> fetchVerificationDocuments() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/verification/documents'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) return json.decode(response.body) as List;
      return null;
    } catch (e) {
      _log('Fetch documents error: $e');
      return null;
    }
  }

  /// Why the last create/update service call failed (shown to the user), or null.
  static String? lastServiceError;

  static String get _origin => SecurityConfig.origin;

  /// A 200/201 with an empty or non-object body still counts as success.
  static Map<String, dynamic> _decodeMap(String body) {
    try {
      final d = json.decode(body);
      if (d is Map<String, dynamic>) return d;
      if (d is Map) return Map<String, dynamic>.from(d);
    } catch (_) {}
    return <String, dynamic>{'success': true};
  }

  /// Makes a server-relative path ("/uploads/a.jpg") a full URL so it can be shown.
  /// Full URLs and bundled assets are returned unchanged.
  static String absoluteUrl(String raw) {
    final u = raw.trim();
    // Cleartext traffic is blocked in the app, so use https for our own server.
    if (u.startsWith('http://${SecurityConfig.host}')) return 'https://${u.substring(7)}';
    if (u.isEmpty || u.startsWith('http://') || u.startsWith('https://') || u.startsWith('assets/')) return u;
    if (u.startsWith('//')) return 'https:$u';
    if (u.startsWith('/')) return '$_origin$u';
    if (u.contains('/')) return '$_origin/$u';
    return u;
  }

  /// Human readable text for a failed HTTP response.
  static String _httpErrorText(int status, String body) {
    final en = AppStrings.isEnglish;
    String? serverMsg;
    try {
      final d = json.decode(body);
      if (d is Map) serverMsg = (d['message'] ?? d['error'] ?? d['detail'])?.toString().trim();
    } catch (_) {}
    switch (status) {
      case 401:
        return en ? 'Your session expired. Please log in again.' : 'Muda wa kuingia umeisha. Tafadhali ingia tena.';
      case 403:
        return en
            ? 'Not allowed. Make sure you are registered as a Seller.'
            : 'Hairuhusiwi. Hakikisha umesajiliwa kama Muuzaji.';
      case 404:
        return en ? 'This feature is not available on the server yet (404).' : 'Huduma hii bado haipo kwenye seva (404).';
      case 413:
        return en
            ? 'The file is too large for the server. Try a smaller file.'
            : 'Faili ni kubwa mno kwa seva. Jaribu faili ndogo zaidi.';
      case 415:
        return en ? 'The server does not accept this file type.' : 'Seva haikubali aina hii ya faili.';
    }
    if (status >= 500) {
      return en ? 'Server error ($status). Please try again later.' : 'Hitilafu ya seva ($status). Jaribu tena baadaye.';
    }
    if (serverMsg != null && serverMsg.isNotEmpty) return normalizeError(serverMsg);
    return en ? 'Request failed ($status).' : 'Ombi limeshindwa ($status).';
  }

  static String _exceptionText(Object e) {
    final en = AppStrings.isEnglish;
    if (e is TimeoutException) {
      return en ? 'The connection timed out. Check your internet and try again.' : 'Muda umeisha. Angalia mtandao kisha jaribu tena.';
    }
    final t = e.toString();
    if (t.contains('SocketException') || t.contains('ClientException') || t.contains('Failed host lookup')) {
      return en ? 'No internet connection.' : 'Hakuna mtandao.';
    }
    return en ? 'Something went wrong. Please try again.' : 'Kuna hitilafu. Tafadhali jaribu tena.';
  }

  /// Pulls the file URL out of whatever the upload endpoint answers with.
  static String? _extractUrl(String body, List<String> keys) {
    String? fromMap(Map m) {
      for (final k in keys) {
        final v = m[k]?.toString().trim() ?? '';
        if (v.isNotEmpty && v != 'null') return v;
      }
      return null;
    }

    try {
      final d = json.decode(body);
      if (d is Map) {
        final direct = fromMap(d);
        if (direct != null) return direct;
        final nested = d['data'] ?? d['file'] ?? d['result'];
        if (nested is Map) return fromMap(nested);
        if (nested is String && nested.trim().isNotEmpty) return nested.trim();
      } else if (d is List && d.isNotEmpty) {
        final f = d.first;
        if (f is Map) return fromMap(f);
        if (f is String && f.trim().isNotEmpty) return f.trim();
      } else if (d is String && d.trim().isNotEmpty) {
        return d.trim();
      }
    } catch (_) {
      final t = body.trim();
      if (t.startsWith('http') || t.startsWith('/')) return t;
    }
    return null;
  }

  /// The single multipart upload path used by every screen (service photos and
  /// videos, verification documents, profile photo, chat images). Adds auth,
  /// timeout, 401 sign-out and one set of readable error messages.
  static Future<UploadResult> _uploadMedia({
    required String endpoint,
    required String filePath,
    required Duration timeout,
    List<String> urlKeys = const ['url', 'path', 'location'],
    Map<String, String> fields = const {},
    bool requireUrl = true,
    bool bumpOnSuccess = false,
    bool imageOnly = false,
  }) async {
    try {
      final request = http.MultipartRequest('POST', Uri.parse('$baseUrl$endpoint'));
      final token = SessionManager.getToken();
      if (token != null && token.isNotEmpty) request.headers['Authorization'] = 'Bearer $token';
      request.headers['Accept'] = 'application/json';
      request.fields.addAll(fields);
      final part = await http.MultipartFile.fromPath('file', filePath);
      if (imageOnly) {
        // Fail fast on the device: wrong file type or too big (saves data and gives a clear reason).
        final ext = filePath.toLowerCase().split('.').last;
        const okExt = {'jpg', 'jpeg', 'png', 'webp', 'heic', 'heif'};
        if (!okExt.contains(ext)) {
          return UploadResult(
            error: AppStrings.isEnglish
                ? 'Only photos (JPG, PNG, WEBP) are allowed.'
                : 'Picha pekee (JPG, PNG, WEBP) ndizo zinaruhusiwa.',
          );
        }
        if (part.length <= 0) {
          return UploadResult(error: AppStrings.isEnglish ? 'The photo is empty. Pick another one.' : 'Picha haina kitu. Chagua nyingine.');
        }
        if (part.length > 10 * 1024 * 1024) {
          return UploadResult(
            error: AppStrings.isEnglish ? 'The photo is too large (max 10 MB).' : 'Picha ni kubwa mno (juu MB 10).',
          );
        }
      }
      request.files.add(part);
      final streamed = await SecureHttp.client.send(request).timeout(timeout);
      final response = await http.Response.fromStream(streamed);
      if (response.statusCode == 401) await SessionManager.clearSession();
      if (response.statusCode == 200 || response.statusCode == 201) {
        if (bumpOnSuccess) DataSync.bump();
        final url = _extractUrl(response.body, urlKeys);
        if (url != null) return UploadResult(url: absoluteUrl(url));
        if (!requireUrl) return const UploadResult();
        return UploadResult(
          error: AppStrings.isEnglish
              ? 'Uploaded, but the server did not return a file link.'
              : 'Imepakiwa, lakini seva haikurudisha kiungo cha faili.',
        );
      }
      _log('Upload $endpoint failed: ${response.statusCode}');
      return UploadResult(error: _httpErrorText(response.statusCode, response.body));
    } catch (e) {
      _log('Upload $endpoint error: $e');
      return UploadResult(error: _exceptionText(e));
    }
  }

  /// Upload one service photo (multipart).
  /// Backend: POST /services/images  (field "file")  ->  {"url": "https://..."}
  static Future<UploadResult> uploadServiceImage(String filePath) => _uploadMedia(
        endpoint: '/services/images',
        filePath: filePath,
        timeout: const Duration(seconds: 90),
        urlKeys: const ['url', 'imageUrl', 'path', 'location'],
      );

  /// Upload one service video (multipart).
  /// Backend: POST /services/videos  (field "file")  ->  {"url": "https://..."}
  static Future<UploadResult> uploadServiceVideo(String filePath) => _uploadMedia(
        endpoint: '/services/videos',
        filePath: filePath,
        timeout: const Duration(minutes: 5),
        urlKeys: const ['url', 'videoUrl', 'path', 'location'],
      );

  /// Upload one verification document image (multipart).
  /// Backend: POST /verification/documents  (fields "type" + "file", and
  /// "idKind" - nida | voter | driving_licence | passport - for id_front / id_back).
  static Future<UploadResult> uploadVerificationDocument({
    required String type,
    required String filePath,
    String? idKind,
  }) =>
      _uploadMedia(
        endpoint: '/verification/documents',
        filePath: filePath,
        timeout: const Duration(seconds: 60),
        fields: {'type': type, if (idKind != null) 'idKind': idKind},
        requireUrl: false,
        bumpOnSuccess: true,
        imageOnly: true,
      );

  /// Upload the signed-in user's profile photo and remember its URL.
  /// Backend (must exist): POST /users/me/avatar  (field "file")  ->  {"url": "https://..."}
  /// The server is expected to save the photo on the user and return it as
  /// "avatarUrl" from /auth/login and in seller JSON.
  static Future<UploadResult> uploadAvatar(String filePath) async {
    final res = await _uploadMedia(
      endpoint: '/users/me/avatar',
      filePath: filePath,
      timeout: const Duration(seconds: 60),
      urlKeys: const ['avatarUrl', 'url', 'profileImage', 'imageUrl', 'path', 'location'],
      bumpOnSuccess: true,
      imageOnly: true,
    );
    if (res.url != null) await SessionManager.saveAvatarUrl(res.url!);
    return res;
  }

  /// Upload one chat picture. The returned URL is then sent as the message
  /// text (the same way call links are), so /chats/send does not change.
  /// Backend (must exist): POST /chats/images  (field "file")  ->  {"url": "https://..."}
  static Future<UploadResult> uploadChatImage(String filePath) => _uploadMedia(
        endpoint: '/chats/images',
        filePath: filePath,
        timeout: const Duration(seconds: 60),
        urlKeys: const ['url', 'imageUrl', 'path', 'location'],
      );

  /// Upload one chat voice note (.m4a) or document (pdf, docx, xlsx, ...).
  /// Like pictures, the returned URL is then sent as the message text.
  /// Backend (must exist): POST /chats/files  (field "file")  ->  {"url": "https://..."}
  static Future<UploadResult> uploadChatFile(String filePath) => _uploadMedia(
        endpoint: '/chats/files',
        filePath: filePath,
        timeout: const Duration(minutes: 2),
        urlKeys: const ['url', 'fileUrl', 'audioUrl', 'path', 'location'],
      );

  static const List<String> _audioExt = ['m4a', 'aac', 'mp3', 'wav', 'ogg', 'opus', 'amr'];

  /// Document types allowed in chat (also used by the file picker).
  static const List<String> chatFileExtensions = [
    'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'csv', 'rtf', 'odt', 'ods', 'zip',
  ];

  /// Small extras kept after the "#" of an attachment link: k = kind (a/f),
  /// name = original file name, d = voice length in seconds.
  static Map<String, String> _chatMeta(String text) {
    final i = text.indexOf('#');
    if (i < 0) return const {};
    try {
      return Uri.splitQueryString(text.substring(i + 1).trim());
    } catch (_) {
      return const {};
    }
  }

  static String _extOf(String path) {
    final seg = path.split('/').last;
    final dot = seg.lastIndexOf('.');
    return dot < 0 ? '' : seg.substring(dot + 1).toLowerCase();
  }

  /// What kind of attachment [text] is, or null for a normal text message.
  /// Only links to our own server count, so nobody can use a message to make
  /// the other person's phone load a file from somewhere else.
  static ChatAttachmentKind? chatAttachmentKind(String text) {
    final t = text.trim();
    if (t.isEmpty || t.contains(RegExp(r'\s'))) return null;
    final uri = Uri.tryParse(absoluteUrl(t));
    if (uri == null || !uri.isAbsolute || uri.host != Uri.parse(_origin).host) return null;
    final k = _chatMeta(t)['k'];
    if (k == 'a') return ChatAttachmentKind.audio;
    if (k == 'f') return ChatAttachmentKind.file;
    final ext = _extOf(uri.path);
    if (_audioExt.contains(ext)) return ChatAttachmentKind.audio;
    if (chatFileExtensions.contains(ext)) return ChatAttachmentKind.file;
    if (uri.path.startsWith('/uploads/') ||
        RegExp(r'\.(jpe?g|png|webp|gif|heic)$', caseSensitive: false).hasMatch(uri.path)) {
      return ChatAttachmentKind.image;
    }
    return null;
  }

  /// True when [text] is a link to a picture hosted on our own server.
  static bool isOwnImageUrl(String text) => chatAttachmentKind(text) == ChatAttachmentKind.image;

  /// Message text for an uploaded voice note / document.
  static String chatAttachmentLink(
    String url, {
    required ChatAttachmentKind kind,
    String? name,
    int? seconds,
  }) {
    final parts = <String>[
      if (kind == ChatAttachmentKind.audio) 'k=a',
      if (kind == ChatAttachmentKind.file) 'k=f',
      if (name != null && name.trim().isNotEmpty) 'name=${Uri.encodeQueryComponent(name.trim())}',
      if (seconds != null && seconds > 0) 'd=$seconds',
    ];
    final base = url.split('#').first;
    return parts.isEmpty ? base : '$base#${parts.join('&')}';
  }

  /// The plain, absolute file link of an attachment message (no extras).
  static String chatAttachmentUrl(String text) => absoluteUrl(text.trim().split('#').first);

  /// Original file name of a document message (falls back to the link's name).
  static String? chatAttachmentName(String text) {
    final n = _chatMeta(text.trim())['name']?.trim();
    if (n != null && n.isNotEmpty) return n;
    final segs = Uri.tryParse(chatAttachmentUrl(text))?.pathSegments ?? const <String>[];
    return (segs.isEmpty || segs.last.isEmpty) ? null : segs.last;
  }

  /// Length in seconds of a voice note message, when the sender included it.
  static int? chatAudioSeconds(String text) => int.tryParse(_chatMeta(text.trim())['d'] ?? '');

  /// Short text for lists (chat list, notifications): attachments show a label
  /// instead of their link.
  static String chatPreview(String text) {
    final en = AppStrings.isEnglish;
    switch (chatAttachmentKind(text)) {
      case ChatAttachmentKind.image:
        return en ? '📷 Photo' : '📷 Picha';
      case ChatAttachmentKind.audio:
        return en ? '🎤 Voice message' : '🎤 Ujumbe wa sauti';
      case ChatAttachmentKind.file:
        return '📎 ${chatAttachmentName(text) ?? (en ? 'Document' : 'Faili')}';
      case null:
        return text;
    }
  }

  // ---------------------------------------------------------------------------
  // Reviews
  // ---------------------------------------------------------------------------

  /// Reviews customers left for the signed-in provider.
  static Future<List<dynamic>> fetchReviewsReceived() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/reviews/received'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) return json.decode(response.body) as List;
      return [];
    } catch (e) {
      _log('Fetch received reviews error: $e');
      return [];
    }
  }

  /// Public reviews customers left for one provider. Backend: GET /users/{id}/reviews
  /// (a plain list, or {content: [...]}). Null when it can't be loaded.
  static Future<List<dynamic>?> fetchProviderReviews(int sellerId) async {
    try {
      final r = await _Http.get(Uri.parse('$baseUrl/users/$sellerId/reviews'), headers: _getHeaders())
          .timeout(const Duration(seconds: 12));
      if (r.statusCode == 200) {
        final d = json.decode(r.body);
        if (d is List) return d;
        if (d is Map && d['content'] is List) return d['content'] as List;
        if (d is Map && d['reviews'] is List) return d['reviews'] as List;
        return [];
      }
      return null;
    } catch (e) {
      _log('Fetch provider reviews error: $e');
      return null;
    }
  }

  /// Reviews the signed-in buyer wrote for providers.
  static Future<List<dynamic>> fetchReviewsWritten() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/reviews/written'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) return json.decode(response.body) as List;
      return [];
    } catch (e) {
      _log('Fetch written reviews error: $e');
      return [];
    }
  }

  /// Rate a completed booking (buyer).
  static Future<Map<String, dynamic>?> submitReview({
    required String transactionRef,
    required int rating,
    String? comment,
  }) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/reviews'),
        headers: _getHeaders(),
        body: json.encode({
          'transactionRef': transactionRef,
          'rating': rating,
          if (comment != null && comment.trim().isNotEmpty) 'comment': comment.trim(),
        }),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200 || response.statusCode == 201) {
        return json.decode(response.body) as Map<String, dynamic>;
      }
      return null;
    } catch (e) {
      _log('Submit review error: $e');
      return null;
    }
  }

  /// Report a service, a user, or a general problem. Backend: POST /reports
  /// body: {type: SERVICE|USER|GENERAL, reason, details, serviceId?, reportedUserId?}
  /// Returns true when the server accepted the report.
  static Future<bool> submitReport({
    required String type,
    required String reason,
    String details = '',
    String? serviceId,
    int? reportedUserId,
  }) async {
    try {
      final body = <String, dynamic>{
        'type': type,
        'reason': reason,
        'details': details.trim(),
        if (serviceId != null && serviceId.isNotEmpty)
          'serviceId': int.tryParse(serviceId) ?? serviceId,
        if (reportedUserId != null && reportedUserId != 0) 'reportedUserId': reportedUserId,
      };
      final r = await _Http.post(Uri.parse('$baseUrl/reports'), headers: _getHeaders(), body: json.encode(body))
          .timeout(const Duration(seconds: 15));
      return r.statusCode == 200 || r.statusCode == 201 || r.statusCode == 204;
    } catch (e) {
      _log('Submit report error: $e');
      return false;
    }
  }

  /// Block a user. Backend: POST /users/{id}/block
  /// Optional body: {reason, details} (why the user is being blocked).
  static Future<bool> blockUser(int userId, {String? reason, String? details}) async {
    try {
      final hasBody = (reason ?? '').isNotEmpty;
      final r = await _Http.post(
        Uri.parse('$baseUrl/users/$userId/block'),
        headers: _getHeaders(),
        body: hasBody
            ? json.encode({'reason': reason, if ((details ?? '').trim().isNotEmpty) 'details': details!.trim()})
            : null,
      )
          .timeout(const Duration(seconds: 10));
      return r.statusCode == 200 || r.statusCode == 201 || r.statusCode == 204;
    } catch (e) {
      _log('Block user error: $e');
      return false;
    }
  }

  /// Unblock a user. Backend: DELETE /users/{id}/block
  static Future<bool> unblockUser(int userId) async {
    try {
      final r = await _Http.delete(Uri.parse('$baseUrl/users/$userId/block'), headers: _getHeaders())
          .timeout(const Duration(seconds: 10));
      return r.statusCode == 200 || r.statusCode == 204;
    } catch (e) {
      _log('Unblock user error: $e');
      return false;
    }
  }

  /// Tell the server a conversation is muted / unmuted so it can skip push
  /// notifications from that person. Best effort. Backend: POST|DELETE /chats/{userId}/mute
  static Future<bool> setChatMuted(int userId, bool muted) async {
    try {
      final url = Uri.parse('$baseUrl/chats/$userId/mute');
      final r = muted
          ? await _Http.post(url, headers: _getHeaders())
          : await _Http.delete(url, headers: _getHeaders());
      return r.statusCode >= 200 && r.statusCode < 300;
    } catch (e) {
      _log('Mute chat error: $e');
      return false;
    }
  }

  /// Users the signed-in account blocked. Null when it can't be loaded. Backend: GET /users/blocked
  static Future<List<dynamic>?> fetchBlockedUsers() async {
    try {
      final r = await _Http.get(Uri.parse('$baseUrl/users/blocked'), headers: _getHeaders())
          .timeout(const Duration(seconds: 10));
      if (r.statusCode == 200) {
        final d = json.decode(r.body);
        if (d is List) return d;
        if (d is Map && d['content'] is List) return d['content'] as List;
      }
      return null;
    } catch (e) {
      _log('Fetch blocked users error: $e');
      return null;
    }
  }

  /// Fetch user conversations list
  /// Reads an 'online' flag the server may send as bool, 0/1 or 'true'/'1'.
  static bool parseOnline(dynamic v) => v == true || v == 1 || v == '1' || v.toString().toLowerCase() == 'true';

  static Future<List<dynamic>> fetchConversations() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/chats/conversations'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body) as List;
      }
      return [];
    } catch (e) {
      _log('Fetch conversations error: $e');
      return [];
    }
  }

  /// Fetch messages for a specific conversation or user
  static Future<List<dynamic>> fetchMessages(String conversationId) async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/chats/$conversationId/messages'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body) as List;
      }
      return [];
    } catch (e) {
      _log('Fetch messages error: $e');
      return [];
    }
  }

  /// Send a real message to another user or conversation
  static Future<Map<String, dynamic>?> sendMessage({
    required String recipientId,
    required String message,
  }) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/chats/send'),
        headers: _getHeaders(),
        body: json.encode({
          'recipientId': recipientId,
          'message': message,
        }),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body);
      }
      return null;
    } catch (e) {
      _log('Send message error: $e');
      return null;
    }
  }

  /// Saves the signed-in user's GPS position in the database (used to rank nearby services).
  /// Backend: PUT /users/me/location  {latitude, longitude}
  static Future<bool> updateUserLocation(double latitude, double longitude) async {
    if (!SessionManager.isLoggedIn()) return false;
    try {
      final response = await _Http.put(
        Uri.parse('$baseUrl/users/me/location'),
        headers: _getHeaders(),
        body: json.encode({'latitude': latitude, 'longitude': longitude}),
      ).timeout(const Duration(seconds: 10));
      return response.statusCode >= 200 && response.statusCode < 300;
    } catch (e) {
      _log('Update location error: $e');
      return false;
    }
  }

  /// Fetch active services from the backend with optional pagination
  /// Every service seen so far (Home, Category, Search, Favorites), by id, so a
  /// saved service can be shown anywhere even when it is not on the current page.
  static final Map<String, ServiceItem> knownServices = {};

  static Future<List<ServiceItem>> fetchServices({
    String? category,
    String? query,
    String? city,
    int? radiusKm,
    int page = 0,
    int size = 20,
  }) async {
    final r = await fetchServicesPage(
      category: category, query: query, city: city, radiusKm: radiusKm, page: page, size: size,
    );
    return r.items;
  }

  /// Same as [fetchServices] but also tells the caller whether another page
  /// exists and whether the request worked (so "Load more" can retry on a
  /// network error instead of wrongly deciding the list has ended).
  /// `hasMore` uses the server's `last` flag, else a full raw page; the raw
  /// count is used because blocked / 18+ items are removed from [items] afterwards.
  static Future<({List<ServiceItem> items, bool hasMore, bool ok})> fetchServicesPage({
    String? category,
    String? query,
    String? city,
    int? radiusKm,
    int page = 0,
    int size = 20,
  }) async {
    try {
      final queryParams = <String, String>{
        'page': page.toString(),
        'size': size.toString(),
      };
      if (category != null && category.isNotEmpty && category != 'All') {
        queryParams['category'] = category;
      }
      if (query != null && query.isNotEmpty) {
        queryParams['query'] = query;
      }
      if (city != null && city.isNotEmpty) {
        queryParams['city'] = city;
      }
      // With a GPS fix the server can rank/filter by distance.
      if (GpsService.hasFix) {
        queryParams['lat'] = GpsService.lat!.toStringAsFixed(6);
        queryParams['lng'] = GpsService.lng!.toStringAsFixed(6);
        if (radiusKm != null) queryParams['radiusKm'] = radiusKm.toString();
      }
      final allowSensitive = SecuritySettings.allowSensitive;
      queryParams['includeSensitive'] = allowSensitive.toString();

      final uri = Uri.parse('$baseUrl/services').replace(queryParameters: queryParams.isEmpty ? null : queryParams);
      final response = await _Http.get(uri, headers: _getHeaders()).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final List content = data['content'] ?? [];
        final last = data['last'];
        final hasMore = last is bool ? !last : content.length >= size;

        final items = content.map((jsonItem) => _mapJsonToServiceItem(jsonItem)).toList();
        for (final it in items) {
          knownServices[it.id] = it;
        }
        // Nearest first (items without a known distance keep their order, after the rest).
        if (GpsService.hasFix && items.any((s) => s.distanceKm != null)) {
          final indexed = items.asMap().entries.toList()
            ..sort((a, b) {
              final x = a.value.distanceKm, y = b.value.distanceKm;
              if (x == null && y == null) return a.key.compareTo(b.key);
              if (x == null) return 1;
              if (y == null) return -1;
              final c = x.compareTo(y);
              return c != 0 ? c : a.key.compareTo(b.key);
            });
          items
            ..clear()
            ..addAll(indexed.map((e) => e.value));
        }
        // Boosted services first (stable: keeps the nearest-first order inside each group).
        if (items.any((s) => s.isBoosted)) {
          final boosted = items.where((s) => s.isBoosted).toList();
          final rest = items.where((s) => !s.isBoosted).toList();
          items
            ..clear()
            ..addAll(boosted)
            ..addAll(rest);
        }
        // Hide sensitive (18+) services unless the user allowed them in Settings.
        // Hide services from sellers the user blocked.
        final visible = items.where((s) => !BlockService.isBlocked(s.sellerId));
        final out = allowSensitive ? visible.toList() : visible.where((s) => !s.is18Plus).toList();
        return (items: out, hasMore: hasMore, ok: true);
      } else {
        _log('Failed to load services: ${response.statusCode}');
        return (items: <ServiceItem>[], hasMore: true, ok: false);
      }
    } catch (e) {
      _log('Error fetching services: $e');
      return (items: <ServiceItem>[], hasMore: true, ok: false);
    }
  }

  /// One public service by id (used when a shared link is opened), or null.
  /// GET /services/{id}
  static Future<ServiceItem?> fetchServiceById(String id) async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/services/${Uri.encodeComponent(id)}'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final d = json.decode(response.body);
        if (d is Map) return _mapJsonToServiceItem(Map<String, dynamic>.from(d));
      }
      return null;
    } catch (e) {
      _log('Fetch service by id error: $e');
      return null;
    }
  }

  /// 90 -> '1 hr 30 min', 60 -> '1 hr', 45 -> '45 min'; '' when no duration is set.
  static String formatDuration(int? minutes) {
    if (minutes == null || minutes <= 0) return '';
    if (minutes < 60) return '$minutes min';
    final h = minutes ~/ 60, m = minutes % 60;
    return m == 0 ? '$h hr' : '$h hr $m min';
  }

  static ServiceItem _mapJsonToServiceItem(Map<String, dynamic> json) {
    final seller = json['seller'] ?? {};
    final String stageName = seller['stageName'] ?? 'Verified Pro';
    final int? sellerId = seller['id'] != null ? (seller['id'] as num).toInt() : null;
    final String badge = seller['verificationBadge'] ?? 'NONE';

    VerificationLevel vLevel = VerificationLevel.none;
    if (badge == 'GREEN_BADGE') {
      vLevel = VerificationLevel.greenNidaNumber;
    } else if (badge == 'BLUE_TICK') {
      vLevel = VerificationLevel.blueNidaPhotoWithId;
    }

    final double? svcLat = (json['latitude'] ?? seller['latitude']) is num ? ((json['latitude'] ?? seller['latitude']) as num).toDouble() : null;
    final double? svcLng = (json['longitude'] ?? seller['longitude']) is num ? ((json['longitude'] ?? seller['longitude']) as num).toDouble() : null;
    // Prefer the server's distance; otherwise work it out from GPS + the service's coordinates.
    final double? distKm = (json['distanceKm'] is num)
        ? (json['distanceKm'] as num).toDouble()
        : GpsService.distanceKmTo(svcLat, svcLng);
    final String cityText = '${(json['city'] ?? 'Dar es Salaam')}';
    final String distanceText = distKm == null
        ? cityText
        : (distKm < 1 ? '${(distKm * 1000).round()} m' : '${distKm.toStringAsFixed(distKm < 10 ? 1 : 0)} km');

    final category = json['category'] ?? 'General';
    final listed = (json['price'] as num?)?.toInt() ?? 50000;
    // Discount: the server may send the final price (salePrice) or just a percent.
    // The server stays the authority at booking time; this only decides what to show.
    final DateTime? discountEnds = DateTime.tryParse('${json['discountValidUntil'] ?? json['discountEndsAt'] ?? ''}');
    final bool discountExpired = discountEnds != null && !discountEnds.isAfter(DateTime.now());
    final int pct = ((_num(json['discountPercent']) ?? 0).toInt()).clamp(0, 90).toInt();
    final int? sale = _num(json['salePrice'] ?? json['discountedPrice'])?.toInt();
    int price = listed;
    if (!discountExpired) {
      if (sale != null && sale > 0 && sale < listed) {
        price = sale;
      } else if (pct > 0) {
        price = ((listed * (100 - pct) / 100) / 100).round() * 100; // nearest TSh 100
      }
    }
    final bool isInfoLocked = json['isInfoLocked'] ?? false;
    final bool profileLocked = seller['profileLocked'] == true || json['profileLocked'] == true;
    final bool contactsVisible = json['contactsVisible'] ?? !(isInfoLocked || profileLocked);
    final bool isOnline = parseOnline(seller['isOnline'] ?? seller['online'] ?? json['isOnline'] ?? json['sellerOnline']);

    // An unlocked service with no contact of its own uses the provider's profile
    // contacts: from the server's seller object, or from this device when it is
    // the signed-in provider's own service (and their profile is Unlocked).
    final bool isMine = sellerId != null && SessionManager.isLoggedIn() && sellerId == SessionManager.getUserIdValue();
    final bool useProfile = contactsVisible && !(isMine && SecuritySettings.profileLocked);
    String? pick(String key, {String? localKey}) {
      String? clean(dynamic v) {
        final t = v?.toString().trim() ?? '';
        return t.isEmpty ? null : t;
      }

      final own = clean(json[key]);
      if (own != null || !useProfile) return own;
      return clean(seller[key]) ?? (isMine && localKey != null ? clean(SessionManager.getSocial(localKey)) : null);
    }

    final String? phone = pick('phone') ??
        (useProfile && isMine && SessionManager.getPhone().trim().isNotEmpty ? SessionManager.getPhone().trim() : null);

    return ServiceItem(
      id: json['id'].toString(),
      sellerId: sellerId,
      title: json['title'] ?? 'Huduma',
      subtitle: json['description'] ?? '',
      category: category,
      distance: distanceText,
      distanceKm: distKm,
      rating: _num(json['rating'] ?? json['averageRating'] ?? seller['rating'] ?? seller['averageRating'])?.toDouble() ?? 0.0,
      reviewsCount: _num(json['reviewsCount'] ?? json['reviewCount'] ?? seller['reviewsCount'] ?? seller['reviewCount'])?.toInt() ?? 0,
      priceText: 'TSh ${price.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]},')}',
      priceAmount: price,
      listedPriceAmount: price < listed ? listed : 0,
      discountPercent: price < listed ? pct : 0,
      discountEndsAt: price < listed ? discountEnds : null,
      allowOffers: json['allowOffers'] != false,
      durationText: formatDuration(_num(json['durationMinutes'])?.toInt()),
      stageName: stageName,
      sellerAvatar: _firstText([seller['avatarUrl'], seller['profileImage'], seller['profilePhoto'], seller['avatar']]),
      verificationLevel: vLevel,
      isSponsored: BoostInfo.fromJson(json).active,
      boostedUntil: BoostInfo.fromJson(json).until,
      themeColor: _getCategoryColor(category),
      icon: _getCategoryIcon(category),
      isInfoLocked: isInfoLocked,
      profileLocked: profileLocked,
      contactsVisible: contactsVisible,
      is18Plus: json['is18Plus'] == true,
      features: _featureList(json['features'] ?? json['menuItems']),
      phone: phone,
      whatsappPhone: pick('whatsappPhone', localKey: 'whatsapp'),
      email: pick('email'),
      instagramUsername: pick('instagramUsername', localKey: 'instagram'),
      facebookUsername: pick('facebookUsername', localKey: 'facebook'),
      xUsername: pick('xUsername', localKey: 'x'),
      tiktokUsername: pick('tiktokUsername', localKey: 'tiktok'),
      youtubeUsername: pick('youtubeUsername', localKey: 'youtube'),
      imageUrls: _featuredFirst(
        _urlList(json['imageUrls'] ?? json['images'] ?? json['photos']),
        (json['featuredImageUrl'] ?? json['featuredImage'] ?? json['coverImage'])?.toString(),
      ),
      videoUrls: _urlList(json['videoUrls'] ?? json['videos']),
      isOnline: isOnline,
      availableDays: json['availableDays'] is List
          ? (json['availableDays'] as List).map((e) => e.toString().trim()).where((e) => e.isNotEmpty).toList()
          : const [],
      availableFrom: json['availableFrom']?.toString(),
      availableTo: json['availableTo']?.toString(),
      serviceMode: _serviceModeOf(json),
      sellerSince: DateTime.tryParse(_firstText([
            seller['createdAt'],
            seller['memberSince'],
            seller['joinedAt'],
            seller['registeredAt'],
            json['sellerSince'],
          ]) ??
          ''),
      sellerBio: _firstText([seller['bio'], seller['about'], seller['aboutMe'], seller['description'], json['sellerBio']]),
      completedJobs: _num(seller['completedJobs'] ?? seller['completedBookings'] ?? seller['jobsCompleted'] ?? json['completedJobs'])?.toInt(),
      totalBookings: _num(seller['totalBookings'] ?? seller['bookingsCount'] ?? json['totalBookings'])?.toInt(),
      latitude: svcLat,
      longitude: svcLng,
      city: (json['city'] ?? '').toString().trim().isEmpty ? null : json['city'].toString().trim(),
    );
  }

  /// Normalises whatever the server sends for "where is the service done".
  static String? _serviceModeOf(Map<String, dynamic> json) {
    final raw = (json['serviceMode'] ?? json['serviceType'] ?? json['locationType'] ?? json['serviceLocation'])
        ?.toString()
        .toLowerCase()
        .trim();
    if (raw == null || raw.isEmpty) return null;
    if (raw.contains('both')) return 'both';
    if (raw.contains('travel') || raw.contains('mobile') || raw.contains('home') || raw.contains('visit')) {
      return 'provider_travels';
    }
    if (raw.contains('customer') || raw.contains('studio') || raw.contains('shop') || raw.contains('salon') || raw.contains('site')) {
      return 'customer_comes';
    }
    return null;
  }

  /// Accepts ['Soup', ...], [{name: 'Soup'}, ...] or 'Soup, Pizza'; drops blanks and duplicates.
  static List<String> _featureList(dynamic raw) {
    Iterable<dynamic> items;
    if (raw is List) {
      items = raw;
    } else if (raw is String) {
      items = raw.split(',');
    } else {
      return const [];
    }
    final out = <String>[];
    for (final it in items) {
      final t = (it is Map ? (it['name'] ?? it['title'] ?? it['label']) : it)?.toString().trim() ?? '';
      if (t.isNotEmpty && !out.any((e) => e.toLowerCase() == t.toLowerCase())) out.add(t);
    }
    return out;
  }

  /// Moves the featured image to the front so every screen that shows the
  /// first image (cards, favorites, gallery) shows the featured one.
  static List<String> _featuredFirst(List<String> urls, String? featured) {
    final f = featured?.trim() ?? '';
    if (f.isEmpty || urls.isEmpty) return urls;
    final i = urls.indexOf(f);
    if (i <= 0) return urls;
    return [f, ...urls.sublist(0, i), ...urls.sublist(i + 1)];
  }

  /// Accepts ['url', ...] or [{url: '...'}, ...]; drops blanks.
  static List<String> _urlList(dynamic raw) {
    if (raw is! List) return const [];
    final out = <String>[];
    for (final e in raw) {
      final t = (e is Map ? (e['url'] ?? e['path'] ?? e['src']) : e)?.toString().trim() ?? '';
      if (t.isNotEmpty && t != 'null') out.add(absoluteUrl(t));
    }
    return out;
  }

  static String? _firstText(List<dynamic> options) {
    for (final v in options) {
      final t = v?.toString().trim() ?? '';
      if (t.isNotEmpty && t != 'null') return t;
    }
    return null;
  }

  static num? _num(dynamic v) => v is num ? v : (v is String ? num.tryParse(v) : null);

  static Color _getCategoryColor(String category) {
    switch (category.toLowerCase()) {
      case 'cleaning':
      case 'usafi':
        return AppColors.categoryBlue;
      case 'beauty':
      case 'saloon':
        return AppColors.categoryBeauty;
      case 'plumbing':
      case 'fundi bomba':
        return AppColors.categoryTeal;
      case 'electrical':
      case 'umeme':
        return AppColors.categoryElectrical;
      case 'repair':
      case 'urekebishaji':
        return AppColors.categoryMechanic;
      case 'food':
      case 'chakula':
        return AppColors.warning;
      default:
        return AppColors.categoryBlue;
    }
  }

  static IconData _getCategoryIcon(String category) {
    switch (category.toLowerCase()) {
      case 'food':
      case 'chakula':
        return Icons.restaurant_rounded;
      case 'cleaning':
      case 'usafi':
        return Icons.cleaning_services_rounded;
      case 'beauty':
      case 'saloon':
        return Icons.spa_rounded;
      case 'plumbing':
      case 'fundi bomba':
        return Icons.plumbing_rounded;
      case 'electrical':
      case 'umeme':
        return Icons.bolt_rounded;
      case 'repair':
      case 'urekebishaji':
        return Icons.build_rounded;
      default:
        return Icons.design_services_rounded;
    }
  }
}

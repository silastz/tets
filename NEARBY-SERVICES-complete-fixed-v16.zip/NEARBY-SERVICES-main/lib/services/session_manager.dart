import 'notification_service.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SessionManager {
  static const String _keyToken = 'auth_token';
  static const String _keyUserId = 'user_id';
  static const String _keyUsername = 'username';
  static const String _keyStageName = 'stage_name';
  static const String _keyRole = 'user_role';
  static const String _keyBadge = 'user_badge';
  static const String _keyCity = 'user_city';
  static const String _keyPhone = 'user_phone';
  static const String _keyAvatar = 'user_avatar_url';

  static SharedPreferences? _prefs;

  // The auth token lives in encrypted storage (Android Keystore / iOS Keychain),
  // never in plain SharedPreferences. It is mirrored in memory for sync reads.
  static const FlutterSecureStorage _secure = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );
  static String? _token;

  static Future<void> init() async {
    _prefs ??= await SharedPreferences.getInstance();
    try {
      _token = await _secure.read(key: _keyToken);
      // One-time migration of tokens saved by older versions in plain prefs.
      final legacy = _prefs!.getString(_keyToken);
      if (legacy != null) {
        if (_token == null || _token!.isEmpty) {
          _token = legacy;
          await _secure.write(key: _keyToken, value: legacy);
        }
        await _prefs!.remove(_keyToken);
      }
    } catch (e) {
      debugPrint('Secure storage unavailable: $e');
      _token = null; // fail closed: user simply signs in again
    }
  }

  static Future<void> _writeToken(String token) async {
    _token = token;
    try {
      await _secure.write(key: _keyToken, value: token);
    } catch (e) {
      debugPrint('Secure storage write failed: $e');
    }
  }

  static Future<void> saveSession({
    required String token,
    required int userId,
    required String username,
    required String stageName,
    required String role,
    required String badge,
  }) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await _writeToken(token);
    await prefs.setInt(_keyUserId, userId);
    await prefs.setString(_keyUsername, username);
    await prefs.setString(_keyStageName, stageName);
    await prefs.setString(_keyRole, role);
    await prefs.setString(_keyBadge, badge);
    NotificationService.login(userId.toString(), role: role);
    notifySessionChanged();
  }

  static String? getToken() {
    return _token;
  }

  static bool isLoggedIn() {
    final token = getToken();
    return token != null && token.isNotEmpty;
  }

  static String getStageName() {
    return _prefs?.getString(_keyStageName) ?? 'Guest User';
  }

  static String getUsername() {
    return _prefs?.getString(_keyUsername) ?? 'guest';
  }

  static int getUserIdValue() {
    return _prefs?.getInt(_keyUserId) ?? 0;
  }

  static String getRole() {
    return _prefs?.getString(_keyRole) ?? 'ROLE_BUYER';
  }

  static String getBadge() {
    return _prefs?.getString(_keyBadge) ?? 'NONE';
  }

  static String getUserCity() {
    return _prefs?.getString(_keyCity) ?? 'Dar es Salaam';
  }

  static bool hasUserCity() {
    return (_prefs?.getString(_keyCity) ?? '').trim().isNotEmpty;
  }

  static String getPhone() {
    return _prefs?.getString(_keyPhone) ?? '';
  }

  static Future<void> savePhone(String phone) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await prefs.setString(_keyPhone, phone);
  }

  /// The signed-in user's profile photo URL ('' when none). Cleared on sign-out.
  static String getAvatarUrl() => _prefs?.getString(_keyAvatar) ?? '';

  static Future<void> saveAvatarUrl(String url) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    if (url.trim().isEmpty) {
      await prefs.remove(_keyAvatar);
    } else {
      await prefs.setString(_keyAvatar, url.trim());
    }
  }

  // Own social handles, shown on the profile when it is Unlocked.
  static const List<String> socialKeys = ['whatsapp', 'instagram', 'facebook', 'x', 'tiktok', 'youtube'];

  static String getSocial(String key) => _prefs?.getString('user_social_$key') ?? '';

  static Future<void> saveSocial(String key, String value) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    final v = value.trim();
    if (v.isEmpty) {
      await prefs.remove('user_social_$key');
    } else {
      await prefs.setString('user_social_$key', v);
    }
  }

  /// Country (ISO code, e.g. 'KE') detected from the device's network location.
  static String getCountryIso() => _prefs?.getString('detected_country_iso') ?? '';

  static Future<void> saveCountryIso(String iso) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await prefs.setString('detected_country_iso', iso);
  }

  static Future<void> saveUserCity(String city) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await prefs.setString(_keyCity, city);
    notifySessionChanged();
  }

  static Future<void> saveBadge(String badge) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await prefs.setString(_keyBadge, badge);
    notifySessionChanged();
  }

  // Verification documents this provider has uploaded from this device
  // (the server stays the source of truth for approval status).
  static String get _docsKey => 'docs_submitted_${getUserIdValue()}';

  static Set<String> getSubmittedDocs() => (_prefs?.getStringList(_docsKey) ?? const <String>[]).toSet();

  static Future<void> addSubmittedDoc(String type) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    final set = getSubmittedDocs()..add(type);
    await prefs.setStringList(_docsKey, set.toList());
    notifySessionChanged();
  }

  // How this provider works and how far they cover: [type, radius km, area].
  // Saved per user on this device by the "Service Radius" sheet.
  static String get _coverageKey => 'service_coverage_${getUserIdValue()}';

  /// Null until the user has saved it once.
  static ({String type, double radiusKm, String area})? getServiceCoverage() {
    final v = _prefs?.getStringList(_coverageKey);
    if (v == null || v.length != 3) return null;
    final km = double.tryParse(v[1]);
    if (km == null) return null;
    return (type: v[0], radiusKm: km, area: v[2]);
  }

  static Future<void> saveServiceCoverage({required String type, required double radiusKm, required String area}) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await prefs.setStringList(_coverageKey, [type, radiusKm.toString(), area]);
    notifySessionChanged();
  }

  // Which identity document the user verifies with (nida, voter, ...).
  static String get _idKindKey => 'id_kind_${getUserIdValue()}';

  static String getIdKind() => _prefs?.getString(_idKindKey) ?? 'nida';

  static Future<void> saveIdKind(String kind) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await prefs.setString(_idKindKey, kind);
  }

  // Provider one-time registration fee (TSh). Stored per user on this device;
  // null = unknown (older accounts), the server is asked in that case.
  static const int registrationFee = 10000;

  static String get _feeKey => 'reg_fee_paid_${getUserIdValue()}';

  static bool? getRegFeePaid() {
    final prefs = _prefs;
    if (prefs == null || !prefs.containsKey(_feeKey)) return null;
    return prefs.getBool(_feeKey);
  }

  static Future<void> setRegFeePaid(bool paid) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await prefs.setBool(_feeKey, paid);
    notifySessionChanged();
  }

  static bool isSeller() {
    return getRole() == 'ROLE_SELLER';
  }

  static final ValueNotifier<int> sessionNotifier = ValueNotifier<int>(0);

  static void notifySessionChanged() {
    sessionNotifier.value++;
  }

  static Future<void> updateRole(String newRole) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await prefs.setString(_keyRole, newRole);
    NotificationService.setRole(newRole);
    notifySessionChanged();
  }

  static const String _keyStartupPermissionsPrompted = 'startup_permissions_prompted';

  static bool hasPromptedStartupPermissions() {
    return _prefs?.getBool(_keyStartupPermissionsPrompted) ?? false;
  }

  static Future<void> markStartupPermissionsPrompted() async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await prefs.setBool(_keyStartupPermissionsPrompted, true);
  }

  static const String _keyFavorites = 'user_favorite_services';

  static List<String> getFavoriteIds() {
    return _prefs?.getStringList(_keyFavorites) ?? [];
  }

  static bool isFavorite(String serviceId) {
    return getFavoriteIds().contains(serviceId);
  }

  static Future<bool> toggleFavorite(String serviceId) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    final list = List<String>.from(getFavoriteIds());
    bool isNowFav;
    if (list.contains(serviceId)) {
      list.remove(serviceId);
      isNowFav = false;
    } else {
      list.add(serviceId);
      isNowFav = true;
    }
    await prefs.setStringList(_keyFavorites, list);
    notifySessionChanged();
    return isNowFav;
  }

  static Future<void> clearSession() async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    _token = null;
    try {
      await _secure.delete(key: _keyToken);
    } catch (_) {}
    await prefs.remove(_keyToken);
    await prefs.remove(_keyPhone);
    await prefs.remove(_keyAvatar);
    for (final k in socialKeys) {
      await prefs.remove('user_social_$k');
    }
    await prefs.remove(_keyUserId);
    await prefs.remove(_keyUsername);
    await prefs.remove(_keyStageName);
    await prefs.remove(_keyRole);
    await prefs.remove(_keyBadge);
    NotificationService.logout();
    notifySessionChanged();
  }
}


import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import '../constants/app_strings.dart';
import '../models/models.dart';

/// Round social media buttons shown under the price on the Service Details page:
/// WhatsApp, Instagram, Facebook, X, TikTok, YouTube.
///
/// - Locked service: all icons are shown; tapping explains contacts unlock
///   after the service request is accepted.
/// - Unlocked service: only the links the provider has are shown; tapping opens them.
class SocialLinksRow extends StatelessWidget {
  final ServiceItem service;
  final EdgeInsets padding;

  const SocialLinksRow({
    super.key,
    required this.service,
    this.padding = const EdgeInsets.fromLTRB(16, 14, 16, 0),
  });

  static bool _has(String? v) => v != null && v.trim().isNotEmpty;

  /// Accepts a full URL or a handle (with or without '@').
  static String _url(String base, String value) {
    final v = value.trim();
    final baseHost = Uri.parse(base).host.replaceFirst('www.', '');
    if (v.startsWith('http://') || v.startsWith('https://')) {
      // Only accept https links that stay on the platform's own domain
      // (providers can type anything; never open arbitrary sites from here).
      final uri = Uri.tryParse(v);
      final host = uri?.host.replaceFirst('www.', '').replaceFirst('m.', '') ?? '';
      final ok = uri != null &&
          uri.scheme == 'https' &&
          (host == baseHost || host.endsWith('.$baseHost') || (baseHost == 'x.com' && host == 'twitter.com'));
      return ok ? uri.toString() : base;
    }
    // Handle: keep only characters valid in a username so it can't alter the path/query.
    final handle = v.replaceFirst('@', '').replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '');
    return '$base$handle';
  }

  static String _waUrl(String phone) {
    final digits = phone.replaceAll(RegExp(r'\D'), '');
    return 'https://wa.me/$digits';
  }

  Future<void> _open(BuildContext context, String url) async {
    final uri = Uri.tryParse(url);
    final ok = uri != null &&
        uri.scheme == 'https' &&
        await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(AppStrings.isEnglish ? 'Could not open link' : 'Imeshindwa kufungua kiungo')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final locked = service.isContactLocked;
    // Locked contacts: social links are not shown at all.
    if (locked) return const SizedBox.shrink();

    final items = <_Social>[
      _Social(
        icon: FontAwesomeIcons.whatsapp,
        color: const Color(0xFF25D366),
        url: _has(service.whatsappPhone) ? _waUrl(service.whatsappPhone!) : null,
      ),
      _Social(
        icon: FontAwesomeIcons.instagram,
        gradient: const LinearGradient(
          begin: Alignment.bottomLeft,
          end: Alignment.topRight,
          colors: [Color(0xFFFEDA77), Color(0xFFF58529), Color(0xFFDD2A7B), Color(0xFF8134AF)],
        ),
        url: _has(service.instagramUsername) ? _url('https://instagram.com/', service.instagramUsername!) : null,
      ),
      _Social(
        icon: FontAwesomeIcons.facebookF,
        color: const Color(0xFF1877F2),
        url: _has(service.facebookUsername) ? _url('https://facebook.com/', service.facebookUsername!) : null,
      ),
      _Social(
        icon: FontAwesomeIcons.xTwitter,
        color: Colors.black,
        url: _has(service.xUsername) ? _url('https://x.com/', service.xUsername!) : null,
      ),
      _Social(
        icon: FontAwesomeIcons.tiktok,
        color: Colors.black,
        url: _has(service.tiktokUsername) ? _url('https://tiktok.com/@', service.tiktokUsername!) : null,
      ),
      _Social(
        icon: FontAwesomeIcons.youtube,
        color: const Color(0xFFFF0000),
        url: _has(service.youtubeUsername) ? _url('https://youtube.com/@', service.youtubeUsername!) : null,
      ),
    ];

    // Unlocked: show only what the provider actually has.
    final visible = items.where((i) => i.url != null).toList();
    if (visible.isEmpty) return const SizedBox.shrink();

    return Padding(
      padding: padding,
      // Wrap: six icons flow onto a second line on narrow screens instead of overflowing.
      child: Wrap(
        spacing: 12,
        runSpacing: 10,
        children: [
          for (final item in visible)
            _SocialButton(
              item: item,
              onTap: () {
                if (item.url != null) _open(context, item.url!);
              },
            ),
        ],
      ),
    );
  }
}

class _Social {
  final IconData icon;
  final Color? color;
  final Gradient? gradient;
  final String? url;

  const _Social({required this.icon, this.color, this.gradient, this.url});
}

class _SocialButton extends StatelessWidget {
  final _Social item;
  final VoidCallback onTap;

  const _SocialButton({required this.item, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: item.gradient == null ? item.color : null,
          gradient: item.gradient,
        ),
        child: Center(child: FaIcon(item.icon, size: 17, color: Colors.white)),
      ),
    );
  }
}

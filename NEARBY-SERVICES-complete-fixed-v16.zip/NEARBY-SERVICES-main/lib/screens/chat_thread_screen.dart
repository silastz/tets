import 'dart:async';
import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:record/record.dart';
import 'package:url_launcher/url_launcher.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/call_service.dart';
import '../services/media_picker.dart';
import '../services/permission_service.dart';
import '../services/session_manager.dart';
import '../services/block_service.dart';
import '../services/chat_prefs.dart';
import '../models/models.dart';
import 'seller_profile_screen.dart';
import '../widgets/app_image.dart';
import '../widgets/app_ui.dart';
import '../widgets/block_user_dialog.dart';
import '../widgets/call_options_sheet.dart';
import '../widgets/report_sheet.dart';
import '../widgets/fullscreen_image_viewer.dart';
import '../widgets/login_modal.dart';
import '../services/data_sync.dart';
import '../widgets/online_indicator.dart';

/// One-to-one conversation with a provider / client.
/// Open it with [ChatThreadScreen.open] - it asks the user to sign in first.
class ChatThreadScreen extends StatefulWidget {
  /// User id of the person being chatted with (the seller's user id).
  final String otherUserId;
  final String otherName;

  /// Whether the other person was online when the chat was opened.
  final bool isOnline;

  const ChatThreadScreen({
    super.key,
    required this.otherUserId,
    required this.otherName,
    this.isOnline = false,
  });

  /// Opens a chat with [recipientId]. Guests get the login sheet first.
  static Future<void> open(
    BuildContext context, {
    required int? recipientId,
    required String name,
    bool isOnline = false,
  }) async {
    final isEn = AppStrings.isEnglish;
    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);

    if (recipientId == null || recipientId == 0) {
      messenger.showSnackBar(SnackBar(
        content: Text(isEn ? 'Chat is not available for this provider yet.' : 'Mazungumzo hayapatikani kwa mtoa huduma huyu bado.'),
      ));
      return;
    }

    if (!SessionManager.isLoggedIn()) {
      final ok = await LoginModal.show(context);
      if (ok != true || !SessionManager.isLoggedIn()) return;
    }

    if (SessionManager.getUserIdValue() == recipientId) {
      messenger.showSnackBar(SnackBar(
        content: Text(isEn ? "You can't chat with yourself." : 'Huwezi kuzungumza na wewe mwenyewe.'),
      ));
      return;
    }

    await navigator.push(MaterialPageRoute(
      builder: (_) => ChatThreadScreen(otherUserId: recipientId.toString(), otherName: name, isOnline: isOnline),
    ));
    // Messages were read/sent in the thread: refresh the Chats list and the Home bell badge.
    DataSync.bump();
  }

  @override
  State<ChatThreadScreen> createState() => _ChatThreadScreenState();
}

class _Msg {
  final bool isMe;
  final String text;
  final String time;
  final bool pending;

  /// Picture shown in the bubble (a link on our own server), if any.
  final String? imageUrl;

  /// Voice note (link on our own server) and its length in seconds, if known.
  final String? audioUrl;
  final int? audioSeconds;

  /// Document (link on our own server) and its original file name.
  final String? fileUrl;
  final String? fileName;

  /// An attachment (photo / voice note / document) still being uploaded.
  final ChatAttachmentKind? uploading;

  /// When the message was sent (null when the server gave no usable time).
  final DateTime? at;

  _Msg({
    required this.isMe,
    required this.text,
    required this.time,
    this.pending = false,
    this.imageUrl,
    this.audioUrl,
    this.audioSeconds,
    this.fileUrl,
    this.fileName,
    this.uploading,
    this.at,
  });
}

class _ChatThreadScreenState extends State<ChatThreadScreen> {
  final _input = TextEditingController();
  final _scroll = ScrollController();
  List<_Msg> _messages = [];
  bool _loading = true;
  bool _sending = false;
  Timer? _poll;

  // Search in conversation
  bool _searching = false;
  String _query = '';
  final TextEditingController _searchCtl = TextEditingController();
  final FocusNode _searchFocus = FocusNode();

  // View profile (looks the provider up first when it is not cached)
  bool _profileLoading = false;

  // Voice note recording
  static const int _maxVoiceSeconds = 300; // 5 minutes
  static const int _maxFileBytes = 15 * 1024 * 1024; // 15 MB
  final AudioRecorder _recorder = AudioRecorder();
  bool _recording = false;
  int _recSeconds = 0;
  Timer? _recTimer;

  // Voice note playback (one at a time)
  final AudioPlayer _player = AudioPlayer();
  final List<StreamSubscription<dynamic>> _playerSubs = [];
  final ValueNotifier<Duration> _pos = ValueNotifier(Duration.zero);
  final ValueNotifier<Duration> _dur = ValueNotifier(Duration.zero);
  String? _playingUrl;
  bool _isPlaying = false;

  bool get _isEn => AppStrings.isEnglish;
  int? get _otherId => int.tryParse(widget.otherUserId);
  bool get _isBlocked => BlockService.isBlocked(_otherId);
  bool get _isMuted => ChatPrefs.isMuted(_otherId);
  int get _myId => SessionManager.getUserIdValue();

  @override
  void initState() {
    super.initState();
    BlockService.changed.addListener(_onBlockChanged);
    ChatPrefs.changed.addListener(_onBlockChanged);
    _load();
    // Light polling so new replies show up while the screen is open.
    _poll = Timer.periodic(const Duration(seconds: 8), (_) => _load(silent: true));

    _playerSubs.addAll([
      _player.onPlayerStateChanged.listen((s) {
        if (mounted) setState(() => _isPlaying = s == PlayerState.playing);
      }),
      _player.onPositionChanged.listen((p) => _pos.value = p),
      _player.onDurationChanged.listen((d) => _dur.value = d),
      _player.onPlayerComplete.listen((_) {
        _pos.value = Duration.zero;
        if (mounted) {
          setState(() {
            _isPlaying = false;
            _playingUrl = null;
          });
        }
      }),
    ]);
  }

  void _onBlockChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    BlockService.changed.removeListener(_onBlockChanged);
    ChatPrefs.changed.removeListener(_onBlockChanged);
    _searchCtl.dispose();
    _searchFocus.dispose();
    _poll?.cancel();
    _recTimer?.cancel();
    if (_recording) {
      unawaited(_recorder.cancel().whenComplete(_recorder.dispose));
    } else {
      _recorder.dispose();
    }
    for (final sub in _playerSubs) {
      sub.cancel();
    }
    _player.dispose();
    _pos.dispose();
    _dur.dispose();
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  String _fmtTime(dynamic raw) {
    final d = DateTime.tryParse(raw?.toString() ?? '')?.toLocal();
    if (d == null) return '';
    final h = d.hour.toString().padLeft(2, '0');
    final m = d.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }

  _Msg _parse(Map<String, dynamic> m) {
    dynamic senderId = m['senderId'];
    final sender = m['sender'];
    if (senderId == null && sender is Map) senderId = sender['id'];
    final isMe = m['isMe'] == true ||
        (senderId != null && senderId.toString() == _myId.toString());
    final text = (m['content'] ?? m['message'] ?? m['text'] ?? '').toString();
    // A picture arrives either as its own field or as a link in the text
    // (that is how this app sends one, like call links). Voice notes and
    // documents are links in the text too.
    var image = (m['imageUrl'] ?? m['attachmentUrl'] ?? m['mediaUrl'])?.toString().trim();
    if (image != null && (image.isEmpty || image == 'null')) image = null;
    final kind = ApiService.chatAttachmentKind(text);
    if (image == null && kind == ChatAttachmentKind.image) image = text.trim();
    final rawTime = m['createdAt'] ?? m['timestamp'] ?? m['sentAt'] ?? m['time'];
    return _Msg(
      isMe: isMe,
      at: DateTime.tryParse(rawTime?.toString() ?? '')?.toLocal(),
      text: kind != null ? '' : text,
      imageUrl: image == null ? null : ApiService.absoluteUrl(image),
      audioUrl: kind == ChatAttachmentKind.audio ? ApiService.chatAttachmentUrl(text) : null,
      audioSeconds: kind == ChatAttachmentKind.audio ? ApiService.chatAudioSeconds(text) : null,
      fileUrl: kind == ChatAttachmentKind.file ? ApiService.chatAttachmentUrl(text) : null,
      fileName: kind == ChatAttachmentKind.file ? ApiService.chatAttachmentName(text) : null,
      time: _fmtTime(rawTime),
    );
  }

  Future<void> _load({bool silent = false}) async {
    await ChatPrefs.ensureLoaded();
    final raw = await ApiService.fetchMessages(widget.otherUserId);
    if (!mounted) return;
    final clearedAt = ChatPrefs.clearedAt(_otherId);
    final parsed = raw
        .whereType<Map>()
        .map((e) => _parse(Map<String, dynamic>.from(e)))
        .where((m) => m.text.isNotEmpty || m.imageUrl != null || m.audioUrl != null || m.fileUrl != null)
        .where((m) => clearedAt == null || m.at == null || m.at!.isAfter(clearedAt))
        .toList();
    final changed = parsed.length != _messages.where((m) => !m.pending).length;
    setState(() {
      _loading = false;
      // keep any message still being sent
      _messages = [...parsed, ..._messages.where((m) => m.pending)];
    });
    if (changed || !silent) _scrollToEnd();
  }

  void _scrollToEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _send() async {
    final text = _input.text.trim();
    if (text.isEmpty || _sending || _isBlocked) return;
    _input.clear();
    setState(() {
      _sending = true;
      _messages.add(_Msg(isMe: true, text: text, time: _fmtTime(DateTime.now().toIso8601String()), pending: true));
    });
    _scrollToEnd();

    final res = await ApiService.sendMessage(recipientId: widget.otherUserId, message: text);
    if (!mounted) return;
    setState(() => _sending = false);

    if (res == null) {
      setState(() => _messages.removeWhere((m) => m.pending && m.text == text));
      _input.text = text;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        backgroundColor: AppColors.danger,
        content: Text(_isEn ? 'Message not sent. Try again.' : 'Ujumbe haujatumwa. Jaribu tena.'),
      ));
      return;
    }
    await _load(silent: true);
    _scrollToEnd();
  }

  // ---------------------------------------------------------------------------
  // Three-dots menu actions
  // ---------------------------------------------------------------------------

  void _openSearch() {
    setState(() {
      _searching = true;
      _query = '';
      _searchCtl.clear();
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _searchFocus.requestFocus();
    });
  }

  void _closeSearch() {
    FocusScope.of(context).unfocus();
    setState(() {
      _searching = false;
      _query = '';
      _searchCtl.clear();
    });
    _scrollToEnd();
  }

  bool _matchesQuery(_Msg m) {
    final q = _query.trim().toLowerCase();
    if (q.isEmpty) return true;
    return m.text.toLowerCase().contains(q) || (m.fileName ?? '').toLowerCase().contains(q);
  }

  /// The other person's service (needed for the profile page and call options).
  /// Opened from the Chats list or a notification it is not cached yet, so it
  /// is looked up first. Null when this person has no provider listing.
  Future<ServiceItem?> _resolveProvider() async {
    final id = _otherId;
    if (id == null || id == 0) return null;

    ServiceItem? find() {
      for (final s in ApiService.knownServices.values) {
        if (s.sellerId == id) return s;
      }
      return null;
    }

    var provider = find();
    if (provider == null) {
      setState(() => _profileLoading = true);
      await ApiService.fetchServices(query: widget.otherName);
      if (!mounted) return null;
      setState(() => _profileLoading = false);
      provider = find();
    }
    return provider;
  }

  Future<void> _viewProfile() async {
    if (_profileLoading) return;
    final provider = await _resolveProvider();
    if (!mounted) return;
    if (provider == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(_isEn
            ? 'No provider profile for ${widget.otherName}.'
            : 'Hakuna wasifu wa mtoa huduma kwa ${widget.otherName}.'),
      ));
      return;
    }
    await Navigator.push(context, MaterialPageRoute(builder: (_) => SellerProfileScreen(provider: provider)));
  }

  /// Call button: opens every way to reach this person (in-app audio / video,
  /// mobile call, WhatsApp, directions).
  Future<void> _showCallOptions() async {
    if (_profileLoading) return;
    final provider = await _resolveProvider();
    if (!mounted) return;
    if (provider == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(_isEn
            ? 'No call options available for ${widget.otherName}.'
            : 'Hakuna njia za kupiga simu kwa ${widget.otherName}.'),
      ));
      return;
    }
    await CallOptionsSheet.show(context, provider);
  }

  Future<void> _toggleMute() async {
    final id = _otherId;
    if (id == null || id == 0) return;
    final mute = !_isMuted;
    await ChatPrefs.setMuted(id, mute);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(mute
          ? (_isEn ? 'Notifications muted for ${widget.otherName}.' : 'Arifa zimenyamazishwa kwa ${widget.otherName}.')
          : (_isEn ? 'Notifications turned on.' : 'Arifa zimewashwa.')),
    ));
  }

  Future<void> _clearChat() async {
    final id = _otherId;
    if (id == null || id == 0) return;
    DateTime? latest;
    for (final m in _messages) {
      final t = m.at;
      if (!m.pending && t != null && (latest == null || t.isAfter(latest))) latest = t;
    }
    if (latest == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(_isEn ? 'There are no messages to clear.' : 'Hakuna ujumbe wa kufuta.'),
      ));
      return;
    }
    final moment = latest;
    final ok = await AppDialog.confirm(
      context,
      icon: Icons.delete_sweep_outlined,
      color: AppColors.danger,
      title: _isEn ? 'Clear this chat?' : 'Futa mazungumzo haya?',
      message: _isEn
          ? 'Messages are removed from this phone only. ${widget.otherName} keeps their copy.'
          : 'Ujumbe unafutwa kwenye simu hii tu. ${widget.otherName} ataendelea kuwa nao.',
      confirmLabel: _isEn ? 'Clear chat' : 'Futa',
    );
    if (!ok || !mounted) return;
    await ChatPrefs.clearUpTo(id, moment);
    if (!mounted) return;
    setState(() => _messages.removeWhere((m) => !m.pending));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(_isEn ? 'Chat cleared.' : 'Mazungumzo yamefutwa.'),
    ));
  }

  /// Opens the "+" menu: photo or document.
  Future<void> _showAttachMenu() async {
    if (_sending || _isBlocked) return;
    final choice = await AppSheet.show<String>(
      context,
      title: _isEn ? 'Attach' : 'Ambatisha',
      builder: (ctx) => Column(
        children: [
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.photo_outlined, color: AppColors.textPrimary),
            title: Text(_isEn ? 'Photo' : 'Picha',
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
            onTap: () => Navigator.pop(ctx, 'photo'),
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.insert_drive_file_outlined, color: AppColors.textPrimary),
            title: Text(_isEn ? 'Document' : 'Hati / Faili',
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
            subtitle: Text(
              _isEn ? 'PDF, Word, Excel, PowerPoint, text...' : 'PDF, Word, Excel, PowerPoint, maandishi...',
              style: const TextStyle(fontSize: 11, color: AppColors.textMuted),
            ),
            onTap: () => Navigator.pop(ctx, 'file'),
          ),
        ],
      ),
    );
    if (!mounted) return;
    if (choice == 'photo') {
      _attachImage();
    } else if (choice == 'file') {
      _attachFile();
    }
  }

  /// Pick a photo, upload it, then send its link as the message.
  Future<void> _attachImage() async {
    if (_sending || _isBlocked) return;
    final file = await MediaPicker.pickImage(
      context,
      title: _isEn ? 'Send a photo' : 'Tuma picha',
      maxWidth: 1600,
    );
    if (file == null || !mounted) return;
    await _sendAttachment(path: file.path, kind: ChatAttachmentKind.image);
  }

  /// Pick a document, upload it, then send its link as the message.
  Future<void> _attachFile() async {
    if (_sending || _isBlocked) return;
    final messenger = ScaffoldMessenger.of(context);
    void warn(String text) =>
        messenger.showSnackBar(SnackBar(backgroundColor: AppColors.danger, content: Text(text)));

    FilePickerResult? res;
    try {
      res = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ApiService.chatFileExtensions,
        withData: false,
      );
    } catch (_) {
      warn(_isEn ? 'Could not open the file picker.' : 'Imeshindwa kufungua uchaguzi wa faili.');
      return;
    }
    if (res == null || res.files.isEmpty || !mounted) return;
    final f = res.files.single;
    final path = f.path;
    if (path == null) {
      warn(_isEn ? 'Could not read that file.' : 'Imeshindwa kusoma faili hilo.');
      return;
    }
    if (f.size > _maxFileBytes) {
      warn(_isEn ? 'File is too large (max 15 MB).' : 'Faili ni kubwa mno (kiwango ni MB 15).');
      return;
    }
    await _sendAttachment(path: path, kind: ChatAttachmentKind.file, name: f.name);
  }

  /// Uploads [path] and sends its link as the message. Shows a placeholder
  /// bubble while uploading and removes it again if anything fails.
  Future<void> _sendAttachment({
    required String path,
    required ChatAttachmentKind kind,
    String? name,
    int? seconds,
  }) async {
    final messenger = ScaffoldMessenger.of(context);
    setState(() {
      _sending = true;
      _messages.add(_Msg(
        isMe: true,
        text: '',
        time: _fmtTime(DateTime.now().toIso8601String()),
        pending: true,
        uploading: kind,
      ));
    });
    _scrollToEnd();

    final failText = switch (kind) {
      ChatAttachmentKind.image => _isEn ? 'Photo not sent. Try again.' : 'Picha haijatumwa. Jaribu tena.',
      ChatAttachmentKind.audio => _isEn ? 'Voice message not sent. Try again.' : 'Ujumbe wa sauti haujatumwa. Jaribu tena.',
      ChatAttachmentKind.file => _isEn ? 'File not sent. Try again.' : 'Faili halijatumwa. Jaribu tena.',
    };

    void fail(String text) {
      if (!mounted) return;
      setState(() {
        _sending = false;
        _messages.removeWhere((m) => m.uploading != null);
      });
      messenger.showSnackBar(SnackBar(backgroundColor: AppColors.danger, content: Text(text)));
    }

    final up = kind == ChatAttachmentKind.image
        ? await ApiService.uploadChatImage(path)
        : await ApiService.uploadChatFile(path);
    if (!mounted) return;
    final url = up.url;
    if (!up.ok || url == null) {
      fail(up.error ?? failText);
      return;
    }
    final message = kind == ChatAttachmentKind.image
        ? url
        : ApiService.chatAttachmentLink(url, kind: kind, name: name, seconds: seconds);
    final res = await ApiService.sendMessage(recipientId: widget.otherUserId, message: message);
    if (!mounted) return;
    if (res == null) {
      fail(failText);
      return;
    }
    if (kind == ChatAttachmentKind.audio) {
      // the recording was only a temporary file
      try {
        await File(path).delete();
      } catch (_) {}
    }
    setState(() {
      _sending = false;
      _messages.removeWhere((m) => m.uploading != null);
    });
    await _load(silent: true);
    _scrollToEnd();
  }

  // ---------------------------------------------------------------------------
  // Voice notes: record
  // ---------------------------------------------------------------------------

  Future<void> _startRecording() async {
    if (_sending || _isBlocked || _recording) return;
    final messenger = ScaffoldMessenger.of(context);
    final access = await MediaPermissions.microphone();
    if (!mounted) return;
    if (access != MediaAccess.granted) {
      messenger.showSnackBar(SnackBar(
        backgroundColor: AppColors.danger,
        content: Text(_isEn ? 'Allow microphone access to record a voice message.' : 'Ruhusu kipaza sauti ili kurekodi ujumbe wa sauti.'),
        action: access == MediaAccess.permanentlyDenied
            ? SnackBarAction(
                label: _isEn ? 'Settings' : 'Mipangilio',
                textColor: Colors.white,
                onPressed: PermissionService.openSettings,
              )
            : null,
      ));
      return;
    }

    try {
      await _player.pause(); // don't record over a playing voice note
      final path = '${Directory.systemTemp.path}/voice_${DateTime.now().millisecondsSinceEpoch}.m4a';
      await _recorder.start(
        const RecordConfig(
          encoder: AudioEncoder.aacLc,
          bitRate: 64000,
          sampleRate: 44100,
          numChannels: 1,
        ),
        path: path,
      );
      if (!mounted) {
        await _recorder.cancel();
        return;
      }
      setState(() {
        _recording = true;
        _recSeconds = 0;
      });
      _recTimer?.cancel();
      _recTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (!mounted || !_recording) return;
        setState(() => _recSeconds++);
        if (_recSeconds >= _maxVoiceSeconds) _finishRecording();
      });
    } catch (_) {
      messenger.showSnackBar(SnackBar(
        backgroundColor: AppColors.danger,
        content: Text(_isEn ? 'Could not start recording.' : 'Imeshindwa kuanza kurekodi.'),
      ));
    }
  }

  /// Stops recording and sends the voice note.
  Future<void> _finishRecording() async {
    if (!_recording) return;
    final seconds = _recSeconds;
    _recTimer?.cancel();
    setState(() {
      _recording = false;
      _recSeconds = 0;
    });
    String? path;
    try {
      path = await _recorder.stop();
    } catch (_) {}
    if (!mounted) return;
    if (path == null || seconds < 1) {
      if (path != null) {
        try {
          await File(path).delete();
        } catch (_) {}
      }
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(_isEn ? 'Voice message too short.' : 'Ujumbe wa sauti ni mfupi mno.'),
      ));
      return;
    }
    await _sendAttachment(path: path, kind: ChatAttachmentKind.audio, seconds: seconds);
  }

  /// Throws the recording away.
  Future<void> _cancelRecording() async {
    if (!_recording) return;
    _recTimer?.cancel();
    setState(() {
      _recording = false;
      _recSeconds = 0;
    });
    try {
      await _recorder.cancel();
    } catch (_) {}
  }

  // ---------------------------------------------------------------------------
  // Voice notes: play, and open documents
  // ---------------------------------------------------------------------------

  Future<void> _togglePlay(String url) async {
    try {
      if (_playingUrl == url) {
        if (_isPlaying) {
          await _player.pause();
        } else {
          await _player.resume();
        }
        return;
      }
      await _player.stop();
      _pos.value = Duration.zero;
      _dur.value = Duration.zero;
      setState(() => _playingUrl = url);
      await _player.play(UrlSource(url));
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _playingUrl = null;
        _isPlaying = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        backgroundColor: AppColors.danger,
        content: Text(_isEn ? 'Could not play this voice message.' : 'Imeshindwa kucheza ujumbe huu wa sauti.'),
      ));
    }
  }

  Future<void> _openFile(String url) async {
    final messenger = ScaffoldMessenger.of(context);
    var ok = false;
    try {
      ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (_) {}
    if (!ok) {
      messenger.showSnackBar(SnackBar(
        backgroundColor: AppColors.danger,
        content: Text(_isEn ? 'Could not open this file.' : 'Imeshindwa kufungua faili hili.'),
      ));
    }
  }

  String _fmtDur(Duration d) {
    final m = d.inMinutes.toString();
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  Widget _blockedBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: AppColors.borderLight)),
      ),
      child: Row(
        children: [
          const Icon(Icons.block_rounded, size: 18, color: AppColors.danger),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              _isEn ? 'You blocked this user. Unblock to send messages.' : 'Umemzuia mtumiaji huyu. Mfungulie ili utume ujumbe.',
              style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
            ),
          ),
          TextButton(
            onPressed: () {
              final id = _otherId;
              if (id != null) BlockUserDialog.confirmUnblock(context, userId: id, name: widget.otherName);
            },
            child: Text(_isEn ? 'Unblock' : 'Fungulia', style: const TextStyle(fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      // Back closes the search first instead of leaving the chat.
      canPop: !_searching,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && _searching) _closeSearch();
      },
      child: _scaffold(context),
    );
  }

  Widget _scaffold(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        titleSpacing: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18, color: AppColors.textPrimary),
          onPressed: _searching ? _closeSearch : () => Navigator.pop(context),
        ),
        title: _searching ? _searchField() : Row(
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                CircleAvatar(
                  radius: 17,
                  backgroundColor: AppColors.primaryLight,
                  child: Text(
                    widget.otherName.isNotEmpty ? widget.otherName.substring(0, 1).toUpperCase() : '?',
                    style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.primary),
                  ),
                ),
                Positioned(right: -1, bottom: -1, child: OnlineDot(online: widget.isOnline, size: 12)),
              ],
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          widget.otherName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                        ),
                      ),
                      if (_isMuted)
                        const Padding(
                          padding: EdgeInsets.only(left: 6),
                          child: Icon(Icons.notifications_off_outlined, size: 15, color: AppColors.textMuted),
                        ),
                    ],
                  ),
                  if (widget.isOnline)
                    Text(
                      AppStrings.chatsOnline,
                      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.onlineGreen),
                    ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          if (_searching) ...[
            if (_query.isNotEmpty)
              IconButton(
                tooltip: _isEn ? 'Clear' : 'Futa',
                icon: const Icon(Icons.close_rounded, color: AppColors.textSecondary),
                onPressed: () {
                  _searchCtl.clear();
                  setState(() => _query = '');
                },
              ),
          ] else if (_otherId != null && _otherId != 0) ...[
            IconButton(
              tooltip: _isEn ? 'Call' : 'Piga simu',
              icon: const Icon(Icons.call_outlined, color: AppColors.textPrimary),
              onPressed: _isBlocked ? null : _showCallOptions,
            ),
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_vert_rounded, color: AppColors.textPrimary),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              onSelected: (v) {
                final id = _otherId!;
                switch (v) {
                  case 'profile':
                    _viewProfile();
                  case 'search':
                    _openSearch();
                  case 'mute':
                    _toggleMute();
                  case 'clear':
                    _clearChat();
                  case 'report':
                    ReportSheet.show(context, target: ReportTarget.user, userId: id, name: widget.otherName).then((out) {
                      if (out.blocked && mounted) Navigator.pop(context);
                    });
                  case 'block':
                    BlockUserDialog.confirmBlock(context, userId: id, name: widget.otherName);
                  default:
                    BlockUserDialog.confirmUnblock(context, userId: id, name: widget.otherName);
                }
              },
              itemBuilder: (_) => [
                _menuItem('profile', Icons.person_outline_rounded, _isEn ? 'View profile' : 'Tazama wasifu'),
                _menuItem('search', Icons.search_rounded, _isEn ? 'Search' : 'Tafuta'),
                _menuItem(
                  'mute',
                  _isMuted ? Icons.notifications_active_outlined : Icons.notifications_off_outlined,
                  _isMuted
                      ? (_isEn ? 'Unmute notifications' : 'Washa arifa')
                      : (_isEn ? 'Mute notifications' : 'Nyamazisha arifa'),
                ),
                _menuItem('clear', Icons.delete_sweep_outlined, _isEn ? 'Clear chat' : 'Futa mazungumzo'),
                const PopupMenuDivider(),
                _menuItem(
                  _isBlocked ? 'unblock' : 'block',
                  _isBlocked ? Icons.lock_open_rounded : Icons.block_rounded,
                  _isBlocked ? (_isEn ? 'Unblock user' : 'Mfungulie mtumiaji') : (_isEn ? 'Block user' : 'Mzuie mtumiaji'),
                  color: _isBlocked ? AppColors.primary : AppColors.danger,
                ),
                _menuItem('report', Icons.flag_outlined, _isEn ? 'Report user' : 'Ripoti mtumiaji'),
              ],
            ),
          ],
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.border, height: 1),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            if (_profileLoading)
              const LinearProgressIndicator(minHeight: 2, color: AppColors.primary, backgroundColor: AppColors.borderLight),
            Expanded(child: _messageArea()),
            if (_searching)
              const SizedBox.shrink()
            else if (_isBlocked)
              _blockedBar()
            else
              _composer(),
          ],
        ),
      ),
    );
  }

  /// The messages (or the search results while searching).
  Widget _messageArea() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator(color: AppColors.primary));
    }
    final visible = _searching ? _messages.where(_matchesQuery).toList() : _messages;
    if (visible.isEmpty) {
      final searchingNothing = _searching && _query.trim().isNotEmpty;
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Text(
            searchingNothing
                ? (_isEn ? 'No messages found.' : 'Hakuna ujumbe uliopatikana.')
                : (_isEn ? 'Say hello to ${widget.otherName} 👋' : 'Mwambie ${widget.otherName} habari 👋'),
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 14, color: AppColors.textSecondary),
          ),
        ),
      );
    }
    return ListView.builder(
      controller: _scroll,
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
      itemCount: visible.length,
      itemBuilder: (_, i) => _bubble(visible[i]),
    );
  }

  Widget _searchField() {
    return TextField(
      controller: _searchCtl,
      focusNode: _searchFocus,
      textInputAction: TextInputAction.search,
      onChanged: (v) => setState(() => _query = v),
      decoration: InputDecoration(
        hintText: _isEn ? 'Search messages...' : 'Tafuta ujumbe...',
        hintStyle: const TextStyle(fontSize: 14, color: AppColors.textMuted),
        border: InputBorder.none,
      ),
      style: const TextStyle(fontSize: 15, color: AppColors.textPrimary),
    );
  }

  PopupMenuItem<String> _menuItem(String value, IconData icon, String label, {Color? color}) {
    final c = color ?? AppColors.textPrimary;
    return PopupMenuItem<String>(
      value: value,
      child: Row(
        children: [
          Icon(icon, size: 18, color: color ?? AppColors.textSecondary),
          const SizedBox(width: 10),
          Text(label, style: TextStyle(fontWeight: FontWeight.w600, color: c)),
        ],
      ),
    );
  }

  /// A text message; while searching, the matching words are highlighted.
  Widget _messageText(_Msg m) {
    final style = TextStyle(fontSize: 14, color: m.isMe ? Colors.white : AppColors.textPrimary);
    final q = _query.trim().toLowerCase();
    final lower = m.text.toLowerCase();
    if (!_searching || q.isEmpty || lower.length != m.text.length) return Text(m.text, style: style);
    final spans = <TextSpan>[];
    var i = 0;
    while (true) {
      final at = lower.indexOf(q, i);
      if (at < 0) {
        if (i < m.text.length) spans.add(TextSpan(text: m.text.substring(i)));
        break;
      }
      if (at > i) spans.add(TextSpan(text: m.text.substring(i, at)));
      spans.add(TextSpan(
        text: m.text.substring(at, at + q.length),
        style: TextStyle(backgroundColor: Colors.yellow.shade300, color: Colors.black, fontWeight: FontWeight.w700),
      ));
      i = at + q.length;
    }
    return Text.rich(TextSpan(style: style, children: spans));
  }

  Widget _roundButton({required IconData icon, required VoidCallback? onTap, Color color = AppColors.primary}) {
    return Material(
      color: color,
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(11),
          child: Icon(icon, color: Colors.white, size: 20),
        ),
      ),
    );
  }

  Widget _composer() {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: AppColors.borderLight)),
      ),
      child: _recording ? _recordingBar() : _inputRow(),
    );
  }

  Widget _inputRow() {
    return Row(
      children: [
        IconButton(
          tooltip: _isEn ? 'Attach' : 'Ambatisha',
          onPressed: _sending ? null : _showAttachMenu,
          icon: const Icon(Icons.attach_file_rounded, color: AppColors.primary),
        ),
        Expanded(
          child: TextField(
            controller: _input,
            minLines: 1,
            maxLines: 4,
            textInputAction: TextInputAction.send,
            onSubmitted: (_) => _send(),
            decoration: InputDecoration(
              hintText: _isEn ? 'Type a message...' : 'Andika ujumbe...',
              hintStyle: const TextStyle(fontSize: 13, color: AppColors.textMuted),
              filled: true,
              fillColor: AppColors.background,
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(22),
                borderSide: BorderSide.none,
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        // Empty box: microphone (tap to record). With text: send.
        ValueListenableBuilder<TextEditingValue>(
          valueListenable: _input,
          builder: (_, value, _) {
            final hasText = value.text.trim().isNotEmpty;
            return Tooltip(
              message: hasText
                  ? (_isEn ? 'Send' : 'Tuma')
                  : (_isEn ? 'Record voice message' : 'Rekodi ujumbe wa sauti'),
              child: _roundButton(
                icon: hasText ? Icons.send_rounded : Icons.mic_rounded,
                onTap: hasText ? _send : (_sending ? null : _startRecording),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _recordingBar() {
    return Row(
      children: [
        IconButton(
          tooltip: _isEn ? 'Cancel' : 'Ghairi',
          onPressed: _cancelRecording,
          icon: const Icon(Icons.delete_outline_rounded, color: AppColors.danger),
        ),
        const SizedBox(width: 4),
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(
            color: _recSeconds.isEven ? AppColors.danger : AppColors.danger.withValues(alpha: 0.35),
            shape: BoxShape.circle,
          ),
        ),
        const SizedBox(width: 10),
        Text(
          _fmtDur(Duration(seconds: _recSeconds)),
          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            _isEn ? 'Recording...' : 'Inarekodi...',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
          ),
        ),
        _roundButton(icon: Icons.send_rounded, onTap: _finishRecording),
      ],
    );
  }

  /// Our own call-room link inside a message, if any.
  String? _callLink(String text) {
    final m = RegExp(r'https://meet\.jit\.si/[^\s]+').firstMatch(text);
    return m?.group(0);
  }

  Widget _bubble(_Msg m) {
    return Align(
      alignment: m.isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 3),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
        decoration: BoxDecoration(
          color: m.isMe ? AppColors.primary : Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(14),
            topRight: const Radius.circular(14),
            bottomLeft: Radius.circular(m.isMe ? 14 : 3),
            bottomRight: Radius.circular(m.isMe ? 3 : 14),
          ),
          border: m.isMe ? null : Border.all(color: AppColors.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            if (m.uploading != null)
              _uploadingPlaceholder(m)
            else if (m.audioUrl != null)
              _voiceBubble(m)
            else if (m.fileUrl != null)
              _fileBubble(m)
            else if (m.imageUrl != null)
              GestureDetector(
                onTap: () {
                  final all = [for (final x in _messages) if (x.imageUrl != null) x.imageUrl!];
                  final at = all.indexOf(m.imageUrl!);
                  FullscreenImageViewer.open(context, images: all, initialIndex: at < 0 ? 0 : at);
                },
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: AppImage(
                    m.imageUrl!,
                    width: 220,
                    height: 160,
                    fit: BoxFit.cover,
                    errorBuilder: (_, _, _) => Container(
                      width: 220,
                      height: 120,
                      alignment: Alignment.center,
                      color: Colors.black12,
                      child: const Icon(Icons.broken_image_outlined, color: AppColors.textMuted),
                    ),
                  ),
                ),
              ),
            if (m.text.isNotEmpty)
              Padding(
                padding: EdgeInsets.only(top: m.imageUrl != null ? 6 : 0),
                child: _messageText(m),
              ),
            if (_callLink(m.text) != null) ...[
              const SizedBox(height: 8),
              SizedBox(
                height: 34,
                child: ElevatedButton.icon(
                  onPressed: () => CallService.joinCall(context, _callLink(m.text)!),
                  icon: const Icon(Icons.call_rounded, size: 16),
                  label: Text(_isEn ? 'Join call' : 'Jiunge na simu'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: m.isMe ? Colors.white : AppColors.success,
                    foregroundColor: m.isMe ? AppColors.primary : Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                ),
              ),
            ],
            const SizedBox(height: 2),
            Text(
              m.pending ? '…' : m.time,
              style: TextStyle(fontSize: 10, color: m.isMe ? Colors.white70 : AppColors.textMuted),
            ),
          ],
        ),
      ),
    );
  }

  Widget _uploadingPlaceholder(_Msg m) {
    if (m.uploading == ChatAttachmentKind.image) {
      return Container(
        width: 160,
        height: 120,
        alignment: Alignment.center,
        decoration: BoxDecoration(color: Colors.black12, borderRadius: BorderRadius.circular(10)),
        child: const SizedBox(
          width: 22,
          height: 22,
          child: CircularProgressIndicator(strokeWidth: 2),
        ),
      );
    }
    final fg = m.isMe ? Colors.white : AppColors.textPrimary;
    final label = m.uploading == ChatAttachmentKind.audio
        ? (_isEn ? 'Sending voice message...' : 'Inatuma ujumbe wa sauti...')
        : (_isEn ? 'Sending file...' : 'Inatuma faili...');
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          width: 18,
          height: 18,
          child: CircularProgressIndicator(strokeWidth: 2, color: fg),
        ),
        const SizedBox(width: 10),
        Text(label, style: TextStyle(fontSize: 13, color: fg)),
      ],
    );
  }

  Widget _voiceBubble(_Msg m) {
    final url = m.audioUrl!;
    final fg = m.isMe ? Colors.white : AppColors.primary;
    final active = _playingUrl == url;
    final playing = active && _isPlaying;
    final known = Duration(seconds: m.audioSeconds ?? 0);

    return SizedBox(
      width: 210,
      child: Row(
        children: [
          InkWell(
            customBorder: const CircleBorder(),
            onTap: () => _togglePlay(url),
            child: Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: m.isMe ? Colors.white24 : AppColors.primaryLight,
              ),
              child: Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded, color: fg, size: 24),
            ),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: ValueListenableBuilder<Duration>(
              valueListenable: _pos,
              builder: (_, pos, _) => ValueListenableBuilder<Duration>(
                valueListenable: _dur,
                builder: (_, dur, _) {
                  final total = active && dur.inMilliseconds > 0 ? dur : known;
                  final shownPos = active ? pos : Duration.zero;
                  final frac = total.inMilliseconds == 0
                      ? 0.0
                      : (shownPos.inMilliseconds / total.inMilliseconds).clamp(0.0, 1.0).toDouble();
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SliderTheme(
                        data: SliderTheme.of(context).copyWith(
                          trackHeight: 3,
                          thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 5, disabledThumbRadius: 5),
                          overlayShape: SliderComponentShape.noOverlay,
                          activeTrackColor: fg,
                          inactiveTrackColor: fg.withValues(alpha: 0.3),
                          thumbColor: fg,
                          disabledActiveTrackColor: fg,
                          disabledInactiveTrackColor: fg.withValues(alpha: 0.3),
                          disabledThumbColor: fg,
                        ),
                        child: Slider(
                          value: frac,
                          onChanged: active && total.inMilliseconds > 0
                              ? (v) => _player.seek(Duration(milliseconds: (v * total.inMilliseconds).round()))
                              : null,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 6),
                        child: Text(
                          total.inMilliseconds == 0 && !active
                              ? '🎤'
                              : _fmtDur(active ? shownPos : total),
                          style: TextStyle(fontSize: 11, color: m.isMe ? Colors.white70 : AppColors.textSecondary),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  IconData _fileIcon(String ext) {
    switch (ext) {
      case 'pdf':
        return Icons.picture_as_pdf_outlined;
      case 'doc':
      case 'docx':
      case 'odt':
      case 'rtf':
      case 'txt':
        return Icons.description_outlined;
      case 'xls':
      case 'xlsx':
      case 'csv':
      case 'ods':
        return Icons.table_chart_outlined;
      case 'ppt':
      case 'pptx':
        return Icons.slideshow_outlined;
      case 'zip':
        return Icons.folder_zip_outlined;
      default:
        return Icons.insert_drive_file_outlined;
    }
  }

  Widget _fileBubble(_Msg m) {
    final name = m.fileName ?? (_isEn ? 'Document' : 'Faili');
    final dot = name.lastIndexOf('.');
    final ext = dot < 0 ? '' : name.substring(dot + 1).toLowerCase();
    final fg = m.isMe ? Colors.white : AppColors.textPrimary;
    final sub = m.isMe ? Colors.white70 : AppColors.textSecondary;
    return InkWell(
      borderRadius: BorderRadius.circular(10),
      onTap: () => _openFile(m.fileUrl!),
      child: SizedBox(
        width: 220,
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: m.isMe ? Colors.white24 : AppColors.primaryLight,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(_fileIcon(ext), color: m.isMe ? Colors.white : AppColors.primary, size: 22),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: fg),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '${ext.isEmpty ? '' : '${ext.toUpperCase()} • '}${_isEn ? 'Tap to open' : 'Gusa kufungua'}',
                    style: TextStyle(fontSize: 10, color: sub),
                  ),
                ],
              ),
            ),
            Icon(Icons.download_rounded, size: 18, color: sub),
          ],
        ),
      ),
    );
  }
}

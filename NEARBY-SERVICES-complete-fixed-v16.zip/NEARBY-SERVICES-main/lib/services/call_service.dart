import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../screens/map_tracking_screen.dart';
import '../widgets/login_modal.dart';
import 'api_service.dart';
import 'session_manager.dart';

/// Phone and in-app calling.
///
/// In-app calls use a private Jitsi room. The other person is invited through
/// the app chat (the invite message contains the room link and shows a
/// "Join call" button). Audio calls start with the camera off.
class CallService {
  static bool get _isEn => AppStrings.isEnglish;

  static void _snack(BuildContext context, String msg, {Color? color}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: color));
  }

  /// Normal phone call through the phone dialer.
  static Future<void> mobileCall(BuildContext context, String phone) async {
    final number = phone.replaceAll(RegExp(r'[^0-9+]'), '');
    if (number.isEmpty) return;
    final ok = await launchUrl(Uri(scheme: 'tel', path: number));
    if (!ok && context.mounted) {
      _snack(context, _isEn ? 'Could not open the phone dialer' : 'Imeshindwa kufungua simu');
    }
  }

  /// Opens a WhatsApp chat with the number.
  static Future<void> whatsapp(BuildContext context, String phone) async {
    final digits = phone.replaceAll(RegExp(r'\D'), '');
    if (digits.isEmpty) return;
    final ok = await launchUrl(Uri.parse('https://wa.me/$digits'), mode: LaunchMode.externalApplication);
    if (!ok && context.mounted) {
      _snack(context, _isEn ? 'Could not open WhatsApp' : 'Imeshindwa kufungua WhatsApp');
    }
  }

  /// Opens in-app turn-by-turn navigation to the provider (no external maps app).
  /// Uses the provider's coordinates when known, otherwise looks up [query].
  static Future<void> navigate(
    BuildContext context, {
    double? lat,
    double? lng,
    String? query,
    String providerName = '',
    String serviceTitle = '',
  }) async {
    final hasCoords = lat != null && lng != null;
    final hasQuery = query != null && query.trim().isNotEmpty;
    if (!hasCoords && !hasQuery) {
      _snack(context, _isEn ? 'No location available for this provider.' : 'Hakuna eneo la mtoa huduma huyu.');
      return;
    }
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => MapTrackingScreen(
          providerName: providerName,
          serviceTitle: serviceTitle,
          address: hasQuery ? query.trim() : '',
          providerLat: lat,
          providerLng: lng,
          startNavigating: true,
        ),
      ),
    );
  }

  /// Starts an in-app audio or video call with the provider.
  static Future<void> inAppCall(
    BuildContext context, {
    required int? recipientId,
    required String name,
    required bool video,
  }) async {
    if (recipientId == null || recipientId == 0) {
      _snack(context, _isEn ? 'Calls are not available for this provider yet.' : 'Simu hazipatikani kwa mtoa huduma huyu bado.');
      return;
    }
    if (!SessionManager.isLoggedIn()) {
      final ok = await LoginModal.show(context);
      if (ok != true || !SessionManager.isLoggedIn()) return;
    }
    if (!context.mounted) return;

    final me = SessionManager.getUserIdValue();
    if (me == recipientId) {
      _snack(context, _isEn ? "You can't call yourself." : 'Huwezi kujipigia simu.');
      return;
    }

    final lo = me < recipientId ? me : recipientId;
    final hi = me < recipientId ? recipientId : me;
    final room = 'nearbyservices-$lo-$hi-${DateTime.now().millisecondsSinceEpoch}';
    final myName = Uri.encodeComponent('"${SessionManager.getStageName()}"');
    final config = video
        ? 'config.startWithVideoMuted=false'
        : 'config.startAudioOnly=true&config.startWithVideoMuted=true';
    final url = 'https://meet.jit.si/$room#$config&userInfo.displayName=$myName';

    final label = video ? (_isEn ? 'video' : 'video') : (_isEn ? 'audio' : 'sauti');
    final invite = _isEn
        ? '📞 Incoming $label call from ${SessionManager.getStageName()}. Tap to join: $url'
        : '📞 Simu ya $label inakupigia kutoka kwa ${SessionManager.getStageName()}. Bonyeza kujiunga: $url';

    _snack(context, _isEn ? 'Calling $name...' : 'Inampigia $name...');
    final sent = await ApiService.sendMessage(recipientId: recipientId.toString(), message: invite);
    if (!context.mounted) return;
    if (sent == null) {
      _snack(
        context,
        _isEn ? 'Could not reach $name. Check your connection and try again.' : 'Imeshindwa kumfikia $name. Angalia mtandao kisha jaribu tena.',
        color: AppColors.danger,
      );
      return;
    }
    await joinCall(context, url);
  }

  /// Opens a call room link (used by the caller, and by the "Join call" button in chat).
  static Future<void> joinCall(BuildContext context, String url) async {
    final uri = Uri.tryParse(url);
    // Only ever open our own Jitsi rooms.
    if (uri == null || uri.scheme != 'https' || uri.host != 'meet.jit.si') return;
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && context.mounted) {
      _snack(context, _isEn ? 'Could not open the call' : 'Imeshindwa kufungua simu');
    }
  }
}

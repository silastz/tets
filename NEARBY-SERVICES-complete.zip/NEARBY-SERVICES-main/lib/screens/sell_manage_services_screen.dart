import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/session_manager.dart';
import '../services/share_service.dart';
import '../widgets/skeleton_loader.dart';
import 'add_edit_service_screen.dart';
import 'register_provider_screen.dart';
import '../services/data_sync.dart';

class SellManageServicesScreen extends StatefulWidget {
  final VoidCallback? onBackToHome;

  const SellManageServicesScreen({super.key, this.onBackToHome});

  @override
  State<SellManageServicesScreen> createState() => _SellManageServicesScreenState();
}

class _SellManageServicesScreenState extends State<SellManageServicesScreen> {
  String _activeTab = 'Active'; // 'Active', 'Pending', 'Inactive'
  bool _isLoading = true;
  List<dynamic> _services = [];

  // Something was written to the server elsewhere (booking, accept, wallet, review...): re-fetch.
  void _onDataChanged() {
    if (mounted) _loadSellerServices();
  }

  @override
  void dispose() {
    DataSync.changed.removeListener(_onDataChanged);
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    DataSync.changed.addListener(_onDataChanged);
    _loadSellerServices();
  }

  Future<void> _loadSellerServices() async {
    setState(() => _isLoading = true);
    final list = await ApiService.fetchSellerServices();
    if (mounted) {
      setState(() {
        _services = list;
        _isLoading = false;
      });
    }
  }

  /// Opens the full-page Add / Edit Service flow (no more modal).
  Future<void> _openAddEditService({Map<String, dynamic>? existing}) async {
    final saved = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => AddEditServiceScreen(existing: existing)),
    );
    if (saved == true && mounted) {
      _loadSellerServices();
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppLanguage>(
      valueListenable: AppStrings.currentLanguage,
      builder: (context, _, _) {
        final bool isProvider = SessionManager.isLoggedIn() && SessionManager.getRole() == 'ROLE_SELLER';
        return Scaffold(
          backgroundColor: AppColors.surface,
          appBar: AppBar(
            backgroundColor: AppColors.surface,
            elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () {
            if (widget.onBackToHome != null) {
              widget.onBackToHome!();
            } else if (Navigator.canPop(context)) {
              Navigator.pop(context);
            }
          },
        ),
        title: Text(
          // Guests & buyers are NOT on a services page: they see the registration page.
          // Only providers (sellers) see "My Services".
          isProvider
              ? AppStrings.sellMyServicesTitle
              : (AppStrings.isEnglish ? 'Register as Provider' : 'Jisajili kama Mtoa Huduma'),
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        actions: [
          // "Add Service" is for providers only (hidden for guests & buyers)
          if (isProvider)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            child: SizedBox(
              height: 36,
              child: ElevatedButton.icon(
                onPressed: () => _openAddEditService(),
                icon: const Icon(Icons.add, size: 16),
                label: Text(AppStrings.sellAddService),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                ),
              ),
            ),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: (!SessionManager.isLoggedIn() || SessionManager.getRole() != 'ROLE_SELLER')
          ? SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      color: AppColors.primaryLight,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.primary.withValues(alpha: 0.15),
                          blurRadius: 16,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: const Icon(Icons.storefront_rounded, size: 40, color: AppColors.primary),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    AppStrings.profileBecomeSeller,
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AppColors.textPrimary),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    AppStrings.isEnglish
                        ? 'Start selling and offering your services to clients right near you. Join thousands of trusted service providers across Tanzania!'
                        : 'Anza kuuza na kutoa huduma zako kwa wateja waliokaribu nawe. Jiunge na maelfu ya watoa huduma wanaoaminika Tanzania nzima!',
                    style: const TextStyle(fontSize: 13, height: 1.5, color: AppColors.textSecondary),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 24),

                  // Benefits checklist
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppColors.background,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          AppStrings.isEnglish ? 'Benefits of Becoming a Provider:' : 'Faida za Kuwa Mtoa Huduma:',
                          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                        ),
                        const SizedBox(height: 12),
                        _buildBenefitRow(
                          Icons.near_me_rounded,
                          AppStrings.isEnglish ? 'Nearby Clients' : 'Wateja Waliokaribu',
                          AppStrings.isEnglish ? 'Get service requests from customers located in your neighborhood or local area.' : 'Pata maombi ya kazi kutoka kwa wateja waliopo mtaa au eneo lako.',
                        ),
                        const SizedBox(height: 10),
                        _buildBenefitRow(
                          Icons.security_rounded,
                          AppStrings.isEnglish ? 'Safe Escrow Payments' : 'Malipo Salama ya Escrow',
                          AppStrings.isEnglish ? 'Job payments are held securely until the task is marked completed.' : 'Fedha za kazi zinashikiliwa kwa usalama hadi kazi inapokamilika.',
                        ),
                        const SizedBox(height: 10),
                        _buildBenefitRow(
                          Icons.verified_rounded,
                          AppStrings.isEnglish ? 'Verified Badge (Blue Tick)' : 'Beji ya Uhakiki (Blue Tick)',
                          AppStrings.isEnglish ? 'Verify your NIDA identity and build great trust with customers.' : 'Thibitisha NIDA yako na ujenge uaminifu mkubwa kwa wateja.',
                        ),
                        const SizedBox(height: 10),
                        _buildBenefitRow(
                          Icons.lock_clock_rounded,
                          AppStrings.isEnglish ? 'Contact Privacy' : 'Faragha ya Mawasiliano',
                          AppStrings.isEnglish ? 'It is your choice to keep direct contacts locked until the client confirms the booking.' : 'Uamuzi ni wako kufunga mawasiliano yako mpaka mteja athibitishe oda.',
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Action Button
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: () async {
                        final res = await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => RegisterProviderScreen(
                              isUpgradeFromBuyer: SessionManager.isLoggedIn(),
                            ),
                          ),
                        );
                        if (res == true && mounted) {
                          _loadSellerServices();
                          setState(() {});
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        elevation: 0,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      child: Text(
                        AppStrings.regProviderTitle,
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            )
              : Column(
              children: [
                // Filter Tabs (Active, Pending, Inactive)
          Container(
            color: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: Row(
              children: ['Active', 'Pending', 'Inactive'].map((tab) {
                final isSelected = _activeTab == tab;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: GestureDetector(
                    onTap: () => setState(() => _activeTab = tab),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                      decoration: BoxDecoration(
                        color: isSelected ? AppColors.primary : AppColors.borderLight,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Text(
                        tab,
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: isSelected ? Colors.white : AppColors.textSecondary,
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
          const Divider(height: 1, color: AppColors.borderLight),

          // Managed Services List or Shimmer
          Expanded(
            child: _isLoading
                ? ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: 3,
                    separatorBuilder: (_, _) => const SizedBox(height: 14),
                    itemBuilder: (_, _) => const VerticalListCardSkeleton(),
                  )
                : _services.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.storefront_outlined, size: 48, color: Colors.grey.shade400),
                            const SizedBox(height: 12),
                            Text(
                              AppStrings.sellNoServicesTitle,
                              style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
                            ),
                            const SizedBox(height: 12),
                            ElevatedButton.icon(
                              onPressed: () => _openAddEditService(),
                              icon: const Icon(Icons.add, size: 16),
                              label: Text(AppStrings.sellAddService),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.primary,
                                foregroundColor: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      )
                    : RefreshIndicator(
                        onRefresh: _loadSellerServices,
                        child: ListView.separated(
                          padding: const EdgeInsets.all(16),
                          itemCount: _services.length,
                          separatorBuilder: (_, _) => const SizedBox(height: 14),
                          itemBuilder: (context, index) {
                            final item = _services[index] as Map<String, dynamic>;
                            final title = item['title'] ?? 'Huduma';
                            final category = item['category'] ?? 'General';
                            final price = (item['price'] as num?)?.toDouble() ?? 0.0;
                            final rateFormatted = 'TSh ${price.toInt().toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},')}';
                            final isLocked = item['isInfoLocked'] == true;

                            return Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: AppColors.border),
                              ),
                              child: Row(
                                children: [
                                  // Category Avatar Icon Box
                                  Container(
                                    width: 52,
                                    height: 52,
                                    decoration: BoxDecoration(
                                      color: AppColors.primaryLight,
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: const Icon(Icons.design_services_rounded, color: AppColors.primary, size: 24),
                                  ),
                                  const SizedBox(width: 12),

                                  // Title, Rate & Active badge
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          title,
                                          style: const TextStyle(
                                            fontSize: 13,
                                            fontWeight: FontWeight.w800,
                                            color: AppColors.textPrimary,
                                          ),
                                        ),
                                        const SizedBox(height: 2),
                                        Text(
                                          '$rateFormatted • $category',
                                          style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                                        ),
                                        const SizedBox(height: 4),
                                        Row(
                                          children: [
                                            const Icon(Icons.check_circle_rounded, size: 12, color: AppColors.success),
                                            const SizedBox(width: 3),
                                            const Text(
                                              'Active',
                                              style: TextStyle(
                                                fontSize: 11,
                                                fontWeight: FontWeight.w700,
                                                color: AppColors.success,
                                              ),
                                            ),
                                            if (isLocked) ...[
                                              const SizedBox(width: 8),
                                              Container(
                                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                                                decoration: BoxDecoration(
                                                  color: AppColors.borderLight,
                                                  borderRadius: BorderRadius.circular(4),
                                                ),
                                                child: Row(
                                                  children: [
                                                    const Icon(Icons.lock_rounded, size: 10, color: AppColors.textSecondary),
                                                    const SizedBox(width: 2),
                                                    Text(AppStrings.sellContactsLockedBadge, style: const TextStyle(fontSize: 9, color: AppColors.textSecondary)),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                  IconButton(
                                    tooltip: AppStrings.isEnglish ? 'Share' : 'Shiriki',
                                    icon: const Icon(Icons.share_outlined, color: AppColors.primary, size: 20),
                                    visualDensity: VisualDensity.compact,
                                    onPressed: () => ShareService.showServiceSheet(
                                      context,
                                      title: title.toString(),
                                      priceText: rateFormatted,
                                      providerName: SessionManager.getStageName(),
                                      category: category.toString(),
                                          serviceId: item['id']?.toString(),
                                    ),
                                  ),
                                  // 3-dots action menu
                                  PopupMenuButton<String>(
                                    icon: const Icon(Icons.more_vert_rounded, color: AppColors.textMuted, size: 20),
                                    onSelected: (value) {
                                      if (value == 'edit') _openAddEditService(existing: item);
                                      if (value == 'share') {
                                        ShareService.showServiceSheet(
                                          context,
                                          title: title.toString(),
                                          priceText: rateFormatted,
                                          providerName: SessionManager.getStageName(),
                                          category: category.toString(),
                                          serviceId: item['id']?.toString(),
                                        );
                                      }
                                    },
                                    itemBuilder: (_) => [
                                      PopupMenuItem(
                                        value: 'share',
                                        child: Row(
                                          children: [
                                            const Icon(Icons.share_outlined, size: 18, color: AppColors.textPrimary),
                                            const SizedBox(width: 10),
                                            Text(AppStrings.isEnglish ? 'Share Service' : 'Shiriki Huduma'),
                                          ],
                                        ),
                                      ),
                                      PopupMenuItem(
                                        value: 'edit',
                                        child: Row(
                                          children: [
                                            const Icon(Icons.edit_outlined, size: 18, color: AppColors.textPrimary),
                                            const SizedBox(width: 10),
                                            Text(AppStrings.isEnglish ? 'Edit Service' : 'Hariri Huduma'),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ),
          ),
        ],
      ),
    );
      },
    );
  }

  Widget _buildBenefitRow(IconData icon, String title, String description) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: AppColors.primaryLight,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, size: 16, color: AppColors.primary),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
              ),
              const SizedBox(height: 1),
              Text(
                description,
                style: const TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.3),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../security/input_validation.dart';
import '../services/attempt_limiter.dart';
import '../services/api_service.dart';
import '../widgets/app_ui.dart';

/// The invited person enters the code a Blue Tick provider sent them, plus their
/// own 20-digit NIN. The server checks both and grants the Blue Tick; both
/// people are then on record as knowing and trusting each other.
class AcceptInvitationScreen extends StatefulWidget {
  /// Pre-fills the code (e.g. when opened from an invitation card).
  final String? initialCode;
  const AcceptInvitationScreen({super.key, this.initialCode});

  @override
  State<AcceptInvitationScreen> createState() => _AcceptInvitationScreenState();
}

class _AcceptInvitationScreenState extends State<AcceptInvitationScreen> {
  final _code = TextEditingController();
  final _nin = TextEditingController();
  bool _busy = false;
  bool _done = false;
  String? _codeError;
  String? _ninError;
  String? _error;

  List<Map<String, dynamic>> _received = const [];

  bool get _isEn => AppStrings.isEnglish;

  @override
  void initState() {
    super.initState();
    final c = widget.initialCode?.trim() ?? '';
    if (c.isNotEmpty) _code.text = c;
    _loadReceived();
  }

  /// Invitations sent to my phone number show up here, so no code typing is needed.
  Future<void> _loadReceived() async {
    final list = await ApiService.fetchPendingReceivedInvitations();
    if (!mounted) return;
    setState(() => _received = list);
  }

  String _codeOf(Map<String, dynamic> inv) => (inv['code'] ?? inv['inviteCode'] ?? '').toString().trim();

  @override
  void dispose() {
    _code.dispose();
    _nin.dispose();
    super.dispose();
  }

  Future<void> _paste() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final text = data?.text?.trim() ?? '';
    final clean = text.replaceAll(RegExp(r'[^A-Za-z0-9\-]'), '');
    if (clean.isNotEmpty) setState(() => _code.text = clean.length > 24 ? clean.substring(0, 24) : clean);
  }

  Future<void> _submit() async {
    if (_busy) return; // ignore double taps
    final code = _code.text.trim().toUpperCase();
    final nin = _nin.text.replaceAll(RegExp(r'[^0-9]'), '');
    final codeErr = InputValidation.inviteCode(code);
    final ninErr = InputValidation.nin(nin);
    if (codeErr != null || ninErr != null) {
      setState(() {
        _codeError = codeErr;
        _ninError = ninErr;
        _error = null;
      });
      return;
    }
    // Guessing codes / NINs: slow down after repeated wrong tries (kept across app restarts).
    const limitKey = 'invite:accept';
    final wait = AttemptLimiter.secondsLocked(limitKey);
    if (wait > 0) {
      setState(() => _error = '${AppStrings.authTooManyAttempts} ${wait}s');
      return;
    }
    setState(() {
      _busy = true;
      _codeError = null;
      _ninError = null;
      _error = null;
    });
    final res = await ApiService.acceptInvitation(code: code, nidaNumber: nin);
    if (!mounted) return;
    if (res.ok) {
      AttemptLimiter.recordSuccess(limitKey);
    } else if (res.error != AppStrings.authNetworkError) {
      AttemptLimiter.recordFailure(limitKey); // a real rejection, not a dropped connection
    }
    setState(() {
      _busy = false;
      if (res.ok) {
        _done = true;
        _nin.clear(); // do not keep the NIN around in memory longer than needed
      } else {
        _error = InputValidation.safeServerMessage(res.error);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context, _done),
        ),
        title: Text(
          _isEn ? 'I have an invitation' : 'Nina mwaliko',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: _done ? _success() : _form(),
      ),
    );
  }

  Widget _success() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.successLight,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.success.withValues(alpha: 0.4)),
      ),
      child: Column(
        children: [
          const Icon(Icons.verified_rounded, color: AppColors.primary, size: 56),
          const SizedBox(height: 12),
          Text(
            _isEn ? 'Congratulations! You now have a Blue Tick.' : 'Hongera! Sasa una Blue Tick.',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
          ),
          const SizedBox(height: 8),
          Text(
            _isEn
                ? 'You and the person who invited you are now on record as knowing and trusting each other.'
                : 'Wewe na aliyekualika mnabaki kwenye kumbukumbu mkijuana na kuaminiana.',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 12, height: 1.45, color: AppColors.textSecondary),
          ),
          const SizedBox(height: 16),
          AppButton.primary(label: _isEn ? 'Done' : 'Sawa', onPressed: () => Navigator.pop(context, true)),
        ],
      ),
    );
  }

  Widget _receivedCard(Map<String, dynamic> inv) {
    final from = (inv['inviterName'] ?? inv['name'] ?? '').toString().trim();
    final code = _codeOf(inv);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.successLight,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.success.withValues(alpha: 0.4)),
      ),
      child: Row(
        children: [
          const Icon(Icons.mark_email_unread_outlined, color: AppColors.successDark),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              from.isNotEmpty
                  ? (_isEn ? '$from invited you.' : '$from amekualika.')
                  : (_isEn ? 'Someone you know invited you.' : 'Mtu unayemjua amekualika.'),
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
            ),
          ),
          if (code.isNotEmpty)
            TextButton(
              onPressed: _busy ? null : () => setState(() => _code.text = code),
              child: Text(_isEn ? 'Use code' : 'Tumia msimbo'),
            ),
        ],
      ),
    );
  }

  Widget _form() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppColors.primaryLight.withValues(alpha: 0.5),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.primary.withValues(alpha: 0.2)),
          ),
          child: Text(
            _isEn
                ? 'A provider with a Blue Tick who knows and trusts you can invite you. Enter the code they sent you and your 20-digit NIN. No ID photo is needed.'
                : 'Mtoa huduma mwenye Blue Tick anayekujua na kukuamini anaweza kukualika. Weka msimbo aliokutumia na NIN yako ya tarakimu 20. Huhitaji picha ya kitambulisho.',
            style: const TextStyle(fontSize: 12, height: 1.45, color: AppColors.textPrimary),
          ),
        ),
        for (final inv in _received) ...[
          const SizedBox(height: 12),
          _receivedCard(inv),
        ],
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              AppTextField(
                controller: _code,
                icon: Icons.vpn_key_outlined,
                label: _isEn ? 'Invitation code' : 'Msimbo wa mwaliko',
                hint: '123-ABC456',
                errorText: _codeError,
                enabled: !_busy,
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'[A-Za-z0-9\-]')),
                  LengthLimitingTextInputFormatter(24),
                ],
              ),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  onPressed: _busy ? null : _paste,
                  icon: const Icon(Icons.paste_rounded, size: 16),
                  label: Text(_isEn ? 'Paste' : 'Bandika'),
                ),
              ),
              const SizedBox(height: 4),
              AppTextField(
                controller: _nin,
                icon: Icons.badge_outlined,
                label: _isEn ? 'Your 20-digit NIN' : 'NIN yako ya tarakimu 20',
                hint: '00000000000000000000',
                keyboardType: TextInputType.number,
                errorText: _ninError,
                enabled: !_busy,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(InputValidation.ninLength),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                _isEn ? 'Your NIN stays private. Customers only see your stage name.' : 'NIN yako ni siri. Wateja wanaona jina lako la kazi pekee.',
                style: const TextStyle(fontSize: 11, color: AppColors.textMuted),
              ),
              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(_error!, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.danger)),
              ],
              const SizedBox(height: 16),
              AppButton.primary(
                label: _isEn ? 'Accept invitation' : 'Kubali mwaliko',
                loading: _busy,
                onPressed: _busy ? null : _submit,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

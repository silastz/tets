import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/session_manager.dart';
import '../widgets/app_ui.dart';
import '../services/data_sync.dart';

enum _PayStatus { paid, pending, failed }

class _PaymentRow {
  final String title;
  final String subtitle;
  final String date;
  final double amount;
  final _PayStatus status;
  const _PaymentRow({
    required this.title,
    required this.subtitle,
    required this.date,
    required this.amount,
    required this.status,
  });
}

/// Payment history for both roles. Buyers see what they paid, providers see
/// what customers paid them. Data comes from the escrow orders.
class PaymentsScreen extends StatefulWidget {
  const PaymentsScreen({super.key});

  @override
  State<PaymentsScreen> createState() => _PaymentsScreenState();
}

class _PaymentsScreenState extends State<PaymentsScreen> {
  bool _loading = true;
  List<_PaymentRow> _rows = [];
  _PayStatus? _filter; // null = all

  bool get _isEn => AppStrings.isEnglish;
  bool get _isSeller => SessionManager.isSeller();

  // Something was written to the server elsewhere (booking, accept, wallet, review...): re-fetch.
  void _onDataChanged() {
    if (mounted) _load();
  }

  @override
  void dispose() {
    DataSync.changed.removeListener(_onDataChanged);
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    DataSync.changed.addListener(_onDataChanged);
    _load();
  }

  static _PayStatus _statusOf(String raw) {
    final s = raw.toUpperCase();
    if (s == 'COMPLETED' || s == 'RELEASED' || s == 'SATISFIED') return _PayStatus.paid;
    if (s.contains('REJECT') || s.contains('CANCEL') || s.contains('REFUND') || s.contains('DISPUTE') || s.contains('FAIL')) {
      return _PayStatus.failed;
    }
    return _PayStatus.pending;
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final list = _isSeller ? await ApiService.fetchSellerOrders() : await ApiService.fetchBuyerTransactions();
    final rows = <_PaymentRow>[];
    for (final raw in list) {
      if (raw is! Map) continue;
      final tx = Map<String, dynamic>.from(raw);
      final other = (_isSeller ? tx['buyer'] : tx['seller']) as Map? ?? {};
      final otherName = (other['stageName'] ?? other['username'] ?? (_isSeller ? 'Customer' : 'Service Provider')).toString();
      final service = tx['service'] as Map? ?? {};
      final serviceTitle = service['title']?.toString();
      final created = tx['createdAt']?.toString() ?? '';
      rows.add(_PaymentRow(
        title: serviceTitle != null && serviceTitle.isNotEmpty ? serviceTitle : otherName,
        subtitle: serviceTitle != null && serviceTitle.isNotEmpty ? otherName : '',
        date: created.length >= 10 ? created.substring(0, 10) : (_isEn ? 'Recent' : 'Hivi karibuni'),
        amount: (tx['amount'] as num?)?.toDouble() ?? 0,
        status: _statusOf((tx['status'] ?? 'PENDING_ACCEPTANCE').toString()),
      ));
    }
    if (!mounted) return;
    setState(() {
      _rows = rows;
      _loading = false;
    });
  }

  String _money(num v) =>
      'TSh ${v.toInt().toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},')}';

  double _sum(_PayStatus s) => _rows.where((r) => r.status == s).fold(0.0, (a, r) => a + r.amount);

  String _statusLabel(_PayStatus s) {
    switch (s) {
      case _PayStatus.paid:
        return _isEn ? 'Paid' : 'Imelipwa';
      case _PayStatus.pending:
        return _isEn ? 'In escrow' : 'Inashikiliwa';
      case _PayStatus.failed:
        return _isEn ? 'Cancelled' : 'Imeghairiwa';
    }
  }

  Color _statusColor(_PayStatus s) {
    switch (s) {
      case _PayStatus.paid:
        return AppColors.successDark;
      case _PayStatus.pending:
        return AppColors.warningDark;
      case _PayStatus.failed:
        return AppColors.danger;
    }
  }

  @override
  Widget build(BuildContext context) {
    final visible = _filter == null ? _rows : _rows.where((r) => r.status == _filter).toList();
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          _isEn ? 'Payments' : 'Malipo',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: _summaryBox(
                          label: _isSeller ? (_isEn ? 'Received' : 'Imepokelewa') : (_isEn ? 'Total paid' : 'Jumla ya malipo'),
                          value: _money(_sum(_PayStatus.paid)),
                          color: AppColors.successDark,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _summaryBox(
                          label: _isSeller ? (_isEn ? 'Coming soon' : 'Yanakuja') : (_isEn ? 'Held in escrow' : 'Yanashikiliwa'),
                          value: _money(_sum(_PayStatus.pending)),
                          color: AppColors.warningDark,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        _chip(_isEn ? 'All' : 'Zote', null),
                        _chip(_isEn ? 'Paid' : 'Imelipwa', _PayStatus.paid),
                        _chip(_isEn ? 'In escrow' : 'Inashikiliwa', _PayStatus.pending),
                        _chip(_isEn ? 'Cancelled' : 'Imeghairiwa', _PayStatus.failed),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  if (visible.isEmpty)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 48),
                      child: Column(
                        children: [
                          const Icon(Icons.receipt_long_outlined, size: 44, color: AppColors.textMuted),
                          const SizedBox(height: 10),
                          Text(
                            _isEn ? 'No payments yet' : 'Bado hakuna malipo',
                            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            _isSeller
                                ? (_isEn ? 'Payments from your bookings will show here.' : 'Malipo ya oda zako yataonekana hapa.')
                                : (_isEn ? 'Payments for your bookings will show here.' : 'Malipo ya oda zako yataonekana hapa.'),
                            textAlign: TextAlign.center,
                            style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                          ),
                        ],
                      ),
                    )
                  else
                    for (final r in visible) _paymentTile(r),
                ],
              ),
            ),
    );
  }

  Widget _summaryBox({required String label, required String value, required Color color}) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary, fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(value, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: color)),
          ),
        ],
      ),
    );
  }

  Widget _chip(String label, _PayStatus? value) {
    final selected = _filter == value;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) => setState(() => _filter = value),
        selectedColor: AppColors.primary,
        backgroundColor: AppColors.surface,
        side: BorderSide(color: selected ? AppColors.primary : AppColors.border),
        showCheckmark: false,
        labelStyle: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w700,
          color: selected ? Colors.white : AppColors.textPrimary,
        ),
      ),
    );
  }

  Widget _paymentTile(_PaymentRow r) {
    final color = _statusColor(r.status);
    final sign = r.status == _PayStatus.failed ? '' : (_isSeller ? '+ ' : '- ');
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(color: color.withValues(alpha: 0.1), shape: BoxShape.circle),
            child: Icon(
              r.status == _PayStatus.paid
                  ? Icons.check_rounded
                  : (r.status == _PayStatus.pending ? Icons.hourglass_bottom_rounded : Icons.close_rounded),
              color: color,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(r.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                const SizedBox(height: 2),
                Text(
                  [if (r.subtitle.isNotEmpty) r.subtitle, r.date].join('  •  '),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('$sign${_money(r.amount)}',
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
              const SizedBox(height: 4),
              StatusPill(text: _statusLabel(r.status), color: color),
            ],
          ),
        ],
      ),
    );
  }
}

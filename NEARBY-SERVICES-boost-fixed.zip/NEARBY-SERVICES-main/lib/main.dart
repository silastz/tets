import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'screens/home_screen.dart';
import 'screens/chats_screen.dart';
import 'screens/requests_screen.dart';
import 'screens/sell_manage_services_screen.dart';
import 'constants/app_colors.dart';
import 'constants/app_strings.dart';
import 'services/session_manager.dart';
import 'services/security_settings.dart';
import 'widgets/app_lock_gate.dart';
import 'services/location_service.dart';
import 'services/gps_service.dart';
import 'services/block_service.dart';
import 'services/chat_prefs.dart';
import 'services/notification_service.dart';
import 'services/notification_feed.dart';
import 'services/deep_link_service.dart';
import 'screens/notifications_screen.dart';
import 'widgets/startup_permissions_modal.dart';

import 'screens/profile_screen.dart';
import 'screens/search_filter_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SessionManager.init();
  await SecuritySettings.init();
  // "Remember Me" off: sign in again on every fresh app start.
  if (SessionManager.isLoggedIn() && !SecuritySettings.rememberMe) {
    await SessionManager.clearSession();
  }
  await AppStrings.init();
  LocationService.detectCurrentLocation(); // Asynchronously detect user location on launch
  BlockService.start(); // blocked users (local cache + server sync)
  ChatPrefs.start(); // muted chats + cleared chats (local)
  GpsService.start(); // GPS fix (if permitted) -> saved to the user's profile in the database
  await _initPush();
  NotificationFeed.start(); // Home bell badge + Notifications screen share this feed
  runApp(const NearbyServicesApp());
  DeepLinkService.start(appNavigatorKey); // links from WhatsApp / SMS open the invitation or service
}

final GlobalKey<NavigatorState> appNavigatorKey = GlobalKey<NavigatorState>();

/// OneSignal push setup: link device to the user, tag city/language,
/// and open the notifications screen when a push is tapped.
Future<void> _initPush() async {
  await NotificationService.init();

  if (SessionManager.isLoggedIn()) {
    NotificationService.login(
      SessionManager.getUserIdValue().toString(),
      role: SessionManager.getRole(),
    );
  }

  NotificationService.setCity(LocationService.currentCity);
  LocationService.activeLocationNotifier.addListener(() {
    NotificationService.setCity(LocationService.currentCity);
  });

  void syncLang() =>
      NotificationService.setLanguage(AppStrings.isEnglish ? 'en' : 'sw');
  syncLang();
  AppStrings.currentLanguage.addListener(syncLang);

  NotificationService.onNotificationTap = (data) {
    appNavigatorKey.currentState?.push(
      MaterialPageRoute(builder: (_) => const NotificationsScreen()),
    );
  };
}

class NearbyServicesApp extends StatelessWidget {
  const NearbyServicesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppLanguage>(
      valueListenable: AppStrings.currentLanguage,
      builder: (context, lang, _) {
        return MaterialApp(
          title: 'Nearby Services',
          navigatorKey: appNavigatorKey,
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            useMaterial3: true,
            scaffoldBackgroundColor: Colors.white,
            snackBarTheme: SnackBarThemeData(
              behavior: SnackBarBehavior.floating,
              backgroundColor: AppColors.slateDark,
              contentTextStyle: const TextStyle(fontSize: 13, color: Colors.white),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            switchTheme: SwitchThemeData(
              thumbColor: WidgetStateProperty.all(Colors.white),
              trackColor: WidgetStateProperty.resolveWith(
                (states) => states.contains(WidgetState.selected) ? AppColors.primary : AppColors.textDisabled,
              ),
              trackOutlineColor: WidgetStateProperty.all(Colors.transparent),
            ),
          ),
          builder: (context, child) => AppLockGate(child: child ?? const SizedBox.shrink()),
          home: const MainTabScaffold(),
        );
      },
    );
  }
}

// -------------------------------------------------------------
// MAIN TAB SCAFFOLD (Bottom navigation orchestrator)
// -------------------------------------------------------------
class MainTabScaffold extends StatefulWidget {
  const MainTabScaffold({super.key});

  @override
  State<MainTabScaffold> createState() => _MainTabScaffoldState();
}

class _MainTabScaffoldState extends State<MainTabScaffold> {
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    StartupPermissionsModal.checkAndShow(context);
  }

  // Double back to exit: first back on Home shows a hint, a second back within
  // [_exitWindow] closes the app.
  static const Duration _exitWindow = Duration(seconds: 2);
  DateTime? _lastBackPress;

  void _handleExitBack() {
    final now = DateTime.now();
    final last = _lastBackPress;
    if (last != null && now.difference(last) <= _exitWindow) {
      SystemNavigator.pop();
      return;
    }
    _lastBackPress = now;
    final messenger = ScaffoldMessenger.of(context);
    messenger.hideCurrentSnackBar();
    messenger.showSnackBar(
      SnackBar(
        content: Text(AppStrings.exitAppPressAgain, textAlign: TextAlign.center),
        duration: _exitWindow,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppLanguage>(
      valueListenable: AppStrings.currentLanguage,
      builder: (context, currentLang, _) {
        return ValueListenableBuilder<int>(
          valueListenable: SessionManager.sessionNotifier,
          builder: (context, sessionTick, child) {
            final isLoggedIn = SessionManager.isLoggedIn();
            final isSeller = SessionManager.isSeller();

            // Defined menus per role:
            // 1. Guest: Home, Chats, Sell, Search, Profile
            // 2. Buyer: Home, Chats, Requests, Sell, Profile
            // 3. Provider/Seller: Home, Chats, Requests, Services, Profile (Earnings = top icon on Home)
            final List<Widget> pages = [];
            final List<Map<String, dynamic>> navItems = [];

            // Tab 1: Home (All roles)
            pages.add(const HomeScreen());
            navItems.add({
              'icon': Icons.home_rounded,
              'label': AppStrings.navHome,
            });

            // Tab 2: Chats (All roles)
            pages.add(const ChatsScreen());
            navItems.add({
              'icon': Icons.chat_bubble_outline_rounded,
              'label': AppStrings.navChats,
            });

            if (!isLoggedIn) {
              // GUEST: [Home, Chats, Sell, Search, Profile]
              pages.add(SellManageServicesScreen(
                onBackToHome: () => setState(() => _currentIndex = 0),
              ));
              navItems.add({
                'icon': Icons.storefront_rounded,
                'label': AppStrings.navSell,
              });

              pages.add(SearchFilterScreen(
                onBackToHome: () => setState(() => _currentIndex = 0),
              ));
              navItems.add({
                'icon': Icons.search_rounded,
                'label': AppStrings.navSearch,
              });

              pages.add(const ProfileScreen());
              navItems.add({
                'icon': Icons.person_outline_rounded,
                'label': AppStrings.navProfile,
              });
            } else if (!isSeller) {
              // BUYER: [Home, Chats, Requests, Sell, Profile]
              pages.add(const RequestsScreen());
              navItems.add({
                'icon': Icons.receipt_long_rounded,
                'label': AppStrings.navRequests,
              });

              pages.add(SellManageServicesScreen(
                onBackToHome: () => setState(() => _currentIndex = 0),
              ));
              navItems.add({
                'icon': Icons.storefront_rounded,
                'label': AppStrings.navSell,
              });

              pages.add(const ProfileScreen());
              navItems.add({
                'icon': Icons.person_outline_rounded,
                'label': AppStrings.navProfile,
              });
            } else {
              // PROVIDER / SELLER: [Home, Chats, Requests, Services, Profile]
              pages.add(const RequestsScreen());
              navItems.add({
                'icon': Icons.receipt_long_rounded,
                'label': AppStrings.navRequests,
              });

              pages.add(SellManageServicesScreen(
                onBackToHome: () => setState(() => _currentIndex = 0),
              ));
              navItems.add({
                'icon': Icons.storefront_rounded,
                'label': AppStrings.navServices,
              });

              pages.add(const ProfileScreen());
              navItems.add({
                'icon': Icons.person_outline_rounded,
                'label': AppStrings.navProfile,
              });
            }

            // Ensure current index is within bounds when switching auth/role
            if (_currentIndex >= pages.length) {
              _currentIndex = 0;
            }
            final effectiveIndex = _currentIndex;

            return PopScope(
              // Always intercept back: go to Home first, then press back twice to exit.
              canPop: false,
              onPopInvokedWithResult: (didPop, result) {
                if (didPop) return;
                if (effectiveIndex != 0) {
                  setState(() => _currentIndex = 0);
                } else {
                  _handleExitBack();
                }
              },
              child: Scaffold(
                backgroundColor: Colors.white,
                body: IndexedStack(
                  index: effectiveIndex,
                  children: pages,
                ),
              bottomNavigationBar: Container(
                decoration: const BoxDecoration(
                  color: AppColors.surface,
                  border: Border(
                    top: BorderSide(
                      color: AppColors.borderLight,
                      width: 1,
                    ),
                  ),
                ),
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: List.generate(navItems.length, (idx) {
                        final item = navItems[idx];
                        return _buildNavItem(
                          idx,
                          effectiveIndex,
                          item['icon'] as IconData,
                          item['icon'] as IconData,
                          item['label'] as String,
                        );
                      }),
                    ),
                  ),
                ),
              ),
            ),
          );
          },
        );
      },
    );
  }

  Widget _buildNavItem(int index, int activeIndex, IconData activeIcon, IconData inactiveIcon, String label) {
    final isSelected = activeIndex == index;
    const activeColor = AppColors.primary;
    const inactiveColor = AppColors.textSecondary;

    return InkWell(
      onTap: () => setState(() => _currentIndex = index),
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              isSelected ? activeIcon : inactiveIcon,
              size: 22,
              color: isSelected ? activeColor : inactiveColor,
            ),
            const SizedBox(height: 3),
            Text(
              label,
              style: TextStyle(
                fontSize: 11,
                fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                color: isSelected ? activeColor : inactiveColor,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/foundation.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import '../constants/notification_config.dart';
import 'data_sync.dart';

/// Push notifications through OneSignal (Android + iOS).
///
/// - Manual notifications: send from the OneSignal dashboard (Messages -> New Push),
///   to everyone or to segments / tags (role, city, language).
/// - Auto notifications: your server calls the OneSignal REST API for a user by
///   their external id (= the app user id). See docs/onesignal_send.php.
class NotificationService {
  static bool _ready = false;

  /// Callback for when the user taps a notification. Receives the custom
  /// `data` map sent with the push (e.g. {"type": "booking", "id": "12"}).
  static void Function(Map<String, dynamic> data)? onNotificationTap;

  static Future<void> init() async {
    if (!NotificationConfig.isConfigured) {
      debugPrint('[Push] OneSignal App ID not set - push disabled.');
      return;
    }
    try {
      if (kDebugMode) OneSignal.Debug.setLogLevel(OSLogLevel.warn);
      OneSignal.initialize(NotificationConfig.oneSignalAppId);

      OneSignal.Notifications.addClickListener((event) {
        final extra = event.notification.additionalData ?? <String, dynamic>{};
        onNotificationTap?.call(Map<String, dynamic>.from(extra));
      });

      // A push that arrives while the app is open means server data changed
      // (new booking, accept, message): refresh every screen and the bell badge.
      OneSignal.Notifications.addForegroundWillDisplayListener((event) {
        DataSync.bump();
      });

      _ready = true;
    } catch (e) {
      debugPrint('[Push] init failed: $e');
    }
  }

  /// Ask for the OS notification permission through OneSignal (iOS + Android 13+).
  /// The startup prompt already requests it; this is a safe fallback.
  static Future<bool> requestPermission() async {
    if (!_ready) return false;
    try {
      return await OneSignal.Notifications.requestPermission(true);
    } catch (_) {
      return false;
    }
  }

  /// Link this device to the logged-in user so the server can target them.
  static Future<void> login(String userId, {String? role}) async {
    if (!_ready || userId.isEmpty || userId == '0') return;
    try {
      await OneSignal.login(userId);
      if (role != null && role.isNotEmpty) await OneSignal.User.addTagWithKey('role', role);
    } catch (e) {
      debugPrint('[Push] login failed: $e');
    }
  }

  static Future<void> logout() async {
    if (!_ready) return;
    try {
      await OneSignal.logout();
      await OneSignal.User.removeTag('role');
    } catch (_) {}
  }

  static Future<void> setRole(String role) async {
    if (!_ready || role.isEmpty) return;
    try {
      await OneSignal.User.addTagWithKey('role', role);
    } catch (_) {}
  }

  /// Tags let you send manual pushes to a city or language from the dashboard.
  static Future<void> setCity(String city) async {
    if (!_ready || city.isEmpty) return;
    try {
      await OneSignal.User.addTagWithKey('city', city);
    } catch (_) {}
  }

  static Future<void> setLanguage(String code) async {
    if (!_ready || code.isEmpty) return;
    try {
      await OneSignal.User.setLanguage(code);
      await OneSignal.User.addTagWithKey('lang', code);
    } catch (_) {}
  }
}

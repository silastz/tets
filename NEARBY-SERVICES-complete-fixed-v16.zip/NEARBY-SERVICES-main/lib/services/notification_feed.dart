import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../constants/app_colors.dart';
import 'api_service.dart';
import 'chat_prefs.dart';
import 'data_sync.dart';
import 'session_manager.dart';
import 'payment_flow.dart';

/// One notification entry. [id] is stable across reloads so read state sticks.
class AppNotification {
  final String id;
  final String title;
  final String subtitle;
  final String time;
  final String type; // 'Bookings' | 'Messages' | 'System'
  final IconData icon;
  final Color color;

  const AppNotification({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.time,
    required this.type,
    required this.icon,
    required this.color,
  });
}

/// Single source of truth for the Notifications screen AND the Home bell badge.
///
/// Built from the same bookings / orders / conversations the Requests, Payments
/// and Chats screens show, so a new booking, an accept or a new message appears
/// everywhere together. Read state is remembered per user on this device.
class NotificationFeed {
  static final ValueNotifier<List<AppNotification>> items = ValueNotifier(const []);
  static final ValueNotifier<int> unread = ValueNotifier(0);

  static const List<AppNotification> _system = [
    AppNotification(
      id: 'sys_welcome',
      title: 'Account Ready',
      subtitle: 'Karibu Ungana! Gundua watoa huduma bora walio karibu nawe.',
      time: 'Just now',
      type: 'System',
      icon: Icons.verified_user_rounded,
      color: AppColors.primary,
    ),
    AppNotification(
      id: 'sys_escrow',
      title: 'Escrow Protected',
      subtitle: 'Malipo yako yote yanalindwa kwa usalama hadi huduma inapokamilika.',
      time: 'Yesterday',
      type: 'System',
      icon: Icons.security_rounded,
      color: AppColors.success,
    ),
  ];

  static Set<String> _read = {};
  static bool _started = false;
  static bool _loading = false;
  static bool _again = false; // a change arrived while loading: run once more
  static int _userForRead = -1;

  static String get _readKey => 'notif_read_${SessionManager.getUserIdValue()}';

  /// Call once at app start (after SessionManager.init). Safe to call again.
  static void start() {
    if (_started) return;
    _started = true;
    DataSync.changed.addListener(refresh);
    SessionManager.sessionNotifier.addListener(_onSession);
    refresh();
  }

  static void _onSession() {
    // Login / logout / switching account: reload for the new user.
    if (_userForRead != SessionManager.getUserIdValue() || !SessionManager.isLoggedIn()) refresh();
  }

  static Future<void> _loadRead() async {
    final prefs = await SharedPreferences.getInstance();
    _read = (prefs.getStringList(_readKey) ?? const <String>[]).toSet();
    _userForRead = SessionManager.getUserIdValue();
  }

  static Future<void> _saveRead() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_readKey, _read.toList());
  }

  static bool isRead(AppNotification n) => _read.contains(n.id);

  static void _publish(List<AppNotification> list) {
    items.value = list;
    unread.value = list.where((n) => !_read.contains(n.id)).length;
  }

  static Future<void> markRead(AppNotification n) async {
    if (_read.add(n.id)) {
      _publish(items.value);
      await _saveRead();
    }
  }

  static Future<void> markAllRead() async {
    _read.addAll(items.value.map((n) => n.id));
    _publish(items.value);
    await _saveRead();
  }

  static String _day(dynamic v) {
    final s = v?.toString() ?? '';
    return s.length >= 10 ? s.substring(0, 10) : 'Recent';
  }

  static String _name(dynamic user, String fallback) {
    final m = user is Map ? user : const {};
    return (m['stageName'] ?? m['username'] ?? fallback).toString();
  }

  static Future<void> refresh() async {
    if (_loading) {
      _again = true;
      return;
    }
    _loading = true;
    try {
      if (!SessionManager.isLoggedIn()) {
        _read = {};
        _userForRead = -1;
        items.value = _system;
        unread.value = 0; // guests have no personal notifications to be unread
        return;
      }
      await _loadRead();

      final results = await Future.wait([
        ApiService.fetchBuyerTransactions(),
        SessionManager.isSeller() ? ApiService.fetchSellerOrders() : Future.value(<dynamic>[]),
        ApiService.fetchConversations(),
      ]);

      final out = <AppNotification>[];

      for (final tx in results[0]) {
        final ref = (tx['transactionRef'] ?? tx['id'] ?? '').toString();
        final status = (tx['status'] ?? 'PENDING').toString().toUpperCase();
        final name = _name(tx['seller'], 'Provider');
        final date = _day(tx['createdAt']);
        final payState = PaymentFlow.stateOf(status);
        if (payState == PayState.awaitingPayment) {
          out.add(AppNotification(
            id: 'b_${ref}_pay_requested',
            title: 'Payment Requested',
            subtitle: '$name asks you to pay first to confirm your booking. Tap Requests to pay.',
            time: date,
            type: 'Bookings',
            icon: Icons.payments_rounded,
            color: AppColors.warning,
          ));
        } else if (payState == PayState.paymentSent) {
          out.add(AppNotification(
            id: 'b_${ref}_pay_sent',
            title: 'Waiting for Confirmation',
            subtitle: 'You said you paid. $name will confirm once the money arrives.',
            time: date,
            type: 'Bookings',
            icon: Icons.hourglass_top_rounded,
            color: AppColors.primary,
          ));
        } else if (payState == PayState.disputed) {
          out.add(AppNotification(
            id: 'b_${ref}_pay_disputed',
            title: 'Payment Not Received',
            subtitle: '$name did not receive your payment. Check your reference and contact them.',
            time: date,
            type: 'Bookings',
            icon: Icons.error_rounded,
            color: AppColors.danger,
          ));
        } else if (status == 'ACCEPTED') {
          out.add(AppNotification(
            id: 'b_${ref}_accepted',
            title: 'Booking Accepted',
            subtitle: '$name has accepted your service booking request. Contact details unlocked!',
            time: date,
            type: 'Bookings',
            icon: Icons.check_circle_rounded,
            color: AppColors.success,
          ));
        } else if (status == 'PENDING_ACCEPTANCE') {
          out.add(AppNotification(
            id: 'b_${ref}_placed',
            title: 'Order Placed (Escrow Locked)',
            subtitle: 'Booking sent to $name. Funds are held securely in Escrow.',
            time: date,
            type: 'Bookings',
            icon: Icons.sync_rounded,
            color: AppColors.warning,
          ));
        } else if (status == 'REJECTED' || status == 'DECLINED') {
          out.add(AppNotification(
            id: 'b_${ref}_rejected',
            title: 'Booking Declined',
            subtitle: '$name could not take your booking. Your funds are returned.',
            time: date,
            type: 'Bookings',
            icon: Icons.cancel_rounded,
            color: AppColors.danger,
          ));
        } else if (status == 'COMPLETED' || status == 'RELEASED') {
          out.add(AppNotification(
            id: 'b_${ref}_released',
            title: 'Payment Released',
            subtitle: 'You confirmed satisfaction and released funds for booking with $name.',
            time: date,
            type: 'Bookings',
            icon: Icons.account_balance_wallet_rounded,
            color: AppColors.primary,
          ));
        }
      }

      for (final ord in results[1]) {
        final ref = (ord['transactionRef'] ?? ord['id'] ?? '').toString();
        final status = (ord['status'] ?? 'PENDING').toString().toUpperCase();
        final bName = _name(ord['buyer'], 'Client');
        final date = _day(ord['createdAt']);
        final payState = PaymentFlow.stateOf(status);
        if (payState == PayState.paymentSent) {
          out.add(AppNotification(
            id: 's_${ref}_pay_sent',
            title: 'Buyer Says They Paid',
            subtitle: '$bName marked their payment as sent. Check your account, then confirm it in Requests.',
            time: date,
            type: 'Bookings',
            icon: Icons.notifications_active_rounded,
            color: AppColors.warning,
          ));
        } else if (payState == PayState.awaitingPayment) {
          out.add(AppNotification(
            id: 's_${ref}_awaiting',
            title: 'Waiting for Buyer Payment',
            subtitle: 'You asked $bName to pay first. The booking is accepted once you confirm it.',
            time: date,
            type: 'Bookings',
            icon: Icons.hourglass_top_rounded,
            color: AppColors.primary,
          ));
        } else if (status == 'PENDING_ACCEPTANCE') {
          out.add(AppNotification(
            id: 's_${ref}_new',
            title: 'New Service Request',
            subtitle: '$bName has placed a new order with you. Tap to Review & Accept.',
            time: date,
            type: 'Bookings',
            icon: Icons.notifications_active_rounded,
            color: AppColors.primary,
          ));
        } else if (status == 'COMPLETED' || status == 'RELEASED') {
          out.add(AppNotification(
            id: 's_${ref}_paid',
            title: 'Payment Received',
            subtitle: '$bName confirmed satisfaction. Funds were released to your wallet.',
            time: date,
            type: 'Bookings',
            icon: Icons.payments_rounded,
            color: AppColors.success,
          ));
        }
      }

      for (final c in results[2]) {
        final unreadMsgs = (c['unreadCount'] as num?)?.toInt() ?? 0;
        if (unreadMsgs <= 0) continue;
        final other = c['recipient'] ?? c['sender'] ?? {};
        final otherId = int.tryParse('${(other is Map ? other['id'] : null) ?? c['otherUserId'] ?? ''}');
        if (ChatPrefs.isMuted(otherId)) continue; // muted: no bell entry
        final cid = (c['id'] ?? c['conversationId'] ?? '').toString();
        final last = ApiService.chatPreview((c['lastMessage'] ?? c['content'] ?? '').toString());
        // The id includes the count so a NEW message re-marks the entry unread.
        out.add(AppNotification(
          id: 'm_${cid}_$unreadMsgs',
          title: 'New message from ${_name(other, 'User')}',
          subtitle: last.isEmpty ? '$unreadMsgs unread' : last,
          time: (c['time'] ?? 'Recent').toString(),
          type: 'Messages',
          icon: Icons.chat_bubble_rounded,
          color: AppColors.primary,
        ));
      }

      _publish([...out, ..._system]);
    } finally {
      _loading = false;
      if (_again) {
        _again = false;
        refresh();
      }
    }
  }
}

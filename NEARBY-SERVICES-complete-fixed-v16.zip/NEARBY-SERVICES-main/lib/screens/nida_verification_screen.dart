import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/id_kinds.dart';
import '../services/api_service.dart';
import '../services/session_manager.dart';
import '../widgets/app_ui.dart';
import 'accept_invitation_screen.dart';
import 'invite_trusted_screen.dart';
import 'provider_documents_screen.dart';

/// Where the provider's identity verification stands. Everything shown here is
/// real: the badge from the account and the status of each uploaded document
/// as reviewed by the server. The "Upload documents" button opens the
/// Documents screen, where the photos are actually taken and uploaded.
class NidaVerificationScreen extends StatefulWidget {
  const NidaVerificationScreen({super.key});

  @override
  State<NidaVerificationScreen> createState() => _NidaVerificationScreenState();
}

enum _DocState { approved, pending, rejected, missing }

class _NidaVerificationScreenState extends State<NidaVerificationScreen> {
  bool _loading = true;
  bool _loadFailed = false;
  // document type -> state reported by the server
  final Map<String, _DocState> _server = {};

  bool get _isEn => AppStrings.isEnglish;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final list = await ApiService.fetchVerificationDocuments();
    if (!mounted) return;
    setState(() {
      _loadFailed = list == null;
      _server.clear();
      for (final e in list ?? const []) {
        if (e is Map && e['type'] != null) {
          final s = (e['status'] ?? 'PENDING').toString().toUpperCase();
          _server[e['type'].toString()] = (s == 'APPROVED' || s == 'VERIFIED')
              ? _DocState.approved
              : (s == 'REJECTED' ? _DocState.rejected : _DocState.pending);
        }
      }
      _loading = false;
    });
  }

  _DocState _stateOf(String type) {
    final s = _server[type];
    if (s != null) return s;
    return SessionManager.getSubmittedDocs().contains(type) ? _DocState.pending : _DocState.missing;
  }

  /// Worst state wins: a rejected or missing photo means the group needs action.
  _DocState _group(List<String> types) {
    final states = types.map(_stateOf).toList();
    if (states.contains(_DocState.rejected)) return _DocState.rejected;
    if (states.contains(_DocState.missing)) return _DocState.missing;
    if (states.contains(_DocState.pending)) return _DocState.pending;
    return _DocState.approved;
  }

  Future<void> _openDocuments() async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => const ProviderDocumentsScreen()));
    if (mounted) _load();
  }

  Future<void> _openInvitation() async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => const AcceptInvitationScreen()));
    if (mounted) setState(() {}); // the badge may have changed
  }

  @override
  Widget build(BuildContext context) {
    final badge = SessionManager.getBadge();
    final verified = badge == 'BLUE_TICK' || badge == 'GREEN_BADGE';
    final kind = IdKinds.byId(SessionManager.getIdKind());
    final idState = verified ? _DocState.approved : _group(['id_front', if (kind.hasBack) 'id_back']);
    final selfieState = _stateOf('selfie_with_id');
    final faceState = _stateOf('face_photo');
    final licenceState = _stateOf('business_license');
    final hasPhone = SessionManager.getPhone().trim().isNotEmpty;
    final accent = verified ? AppColors.success : AppColors.warningDark;

    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          _isEn ? 'Verification' : 'Uthibitisho',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
          child: Column(
            children: [
              Center(
                child: Container(
                  width: 72,
                  height: 72,
                  decoration: BoxDecoration(color: verified ? AppColors.primary : AppColors.textMuted, shape: BoxShape.circle),
                  child: const Icon(Icons.verified_user_rounded, color: Colors.white, size: 40),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                _isEn ? 'Identity Verification' : 'Uthibitisho wa Utambulisho',
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
              ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: accent.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: accent.withValues(alpha: 0.3)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(verified ? Icons.check_circle_rounded : Icons.info_outline_rounded, size: 14, color: accent),
                    const SizedBox(width: 4),
                    Text(
                      verified ? (_isEn ? 'Verified' : 'Imethibitishwa') : (_isEn ? 'Not verified yet' : 'Bado haijathibitishwa'),
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: accent),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Text(
                verified
                    ? (_isEn
                        ? 'Your identity has been verified. You can now receive bookings and access all features.'
                        : 'Utambulisho wako umethibitishwa. Sasa unaweza kupokea oda na kutumia huduma zote.')
                    : (_isEn
                        ? 'Upload the front and back of your ID, plus a selfie holding it, to get verified.'
                        : 'Pakia picha za mbele na nyuma za kitambulisho chako, na selfie ukikishika, ili uthibitishwe.'),
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, height: 1.4),
              ),
              const SizedBox(height: 32),
              if (_loading)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 24),
                  child: CircularProgressIndicator(color: AppColors.primary),
                )
              else ...[
                if (_loadFailed)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Text(
                      _isEn
                          ? 'Could not load the latest status. Pull down to try again.'
                          : 'Imeshindwa kupata hali ya sasa. Vuta chini kujaribu tena.',
                      style: const TextStyle(fontSize: 12, color: AppColors.danger),
                    ),
                  ),
                Container(
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Column(
                    children: [
                      _checklistItem(
                        icon: kind.icon,
                        iconColor: AppColors.primary,
                        title: kind.title(_isEn),
                        state: idState,
                        missingText: kind.hasBack
                            ? (_isEn ? 'Front and back needed' : 'Mbele na nyuma zinahitajika')
                            : (_isEn ? 'Photo page needed' : 'Ukurasa wa picha unahitajika'),
                      ),
                      const Divider(height: 1, indent: 56, color: AppColors.borderLight),
                      _checklistItem(
                        icon: Icons.face_rounded,
                        iconColor: AppColors.primary,
                        title: _isEn ? 'Selfie holding your ID' : 'Selfie ukishika kitambulisho',
                        state: selfieState,
                      ),
                      const Divider(height: 1, indent: 56, color: AppColors.borderLight),
                      _checklistItem(
                        icon: Icons.face_retouching_natural_rounded,
                        iconColor: AppColors.primary,
                        title: _isEn ? 'Face photo' : 'Picha ya uso',
                        state: faceState,
                      ),
                      const Divider(height: 1, indent: 56, color: AppColors.borderLight),
                      _checklistItem(
                        icon: Icons.phone_android_rounded,
                        iconColor: const Color(0xFF10B981),
                        title: _isEn ? 'Phone number' : 'Namba ya simu',
                        state: hasPhone ? _DocState.approved : _DocState.missing,
                        approvedText: _isEn ? 'Added' : 'Imewekwa',
                        missingText: _isEn ? 'Not added' : 'Haijawekwa',
                      ),
                      const Divider(height: 1, indent: 56, color: AppColors.borderLight),
                      _checklistItem(
                        icon: Icons.storefront_outlined,
                        iconColor: AppColors.textSecondary,
                        title: _isEn ? 'Business licence (optional)' : 'Leseni ya biashara (hiari)',
                        state: licenceState,
                      ),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 24),
              if (badge == 'BLUE_TICK')
                AppButton.primary(
                  label: _isEn ? 'Invite someone you trust' : 'Alika unayemwamini',
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const InviteTrustedScreen())),
                )
              else ...[
                AppButton.primary(
                  label: _isEn ? 'Upload documents' : 'Pakia nyaraka',
                  onPressed: _openDocuments,
                ),
                const SizedBox(height: 10),
                AppButton.outlined(
                  label: _isEn ? 'I have an invitation (NIN only)' : 'Nina mwaliko (NIN tu)',
                  onPressed: _openInvitation,
                ),
              ],
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.primaryLight.withValues(alpha: 0.5),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.primary.withValues(alpha: 0.2)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.info_outline_rounded, color: AppColors.primary, size: 20),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        _isEn
                            ? 'Your verification data is protected and only visible to trusted systems.'
                            : 'Taarifa zako za uthibitisho zinalindwa na zinaonekana kwa mifumo inayoaminika tu.',
                        style: const TextStyle(fontSize: 12, color: AppColors.textPrimary, height: 1.35),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _checklistItem({
    required IconData icon,
    required Color iconColor,
    required String title,
    required _DocState state,
    String? approvedText,
    String? missingText,
  }) {
    final String text;
    final Color color;
    final IconData stateIcon;
    switch (state) {
      case _DocState.approved:
        text = approvedText ?? (_isEn ? 'Verified' : 'Imethibitishwa');
        color = AppColors.success;
        stateIcon = Icons.check_circle_rounded;
      case _DocState.pending:
        text = _isEn ? 'Under review' : 'Inakaguliwa';
        color = AppColors.warningDark;
        stateIcon = Icons.hourglass_top_rounded;
      case _DocState.rejected:
        text = _isEn ? 'Rejected - upload again' : 'Imekataliwa - pakia tena';
        color = AppColors.danger;
        stateIcon = Icons.cancel_rounded;
      case _DocState.missing:
        text = missingText ?? (_isEn ? 'Not uploaded' : 'Haijapakiwa');
        color = AppColors.textMuted;
        stateIcon = Icons.remove_circle_outline_rounded;
    }
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: iconColor.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: iconColor, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
            ),
          ),
          Flexible(
            child: Text(
              text,
              textAlign: TextAlign.end,
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: color),
            ),
          ),
          const SizedBox(width: 8),
          Icon(stateIcon, color: color, size: 18),
        ],
      ),
    );
  }
}

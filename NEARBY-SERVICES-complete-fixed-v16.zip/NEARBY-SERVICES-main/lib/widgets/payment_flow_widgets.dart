import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/data_sync.dart';
import '../services/payment_flow.dart';
import '../services/payment_methods_service.dart';
import 'card_payment_dialog.dart';

bool get _en => AppStrings.isEnglish;

void _toast(BuildContext context, String msg, {bool error = false}) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    backgroundColor: error ? AppColors.danger : null,
    content: Text(msg),
  ));
}

String _failText() =>
    ApiService.lastPaymentError ?? (_en ? 'Something went wrong. Please try again.' : 'Kuna hitilafu. Tafadhali jaribu tena.');

/// Shared rounded sheet frame that lifts above the keyboard.
class _SheetFrame extends StatelessWidget {
  final String title;
  final String? subtitle;
  final List<Widget> children;
  const _SheetFrame({required this.title, this.subtitle, required this.children});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        decoration: const BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
        ),
        child: SafeArea(
          top: false,
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(18, 10, 18, 18),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 38,
                    height: 4,
                    decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)),
                  ),
                ),
                const SizedBox(height: 14),
                Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                if (subtitle != null) ...[
                  const SizedBox(height: 4),
                  Text(subtitle!, style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textSecondary)),
                ],
                const SizedBox(height: 14),
                ...children,
              ],
            ),
          ),
        ),
      ),
    );
  }
}

InputDecoration _fieldDecoration(String hint) => InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(fontSize: 13, color: AppColors.textMuted),
      isDense: true,
      contentPadding: const EdgeInsets.all(12),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
    );

Widget _primaryButton({required String label, required VoidCallback? onPressed, required bool busy, Color color = AppColors.primary}) {
  return SizedBox(
    width: double.infinity,
    height: 46,
    child: ElevatedButton(
      onPressed: busy ? null : onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        foregroundColor: Colors.white,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
      child: busy
          ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
          : Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
    ),
  );
}

// ---------------------------------------------------------------------------
// Provider: "Ask buyer to pay first"
// ---------------------------------------------------------------------------
class AskPaymentSheet extends StatefulWidget {
  final String transactionRef;
  final String amountText;
  const AskPaymentSheet({super.key, required this.transactionRef, required this.amountText});

  /// Resolves to true when the request for payment was sent.
  static Future<bool> show(BuildContext context, {required String transactionRef, required String amountText}) async {
    final r = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => AskPaymentSheet(transactionRef: transactionRef, amountText: amountText),
    );
    return r == true;
  }

  @override
  State<AskPaymentSheet> createState() => _AskPaymentSheetState();
}

class _AskPaymentSheetState extends State<AskPaymentSheet> {
  String _mode = 'OFFLINE'; // OFFLINE = pay me directly, ONLINE = pay in the app
  int _minutes = 60;
  final _instructions = TextEditingController();
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _prefill();
  }

  /// Pre-fill with the wallet numbers this user already saved on the device.
  Future<void> _prefill() async {
    try {
      final numbers = await PaymentMethodsService.loadNumbers();
      final lines = <String>[];
      for (final m in PaymentMethodsService.methods) {
        final n = numbers[m.id];
        if (m.isMobileMoney && n != null && n.trim().isNotEmpty) lines.add('${m.nameEn}: $n');
      }
      if (mounted && _instructions.text.isEmpty && lines.isNotEmpty) {
        setState(() => _instructions.text = lines.join('\n'));
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    _instructions.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_mode == 'OFFLINE' && _instructions.text.trim().length < 5) {
      _toast(context, _en ? 'Add the number or account the buyer should pay to.' : 'Weka namba au akaunti ambayo mnunuzi atalipa.', error: true);
      return;
    }
    setState(() => _busy = true);
    final res = await ApiService.requestPayment(
      widget.transactionRef,
      mode: _mode,
      instructions: _mode == 'OFFLINE' ? _instructions.text : null,
      deadlineMinutes: _minutes,
    );
    if (!mounted) return;
    setState(() => _busy = false);
    if (res == null) {
      _toast(context, _failText(), error: true);
      return;
    }
    DataSync.bump();
    Navigator.pop(context, true);
  }

  Widget _modeTile(String id, String title, String sub, IconData icon) {
    final selected = _mode == id;
    return GestureDetector(
      onTap: () => setState(() => _mode = id),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: selected ? AppColors.primaryLight : AppColors.background,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: selected ? AppColors.primary : AppColors.border, width: selected ? 1.5 : 1),
        ),
        child: Row(
          children: [
            Icon(selected ? Icons.radio_button_checked : Icons.radio_button_off, size: 18, color: AppColors.primary),
            const SizedBox(width: 10),
            Icon(icon, size: 20, color: AppColors.textSecondary),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                  const SizedBox(height: 2),
                  Text(sub, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.3)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const options = <int, String>{30: '30 min', 60: '1 h', 180: '3 h', 1440: '24 h'};
    return _SheetFrame(
      title: _en ? 'Ask buyer to pay first' : 'Mwombe mnunuzi alipe kwanza',
      subtitle: _en
          ? 'The request stays unaccepted until payment is confirmed. Amount: ${widget.amountText}.'
          : 'Ombi halikubaliwi hadi malipo yathibitishwe. Kiasi: ${widget.amountText}.',
      children: [
        _modeTile(
          'OFFLINE',
          _en ? 'Pay me directly' : 'Nilipe moja kwa moja',
          _en ? 'Buyer sends money to your number/account, taps "I have paid", then you confirm.' : 'Mnunuzi anatuma pesa kwenye namba/akaunti yako, anabonyeza "Nimelipa", kisha unathibitisha.',
          Icons.swap_horiz_rounded,
        ),
        _modeTile(
          'ONLINE',
          _en ? 'Pay in the app' : 'Alipe ndani ya app',
          _en ? 'Buyer pays with Pocket Fund, mobile money or card. Held safely until the job is done.' : 'Mnunuzi analipa kwa Pocket Fund, pesa za simu au kadi. Inashikiliwa salama hadi kazi iishe.',
          Icons.shield_outlined,
        ),
        if (_mode == 'OFFLINE') ...[
          const SizedBox(height: 6),
          Text(_en ? 'Where should the buyer pay?' : 'Mnunuzi alipe wapi?',
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
          const SizedBox(height: 6),
          TextField(
            controller: _instructions,
            maxLines: 3,
            decoration: _fieldDecoration(_en ? 'e.g. M-Pesa 0712 345 678 (Asha M.)' : 'Mfano: M-Pesa 0712 345 678 (Asha M.)'),
          ),
        ],
        const SizedBox(height: 12),
        Text(_en ? 'Time to pay' : 'Muda wa kulipa',
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
        const SizedBox(height: 6),
        Wrap(
          spacing: 8,
          children: options.entries
              .map((e) => ChoiceChip(
                    label: Text(e.value),
                    selected: _minutes == e.key,
                    onSelected: (_) => setState(() => _minutes = e.key),
                  ))
              .toList(),
        ),
        const SizedBox(height: 16),
        _primaryButton(
          label: _en ? 'Send payment request' : 'Tuma ombi la malipo',
          onPressed: _submit,
          busy: _busy,
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Buyer: "I have paid"
// ---------------------------------------------------------------------------
class MarkPaidSheet extends StatefulWidget {
  final String transactionRef;
  final String amountText;
  const MarkPaidSheet({super.key, required this.transactionRef, required this.amountText});

  static Future<bool> show(BuildContext context, {required String transactionRef, required String amountText}) async {
    final r = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => MarkPaidSheet(transactionRef: transactionRef, amountText: amountText),
    );
    return r == true;
  }

  @override
  State<MarkPaidSheet> createState() => _MarkPaidSheetState();
}

class _MarkPaidSheetState extends State<MarkPaidSheet> {
  final _reference = TextEditingController();
  final _note = TextEditingController();
  bool _confirmed = false;
  bool _busy = false;

  @override
  void dispose() {
    _reference.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_confirmed) {
      _toast(context, _en ? 'Tick the box to confirm you sent the money.' : 'Weka tiki kuthibitisha umetuma pesa.', error: true);
      return;
    }
    setState(() => _busy = true);
    final res = await ApiService.markPaymentSent(widget.transactionRef, reference: _reference.text, note: _note.text);
    if (!mounted) return;
    setState(() => _busy = false);
    if (res == null) {
      _toast(context, _failText(), error: true);
      return;
    }
    DataSync.bump();
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return _SheetFrame(
      title: _en ? 'I have paid' : 'Nimelipa',
      subtitle: _en
          ? 'The provider is alerted and will confirm once the money arrives. Only tap this after you have really paid.'
          : 'Mtoa huduma atapewa taarifa na atathibitisha pesa zikifika. Bonyeza hii baada ya kulipa kweli tu.',
      children: [
        Text(_en ? 'Payment reference (from the SMS)' : 'Namba ya muamala (kutoka SMS)',
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
        const SizedBox(height: 6),
        TextField(controller: _reference, decoration: _fieldDecoration(_en ? 'e.g. QJ47XK92LA' : 'Mfano: QJ47XK92LA')),
        const SizedBox(height: 12),
        Text(_en ? 'Note (optional)' : 'Maelezo (si lazima)',
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
        const SizedBox(height: 6),
        TextField(
          controller: _note,
          maxLines: 2,
          decoration: _fieldDecoration(_en ? 'Name used to pay, time sent...' : 'Jina lililotumika kulipa, muda ulipotuma...'),
        ),
        const SizedBox(height: 10),
        InkWell(
          onTap: () => setState(() => _confirmed = !_confirmed),
          child: Row(
            children: [
              Checkbox(value: _confirmed, onChanged: (v) => setState(() => _confirmed = v == true), activeColor: AppColors.primary),
              Expanded(
                child: Text(
                  _en ? 'I sent ${widget.amountText} to the provider.' : 'Nimetuma ${widget.amountText} kwa mtoa huduma.',
                  style: const TextStyle(fontSize: 12, color: AppColors.textPrimary),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        _primaryButton(label: _en ? 'Notify provider' : 'Mjulishe mtoa huduma', onPressed: _submit, busy: _busy),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Provider: "Not received"
// ---------------------------------------------------------------------------
class NotReceivedSheet extends StatefulWidget {
  final String transactionRef;
  const NotReceivedSheet({super.key, required this.transactionRef});

  static Future<bool> show(BuildContext context, {required String transactionRef}) async {
    final r = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => NotReceivedSheet(transactionRef: transactionRef),
    );
    return r == true;
  }

  @override
  State<NotReceivedSheet> createState() => _NotReceivedSheetState();
}

class _NotReceivedSheetState extends State<NotReceivedSheet> {
  int _reason = 0;
  final _note = TextEditingController();
  bool _busy = false;

  List<String> get _reasons => _en
      ? ['Nothing received', 'Wrong amount', 'Other']
      : ['Sijapokea chochote', 'Kiasi si sahihi', 'Nyingine'];

  @override
  void dispose() {
    _note.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    setState(() => _busy = true);
    final text = [_reasons[_reason], if (_note.text.trim().isNotEmpty) _note.text.trim()].join(': ');
    final res = await ApiService.reportPaymentNotReceived(widget.transactionRef, reason: text);
    if (!mounted) return;
    setState(() => _busy = false);
    if (res == null) {
      _toast(context, _failText(), error: true);
      return;
    }
    DataSync.bump();
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return _SheetFrame(
      title: _en ? 'Payment not received' : 'Malipo hayajapokelewa',
      subtitle: _en
          ? 'The buyer will be told. If the money arrives later you can still confirm it.'
          : 'Mnunuzi ataarifiwa. Pesa zikifika baadaye bado unaweza kuthibitisha.',
      children: [
        Wrap(
          spacing: 8,
          children: List.generate(
            _reasons.length,
            (i) => ChoiceChip(label: Text(_reasons[i]), selected: _reason == i, onSelected: (_) => setState(() => _reason = i)),
          ),
        ),
        const SizedBox(height: 12),
        TextField(controller: _note, maxLines: 2, decoration: _fieldDecoration(_en ? 'Details (optional)' : 'Maelezo (si lazima)')),
        const SizedBox(height: 14),
        _primaryButton(
          label: _en ? 'Report not received' : 'Ripoti hayajapokelewa',
          onPressed: _submit,
          busy: _busy,
          color: AppColors.danger,
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Buyer: pay an existing booking online
// ---------------------------------------------------------------------------
class PayNowSheet extends StatefulWidget {
  final String transactionRef;
  final double amount;
  final String description;
  const PayNowSheet({super.key, required this.transactionRef, required this.amount, required this.description});

  static Future<bool> show(BuildContext context,
      {required String transactionRef, required double amount, required String description}) async {
    final r = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => PayNowSheet(transactionRef: transactionRef, amount: amount, description: description),
    );
    return r == true;
  }

  @override
  State<PayNowSheet> createState() => _PayNowSheetState();
}

class _PayNowSheetState extends State<PayNowSheet> {
  String _method = 'POCKET_FUND'; // POCKET_FUND | mobile_money | card
  final _phone = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _phone.dispose();
    super.dispose();
  }

  Future<void> _pay() async {
    final nav = Navigator.of(context);
    if (_method == 'mobile_money') {
      final normalized = PaymentMethodsService.normalizeTzNumber(_phone.text);
      if (normalized == null) {
        _toast(context, _en ? 'Enter a valid Tanzanian number' : 'Weka namba sahihi ya Tanzania', error: true);
        return;
      }
      setState(() => _busy = true);
      final res = await ApiService.requestMobilePayment(
        amount: widget.amount,
        purpose: 'BOOKING',
        reference: widget.transactionRef,
        phone: '+$normalized',
      );
      if (!mounted) return;
      setState(() => _busy = false);
      if (res == null) {
        _toast(context, _en ? 'Could not send the payment request. Try again.' : 'Imeshindwa kutuma ombi la malipo. Jaribu tena.', error: true);
        return;
      }
      _toast(context, _en ? 'Check your phone and approve the payment.' : 'Angalia simu yako na uidhinishe malipo.');
      DataSync.bump();
      nav.pop(true);
      return;
    }

    if (_method == 'card') {
      final paid = await CardPayment.pay(
        context,
        amount: widget.amount,
        purpose: 'BOOKING',
        reference: widget.transactionRef,
        description: widget.description,
      );
      if (!mounted) return;
      if (paid) DataSync.bump();
      nav.pop(paid);
      return;
    }

    setState(() => _busy = true);
    final res = await ApiService.payEscrow(widget.transactionRef, paymentMethod: 'POCKET_FUND');
    if (!mounted) return;
    setState(() => _busy = false);
    if (res == null) {
      _toast(context, _failText(), error: true);
      return;
    }
    DataSync.bump();
    nav.pop(true);
  }

  Widget _tile(String id, String title, String sub, IconData icon) {
    final selected = _method == id;
    return GestureDetector(
      onTap: () => setState(() => _method = id),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: selected ? AppColors.primaryLight : AppColors.background,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: selected ? AppColors.primary : AppColors.border, width: selected ? 1.5 : 1),
        ),
        child: Row(
          children: [
            Icon(selected ? Icons.radio_button_checked : Icons.radio_button_off, size: 18, color: AppColors.primary),
            const SizedBox(width: 10),
            Icon(icon, size: 20, color: AppColors.textSecondary),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                  Text(sub, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return _SheetFrame(
      title: _en ? 'Pay now' : 'Lipa sasa',
      subtitle: PaymentFlow.money(widget.amount),
      children: [
        _tile('POCKET_FUND', 'Pocket Fund', _en ? 'Wallet balance' : 'Salio la wallet', Icons.account_balance_wallet_outlined),
        _tile('mobile_money', _en ? 'Mobile Money' : 'Pesa za Simu', 'M-Pesa • Airtel Money • Tigo Pesa • Halopesa', Icons.phone_android_rounded),
        if (_method == 'mobile_money') ...[
          TextField(
            controller: _phone,
            keyboardType: TextInputType.phone,
            decoration: _fieldDecoration(_en ? 'Number to pay with e.g. 0712 345 678' : 'Namba ya kulipia mf. 0712 345 678'),
          ),
          const SizedBox(height: 8),
        ],
        _tile('card', _en ? 'Card' : 'Kadi', 'Visa • Mastercard', Icons.credit_card_rounded),
        const SizedBox(height: 8),
        _primaryButton(label: '${_en ? 'Pay' : 'Lipa'} ${PaymentFlow.money(widget.amount)}', onPressed: _pay, busy: _busy),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Status panel + actions, used on the buyer card, the provider card and details
// ---------------------------------------------------------------------------
class PaymentFlowPanel extends StatefulWidget {
  final Map<String, dynamic> tx;
  final bool isBuyer;

  /// Called after a successful action (refresh your list / pop the screen).
  final VoidCallback? onChanged;

  const PaymentFlowPanel({super.key, required this.tx, required this.isBuyer, this.onChanged});

  @override
  State<PaymentFlowPanel> createState() => _PaymentFlowPanelState();
}

class _PaymentFlowPanelState extends State<PaymentFlowPanel> {
  Timer? _timer;

  Map<String, dynamic> get _tx => widget.tx;
  String get _ref => (_tx['transactionRef'] ?? '').toString();
  PayState get _state => PaymentFlow.stateOf(_tx['status']);
  double get _amount => (_tx['amount'] as num?)?.toDouble() ?? 0;
  String get _amountText => PaymentFlow.money(_amount);
  bool get _offline => PaymentFlow.payMode(_tx) == 'OFFLINE';
  DateTime? get _deadline => DateTime.tryParse((_tx['paymentDeadline'] ?? '').toString())?.toLocal();
  String _text(String key) => (_tx[key] ?? '').toString().trim();

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && _state == PayState.awaitingPayment && _deadline != null) setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _done(String message) {
    _toast(context, message);
    widget.onChanged?.call();
  }

  Future<void> _iPaid() async {
    final ok = await MarkPaidSheet.show(context, transactionRef: _ref, amountText: _amountText);
    if (ok && mounted) _done(_en ? 'Provider notified. Waiting for confirmation.' : 'Mtoa huduma amejulishwa. Inasubiri uthibitisho.');
  }

  Future<void> _payNow() async {
    final ok = await PayNowSheet.show(
      context,
      transactionRef: _ref,
      amount: _amount,
      description: (_tx['serviceTitle'] ?? 'Booking').toString(),
    );
    if (ok && mounted) _done(_en ? 'Payment started.' : 'Malipo yameanza.');
  }

  Future<void> _confirmReceived() async {
    final sure = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(_en ? 'Confirm payment received?' : 'Thibitisha malipo yamepokelewa?'),
        content: Text(_en
            ? 'Only confirm after $_amountText is in your account. This accepts the booking and cannot be undone.'
            : 'Thibitisha tu baada ya $_amountText kuingia kwenye akaunti yako. Hii inakubali oda na haiwezi kutenguliwa.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(_en ? 'Not yet' : 'Bado')),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.success, foregroundColor: Colors.white),
            child: Text(_en ? 'Yes, received' : 'Ndiyo, nimepokea'),
          ),
        ],
      ),
    );
    if (sure != true || !mounted) return;
    final res = await ApiService.confirmPaymentReceived(_ref);
    if (!mounted) return;
    if (res == null) {
      _toast(context, _failText(), error: true);
      return;
    }
    DataSync.bump();
    _done(_en ? 'Payment confirmed. Booking accepted.' : 'Malipo yamethibitishwa. Oda imekubaliwa.');
  }

  Future<void> _notReceived() async {
    final ok = await NotReceivedSheet.show(context, transactionRef: _ref);
    if (ok && mounted) _done(_en ? 'Buyer has been told the payment was not received.' : 'Mnunuzi ameambiwa malipo hayajapokelewa.');
  }

  String _countdown() {
    final d = _deadline;
    if (d == null) return '';
    final left = d.difference(DateTime.now());
    if (left.isNegative) return _en ? 'Payment window expired' : 'Muda wa kulipa umeisha';
    final h = left.inHours;
    final m = left.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = left.inSeconds.remainder(60).toString().padLeft(2, '0');
    final t = h > 0 ? '$h:$m:$s' : '$m:$s';
    return _en ? 'Time left to pay: $t' : 'Muda uliobaki kulipa: $t';
  }

  Widget _copyRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Container(
        padding: const EdgeInsets.fromLTRB(10, 8, 4, 8),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label, style: const TextStyle(fontSize: 10, color: AppColors.textMuted, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 2),
                  SelectableText(value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textPrimary, height: 1.35)),
                ],
              ),
            ),
            IconButton(
              visualDensity: VisualDensity.compact,
              icon: const Icon(Icons.copy_rounded, size: 18, color: AppColors.primary),
              onPressed: () {
                Clipboard.setData(ClipboardData(text: value));
                _toast(context, _en ? 'Copied' : 'Imenakiliwa');
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _action(String label, VoidCallback onTap, {Color color = AppColors.primary, bool outlined = false}) {
    final shape = RoundedRectangleBorder(borderRadius: BorderRadius.circular(8));
    return SizedBox(
      height: 38,
      child: outlined
          ? OutlinedButton(
              onPressed: onTap,
              style: OutlinedButton.styleFrom(foregroundColor: color, side: BorderSide(color: color), shape: shape),
              child: Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
            )
          : ElevatedButton(
              onPressed: onTap,
              style: ElevatedButton.styleFrom(backgroundColor: color, foregroundColor: Colors.white, elevation: 0, shape: shape),
              child: Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
            ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = _state;
    final unpaidOnline = state == PayState.none && PaymentFlow.isUnpaidOnline(_tx);
    if (state == PayState.none && !unpaidOnline) return const SizedBox.shrink();

    final buyer = widget.isBuyer;
    late final String title;
    late final String body;
    late final Color tone;
    late final IconData icon;

    if (unpaidOnline) {
      tone = AppColors.warning;
      icon = Icons.payments_outlined;
      title = buyer ? (_en ? 'Payment not completed' : 'Malipo hayajakamilika') : (_en ? 'Buyer has not paid yet' : 'Mnunuzi hajalipa bado');
      body = buyer
          ? (_en ? 'Complete your payment so the provider can accept your request.' : 'Kamilisha malipo ili mtoa huduma akubali ombi lako.')
          : (_en ? 'You can accept once the buyer has paid.' : 'Unaweza kukubali mnunuzi akishalipa.');
    } else if (state == PayState.awaitingPayment) {
      tone = AppColors.warning;
      icon = Icons.hourglass_top_rounded;
      if (buyer) {
        title = _en ? 'Payment required' : 'Malipo yanahitajika';
        body = _offline
            ? (_en ? 'Send $_amountText to the provider, then tap "I have paid".' : 'Tuma $_amountText kwa mtoa huduma, kisha bonyeza "Nimelipa".')
            : (_en ? 'The provider asks you to pay in the app to confirm this booking.' : 'Mtoa huduma anakuomba ulipe ndani ya app ili kuthibitisha oda hii.');
      } else {
        title = _en ? 'Waiting for buyer to pay' : 'Inasubiri mnunuzi alipe';
        body = _en ? 'The booking is accepted once the payment is confirmed.' : 'Oda inakubaliwa malipo yakithibitishwa.';
      }
    } else if (state == PayState.paymentSent) {
      tone = AppColors.primary;
      icon = Icons.mark_email_read_outlined;
      if (buyer) {
        title = _en ? 'Waiting for provider to confirm' : 'Inasubiri mtoa huduma athibitishe';
        body = _en ? 'You told the provider you paid. They will confirm once the money arrives.' : 'Umemwambia mtoa huduma umelipa. Atathibitisha pesa zikifika.';
      } else {
        title = _en ? 'Buyer says they have paid' : 'Mnunuzi anasema amelipa';
        body = _en ? 'Check your account. Confirm only after $_amountText has arrived.' : 'Angalia akaunti yako. Thibitisha tu baada ya $_amountText kufika.';
      }
    } else {
      tone = AppColors.danger;
      icon = Icons.error_outline_rounded;
      if (buyer) {
        title = _en ? 'Provider did not receive your payment' : 'Mtoa huduma hajapokea malipo yako';
        body = _en ? 'Check your payment reference and chat with the provider, or contact support.' : 'Angalia namba ya muamala na zungumza na mtoa huduma, au wasiliana na msaada.';
      } else {
        title = _en ? 'Marked as not received' : 'Imewekwa hayajapokelewa';
        body = _en ? 'If the money arrives later you can still confirm it.' : 'Pesa zikifika baadaye bado unaweza kuthibitisha.';
      }
    }

    final instructions = _text('paymentInstructions');
    final paidRef = _text('paymentReference');
    final paidNote = _text('paymentNote');
    final countdown = state == PayState.awaitingPayment ? _countdown() : '';

    final actions = <Widget>[];
    if (buyer && (state == PayState.awaitingPayment || unpaidOnline)) {
      final online = unpaidOnline || !_offline;
      actions.add(Expanded(
        child: online
            ? _action(_en ? 'Pay now' : 'Lipa sasa', _payNow)
            : _action(_en ? 'I have paid' : 'Nimelipa', _iPaid, color: AppColors.success),
      ));
    }
    if (!buyer && (state == PayState.paymentSent || state == PayState.disputed)) {
      actions.add(Expanded(child: _action(_en ? 'Confirm received' : 'Thibitisha nimepokea', _confirmReceived, color: AppColors.success)));
      if (state == PayState.paymentSent) {
        actions.add(const SizedBox(width: 10));
        actions.add(Expanded(child: _action(_en ? 'Not received' : 'Sijapokea', _notReceived, color: AppColors.danger, outlined: true)));
      }
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: tone.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: tone.withValues(alpha: 0.35)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, size: 18, color: tone),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: tone)),
                    const SizedBox(height: 2),
                    Text(body, style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textPrimary)),
                  ],
                ),
              ),
            ],
          ),
          if (countdown.isNotEmpty) ...[
            const SizedBox(height: 6),
            Text(countdown, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: tone)),
          ],
          // Buyer: where to pay + the reference to quote (like a P2P order)
          if (buyer && state == PayState.awaitingPayment && _offline) ...[
            if (instructions.isNotEmpty) _copyRow(_en ? 'Pay to' : 'Lipa kwa', instructions),
            if (_ref.isNotEmpty) _copyRow(_en ? 'Booking reference (put it in the payment note)' : 'Kumbukumbu ya oda (iweke kwenye maelezo ya malipo)', _ref),
          ],
          // Provider: what the buyer reported
          if (!buyer && (state == PayState.paymentSent || state == PayState.disputed)) ...[
            _copyRow(_en ? 'Amount to receive' : 'Kiasi cha kupokea', _amountText),
            if (paidRef.isNotEmpty) _copyRow(_en ? "Buyer's payment reference" : 'Namba ya muamala ya mnunuzi', paidRef),
            if (paidNote.isNotEmpty) _copyRow(_en ? "Buyer's note" : 'Maelezo ya mnunuzi', paidNote),
          ],
          if (actions.isNotEmpty) ...[
            const SizedBox(height: 10),
            Row(children: actions),
          ],
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'session_manager.dart';

/// One way a buyer can pay.
class PaymentMethodInfo {
  final String id;
  final String nameEn;
  final String nameSw;
  final IconData icon;
  final Color color;

  /// Mobile-money wallets store a phone number. Cards never store anything:
  /// they are paid on the gateway's secure checkout page.
  final bool isMobileMoney;

  const PaymentMethodInfo({
    required this.id,
    required this.nameEn,
    required this.nameSw,
    required this.icon,
    required this.color,
    required this.isMobileMoney,
  });
}

/// Buyer payment methods + default choice, kept per signed-in user on the device.
class PaymentMethodsService {
  PaymentMethodsService._();

  static const List<PaymentMethodInfo> methods = [
    PaymentMethodInfo(
      id: 'mpesa',
      nameEn: 'M-Pesa',
      nameSw: 'M-Pesa',
      icon: Icons.phone_android_rounded,
      color: Color(0xFF10B981),
      isMobileMoney: true,
    ),
    PaymentMethodInfo(
      id: 'airtel',
      nameEn: 'Airtel Money',
      nameSw: 'Airtel Money',
      icon: Icons.sim_card_outlined,
      color: Color(0xFFEF4444),
      isMobileMoney: true,
    ),
    PaymentMethodInfo(
      id: 'tigo',
      nameEn: 'Tigo Pesa',
      nameSw: 'Tigo Pesa',
      icon: Icons.swap_horiz_rounded,
      color: Color(0xFF3B82F6),
      isMobileMoney: true,
    ),
    PaymentMethodInfo(
      id: 'card',
      nameEn: 'Debit / Credit card',
      nameSw: 'Kadi ya benki',
      icon: Icons.credit_card_rounded,
      color: Color(0xFF6B7280),
      isMobileMoney: false,
    ),
  ];

  static PaymentMethodInfo byId(String id) => methods.firstWhere((m) => m.id == id);

  static String get _numbersKey => 'pay_numbers_${SessionManager.getUserIdValue()}';
  static String get _defaultKey => 'pay_default_${SessionManager.getUserIdValue()}';

  /// Saved wallet numbers, e.g. {'mpesa': '255712345678'}.
  static Future<Map<String, String>> loadNumbers() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_numbersKey) ?? const <String>[];
    final out = <String, String>{};
    for (final entry in raw) {
      final i = entry.indexOf('=');
      if (i > 0) out[entry.substring(0, i)] = entry.substring(i + 1);
    }
    return out;
  }

  static Future<void> _saveNumbers(Map<String, String> numbers) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_numbersKey, [for (final e in numbers.entries) '${e.key}=${e.value}']);
  }

  static Future<String?> loadDefault() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_defaultKey);
  }

  static Future<void> setDefault(String id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_defaultKey, id);
  }

  static Future<void> saveNumber(String id, String normalizedNumber) async {
    final numbers = await loadNumbers();
    numbers[id] = normalizedNumber;
    await _saveNumbers(numbers);
    // First method added becomes the default automatically.
    if (await loadDefault() == null) await setDefault(id);
  }

  static Future<void> remove(String id) async {
    final numbers = await loadNumbers();
    numbers.remove(id);
    await _saveNumbers(numbers);
    if (await loadDefault() == id) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_defaultKey);
      if (numbers.isNotEmpty) await setDefault(numbers.keys.first);
    }
  }

  /// Tanzanian mobile number -> 255XXXXXXXXX, or null when it is not valid.
  /// Accepts 07XXXXXXXX, 7XXXXXXXX, 2557XXXXXXXX and +2557XXXXXXXX.
  static String? normalizeTzNumber(String input) {
    var d = input.replaceAll(RegExp(r'[^0-9]'), '');
    if (d.startsWith('255')) d = d.substring(3);
    if (d.startsWith('0')) d = d.substring(1);
    if (d.length != 9 || !RegExp(r'^[67]').hasMatch(d)) return null;
    return '255$d';
  }

  /// 255712345678 -> +255 71• •••• 678 style mask so the full number is not on screen.
  static String mask(String normalized) {
    if (normalized.length < 12) return normalized;
    return '+255 ${normalized.substring(3, 5)}• •••• ${normalized.substring(9)}';
  }
}

import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';

/// A country the app supports for phone numbers.
class CountryDial {
  final String iso;
  final String dial; // e.g. +255
  final String name;
  final String flag;
  const CountryDial(this.iso, this.dial, this.name, this.flag);

  static const List<CountryDial> all = [
    CountryDial('TZ', '+255', 'Tanzania', '🇹🇿'),
    CountryDial('KE', '+254', 'Kenya', '🇰🇪'),
    CountryDial('UG', '+256', 'Uganda', '🇺🇬'),
    CountryDial('RW', '+250', 'Rwanda', '🇷🇼'),
    CountryDial('BI', '+257', 'Burundi', '🇧🇮'),
    CountryDial('CD', '+243', 'DRC', '🇨🇩'),
  ];

  static CountryDial byDial(String dial) =>
      all.firstWhere((c) => c.dial == dial, orElse: () => all.first);

  /// The supported country whose code starts [phone] (e.g. "+254712..."), or null.
  static CountryDial? fromInternational(String phone) {
    final p = phone.trim();
    if (!p.startsWith('+')) return null;
    for (final c in all) {
      if (p.startsWith(c.dial)) return c;
    }
    return null;
  }
}

/// Tappable "flag + code" chip that opens a list of countries.
/// Use it as the prefix of a phone TextField.
class CountryCodePicker extends StatelessWidget {
  final String value; // selected dial code, e.g. +255
  final ValueChanged<String> onChanged;
  final bool enabled;

  const CountryCodePicker({
    super.key,
    required this.value,
    required this.onChanged,
    this.enabled = true,
  });

  Future<void> _open(BuildContext context) async {
    final picked = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 10),
            Container(width: 38, height: 4, decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(4))),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 6),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  AppStrings.isEnglish ? 'Select country' : 'Chagua nchi',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                ),
              ),
            ),
            Flexible(
              child: ListView(
                shrinkWrap: true,
                children: [
                  for (final c in CountryDial.all)
                    ListTile(
                      leading: Text(c.flag, style: const TextStyle(fontSize: 24)),
                      title: Text(c.name, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                      subtitle: Text(c.dial, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                      trailing: c.dial == value ? const Icon(Icons.check_circle_rounded, color: AppColors.primary) : null,
                      onTap: () => Navigator.pop(ctx, c.dial),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
    if (picked != null && picked != value) onChanged(picked);
  }

  @override
  Widget build(BuildContext context) {
    final c = CountryDial.byDial(value);
    return Padding(
      padding: const EdgeInsets.only(left: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(6),
        onTap: enabled ? () => _open(context) : null,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.phone_outlined, size: 18, color: AppColors.textSecondary),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
              decoration: BoxDecoration(color: AppColors.background, borderRadius: BorderRadius.circular(4)),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('${c.flag} ${c.dial}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                  if (enabled) const Icon(Icons.arrow_drop_down_rounded, size: 18, color: AppColors.textSecondary),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Container(height: 18, width: 1, color: AppColors.border),
            const SizedBox(width: 8),
          ],
        ),
      ),
    );
  }
}

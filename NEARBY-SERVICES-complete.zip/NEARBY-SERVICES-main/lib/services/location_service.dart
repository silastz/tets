import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'session_manager.dart';

class LocationService {
  static const String _defaultCity = 'Dar es Salaam';

  // Supported regions in Tanzania for smooth manual selection
  static const List<String> supportedRegions = [
    'Dar es Salaam',
    'Arusha',
    'Dodoma',
    'Mwanza',
    'Zanzibar',
    'Kilimanjaro (Moshi)',
    'Mbeya',
    'Morogoro',
    'Tanga',
    'Iringa',
    'Kigoma',
    'Tabora',
    'Mtwara',
    'Ruvuma (Songea)',
    'Shinyanga',
    'Kagera (Bukoba)',
    'Mara (Musoma)',
    'Singida',
    'Manyara (Babati)',
    'Geita',
    'Katavi',
    'Njombe',
    'Songwe',
    'Simiyu',
    'Lindi',
    'Pwani (Kibaha)',
  ];

  static final ValueNotifier<String> activeLocationNotifier =
      ValueNotifier<String>(SessionManager.getUserCity());

  static String get currentCity => activeLocationNotifier.value;

  // ---- Country / phone code ---------------------------------------------------
  static const Map<String, ({String dial, String name})> _countries = {
    'TZ': (dial: '+255', name: 'Tanzania'),
    'KE': (dial: '+254', name: 'Kenya'),
    'UG': (dial: '+256', name: 'Uganda'),
    'RW': (dial: '+250', name: 'Rwanda'),
    'BI': (dial: '+257', name: 'Burundi'),
    'CD': (dial: '+243', name: 'DRC'),
  };

  /// Dial code of the country the app was launched in (Tanzania when unknown).
  static final ValueNotifier<String> dialCodeNotifier = ValueNotifier<String>(_dialFor(SessionManager.getCountryIso()));

  static String _dialFor(String? iso) => _countries[(iso ?? '').toUpperCase()]?.dial ?? '+255';

  static String get dialCode => dialCodeNotifier.value;

  static String get countryName {
    final iso = SessionManager.getCountryIso().toUpperCase();
    return _countries[iso]?.name ?? 'Tanzania';
  }

  static Future<void> _saveCountry(String? iso) async {
    if (iso == null || iso.trim().isEmpty) return;
    final code = iso.trim().toUpperCase();
    await SessionManager.saveCountryIso(code);
    dialCodeNotifier.value = _dialFor(code);
  }

  /// Checks the country on every launch (even when a city is already saved),
  /// so registration uses the right phone code, e.g. +254 in Kenya.
  static Future<void> refreshCountry() async {
    try {
      final r = await http.get(Uri.parse('https://ipwho.is/')).timeout(const Duration(seconds: 4));
      if (r.statusCode == 200) {
        final d = json.decode(r.body);
        if (d['success'] == true && d['country_code'] is String) {
          await _saveCountry(d['country_code'] as String);
          return;
        }
      }
    } catch (e) {
      debugPrint('Country detection (ipwho.is) error: $e');
    }
    try {
      final r = await http.get(Uri.parse('https://ipapi.co/json/')).timeout(const Duration(seconds: 4));
      if (r.statusCode == 200) {
        final d = json.decode(r.body);
        if (d['error'] != true && d['country_code'] is String) {
          await _saveCountry(d['country_code'] as String);
        }
      }
    } catch (e) {
      debugPrint('Country detection (ipapi.co) error: $e');
    }
  }

  /// Detect user's current city based on network location/IP with multi-provider fallback.
  /// If already saved in SessionManager, keeps saved choice unless forceRefresh is true.
  static Future<String> detectCurrentLocation({bool forceRefresh = false}) async {
    final saved = SessionManager.getUserCity();
    if (!forceRefresh && saved.isNotEmpty && saved != _defaultCity) {
      activeLocationNotifier.value = saved;
      refreshCountry(); // keep the phone code in step with where the app is opened
      return saved;
    }

    // Provider 1: ipwho.is (fast, generous limits, returns detailed country & city)
    try {
      final response = await http
          .get(Uri.parse('https://ipwho.is/'))
          .timeout(const Duration(seconds: 4));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          final city = data['city'] as String?;
          final region = data['region'] as String?;
          final countryCode = data['country_code'] as String?;
          final countryName = data['country'] as String?;

          await _saveCountry(countryCode);
          String detected = _defaultCity;

          if (countryCode != null && countryCode.toUpperCase() != 'TZ') {
            // User is connecting from abroad (e.g., USA, Kenya, UK, or VPN)
            final locName = (city != null && city.isNotEmpty)
                ? city
                : (region ?? countryName ?? 'International');
            detected = countryName != null ? '$locName, $countryName' : locName;
          } else {
            // User is in Tanzania
            if (city != null && city.trim().isNotEmpty) {
              detected = _matchTanzaniaRegion(city.trim());
            } else if (region != null && region.trim().isNotEmpty) {
              detected = _matchTanzaniaRegion(region.trim());
            }
          }

          await setLocation(detected);
          return detected;
        }
      }
    } catch (e) {
      debugPrint('Primary location detection (ipwho.is) error: $e');
    }

    // Provider 2: ipapi.co (backup)
    try {
      final response = await http
          .get(Uri.parse('https://ipapi.co/json/'))
          .timeout(const Duration(seconds: 4));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['error'] != true) {
          final city = data['city'] as String?;
          final region = data['region'] as String?;
          final country = data['country_name'] as String?;
          final countryCode = data['country_code'] as String?;

          await _saveCountry(countryCode);
          String detected = _defaultCity;

          if (countryCode != null && countryCode.toUpperCase() != 'TZ') {
            final locName = (city != null && city.isNotEmpty) ? city : (region ?? 'International');
            detected = country != null ? '$locName, $country' : locName;
          } else {
            if (city != null && city.trim().isNotEmpty) {
              detected = _matchTanzaniaRegion(city.trim());
            } else if (region != null && region.trim().isNotEmpty) {
              detected = _matchTanzaniaRegion(region.trim());
            }
          }

          await setLocation(detected);
          return detected;
        }
      }
    } catch (e) {
      debugPrint('Backup location detection (ipapi.co) error: $e');
    }

    // Fallback to saved or default
    final fallback = saved.isNotEmpty ? saved : _defaultCity;
    activeLocationNotifier.value = fallback;
    return fallback;
  }

  /// Manually update and persist selected region
  static Future<void> setLocation(String regionName) async {
    activeLocationNotifier.value = regionName;
    await SessionManager.saveUserCity(regionName);
  }

  static String _matchTanzaniaRegion(String raw) {
    final clean = raw.toLowerCase().replaceAll('region', '').trim();
    for (final reg in supportedRegions) {
      if (reg.toLowerCase().contains(clean) || clean.contains(reg.toLowerCase().split(' ').first)) {
        return reg;
      }
    }
    return raw;
  }
}

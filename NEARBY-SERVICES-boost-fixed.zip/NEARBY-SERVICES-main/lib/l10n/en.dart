import 'base_strings.dart';

/// English Dictionary (en.dart)
class EnStrings implements BaseStrings {
  const EnStrings();

  // 1. Common / Global
  @override String get appName => 'Nearby Services';
  @override String get cancel => 'Cancel';
  @override String get close => 'Close';
  @override String get save => 'Save';
  @override String get submit => 'Submit';
  @override String get confirm => 'Confirm';
  @override String get back => 'Back';
  @override String get retry => 'Retry';
  @override String get search => 'Search';
  @override String get loading => 'Loading...';
  @override String get success => 'Success';
  @override String get error => 'Error';
  @override String get guest => 'Guest User';
  @override String get active => 'Active';
  @override String get pending => 'Pending';
  @override String get completed => 'Completed';
  @override String get currency => 'TSh';
  @override String get viewAll => 'View All';

  // 2. Navigation Bar
  @override String get navHome => 'Home';
  @override String get authNumberNotVerifiedNotice => 'This number is not verified yet. We sent you a code - verify it first, then you can sign in or reset your password.';
  @override String get authTooManyAttempts => 'Too many attempts. Please wait before trying again:';
  @override String get exitAppTitle => 'Exit app?';
  @override String get exitAppMessage => 'Are you sure you want to exit Nearby Services?';
  @override String get exitAppCancel => 'Stay';
  @override String get exitAppConfirm => 'Exit';
  @override String get exitAppPressAgain => 'Press back again to exit';
  @override String get loadingServices => 'Loading services near you...';
  @override String get navChats => 'Chats';
  @override String get navRequests => 'Requests';
  @override String get navSell => 'Sell';
  @override String get navServices => 'Services';
  @override String get navEarnings => 'Earnings';
  @override String get navProfile => 'Profile';
  @override String get navSearch => 'Search';

  // 3. Home Screen
  @override String get homeHeaderLocationTitle => 'CURRENT LOCATION';
  @override String get homeGreeting => 'Hi, Welcome!';
  @override String get homeGreetingSubtitle => 'Find trusted services near you';
  @override String get homeSearchPlaceholder => 'What service do you need?';
  @override String get homeChangeLocation => 'Change location';
  @override String get selectRegionTitle => 'Select Your Region';
  @override String get detectingLocation => 'Detecting location...';
  @override String get searchRegionHint => 'Search region or town...';
  @override String get nearYouRadius => 'Near you • Within 5 km';
  @override String get noServicesNearby => 'No providers found in this region yet.';
  @override String get bookNow => 'Request Service';
  @override String get bannerRelaxTitle => 'Professional Services\nRight Near You';
  @override String get bannerRelaxSubtitle => 'Quality • Trusted • Affordable';
  @override String get bannerExploreNow => 'Explore Now';
  @override String get chipAll => 'All';
  @override String get chipNearby => 'Nearby';
  @override String get chipTopRated => 'Top Rated';
  @override String get chipVerified => 'Verified';
  @override String get homeCategoriesTitle => 'Service Categories';
  @override String get homePopularServices => 'Popular Services';
  @override String get homeNearbyProviders => 'Nearby Services';
  @override String get homeFeaturedProviders => 'Featured Providers';
  @override String get homeVerifiedBadge => 'Verified';
  @override String get homeStartingFrom => 'Starting from';
  @override String get homeAllServicesSeen => 'You have seen all nearby services';

  // Categories
  @override String get catMassage => 'Massage';
  @override String get catBeauty => 'Beauty';
  @override String get catBarber => 'Barber';
  @override String get catCleaning => 'Cleaning';
  @override String get catPlumbing => 'Plumbing';
  @override String get catElectrical => 'Electrical';
  @override String get catMechanic => 'Mechanic';
  @override String get catPhotography => 'Photography';
  @override String get catRepair => 'Repair';
  @override String get catGeneral => 'General';

  // 4. Auth & Login / Registration Modal
  @override String get authWelcomeBack => 'Welcome Back!';
  @override String get authWelcomeSubtitle => 'Sign in to book escrow services and manage your requests';
  @override String get authCreateAccount => 'Create an Account';
  @override String get authCreateSubtitle => 'Join our community of verified buyers and service experts';
  @override String get authLoginTab => 'Sign In';
  @override String get authRegisterTab => 'Register';
  @override String get authFullNameLabel => 'Full Legal Name / Stage Name';
  @override String get authFullNameHint => 'e.g. John Doe / Master Barber';
  @override String get authPhoneLabel => 'Phone Number';
  @override String get authPhoneHint => 'e.g. 0712345678';
  @override String get authEmailLabel => 'Email Address';
  @override String get authEmailHint => 'name@example.com';
  @override String get authPasswordLabel => 'Password';
  @override String get authPasswordHint => 'At least 6 characters';
  @override String get authSellerAccountSwitch => 'Register as Service Provider (Seller)';
  @override String get authSellerSubtitle => 'Enables you to publish service listings and earn';
  @override String get authSignInButton => 'Sign In';
  @override String get authRegisterButton => 'Create Account';
  @override String get authVerifyOtpTitle => 'Verify Email Address';
  @override String get authVerifyPhoneOtpTitle => 'Verify Phone Number';
  @override String get authOtpSentSubtitle => 'We sent a 6-digit OTP code to: ';
  @override String get authPhoneOtpSentSubtitle => 'We sent a 6-digit OTP via SMS to: ';
  @override String get authOtpHint => '6-digit OTP code';
  @override String get authVerifyButton => 'Verify OTP';
  @override String get authResendOtp => 'Resend OTP';
  @override String get authInvalidOtpError => 'Invalid OTP or expired';
  @override String get authLoginSuccess => 'Welcome back, ';
  @override String get authRegisterSuccess => 'Account successfully created!';
  @override String get authAlreadyHaveAccount => 'Already have an account? Sign in';
  @override String get authDontHaveAccount => "Don't have an account? Register now";

  // Multi-step Service Provider Registration
  @override String get regProviderTitle => 'Register as Service Provider';
  @override String get regStepBasic => 'Basic Info';
  @override String get regStepBusiness => 'Business Info';
  @override String get regStepDocuments => 'Documents';
  @override String get regStepPayment => 'Payment';
  @override String get regBasicTitle => '1. Basic Information';
  @override String get regBasicSubtitle => 'Tell us about yourself';
  @override String get regBusinessTitle => '2. Business Information';
  @override String get regBusinessSubtitle => 'Details about your business / services';
  @override String get regBusinessNameLabel => 'Business / Service Name';
  @override String get regBusinessNameHint => 'e.g. Gloria Massage Spa';
  @override String get regCategoryLabel => 'Service Category';
  @override String get regCategoryHint => 'Select category';
  @override String get regDescLabel => 'Description';
  @override String get regDescHint => 'Describe your services, experience and what makes you unique...';
  @override String get regLocationLabel => 'Location';
  @override String get regLocationHint => 'Dar es Salaam, Tanzania';
  @override String get regRadiusLabel => 'Service Area (Radius)';
  @override String get regRadiusHint => 'e.g. 5 km';
  @override String get regDocumentsTitle => '3. Documents';
  @override String get regDocumentsSubtitle => 'Upload required documents for verification';
  @override String get regNidaDocTitle => 'National ID (NIDA)';
  @override String get regNidaDocSubtitle => 'Front side photo';
  @override String get regLicenseDocTitle => 'Business License (Optional)';
  @override String get regLicenseDocSubtitle => 'Business registration / license';
  @override String get regProfilePhotoTitle => 'Profile Photo';
  @override String get regProfilePhotoSubtitle => 'Clear photo of yourself';
  @override String get regUploadPhoto => 'Upload Photo';
  @override String get regUploadDoc => 'Upload Document';
  @override String get regDocSafeNotice => 'Your documents are safe and will only be used for verification purposes.';
  @override String get regPaymentTitle => '4. Registration Payment';
  @override String get regPaymentSubtitle => 'Complete your registration by paying the one-time fee.';
  @override String get regFeeLabel => 'Registration Fee';
  @override String get regFeeOneTime => 'One-time';
  @override String get regSelectPaymentMethod => 'Select Payment Method';
  @override String get regPaymentActivationNotice => 'After successful payment, your account will be activated immediately.';
  @override String get regBtnContinue => 'Continue';
  @override String get regBtnPayAndContinue => 'Pay & Continue';
  @override String get regUpgradeFromBuyerBanner => 'Upgrading existing buyer account to Service Provider';
  @override String get regSuccessTitle => 'Congratulations!';
  @override String get regSuccessMsg => 'Your Service Provider account is now active!';
  @override String get profileBecomeSeller => 'Become a Service Provider (Seller)';
  @override String get profileBecomeSellerSubtitle => 'Register to publish services, get bookings, and earn';
  @override String get authForgotPasswordLink => 'Forgot Password?';
  @override String get authForgotPasswordTitle => 'Reset Password';
  @override String get authForgotPasswordSubtitle => 'Enter your phone number or email to receive a verification code (OTP)';
  @override String get authSendResetCodeButton => 'Send OTP Code';
  @override String get authResetPasswordTitle => 'Create New Password';
  @override String get authNewPasswordLabel => 'New Password';
  @override String get authResetPasswordButton => 'Save New Password';
  @override String get authBackToLogin => 'Back to Sign In';
  @override String get authAccountNotVerifiedError => 'Your account is not verified. Please complete OTP verification first.';
  @override String get authInvalidCredentialsError => 'Invalid login credentials. Please check and try again.';
  @override String get authPhoneExistsError => 'Phone number is already registered. Please sign in instead.';
  @override String get authEmailExistsError => 'Email is already registered. Please use a different email.';
  @override String get authUsernameExistsError => 'Username is already taken. Please choose another.';
  @override String get authUserNotFoundError => 'User account not found with the provided details.';
  @override String get authInvalidPhoneError => 'Please enter a valid phone number.';
  @override String get authNetworkError => 'Unable to connect to the server. Please check your internet connection.';

  // Guest Access State
  @override String get guestTitle => 'Sign in to Your Account';
  @override String get guestSubtitle => 'Please log in or create an account to access this feature and view your records.';
  @override String get guestAction => 'Sign In or Register';
  @override String get guestChatsDesc => 'Chat directly with service providers, send messages and receive immediate responses.';
  @override String get guestRequestsDesc => 'Track your service bookings, manage escrow orders, and release payments safely.';
  @override String get guestSellDesc => 'Publish your professional services and start receiving job requests from nearby clients.';

  // 5. Profile Screen
  @override String get profileTitle => 'Profile';
  @override String get profileGuestTitle => 'Guest User';
  @override String get profileGuestSubtitle => 'Tap to sign in or create an account';
  @override String get profileSignInAction => 'Sign In';
  @override String get profileSignOutAction => 'Sign Out';
  @override String get profileWalletTitle => 'Pocket Fund (Wallet)';
  @override String get profileWalletSubtitle => 'Escrow protected balance, top-up & payments';
  @override String get profileNidaTitle => 'NIDA Verification & Guarantor';
  @override String get profileNidaSubtitle => 'Green Badge, Blue Tick, or invite code';
  @override String get profileLocationTitle => 'Location & Service Radius';
  @override String get profileLocationSubtitle => 'Configure travel distance and area';
  @override String get profileFavoritesTitle => 'Favorites';
  @override String get profileFavoritesSubtitle => 'Saved services and trusted providers';
  @override String get profilePrivacyTitle => 'Security & Privacy';
  @override String get profilePrivacySubtitle => 'Legal names kept private from public';
  @override String get profileHelpTitle => 'Help & Support';
  @override String get profileHelpSubtitle => 'FAQs, support & contact';
  @override String get profileLanguageTitle => 'App Language';

  // Badges
  @override String get badgeBlueTick => 'Blue Tick Verified';
  @override String get badgeGreenBadge => 'Green Badge (NIDA)';
  @override String get badgeUnverified => 'Unverified';

  // 6. Sell & Manage Services Screen
  @override String get sellMyServicesTitle => 'My Services';
  @override String get sellAddService => 'Add Service';
  @override String get sellTabActive => 'Active';
  @override String get sellTabPending => 'Pending';
  @override String get sellTabInactive => 'Inactive';
  @override String get sellNoServicesTitle => 'No services found';
  @override String get sellNoServicesSubtitle => 'Publish your first service to start receiving customer bookings.';
  @override String get sellPostNewTitle => 'Publish New Service';
  @override String get sellServiceTitleLabel => 'Service Title *';
  @override String get sellServiceTitleHint => 'e.g. Executive Haircut & Styling';
  @override String get sellDescLabel => 'Description';
  @override String get sellDescHint => 'Describe what is included in your service...';
  @override String get sellCategoryLabel => 'Service Category';
  @override String get sellPriceLabel => 'Starting Price (TSh) *';
  @override String get sellPriceHint => 'e.g. 25000';
  @override String get sellPhoneLabel => 'Contact Phone (Optional)';
  @override String get sellPrivacyLockTitle => 'Privacy Lock (Hide Contacts)';
  @override String get sellPrivacyLockSubtitle => 'Customers will only see your contacts after booking request is accepted';
  @override String get sellPublishButton => 'Publish Service';
  @override String get sellPublishSuccess => 'Congratulations! Service successfully published.';
  @override String get sellPublishError => 'Failed to publish service. Make sure you are registered as a Seller.';
  @override String get sellContactsLockedBadge => 'Contacts Locked';

  // 7. Requests & Bookings Screen
  @override String get requestsTitle => 'Requests & Bookings';
  @override String get requestsTabIncoming => 'Incoming (Seller)';
  @override String get requestsTabOutgoing => 'Outgoing (Buyer)';
  @override String get requestsNoRequests => 'No orders or bookings found';
  @override String get requestsAcceptButton => 'Accept & Unveil Contacts';
  @override String get requestsRejectButton => 'Reject Order';
  @override String get requestsReleaseButton => 'Satisfied? Release Escrow';
  @override String get requestsAcceptedNotice => 'Order accepted! Seller contact details are now visible.';
  @override String get requestsReleasedNotice => 'Payment successfully released from escrow to seller!';
  @override String get requestsRejectedNotice => 'Order rejected. Escrow amount refunded to buyer.';
  @override String get requestsEscrowSecured => 'Escrow Secured';

  // 8. Pocket Fund (Wallet) Screen
  @override String get walletTitle => 'Pocket Fund (Wallet)';
  @override String get walletAvailableBalance => 'AVAILABLE BALANCE';
  @override String get walletLockedEscrow => 'LOCKED IN ESCROW';
  @override String get walletDepositAction => 'Top Up';
  @override String get walletWithdrawAction => 'Withdraw';
  @override String get walletHistoryTitle => 'Recent Wallet & Escrow Activity';
  @override String get walletNoTransactions => 'No recent transactions on your wallet.';
  @override String get walletTopUpSheetTitle => 'Top Up Pocket Fund';
  @override String get walletTopUpPhoneHint => 'M-Pesa / Tigo / Airtel Phone';
  @override String get walletTopUpAmountHint => 'Enter amount (TSh):';
  @override String get walletWithdrawSheetTitle => 'Withdraw Funds';
  @override String get walletWithdrawSuccess => 'Funds withdrawn successfully!';
  @override String get walletDepositSuccess => 'Funds added successfully to Pocket Fund!';
  @override String get walletEscrowPolicy => 'Buyer & Seller Protection Policy:\nYour funds are securely held in Escrow. The seller does not receive payment until you are 100% satisfied and release funds.';
  @override String get walletSelectPaymentNetwork => 'Select payment network:';
  @override String get walletWithdrawPhonePrompt => 'Recipient phone number:';
  @override String get walletWithdrawAmountPrompt => 'Enter withdrawal amount (TSh):';
  @override String get walletWithdrawFailed => 'Withdrawal failed. Please check your balance and try again.';
  @override String get walletDepositFailed => 'Top up failed. Please try again.';
  @override String get walletConfirmWithdraw => 'Confirm Withdrawal';

  // 9. NIDA Verification Screen
  @override String get nidaScreenTitle => 'Identity Verification';
  @override String get nidaHeaderTitle => 'Trust & Verification';
  @override String get nidaHeaderSubtitle => 'Obtain official Green Badge (NIDA) or Blue Tick via guarantor to build trust with buyers.';
  @override String get nidaNumberLabel => '20-Digit NIDA Number';
  @override String get nidaFirstNameLabel => 'First Official Legal Name';
  @override String get nidaLastNameLabel => 'Last Official Legal Name';
  @override String get nidaGuarantorCodeLabel => 'Guarantor / Inviter Code';
  @override String get nidaUploadIdPhoto => 'Upload NIDA ID Photo';
  @override String get nidaUploadSelfie => 'Upload Selfie with ID';
  @override String get nidaSubmitButton => 'Submit for Verification';
  @override String get nidaSuccessGreen => 'Congratulations! Green Badge verified.';
  @override String get nidaSuccessBlue => 'Congratulations! Blue Tick granted!';

  // 10. Booking Request Screen
  @override String get bookingTitle => 'Request Service';
  @override String get bookingSummaryTitle => 'Booking Summary';
  @override String get bookingEscrowGuarantee => '100% Escrow Protection: Funds remain securely locked in escrow until you inspect and approve the job.';
  @override String get bookingSelectDate => 'Select Date & Time';
  @override String get bookingSelectTime => 'Time';
  @override String get bookingNotesLabel => 'Special Instructions / Notes';
  @override String get bookingNotesHint => 'Tell provider about location or specifics...';
  @override String get bookingConfirmButton => 'Send Request';
  @override String get bookingSuccessTitle => 'Request Sent!';
  @override String get bookingSuccessSubtitle => 'Your payment is safely held in escrow. The provider will review your request shortly.';

  // 11. Chats Screen
  @override String get chatsTitle => 'Messages & Inquiries';
  @override String get chatsNoMessages => 'No messages yet';
  @override String get chatsTypePlaceholder => 'Type a message...';
  @override String get chatsOnline => 'Online';
  @override String get chatsSearchHint => 'Search chats...';
  @override String get chatsTabAll => 'All';
  @override String get chatsTabBookings => 'Bookings';
  @override String get chatsTabRequests => 'Requests';

  // 12. Notifications Screen
  @override String get notificationsTitle => 'Notifications';
  @override String get notificationsNoItems => 'No notifications yet';
  @override String get notificationsMarkAllRead => 'Mark all as read';

  // 13. Search & Filter Screen
  @override String get searchFilterTitle => 'Search Services';
  @override String get searchFilterRadius => 'Distance Radius';
  @override String get searchFilterRating => 'Minimum Rating';
  @override String get searchFilterApply => 'Apply Filters';
  @override String get searchFilterReset => 'Reset';
  @override String get searchFilterBy => 'Filter by';
  @override String get searchFilterAll => 'All';
  @override String get searchFilterAvailableNow => 'Available Now';
  @override String get searchFilterVerifiedOnly => 'Verified Only';
  @override String get searchFilterDistance => 'Distance';
  @override String get searchFilterAnyDistance => 'Any distance';
  @override String get searchFilterPriceRange => 'Price Range';
  @override String get searchFilterAnyPrice => 'Any price';
  @override String get searchFilterAnyRating => 'Any rating';
  @override String get searchFilterCategory => 'Category';
  @override String get searchFilterAvailability => 'Availability';
  @override String get searchFilterAnyTime => 'Any time';
  @override String get searchFilterServiceType => 'Service Type';
  @override String get searchFilterServiceTypeBoth => 'Customer comes / I travel / Both';
  @override String get searchFilterSortBy => 'Sort By';
  @override String get searchFilterNearestFirst => 'Nearest first';

  // 14. Location & Radius Screen
  @override String get locationRadiusTitle => 'Service Radius';
  @override String get locationRadiusSubtitle => 'Set how far you are willing to travel to provide or receive services.';
  @override String get locationRadiusKm => 'km radius';
  @override String get locationSaveButton => 'Save Radius';

  // Startup Permissions Modal
  @override String get permWelcomeTitle => 'Get Started with NearByServices';
  @override String get permWelcomeSubtitle => 'To discover top services around you and receive instant booking alerts, please allow the following permissions:';
  @override String get permLocationTitle => 'Location Access';
  @override String get permLocationDesc => 'Used to detect your area, calculate accurate distances, and show trusted local service providers right near you.';
  @override String get permNotificationTitle => 'Notifications';
  @override String get permNotificationDesc => 'Stay updated with live job status, new chat messages, and escrow release notifications.';
  @override String get permAllowButton => 'Allow & Continue';
  @override String get permMaybeLaterButton => 'Maybe Later';

  // 15. Favorites Screen
  @override String get favoritesTitle => 'Favorite Services';
  @override String get favoritesNoItems => 'No favorites saved yet';

  // 16. Service Details & Seller Profile Screen
  @override String get detailsAboutService => 'About This Service';
  @override String get detailsPricingOptions => 'Packages & Durations';
  @override String get detailsCustomerReviews => 'Customer Reviews';
  @override String get detailsBookNow => 'Request Service';
  @override String get detailsCallNow => 'Call Provider';
  @override String get detailsWhatsApp => 'Chat WhatsApp';
  @override String get detailsSellerProfile => 'Provider Profile';
  @override String get detailsExperience => 'Experience';
  @override String get detailsTotalOrders => 'Completed Orders';
  @override String get detailsVerifiedProvider => 'Verified Provider';
  @override String get detailsPerSession => 'per session';
  @override String get detailsProfessional => 'Professional';
  @override String get detailsCleanSafe => 'Clean & Safe';
  @override String get detailsAvailableNow => 'Available Now';
  @override String get detailsMemberSince => 'Member since';
  @override String get detailsViewProfile => 'View Profile';
  @override String get detailsTabOverview => 'Overview';
  @override String get detailsTabPortfolio => 'Portfolio';
  @override String get detailsTabReviews => 'Reviews';
  @override String get detailsTabAvailability => 'Availability';
  @override String get detailsTabLocation => 'Location';
  @override String get detailsServiceDurationPrice => 'Service Duration & Price';
  @override String get detailsChat => 'Chat';
  @override String get detailsLocked => 'Locked';
  @override String get detailsContactLockedAlert => 'Provider locked direct contacts. Please submit a booking request first.';
  @override String get nidaPrivacyGuarantee => 'Official Privacy Guarantee: Your legal NIDA names and number remain 100% PRIVATE. Buyers only see your Stage Name.';
  @override String get nidaOption1Title => '1. NIDA Number (Green Badge)';
  @override String get nidaOption1Subtitle => 'Enter your 20-digit NIDA number to get a verified green badge.';
  @override String get nidaOption2Title => '2. NIDA ID Card + Selfie (Blue Tick)';
  @override String get nidaOption2Subtitle => 'Get an official Blue Tick by uploading your NIDA ID photo and a selfie holding your ID.';
  @override String get nidaOption3Title => '3. Guarantor Invitation (Auto Blue Tick)';
  @override String get nidaOption3Subtitle => 'No physical ID card? Invited by a verified user? Enter their invitation code to get instant Blue Tick endorsement.';
  @override String get nidaIdPhotoCard => 'NIDA ID Card Photo';
  @override String get nidaSelfieCard => 'Selfie with ID';
  @override String get nidaUploaded => 'Uploaded!';
  @override String get nidaGuarantorHint => 'Enter Guarantor Invitation Code (e.g. NEARBY-9921)';
  @override String get nidaFailedGreen => 'NIDA verification failed. Ensure your 20-digit number is correct and not previously used.';
  @override String get nidaFailedBlue => 'Blue Tick verification failed. Verify details or ensure guarantor code is valid.';
}

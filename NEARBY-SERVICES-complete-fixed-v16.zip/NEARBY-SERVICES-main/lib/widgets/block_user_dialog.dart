import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/block_service.dart';

/// Confirm dialogs for blocking / unblocking a user.
class BlockUserDialog {
  static bool get _en => AppStrings.isEnglish;

  /// Asks why, then blocks. Returns true when the user was blocked.
  /// Pass [reason] to skip the question (e.g. when it was already given in a report).
  static Future<bool> confirmBlock(BuildContext context, {required int userId, required String name, String? reason, String? details}) async {
    String? chosen = reason;
    String note = details ?? '';
    if (chosen == null) {
      final result = await showDialog<Map<String, String>>(
        context: context,
        builder: (_) => _BlockReasonDialog(name: name),
      );
      if (result == null) return false;
      chosen = result['reason'];
      note = result['details'] ?? '';
    }
    await BlockService.block(userId, name, reason: chosen, details: note);
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(_en ? '$name blocked' : '$name amezuiwa')),
      );
    }
    return true;
  }

  /// Returns true when the user was unblocked.
  static Future<bool> confirmUnblock(BuildContext context, {required int userId, required String name}) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(_en ? 'Unblock $name?' : 'Mfungulie $name?', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
        content: Text(
          _en ? 'They will be able to message you and see your services again.' : 'Ataweza kukutumia ujumbe na kuona huduma zako tena.',
          style: const TextStyle(fontSize: 13, height: 1.45, color: AppColors.textSecondary),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(_en ? 'Cancel' : 'Ghairi')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(_en ? 'Unblock' : 'Fungulia', style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
    if (ok != true) return false;
    await BlockService.unblock(userId);
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(_en ? '$name unblocked' : '$name amefunguliwa')),
      );
    }
    return true;
  }
}

class _BlockReasonDialog extends StatefulWidget {
  final String name;
  const _BlockReasonDialog({required this.name});

  @override
  State<_BlockReasonDialog> createState() => _BlockReasonDialogState();
}

class _BlockReasonDialogState extends State<_BlockReasonDialog> {
  final _note = TextEditingController();
  String? _reason;
  bool _missing = false;

  bool get _en => AppStrings.isEnglish;

  @override
  void dispose() {
    _note.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final name = widget.name;
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Text(_en ? 'Block $name?' : 'Mzuie $name?', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _en
                  ? "They won't be able to message you, and you won't see their services or chats. You can unblock them any time from Profile > Blocked Users."
                  : 'Hataweza kukutumia ujumbe, na hutaona huduma wala mazungumzo yake. Unaweza kumfungulia wakati wowote kupitia Wasifu > Watumiaji Walizuiwa.',
              style: const TextStyle(fontSize: 13, height: 1.45, color: AppColors.textSecondary),
            ),
            const SizedBox(height: 14),
            Text(
              _en ? 'Why are you blocking them?' : 'Kwa nini unamzuia?',
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 6,
              children: [
                for (final c in BlockReasons.codes)
                  ChoiceChip(
                    label: Text(BlockReasons.label(c, en: _en), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                    selected: _reason == c,
                    selectedColor: AppColors.danger.withValues(alpha: 0.15),
                    onSelected: (_) => setState(() {
                      _reason = c;
                      _missing = false;
                    }),
                  ),
              ],
            ),
            if (_missing)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(
                  _en ? 'Please choose a reason.' : 'Tafadhali chagua sababu.',
                  style: const TextStyle(fontSize: 12, color: AppColors.danger, fontWeight: FontWeight.w600),
                ),
              ),
            const SizedBox(height: 12),
            TextField(
              controller: _note,
              maxLines: 2,
              maxLength: 300,
              decoration: InputDecoration(
                hintText: _en ? 'Add a note (optional)' : 'Ongeza maelezo (si lazima)',
                filled: true,
                fillColor: AppColors.background,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: Text(_en ? 'Cancel' : 'Ghairi')),
        TextButton(
          onPressed: () {
            if (_reason == null) {
              setState(() => _missing = true);
              return;
            }
            Navigator.pop(context, {'reason': _reason!, 'details': _note.text.trim()});
          },
          child: Text(_en ? 'Block' : 'Zuia', style: const TextStyle(color: AppColors.danger, fontWeight: FontWeight.w800)),
        ),
      ],
    );
  }
}

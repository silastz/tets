import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/block_service.dart';

/// Confirm dialogs for blocking / unblocking a user.
class BlockUserDialog {
  static bool get _en => AppStrings.isEnglish;

  /// Returns true when the user was blocked.
  static Future<bool> confirmBlock(BuildContext context, {required int userId, required String name}) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(_en ? 'Block $name?' : 'Mzuie $name?', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
        content: Text(
          _en
              ? "They won't be able to message you, and you won't see their services or chats. You can unblock them any time from Profile > Blocked Users."
              : 'Hataweza kukutumia ujumbe, na hutaona huduma wala mazungumzo yake. Unaweza kumfungulia wakati wowote kupitia Wasifu > Watumiaji Walizuiwa.',
          style: const TextStyle(fontSize: 13, height: 1.45, color: AppColors.textSecondary),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(_en ? 'Cancel' : 'Ghairi')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(_en ? 'Block' : 'Zuia', style: const TextStyle(color: AppColors.danger, fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
    if (ok != true) return false;
    await BlockService.block(userId, name);
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(_en ? '$name blocked' : '$name amezuiwa')),
      );
    }
    return true;
  }

  /// Returns true when the user was unblocked.
  static Future<bool> confirmUnblock(BuildContext context, {required int userId, required String name}) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(_en ? 'Unblock $name?' : 'Mfungulie $name?', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
        content: Text(
          _en ? 'They will be able to message you and see your services again.' : 'Ataweza kukutumia ujumbe na kuona huduma zako tena.',
          style: const TextStyle(fontSize: 13, height: 1.45, color: AppColors.textSecondary),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(_en ? 'Cancel' : 'Ghairi')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(_en ? 'Unblock' : 'Fungulia', style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
    if (ok != true) return false;
    await BlockService.unblock(userId);
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(_en ? '$name unblocked' : '$name amefunguliwa')),
      );
    }
    return true;
  }
}

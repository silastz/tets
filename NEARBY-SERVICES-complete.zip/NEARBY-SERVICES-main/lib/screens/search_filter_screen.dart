import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/service_filters.dart';
import '../services/location_service.dart';
import '../widgets/location_picker_sheet.dart';
import 'category_detail_screen.dart';

class SearchFilterScreen extends StatefulWidget {
  final VoidCallback? onBackToHome;

  const SearchFilterScreen({super.key, this.onBackToHome});

  @override
  State<SearchFilterScreen> createState() => _SearchFilterScreenState();
}

class _SearchFilterScreenState extends State<SearchFilterScreen> {
  final TextEditingController _searchController = TextEditingController();

  static const List<double?> _distanceOptions = [null, 2, 5, 10, 20, 50, 100];
  static const List<double?> _ratingOptions = [null, 4.5, 4.0, 3.5, 3.0];

  // (min, max) in TSh; null = open ended.
  static const List<(int?, int?)> _priceOptions = [
    (null, null),
    (null, 20000),
    (20000, 50000),
    (50000, 100000),
    (100000, null),
  ];

  // Category api keys match the home screen / API ('Barber', 'Electrical', ...).
  static const List<String> _categoryKeys = [
    'All', 'Massage', 'Beauty', 'Barber', 'Cleaning', 'Plumbing',
    'Electrical', 'Mechanic', 'Photography', 'Repair', 'General',
  ];

  String _selectedQuickFilter = 'All'; // 'All', 'Available Now', 'Verified Only'
  double? _distanceKm; // null = any distance
  int _priceIdx = 0;
  double? _minRating;
  String _category = 'All';
  AvailabilityFilter _availability = AvailabilityFilter.any;
  ServiceTypeFilter _serviceType = ServiceTypeFilter.both;
  SortOption _sort = SortOption.nearest;

  bool get _en => AppStrings.isEnglish;
  String _t(String en, String sw) => _en ? en : sw;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  String _categoryLabel(String key) {
    switch (key) {
      case 'All': return AppStrings.searchFilterAll;
      case 'Massage': return AppStrings.catMassage;
      case 'Beauty': return AppStrings.catBeauty;
      case 'Barber': return AppStrings.catBarber;
      case 'Cleaning': return AppStrings.catCleaning;
      case 'Plumbing': return AppStrings.catPlumbing;
      case 'Electrical': return AppStrings.catElectrical;
      case 'Mechanic': return AppStrings.catMechanic;
      case 'Photography': return AppStrings.catPhotography;
      case 'Repair': return AppStrings.catRepair;
      default: return AppStrings.catGeneral;
    }
  }

  String _distanceLabel(double? km) => km == null ? AppStrings.searchFilterAnyDistance : _t('Within ${km.round()} km', 'Ndani ya km ${km.round()}');

  String _priceLabel((int?, int?) r) {
    String f(int v) => v.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},');
    if (r.$1 == null && r.$2 == null) return AppStrings.searchFilterAnyPrice;
    if (r.$1 == null) return _t('Under TSh ${f(r.$2!)}', 'Chini ya TSh ${f(r.$2!)}');
    if (r.$2 == null) return _t('Above TSh ${f(r.$1!)}', 'Zaidi ya TSh ${f(r.$1!)}');
    return 'TSh ${f(r.$1!)} - ${f(r.$2!)}';
  }

  String _ratingLabel(double? r) => r == null ? AppStrings.searchFilterAnyRating : _t('${r.toStringAsFixed(1)} ★ & above', '${r.toStringAsFixed(1)} ★ na zaidi');

  AvailabilityFilter get _effectiveAvailability =>
      _selectedQuickFilter == 'Available Now' ? AvailabilityFilter.now : _availability;

  String _availabilityLabel(AvailabilityFilter a) {
    switch (a) {
      case AvailabilityFilter.any: return AppStrings.searchFilterAnyTime;
      case AvailabilityFilter.now: return AppStrings.searchFilterAvailableNow;
      case AvailabilityFilter.today: return _t('Available Today', 'Anapatikana Leo');
      case AvailabilityFilter.tomorrow: return _t('Available Tomorrow', 'Anapatikana Kesho');
      case AvailabilityFilter.weekend: return _t('Available This Weekend', 'Anapatikana Wikendi');
    }
  }

  String _serviceTypeLabel(ServiceTypeFilter t) {
    switch (t) {
      case ServiceTypeFilter.both: return _t('Both', 'Zote mbili');
      case ServiceTypeFilter.customerComes: return _t('Customer comes', 'Mteja anakuja');
      case ServiceTypeFilter.iTravel: return _t('Provider travels', 'Mtoa huduma anasafiri');
    }
  }

  String _sortLabel(SortOption o) {
    switch (o) {
      case SortOption.nearest: return AppStrings.searchFilterNearestFirst;
      case SortOption.lowestPrice: return _t('Lowest price', 'Bei ya chini');
      case SortOption.highestRating: return _t('Highest rating', 'Ukadiriaji wa juu');
      case SortOption.mostPopular: return _t('Most popular', 'Maarufu zaidi');
    }
  }

  void _reset() {
    setState(() {
      _searchController.clear();
      _selectedQuickFilter = 'All';
      _distanceKm = null;
      _priceIdx = 0;
      _minRating = null;
      _category = 'All';
      _availability = AvailabilityFilter.any;
      _serviceType = ServiceTypeFilter.both;
      _sort = SortOption.nearest;
    });
  }

  ServiceFilters _buildFilters() {
    final price = _priceOptions[_priceIdx];
    return ServiceFilters(
      maxDistanceKm: _distanceKm,
      minPrice: price.$1,
      maxPrice: price.$2,
      minRating: _minRating,
      availability: _effectiveAvailability,
      serviceType: _serviceType,
      sort: _sort,
      verifiedOnly: _selectedQuickFilter == 'Verified Only',
    );
  }

  void _applyAndSearch() {
    final query = _searchController.text.trim();
    final isAll = _category == 'All';
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CategoryDetailScreen(
          categoryTitle: isAll ? 'All' : _categoryLabel(_category),
          categoryApiKey: isAll ? null : _category,
          searchQuery: query.isNotEmpty ? query : null,
          filters: _buildFilters(),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppLanguage>(
      valueListenable: AppStrings.currentLanguage,
      builder: (context, _, _) {
        return Scaffold(
          backgroundColor: AppColors.background,
          appBar: AppBar(
            backgroundColor: AppColors.surface,
            elevation: 0,
        leading: (widget.onBackToHome != null || Navigator.canPop(context))
            ? IconButton(
                icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
                onPressed: () {
                  if (widget.onBackToHome != null) {
                    widget.onBackToHome!();
                  } else if (Navigator.canPop(context)) {
                    Navigator.pop(context);
                  }
                },
              )
            : null,
        title: Text(
          AppStrings.searchFilterTitle,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
          ),
        ),
        actions: [
          TextButton(
            onPressed: _reset,
            child: Text(
              AppStrings.searchFilterReset,
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.primary),
            ),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.border, height: 1),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Search Input
            Container(
              height: 48,
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(
                children: [
                  const Icon(Icons.search_rounded, color: AppColors.textMuted, size: 20),
                  const SizedBox(width: 10),
                  Expanded(
                    child: TextField(
                      controller: _searchController,
                      textInputAction: TextInputAction.search,
                      onSubmitted: (_) => _applyAndSearch(),
                      decoration: InputDecoration(
                        hintText: AppStrings.homeSearchPlaceholder,
                        hintStyle: const TextStyle(
                          fontSize: 13,
                          color: AppColors.textMuted,
                        ),
                        border: InputBorder.none,
                        isDense: true,
                      ),
                    ),
                  ),
                  if (_searchController.text.isNotEmpty)
                    IconButton(
                      icon: const Icon(Icons.clear, size: 16, color: AppColors.textMuted),
                      onPressed: () => setState(() => _searchController.clear()),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 12),

            // Location and Radius pills
            Row(
              children: [
                Expanded(
                  flex: 3,
                  child: ValueListenableBuilder<String>(
                    valueListenable: LocationService.activeLocationNotifier,
                    builder: (context, activeCity, _) {
                      return InkWell(
                        onTap: () => LocationPickerSheet.show(context),
                        borderRadius: BorderRadius.circular(10),
                        child: Container(
                          height: 40,
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          decoration: BoxDecoration(
                            color: AppColors.surface,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: AppColors.border),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.location_on_rounded, size: 16, color: AppColors.primary),
                              const SizedBox(width: 6),
                              Expanded(
                                child: Text(
                                  activeCity,
                                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              const Icon(Icons.keyboard_arrow_down_rounded, size: 16, color: AppColors.textSecondary),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  flex: 2,
                  child: InkWell(
                    onTap: _showTopRadiusPicker,
                    borderRadius: BorderRadius.circular(10),
                    child: Container(
                      height: 40,
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      decoration: BoxDecoration(
                        color: AppColors.surface,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: AppColors.border),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            _distanceKm == null ? _t('Any', 'Yoyote') : '${_distanceKm!.round()} km',
                            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                          ),
                          const Icon(Icons.keyboard_arrow_down_rounded, size: 16, color: AppColors.textSecondary),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),

            // Quick Filters (All, Available Now, Verified Only)
            Row(
              children: [
                {'key': 'All', 'label': AppStrings.searchFilterAll},
                {'key': 'Available Now', 'label': AppStrings.searchFilterAvailableNow},
                {'key': 'Verified Only', 'label': AppStrings.searchFilterVerifiedOnly},
              ].map((item) {
                final isSelected = _selectedQuickFilter == item['key'];
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(
                      item['label']!,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: isSelected ? Colors.white : AppColors.slateMuted,
                      ),
                    ),
                    selected: isSelected,
                    selectedColor: AppColors.primary,
                    backgroundColor: AppColors.surface,
                    side: BorderSide(
                      color: isSelected ? AppColors.primary : AppColors.border,
                    ),
                    onSelected: (val) {
                      if (!val) return;
                      setState(() {
                        _selectedQuickFilter = item['key']!;
                        if (_selectedQuickFilter == 'Available Now') {
                          _availability = AvailabilityFilter.now;
                        } else if (_availability == AvailabilityFilter.now) {
                          _availability = AvailabilityFilter.any;
                        }
                      });
                    },
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),

            Text(
              AppStrings.searchFilterBy,
              style: const TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w800,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 10),

            // Filter item list as designed in Screen 2
            Container(
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                children: [
                  _buildFilterRow(
                    icon: Icons.near_me_outlined,
                    title: AppStrings.searchFilterDistance,
                    value: _distanceLabel(_distanceKm),
                    onTap: _showDistancePicker,
                  ),
                  _buildDivider(),
                  _buildFilterRow(
                    icon: Icons.payments_outlined,
                    title: AppStrings.searchFilterPriceRange,
                    value: _priceLabel(_priceOptions[_priceIdx]),
                    onTap: _showPriceRangePicker,
                  ),
                  _buildDivider(),
                  _buildFilterRow(
                    icon: Icons.star_outline_rounded,
                    title: AppStrings.searchFilterRating,
                    value: _ratingLabel(_minRating),
                    onTap: _showRatingPicker,
                  ),
                  _buildDivider(),
                  _buildFilterRow(
                    icon: Icons.category_outlined,
                    title: AppStrings.searchFilterCategory,
                    value: _categoryLabel(_category),
                    onTap: () {
                      _showCategoryPicker();
                    },
                  ),
                  _buildDivider(),
                  _buildFilterRow(
                    icon: Icons.access_time_rounded,
                    title: AppStrings.searchFilterAvailability,
                    value: _availabilityLabel(_effectiveAvailability),
                    onTap: _showAvailabilityPicker,
                  ),
                  _buildDivider(),
                  _buildFilterRow(
                    icon: Icons.directions_car_outlined,
                    title: AppStrings.searchFilterServiceType,
                    value: _serviceTypeLabel(_serviceType),
                    onTap: _showServiceTypePicker,
                  ),
                  _buildDivider(),
                  _buildFilterRow(
                    icon: Icons.sort_rounded,
                    title: AppStrings.searchFilterSortBy,
                    value: _sortLabel(_sort),
                    onTap: _showSortByPicker,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 28),

            // Apply Filters Sticky Button
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: _applyAndSearch,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 0,
                ),
                child: Text(
                  AppStrings.searchFilterApply,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
      },
    );
  }

  Widget _buildFilterRow({
    required IconData icon,
    required String title,
    required String value,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Icon(icon, size: 20, color: AppColors.textSecondary),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    value,
                    style: const TextStyle(
                      fontSize: 11,
                      color: AppColors.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded, size: 18, color: AppColors.textMuted),
          ],
        ),
      ),
    );
  }

  Widget _buildDivider() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: 1,
      color: AppColors.borderLight,
    );
  }

  void _showTopRadiusPicker() => _showDistancePicker(title: AppStrings.searchFilterRadius);

  void _showDistancePicker({String? title}) {
    _pick<double?>(
      title: title ?? AppStrings.searchFilterDistance,
      values: _distanceOptions,
      labelOf: _distanceLabel,
      current: _distanceKm,
      onSelect: (v) => setState(() => _distanceKm = v),
    );
  }

  void _showPriceRangePicker() {
    _pick<int>(
      title: AppStrings.searchFilterPriceRange,
      values: List.generate(_priceOptions.length, (i) => i),
      labelOf: (i) => _priceLabel(_priceOptions[i]),
      current: _priceIdx,
      onSelect: (v) => setState(() => _priceIdx = v),
    );
  }

  void _showRatingPicker() {
    _pick<double?>(
      title: AppStrings.searchFilterRating,
      values: _ratingOptions,
      labelOf: _ratingLabel,
      current: _minRating,
      onSelect: (v) => setState(() => _minRating = v),
    );
  }

  void _showAvailabilityPicker() {
    _pick<AvailabilityFilter>(
      title: AppStrings.searchFilterAvailability,
      values: AvailabilityFilter.values,
      labelOf: _availabilityLabel,
      current: _effectiveAvailability,
      onSelect: (v) => setState(() {
        _availability = v;
        // Keep the quick chip in sync with the dropdown.
        if (v == AvailabilityFilter.now) {
          _selectedQuickFilter = 'Available Now';
        } else if (_selectedQuickFilter == 'Available Now') {
          _selectedQuickFilter = 'All';
        }
      }),
    );
  }

  void _showServiceTypePicker() {
    _pick<ServiceTypeFilter>(
      title: AppStrings.searchFilterServiceType,
      values: ServiceTypeFilter.values,
      labelOf: _serviceTypeLabel,
      current: _serviceType,
      onSelect: (v) => setState(() => _serviceType = v),
    );
  }

  void _showSortByPicker() {
    _pick<SortOption>(
      title: AppStrings.searchFilterSortBy,
      values: SortOption.values,
      labelOf: _sortLabel,
      current: _sort,
      onSelect: (v) => setState(() => _sort = v),
    );
  }

  void _showCategoryPicker() {
    _pick<String>(
      title: AppStrings.homeCategoriesTitle,
      values: _categoryKeys,
      labelOf: _categoryLabel,
      current: _category,
      onSelect: (v) => setState(() => _category = v),
    );
  }

  void _pick<T>({
    required String title,
    required List<T> values,
    required String Function(T) labelOf,
    required T current,
    required ValueChanged<T> onSelect,
  }) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.7),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Text(
                  title,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
                ),
              ),
              const Divider(height: 1, color: AppColors.border),
              Flexible(
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: values.length,
                  itemBuilder: (ctx, idx) {
                    final v = values[idx];
                    final isSelected = v == current;
                    return ListTile(
                      title: Text(labelOf(v), style: TextStyle(fontWeight: isSelected ? FontWeight.bold : FontWeight.normal)),
                      trailing: isSelected ? const Icon(Icons.check, color: AppColors.primary) : null,
                      onTap: () {
                        onSelect(v);
                        Navigator.pop(ctx);
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

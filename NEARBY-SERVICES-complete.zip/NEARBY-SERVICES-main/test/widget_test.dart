import 'package:flutter_test/flutter_test.dart';
import 'package:jamiiapp/main.dart';

void main() {
  testWidgets('NearbyServicesApp smoke test', (WidgetTester tester) async {
    await tester.pumpWidget(const NearbyServicesApp());
    // "Nearby Services" appears in top header and section title
    expect(find.text('Nearby Services'), findsNWidgets(2));
    expect(find.text('Dar es Salaam'), findsOneWidget);
    expect(find.text('What service do you need?'), findsOneWidget);
    expect(find.text('Near you • 5 km'), findsOneWidget);
    expect(find.text('Relax & Feel Better'), findsOneWidget);
    expect(find.text('Categories'), findsOneWidget);
    expect(find.text('Home'), findsOneWidget);
  });
}

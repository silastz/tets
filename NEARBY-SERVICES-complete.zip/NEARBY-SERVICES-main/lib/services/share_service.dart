import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../widgets/app_ui.dart';
import 'deep_link_service.dart';

/// Shares a service through WhatsApp, the Messages app, or any other app.
/// Only public details go out (title, price, category, stage name): never the
/// provider's phone number, socials or legal name.
class ShareService {
  /// Add the Play Store / website link here once published; it is appended to
  /// every shared message when not empty.
  static const String appLink = '';

  static String message({
    required String title,
    required String priceText,
    required String providerName,
    String? category,
    String? serviceId,
  }) {
    final en = AppStrings.isEnglish;
    final cat = (category ?? '').trim();
    final lines = <String>[
      title,
      [priceText, if (cat.isNotEmpty) cat].where((e) => e.trim().isNotEmpty).join(' - '),
      if (providerName.trim().isNotEmpty) (en ? 'By $providerName' : 'Na $providerName'),
      en ? 'Find and book it on Nearby Services.' : 'Ipate na uioda kupitia Nearby Services.',
      if (serviceId != null && serviceId.isNotEmpty) DeepLinkService.serviceLink(serviceId) else if (appLink.isNotEmpty) appLink,
    ];
    return lines.where((e) => e.trim().isNotEmpty).join('\n');
  }

  /// Bottom sheet with WhatsApp, Messages, More apps and Copy.
  static Future<void> showServiceSheet(
    BuildContext context, {
    required String title,
    required String priceText,
    required String providerName,
    String? category,
    String? serviceId,
  }) {
    final en = AppStrings.isEnglish;
    final text = message(title: title, priceText: priceText, providerName: providerName, category: category, serviceId: serviceId);
    final messenger = ScaffoldMessenger.of(context);

    void snack(String t, {bool error = false}) {
      messenger.showSnackBar(SnackBar(backgroundColor: error ? AppColors.danger : null, content: Text(t)));
    }

    Future<void> more() async {
      try {
        await Share.share(text, subject: title);
      } catch (_) {
        snack(en ? 'Could not open sharing' : 'Imeshindwa kufungua kushiriki', error: true);
      }
    }

    Future<void> viaScheme(Uri uri, String notFound) async {
      var ok = false;
      try {
        ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
      } catch (_) {}
      if (!ok) {
        snack(notFound);
        await more();
      }
    }

    return AppSheet.show<void>(
      context,
      title: en ? 'Share this service' : 'Shiriki huduma hii',
      subtitle: title,
      builder: (ctx) {
        Widget tile(IconData icon, String label, Future<void> Function() onTap) => ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(icon, color: AppColors.primary),
              title: Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
              onTap: () {
                Navigator.pop(ctx);
                onTap();
              },
            );
        return Column(
          children: [
            tile(Icons.chat_rounded, 'WhatsApp', () => viaScheme(
                  Uri.parse('whatsapp://send?text=${Uri.encodeComponent(text)}'),
                  en ? 'WhatsApp not found. Choose another app.' : 'WhatsApp haijapatikana. Chagua programu nyingine.',
                )),
            tile(Icons.sms_outlined, en ? 'Messages (SMS)' : 'Ujumbe (SMS)', () => viaScheme(
                  Uri.parse('sms:?body=${Uri.encodeComponent(text)}'),
                  en ? 'Messages app not found. Choose another app.' : 'Programu ya ujumbe haijapatikana. Chagua nyingine.',
                )),
            tile(Icons.share_rounded, en ? 'More apps' : 'Programu nyingine', more),
            tile(Icons.copy_rounded, en ? 'Copy text' : 'Nakili maandishi', () async {
              await Clipboard.setData(ClipboardData(text: text));
              snack(en ? 'Copied' : 'Imenakiliwa');
            }),
          ],
        );
      },
    );
  }
}

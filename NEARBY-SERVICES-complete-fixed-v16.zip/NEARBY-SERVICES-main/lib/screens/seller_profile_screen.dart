import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import '../services/block_service.dart';
import '../services/session_manager.dart';
import '../widgets/app_image.dart';
import '../widgets/boost_badge.dart';
import '../widgets/block_user_dialog.dart';
import '../widgets/call_options_sheet.dart';
import '../widgets/fullscreen_image_viewer.dart';
import '../widgets/login_modal.dart';
import '../widgets/provider_contact_card.dart';
import '../widgets/report_sheet.dart';
import '../widgets/sensitive_tag.dart';
import '../widgets/verification_badge.dart';
import '../widgets/video_player_screen.dart';
import 'booking_request_screen.dart';
import 'chat_thread_screen.dart';
import 'service_details_screen.dart';
import '../widgets/whatsapp_text.dart';

/// Provider profile: hero + trust strip, then Services / Portfolio / Reviews / About.
/// Every number and text on this page comes from the server; a fact the provider
/// has not shared is simply left out (nothing is invented).
class SellerProfileScreen extends StatefulWidget {
  final ServiceItem provider;

  const SellerProfileScreen({
    super.key,
    required this.provider,
  });

  @override
  State<SellerProfileScreen> createState() => _SellerProfileScreenState();
}

class _SellerProfileScreenState extends State<SellerProfileScreen> {
  static const double _heroHeight = 290;
  static const List<String> _dayKeys = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  static const List<String> _monthsEn = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  int _tab = 0;
  late Future<List<dynamic>?> _reviewsFuture;

  bool get _en => AppStrings.isEnglish;
  ServiceItem get _p => widget.provider;
  int? get _sellerId => _p.sellerId;
  bool get _isMine => SessionManager.isLoggedIn() && _sellerId != null && _sellerId == SessionManager.getUserIdValue();
  bool get _canModerate => _sellerId != null && _sellerId != 0 && !_isMine;

  String get _name => _p.stageName.isNotEmpty ? _p.stageName : _p.title;

  /// The provider's real services (same data Home / Category / Details show),
  /// always including the one the buyer came from.
  late final List<ServiceItem> _services = () {
    final mine = ApiService.knownServices.values
        .where((s) => s.id == _p.id || (_p.sellerId != null && s.sellerId == _p.sellerId))
        .toList();
    if (!mine.any((s) => s.id == _p.id)) mine.insert(0, _p);
    return mine;
  }();

  List<String> get _photos {
    final out = <String>[];
    for (final s in _services) {
      for (final u in s.imageUrls) {
        if (u.trim().isNotEmpty && !out.contains(u)) out.add(u);
      }
    }
    return out;
  }

  List<String> get _videos {
    final out = <String>[];
    for (final s in _services) {
      for (final u in s.videoUrls) {
        if (u.trim().isNotEmpty && !out.contains(u)) out.add(u);
      }
    }
    return out;
  }

  String? get _coverImage => _p.imageUrls.isNotEmpty ? _p.imageUrls.first : null;
  String? get _avatarImage => (_p.sellerAvatar ?? '').isNotEmpty ? _p.sellerAvatar : null;

  @override
  void initState() {
    super.initState();
    _loadReviews();
  }

  void _loadReviews() {
    final id = _sellerId;
    _reviewsFuture = (id == null || id == 0) ? Future.value(<dynamic>[]) : ApiService.fetchProviderReviews(id);
  }

  // ---------------------------------------------------------------- helpers

  String _monthYear(DateTime d) => '${_monthsEn[d.month - 1]} ${d.year}';

  String _dateText(DateTime d) => '${d.day} ${_monthsEn[d.month - 1]} ${d.year}';

  int? _minutes(String? hhmm) {
    if (hhmm == null) return null;
    final parts = hhmm.trim().split(':');
    if (parts.length < 2) return null;
    final h = int.tryParse(parts[0]), m = int.tryParse(parts[1]);
    if (h == null || m == null) return null;
    return h * 60 + m;
  }

  bool get _hasSchedule {
    final from = _minutes(_p.availableFrom), to = _minutes(_p.availableTo);
    return _p.availableDays.isNotEmpty || (from != null && to != null);
  }

  /// true = open now, false = closed now, null = no schedule to judge by.
  bool? get _openNow {
    if (_p.isOnline) return true;
    if (!_hasSchedule) return null;
    final now = DateTime.now();
    if (_p.availableDays.isNotEmpty && !_p.availableDays.contains(_dayKeys[now.weekday - 1])) return false;
    final from = _minutes(_p.availableFrom), to = _minutes(_p.availableTo);
    if (from == null || to == null) return true;
    final cur = now.hour * 60 + now.minute;
    return from <= to ? (cur >= from && cur <= to) : (cur >= from || cur <= to);
  }

  String _dayLabel(int i) {
    const sw = ['Jtt', 'Jne', 'Jtn', 'Alh', 'Ijm', 'Jmo', 'Jpi'];
    return _en ? _dayKeys[i] : sw[i];
  }

  String? get _modeLabel {
    switch (_p.serviceMode) {
      case 'customer_comes':
        return _en ? 'You visit the provider' : 'Unamtembelea mtoa huduma';
      case 'provider_travels':
        return _en ? 'Provider comes to you' : 'Mtoa huduma anakufuata';
      case 'both':
        return _en ? 'Visit them or they come to you' : 'Mnaweza kukutana popote';
      default:
        return null;
    }
  }

  Color get _ringColor {
    if (_p.hasBlueTick) return AppColors.primary;
    if (_p.hasGreenBadge) return AppColors.success;
    return Colors.white;
  }

  String get _initial => _name.trim().isEmpty ? '?' : _name.trim().substring(0, 1).toUpperCase();

  Future<void> _book(ServiceItem s) async {
    if (!SessionManager.isLoggedIn()) {
      final ok = await LoginModal.show(context);
      if (ok != true || !mounted) return;
    }
    if (!mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        // The chosen service itself, so the booking charges ITS price and id.
        builder: (_) => BookingRequestScreen(
          provider: s,
          serviceTitle: s.title,
          priceText: s.priceText,
          durationText: s.durationText,
        ),
      ),
    );
  }

  // ------------------------------------------------------------------ build

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      bottomNavigationBar: _isMine ? null : _actionBar(),
      body: CustomScrollView(
        slivers: [
          _hero(),
          SliverToBoxAdapter(child: _statsPanel()),
          SliverPersistentHeader(pinned: true, delegate: _PinnedTabs(_tabBar())),
          SliverToBoxAdapter(child: _tabBody()),
          const SliverToBoxAdapter(child: SizedBox(height: 28)),
        ],
      ),
    );
  }

  // ------------------------------------------------------------------- hero

  Widget _roundButton({required IconData icon, required VoidCallback onTap}) {
    return Padding(
      padding: const EdgeInsets.all(6),
      child: Material(
        color: Colors.black.withValues(alpha: 0.38),
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: Icon(icon, color: Colors.white, size: 20),
        ),
      ),
    );
  }

  Widget _hero() {
    final top = MediaQuery.of(context).padding.top;
    final minH = kToolbarHeight + top;
    final maxH = _heroHeight + top;
    return SliverAppBar(
      pinned: true,
      expandedHeight: _heroHeight,
      backgroundColor: AppColors.slateDark,
      elevation: 0,
      automaticallyImplyLeading: false,
      leadingWidth: 56,
      leading: _roundButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.pop(context)),
      actions: [if (_canModerate) _moderationMenu(), const SizedBox(width: 4)],
      flexibleSpace: LayoutBuilder(
        builder: (context, c) {
          final t = ((c.maxHeight - minH) / (maxH - minH)).clamp(0.0, 1.0);
          return Stack(
            fit: StackFit.expand,
            children: [
              if (_coverImage != null)
                AppImage(_coverImage!, fit: BoxFit.cover, errorBuilder: (_, _, _) => _coverFallback())
              else
                _coverFallback(),
              DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withValues(alpha: 0.25),
                      AppColors.slateDark.withValues(alpha: 0.35),
                      AppColors.slateDark.withValues(alpha: 0.94),
                    ],
                    stops: const [0, 0.45, 1],
                  ),
                ),
              ),
              // Solid bar once the hero has collapsed.
              ColoredBox(color: AppColors.slateDark.withValues(alpha: (1 - t) * 0.97)),
              Positioned(
                left: 20,
                right: 20,
                bottom: 16,
                child: Opacity(opacity: t, child: _heroIdentity()),
              ),
              Positioned(
                top: top,
                left: 60,
                right: 60,
                height: kToolbarHeight,
                child: Opacity(
                  opacity: 1 - t,
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Flexible(
                          child: Text(
                            _name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Colors.white),
                          ),
                        ),
                        if (_p.isVerified) ...[
                          const SizedBox(width: 5),
                          VerificationBadge(level: _p.verificationLevel, size: 16),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _coverFallback() => Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [AppColors.slateDark, AppColors.primaryDark],
          ),
        ),
      );

  Widget _heroIdentity() {
    final sub = [
      if (_p.category.trim().isNotEmpty) _p.category.trim(),
      if ((_p.city ?? '').trim().isNotEmpty) _p.city!.trim(),
    ].join('  •  ');
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Stack(
          clipBehavior: Clip.none,
          children: [
            Container(
              width: 82,
              height: 82,
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(shape: BoxShape.circle, color: _ringColor),
              child: ClipOval(
                child: _avatarImage != null
                    ? AppImage(_avatarImage!, fit: BoxFit.cover, errorBuilder: (_, _, _) => _avatarFallback())
                    : _avatarFallback(),
              ),
            ),
            if (_p.isOnline)
              Positioned(
                right: 2,
                bottom: 2,
                child: Container(
                  width: 18,
                  height: 18,
                  decoration: BoxDecoration(
                    color: AppColors.onlineGreen,
                    shape: BoxShape.circle,
                    border: Border.all(color: AppColors.slateDark, width: 3),
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Flexible(
                    child: Text(
                      _name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Colors.white, letterSpacing: -0.4),
                    ),
                  ),
                  if (_p.isVerified) ...[
                    const SizedBox(width: 6),
                    VerificationBadge(level: _p.verificationLevel, size: 20),
                  ],
                ],
              ),
              if (sub.isNotEmpty) ...[
                const SizedBox(height: 3),
                Text(sub, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12.5, color: Colors.white70)),
              ],
              const SizedBox(height: 9),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  _heroChip(
                    icon: Icons.star_rounded,
                    iconColor: AppColors.goldStar,
                    text: _p.hasReviews ? '${_p.ratingText}  ${_p.reviewsLabel}' : (_en ? 'New provider' : 'Mtoa huduma mpya'),
                  ),
                  if (_p.isOnline)
                    _heroChip(icon: Icons.circle, iconColor: AppColors.onlineGreen, iconSize: 9, text: _en ? 'Online now' : 'Yupo mtandaoni'),
                  if (_p.distanceKm != null) _heroChip(icon: Icons.near_me_rounded, text: _p.distance),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _avatarFallback() => Container(
        color: AppColors.primary,
        alignment: Alignment.center,
        child: Text(_initial, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800, color: Colors.white)),
      );

  Widget _heroChip({required IconData icon, required String text, Color iconColor = Colors.white, double iconSize = 13}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.16),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: iconSize, color: iconColor),
          const SizedBox(width: 5),
          Text(text, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: Colors.white)),
        ],
      ),
    );
  }

  /// Block / unblock / report menu (never on your own profile).
  Widget _moderationMenu() {
    return ValueListenableBuilder<int>(
      valueListenable: BlockService.changed,
      builder: (ctx, _, _) {
        final id = _sellerId!;
        final blocked = BlockService.isBlocked(id);
        return Padding(
          padding: const EdgeInsets.all(6),
          child: Material(
            color: Colors.black.withValues(alpha: 0.38),
            shape: const CircleBorder(),
            child: PopupMenuButton<String>(
              padding: EdgeInsets.zero,
              icon: const Icon(Icons.more_vert_rounded, color: Colors.white, size: 20),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              onSelected: (choice) async {
                if (choice == 'report') {
                  final out = await ReportSheet.show(context, target: ReportTarget.user, userId: id, name: _p.stageName);
                  if (out.blocked && context.mounted) Navigator.pop(context);
                  return;
                }
                if (!SessionManager.isLoggedIn()) {
                  final ok = await LoginModal.show(context);
                  if (ok != true || !context.mounted) return;
                }
                if (!context.mounted) return;
                if (blocked) {
                  await BlockUserDialog.confirmUnblock(context, userId: id, name: _p.stageName);
                } else {
                  final done = await BlockUserDialog.confirmBlock(context, userId: id, name: _p.stageName);
                  if (done && context.mounted) Navigator.pop(context);
                }
              },
              itemBuilder: (_) => [
                PopupMenuItem(
                  value: 'toggle',
                  child: Row(
                    children: [
                      Icon(blocked ? Icons.lock_open_rounded : Icons.block_rounded,
                          size: 18, color: blocked ? AppColors.primary : AppColors.danger),
                      const SizedBox(width: 10),
                      Text(
                        blocked ? (_en ? 'Unblock user' : 'Mfungulie mtumiaji') : (_en ? 'Block user' : 'Mzuie mtumiaji'),
                        style: TextStyle(fontWeight: FontWeight.w600, color: blocked ? AppColors.primary : AppColors.danger),
                      ),
                    ],
                  ),
                ),
                PopupMenuItem(
                  value: 'report',
                  child: Row(
                    children: [
                      const Icon(Icons.flag_outlined, size: 18, color: AppColors.textSecondary),
                      const SizedBox(width: 10),
                      Text(
                        _en ? 'Report user' : 'Ripoti mtumiaji',
                        style: const TextStyle(fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ------------------------------------------------------------ stats panel

  Widget _statsPanel() {
    final cells = <MapEntry<String, String>>[
      MapEntry(_p.ratingText, _p.hasReviews ? (_en ? 'Rating' : 'Ukadiriaji') : (_en ? 'No reviews yet' : 'Hakuna maoni bado')),
      if ((_p.completedJobs ?? 0) > 0) MapEntry('${_p.completedJobs}', _en ? 'Jobs done' : 'Kazi zilizokamilika'),
      if (_p.sellerSince != null) MapEntry(_monthYear(_p.sellerSince!), _en ? 'Member since' : 'Mwanachama tangu'),
      MapEntry('${_services.length}', _en ? (_services.length == 1 ? 'Service' : 'Services') : 'Huduma'),
      if (_p.hasReviews) MapEntry('${_p.reviewsCount}', _en ? 'Reviews' : 'Maoni'),
    ].take(4).toList();

    final children = <Widget>[];
    for (var i = 0; i < cells.length; i++) {
      if (i > 0) children.add(Container(width: 1, height: 30, color: AppColors.border));
      children.add(
        Expanded(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(cells[i].key,
                  maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
              const SizedBox(height: 2),
              Text(cells[i].value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 10.5, color: AppColors.textSecondary)),
            ],
          ),
        ),
      );
    }
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 16, 20, 4),
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 6),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(children: children),
    );
  }

  // ------------------------------------------------------------------- tabs

  Widget _tabBar() {
    final labels = [
      _en ? 'Services' : 'Huduma',
      _en ? 'Portfolio' : 'Kazi',
      _en ? 'Reviews' : 'Maoni',
      _en ? 'About' : 'Kuhusu',
    ];
    return Container(
      color: AppColors.background,
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
      child: Container(
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            for (var i = 0; i < labels.length; i++)
              Expanded(
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => setState(() => _tab = i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    alignment: Alignment.center,
                    padding: const EdgeInsets.symmetric(vertical: 9),
                    decoration: BoxDecoration(
                      color: _tab == i ? AppColors.primary : Colors.transparent,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      labels[i],
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w700,
                        color: _tab == i ? Colors.white : AppColors.textSecondary,
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _tabBody() {
    switch (_tab) {
      case 1:
        return _portfolioTab();
      case 2:
        return _reviewsTab();
      case 3:
        return _aboutTab();
      default:
        return _servicesTab();
    }
  }

  Widget _card({required Widget child, VoidCallback? onTap, EdgeInsets margin = const EdgeInsets.fromLTRB(20, 8, 20, 0)}) {
    return Padding(
      padding: margin,
      child: Material(
        color: AppColors.surface,
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: const BorderSide(color: AppColors.border)),
        child: InkWell(onTap: onTap, child: Padding(padding: const EdgeInsets.all(14), child: child)),
      ),
    );
  }

  Widget _empty(IconData icon, String title, String hint) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(32, 36, 32, 12),
      child: Column(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: const BoxDecoration(color: AppColors.primaryLight, shape: BoxShape.circle),
            child: Icon(icon, color: AppColors.primary, size: 26),
          ),
          const SizedBox(height: 12),
          Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
          const SizedBox(height: 4),
          Text(hint, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textSecondary)),
        ],
      ),
    );
  }

  Widget _sectionTitle(String text) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 2),
        child: Text(text, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
      );

  // --------------------------------------------------------------- services

  Widget _servicesTab() {
    return Column(
      children: [
        for (final s in _services) _serviceCard(s),
      ],
    );
  }

  Widget _serviceCard(ServiceItem s) {
    final thumb = s.imageUrls.isNotEmpty ? s.imageUrls.first : null;
    return _card(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ServiceDetailsScreen(service: s))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: SizedBox(
                  width: 78,
                  height: 78,
                  child: thumb != null
                      ? AppImage(thumb, fit: BoxFit.cover, errorBuilder: (_, _, _) => _thumbFallback(s))
                      : _thumbFallback(s),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(s.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                    if (s.subtitle.trim().isNotEmpty) ...[
                      const SizedBox(height: 3),
                      WhatsAppText(s.subtitle.trim(), maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, height: 1.35, color: AppColors.textSecondary)),
                    ],
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Text(s.priceText, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.primary)),
                        if (s.hasDuration) ...[
                          const SizedBox(width: 8),
                          const Icon(Icons.schedule_rounded, size: 13, color: AppColors.textSecondary),
                          const SizedBox(width: 3),
                          Text(s.durationText, style: const TextStyle(fontSize: 11.5, color: AppColors.textSecondary)),
                        ],
                      ],
                    ),
                    if (s.isBoosted) ...[
                      const SizedBox(height: 5),
                      const BoostBadge(compact: true),
                    ],
                  ],
                ),
              ),
            ],
          ),
          if (s.features.isNotEmpty || !_isMine) ...[
            const SizedBox(height: 10),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      for (final f in s.features.take(3))
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(color: AppColors.background, borderRadius: BorderRadius.circular(8), border: Border.all(color: AppColors.border)),
                          child: Text(f, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600, color: AppColors.slateMuted)),
                        ),
                    ],
                  ),
                ),
                if (!_isMine) ...[
                  const SizedBox(width: 8),
                  SizedBox(
                    height: 34,
                    child: FilledButton(
                      onPressed: () => _book(s),
                      style: FilledButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                      child: Text(_en ? 'Request' : 'Omba', style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700)),
                    ),
                  ),
                ],
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _thumbFallback(ServiceItem s) => Container(
        color: s.themeColor.withValues(alpha: 0.18),
        alignment: Alignment.center,
        child: Icon(s.icon, color: s.themeColor, size: 30),
      );

  // -------------------------------------------------------------- portfolio

  Widget _portfolioTab() {
    final photos = _photos;
    final videos = _videos;
    if (photos.isEmpty && videos.isEmpty) {
      return _empty(
        Icons.photo_library_outlined,
        _en ? 'No photos or videos yet' : 'Hakuna picha wala video bado',
        _en ? 'Photos and videos from this provider\'s services will appear here.' : 'Picha na video za huduma za mtoa huduma zitaonekana hapa.',
      );
    }
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (photos.isNotEmpty)
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: photos.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 6, mainAxisSpacing: 6),
              itemBuilder: (_, i) => GestureDetector(
                onTap: () => FullscreenImageViewer.open(context, images: photos, initialIndex: i),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: AppImage(
                    photos[i],
                    fit: BoxFit.cover,
                    errorBuilder: (_, _, _) => Container(color: AppColors.border, child: const Icon(Icons.broken_image_outlined, color: AppColors.textMuted)),
                  ),
                ),
              ),
            ),
          if (videos.isNotEmpty) ...[
            Padding(
              padding: const EdgeInsets.only(top: 16, bottom: 4),
              child: Text(_en ? 'Videos' : 'Video', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
            ),
            for (var i = 0; i < videos.length; i++)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Material(
                  color: AppColors.slateDark,
                  borderRadius: BorderRadius.circular(14),
                  clipBehavior: Clip.antiAlias,
                  child: InkWell(
                    onTap: () => VideoPlayerScreen.open(context, url: videos[i], title: '$_name • ${i + 1}'),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
                      child: Row(
                        children: [
                          Container(
                            width: 38,
                            height: 38,
                            decoration: const BoxDecoration(color: Colors.white24, shape: BoxShape.circle),
                            child: const Icon(Icons.play_arrow_rounded, color: Colors.white),
                          ),
                          const SizedBox(width: 12),
                          Text(
                            _en ? 'Watch video ${i + 1}' : 'Tazama video ${i + 1}',
                            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ],
      ),
    );
  }

  // ---------------------------------------------------------------- reviews

  _ReviewData _parseReview(dynamic j) {
    if (j is! Map) return const _ReviewData(name: '', rating: 0, comment: '');
    final who = j['reviewer'] ?? j['buyer'] ?? j['user'] ?? j['author'] ?? const {};
    String name = '';
    if (who is Map) name = '${who['stageName'] ?? who['name'] ?? who['username'] ?? ''}'.trim();
    if (name.isEmpty) name = '${j['reviewerName'] ?? j['buyerName'] ?? j['name'] ?? ''}'.trim();
    final r = j['rating'] ?? j['stars'] ?? j['score'];
    final rating = r is num ? r.toDouble() : (double.tryParse('$r') ?? 0);
    final comment = '${j['comment'] ?? j['text'] ?? j['review'] ?? j['message'] ?? ''}'.trim();
    final date = DateTime.tryParse('${j['createdAt'] ?? j['date'] ?? ''}');
    return _ReviewData(name: name, rating: rating, comment: comment, date: date);
  }

  Widget _stars(double rating, {double size = 14}) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(
        5,
        (i) => Icon(i < rating.round() ? Icons.star_rounded : Icons.star_outline_rounded, size: size, color: AppColors.goldStar),
      ),
    );
  }

  Widget _reviewsTab() {
    return FutureBuilder<List<dynamic>?>(
      future: _reviewsFuture,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Padding(
            padding: EdgeInsets.all(40),
            child: Center(child: CircularProgressIndicator(color: AppColors.primary)),
          );
        }
        final list = snap.data?.map(_parseReview).where((r) => r.comment.isNotEmpty || r.rating > 0).toList();
        return Column(
          children: [
            if (_p.hasReviews)
              _card(
                child: Row(
                  children: [
                    Text(_p.ratingText, style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w900, color: AppColors.textPrimary, letterSpacing: -1)),
                    const SizedBox(width: 14),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _stars(_p.rating, size: 18),
                        const SizedBox(height: 4),
                        Text(
                          _en ? 'From ${_p.reviewsCount} ${_p.reviewsCount == 1 ? 'review' : 'reviews'}' : 'Kutoka maoni ${_p.reviewsCount}',
                          style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            if (list != null && list.isEmpty && !_p.hasReviews)
              _empty(
                Icons.rate_review_outlined,
                _en ? 'No reviews yet' : 'Hakuna maoni bado',
                _en ? 'Reviews appear here after customers complete a booking.' : 'Maoni yataonekana hapa baada ya wateja kukamilisha oda.',
              ),
            if (list == null)
              _card(
                child: Row(
                  children: [
                    const Icon(Icons.cloud_off_rounded, color: AppColors.textSecondary),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        _en ? 'Reviews could not be loaded right now.' : 'Maoni hayakuweza kupakiwa kwa sasa.',
                        style: const TextStyle(fontSize: 12.5, color: AppColors.textSecondary),
                      ),
                    ),
                    TextButton(
                      onPressed: () => setState(_loadReviews),
                      child: Text(_en ? 'Retry' : 'Jaribu tena'),
                    ),
                  ],
                ),
              ),
            if (list != null)
              for (final r in list) _reviewCard(r),
          ],
        );
      },
    );
  }

  Widget _reviewCard(_ReviewData r) {
    final name = r.name.isEmpty ? (_en ? 'Customer' : 'Mteja') : r.name;
    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 18,
                backgroundColor: AppColors.primaryLight,
                child: Text(name.substring(0, 1).toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary)),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(name, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                    if (r.date != null) Text(_dateText(r.date!), style: const TextStyle(fontSize: 11, color: AppColors.textMuted)),
                  ],
                ),
              ),
              if (r.rating > 0) _stars(r.rating),
            ],
          ),
          if (r.comment.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(r.comment, style: const TextStyle(fontSize: 13, height: 1.45, color: AppColors.slateMuted)),
          ],
        ],
      ),
    );
  }

  // ------------------------------------------------------------------ about

  Widget _aboutTab() {
    final bio = (_p.sellerBio ?? '').trim().isNotEmpty
        ? _p.sellerBio!.trim()
        : _services.map((s) => s.subtitle.trim()).firstWhere((t) => t.isNotEmpty, orElse: () => '');
    final verificationText = _p.hasBlueTick
        ? AppStrings.badgeBlueTick
        : (_p.hasGreenBadge ? AppStrings.badgeGreenBadge : AppStrings.badgeUnverified);

    final details = <MapEntry<IconData, MapEntry<String, String>>>[
      if (_p.category.trim().isNotEmpty) MapEntry(Icons.category_outlined, MapEntry(_en ? 'Category' : 'Aina', _p.category.trim())),
      if (_modeLabel != null) MapEntry(Icons.directions_walk_rounded, MapEntry(_en ? 'How it works' : 'Jinsi huduma inavyotolewa', _modeLabel!)),
      if ((_p.city ?? '').trim().isNotEmpty) MapEntry(Icons.location_on_outlined, MapEntry(_en ? 'Location' : 'Eneo', _p.city!.trim())),
      if (_p.sellerSince != null) MapEntry(Icons.event_available_outlined, MapEntry(_en ? 'Member since' : 'Mwanachama tangu', _monthYear(_p.sellerSince!))),
      MapEntry(Icons.verified_user_outlined, MapEntry(_en ? 'Verification' : 'Uthibitisho', verificationText)),
    ];

    return Column(
      children: [
        _card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(_en ? 'About' : 'Kuhusu', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
              const SizedBox(height: 8),
              WhatsAppText(
                bio.isNotEmpty ? bio : (_en ? 'This provider has not written a bio yet.' : 'Mtoa huduma bado hajaandika maelezo yake.'),
                style: TextStyle(fontSize: 13, height: 1.5, color: bio.isNotEmpty ? AppColors.slateMuted : AppColors.textMuted),
              ),
            ],
          ),
        ),
        _card(
          child: Column(
            children: [
              for (var i = 0; i < details.length; i++) ...[
                if (i > 0) const Divider(height: 18, color: AppColors.borderLight),
                Row(
                  children: [
                    Icon(details[i].key, size: 18, color: AppColors.primary),
                    const SizedBox(width: 10),
                    Expanded(child: Text(details[i].value.key, style: const TextStyle(fontSize: 12.5, color: AppColors.textSecondary))),
                    const SizedBox(width: 8),
                    Flexible(
                      child: Text(details[i].value.value,
                          textAlign: TextAlign.right, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
        _hoursCard(),
        ProviderContactCard(provider: _p),
        if (_p.is18Plus)
          const Padding(
            padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
            child: Align(alignment: Alignment.centerLeft, child: SensitiveTag()),
          ),
        _card(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.shield_outlined, size: 20, color: AppColors.successDark),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  _en
                      ? 'Stay safe: book and pay through the app so your payment is protected by escrow. Report anyone who asks you to pay outside it.'
                      : 'Kaa salama: weka oda na ulipe kupitia app ili malipo yako yalindwe na escrow. Ripoti yeyote anayekuomba ulipe nje ya app.',
                  style: const TextStyle(fontSize: 12, height: 1.45, color: AppColors.textSecondary),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _hoursCard() {
    final open = _openNow;
    final from = _p.availableFrom, to = _p.availableTo;
    final hasTimes = _minutes(from) != null && _minutes(to) != null;
    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(_en ? 'Working hours' : 'Saa za kazi', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
              ),
              if (open != null)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                  decoration: BoxDecoration(
                    color: open ? AppColors.successLight : AppColors.background,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    open ? (_en ? 'Available now' : 'Anapatikana sasa') : (_en ? 'Closed now' : 'Amefunga sasa'),
                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: open ? AppColors.successDark : AppColors.textSecondary),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 10),
          if (!_hasSchedule)
            Text(
              _en ? 'The provider has not set working hours.' : 'Mtoa huduma bado hajaweka saa za kazi.',
              style: const TextStyle(fontSize: 12.5, color: AppColors.textMuted),
            )
          else ...[
            Row(
              children: [
                for (var i = 0; i < 7; i++)
                  Expanded(
                    child: Container(
                      margin: EdgeInsets.only(right: i == 6 ? 0 : 4),
                      padding: const EdgeInsets.symmetric(vertical: 7),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: (_p.availableDays.isEmpty || _p.availableDays.contains(_dayKeys[i])) ? AppColors.primaryLight : AppColors.background,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        _dayLabel(i),
                        style: TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w700,
                          color: (_p.availableDays.isEmpty || _p.availableDays.contains(_dayKeys[i])) ? AppColors.primary : AppColors.textDisabled,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            if (hasTimes) ...[
              const SizedBox(height: 10),
              Row(
                children: [
                  const Icon(Icons.schedule_rounded, size: 16, color: AppColors.textSecondary),
                  const SizedBox(width: 6),
                  Text('$from – $to', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                ],
              ),
            ],
          ],
        ],
      ),
    );
  }

  // ------------------------------------------------------------- action bar

  Widget _actionBar() {
    return Container(
      decoration: const BoxDecoration(
        color: AppColors.surface,
        border: Border(top: BorderSide(color: AppColors.border)),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
          child: Row(
            children: [
              _squareButton(
                Icons.chat_bubble_outline_rounded,
                () => ChatThreadScreen.open(context, recipientId: _p.sellerId, name: _p.stageName, isOnline: _p.isOnline),
              ),
              const SizedBox(width: 10),
              _squareButton(Icons.phone_outlined, () => CallOptionsSheet.show(context, _p)),
              const SizedBox(width: 12),
              Expanded(
                child: SizedBox(
                  height: 48,
                  child: FilledButton(
                    onPressed: () => _book(_p),
                    style: FilledButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    child: Text(
                      _en ? 'Request Service' : 'Omba Huduma',
                      style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _squareButton(IconData icon, VoidCallback onTap) {
    return SizedBox(
      width: 48,
      height: 48,
      child: OutlinedButton(
        onPressed: onTap,
        style: OutlinedButton.styleFrom(
          padding: EdgeInsets.zero,
          side: const BorderSide(color: AppColors.border),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
        child: Icon(icon, color: AppColors.primary, size: 21),
      ),
    );
  }
}

class _ReviewData {
  final String name;
  final double rating;
  final String comment;
  final DateTime? date;
  const _ReviewData({required this.name, required this.rating, required this.comment, this.date});
}

/// Keeps the Services / Portfolio / Reviews / About switcher pinned under the app bar.
class _PinnedTabs extends SliverPersistentHeaderDelegate {
  final Widget child;
  _PinnedTabs(this.child);

  @override
  double get minExtent => 64;

  @override
  double get maxExtent => 64;

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) => SizedBox(height: 64, child: child);

  @override
  bool shouldRebuild(covariant _PinnedTabs oldDelegate) => true;
}

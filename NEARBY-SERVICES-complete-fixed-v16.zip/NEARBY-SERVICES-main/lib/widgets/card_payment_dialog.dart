import 'dart:async';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';

/// Card payment through the gateway's hosted checkout page.
/// The app never handles card numbers (no PCI scope): it opens the https checkout
/// URL in the browser, then confirms the result with the server before continuing.
class CardPayment {
  /// Returns true only when the server confirms the payment as PAID.
  static Future<bool> pay(
    BuildContext context, {
    required double amount,
    required String purpose,
    required String reference,
    String? description,
    String? phone,
  }) async {
    final messenger = ScaffoldMessenger.of(context);
    final session = await ApiService.createCardCheckout(
      amount: amount,
      purpose: purpose,
      reference: reference,
      description: description,
      phone: phone,
    );
    if (session == null) {
      messenger.showSnackBar(SnackBar(
        content: Text(AppStrings.isEnglish
            ? 'Card payment is unavailable right now. Try another method.'
            : 'Malipo ya kadi hayapatikani sasa. Jaribu njia nyingine.'),
      ));
      return false;
    }

    // Only ever open a secure checkout page.
    final uri = Uri.tryParse(session['checkoutUrl'].toString());
    if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) {
      messenger.showSnackBar(SnackBar(
        content: Text(AppStrings.isEnglish ? 'Invalid payment page.' : 'Ukurasa wa malipo si sahihi.'),
      ));
      return false;
    }
    final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!opened) {
      messenger.showSnackBar(SnackBar(
        content: Text(AppStrings.isEnglish ? 'Could not open the payment page.' : 'Imeshindwa kufungua ukurasa wa malipo.'),
      ));
      return false;
    }

    if (!context.mounted) return false;
    final paid = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => _CardPaymentWaitDialog(reference: session['reference']?.toString() ?? reference),
    );
    return paid == true;
  }
}

class _CardPaymentWaitDialog extends StatefulWidget {
  final String reference;
  const _CardPaymentWaitDialog({required this.reference});

  @override
  State<_CardPaymentWaitDialog> createState() => _CardPaymentWaitDialogState();
}

class _CardPaymentWaitDialogState extends State<_CardPaymentWaitDialog> {
  Timer? _timer;
  bool _checking = false;
  String? _message;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 4), (_) => _check(auto: true));
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _check({bool auto = false}) async {
    if (_checking) return;
    setState(() => _checking = true);
    final status = await ApiService.getCardPaymentStatus(widget.reference);
    if (!mounted) return;
    setState(() => _checking = false);

    if (status == 'PAID') {
      _timer?.cancel();
      Navigator.of(context).pop(true);
    } else if (status == 'FAILED' || status == 'CANCELLED') {
      _timer?.cancel();
      Navigator.of(context).pop(false);
    } else if (!auto) {
      setState(() => _message = AppStrings.isEnglish
          ? 'Payment not confirmed yet. Finish paying in the browser, then try again.'
          : 'Malipo bado hayajathibitishwa. Maliza kulipa kwenye kivinjari, kisha jaribu tena.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Row(
        children: [
          const Icon(Icons.credit_card_rounded, color: AppColors.primary),
          const SizedBox(width: 8),
          Expanded(child: Text(AppStrings.isEnglish ? 'Complete card payment' : 'Kamilisha malipo ya kadi')),
        ],
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(AppStrings.isEnglish
              ? 'Pay securely on the page that just opened. Come back here when you are done.'
              : 'Lipa kwa usalama kwenye ukurasa uliofunguka. Rudi hapa ukimaliza.'),
          const SizedBox(height: 12),
          Row(
            children: [
              const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)),
              const SizedBox(width: 10),
              Text(AppStrings.isEnglish ? 'Waiting for confirmation...' : 'Inasubiri uthibitisho...',
                  style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
            ],
          ),
          if (_message != null) ...[
            const SizedBox(height: 10),
            Text(_message!, style: const TextStyle(fontSize: 12, color: AppColors.warningDark)),
          ],
        ],
      ),
      actions: [
        TextButton(
          onPressed: () {
            _timer?.cancel();
            Navigator.of(context).pop(false);
          },
          child: Text(AppStrings.isEnglish ? 'Cancel' : 'Ghairi'),
        ),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: AppColors.primary),
          onPressed: _checking ? null : () => _check(),
          child: _checking
              ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : Text(AppStrings.isEnglish ? "I've paid" : 'Nimelipa'),
        ),
      ],
    );
  }
}

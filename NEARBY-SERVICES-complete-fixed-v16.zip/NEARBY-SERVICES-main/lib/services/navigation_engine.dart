import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';

/// One manoeuvre of a route ("turn left onto X", "arrive", ...).
class NavStep {
  final String type; // OSRM maneuver type: turn, depart, arrive, roundabout...
  final String modifier; // left, right, straight, slight left, uturn...
  final String street;
  final int? exit; // roundabout exit number
  final double lengthM; // length of this step (until the next manoeuvre)
  final LatLng at; // where the manoeuvre happens
  int polyIndex; // index of the closest route vertex to [at]

  NavStep({
    required this.type,
    required this.modifier,
    required this.street,
    required this.exit,
    required this.lengthM,
    required this.at,
    this.polyIndex = 0,
  });
}

/// A driving route with turn-by-turn steps and cumulative distances.
class NavRoute {
  final List<LatLng> points;
  final List<double> cum; // cumulative metres at each vertex (cum[0] = 0)
  final List<NavStep> steps;
  final double distanceM;
  final double durationS;

  NavRoute._(this.points, this.cum, this.steps, this.distanceM, this.durationS);

  /// Builds a route from one OSRM `routes[i]` object
  /// (requested with `overview=full&geometries=geojson&steps=true`).
  static NavRoute? fromOsrm(Map<String, dynamic> r) {
    try {
      final coords = (r['geometry']['coordinates'] as List)
          .map((c) => LatLng((c[1] as num).toDouble(), (c[0] as num).toDouble()))
          .toList();
      if (coords.length < 2) return null;
      final cum = <double>[0];
      for (var i = 1; i < coords.length; i++) {
        cum.add(cum.last + _dist.as(LengthUnit.Meter, coords[i - 1], coords[i]));
      }
      final steps = <NavStep>[];
      for (final leg in (r['legs'] as List? ?? const [])) {
        for (final s in (leg['steps'] as List? ?? const [])) {
          final m = s['maneuver'] as Map<String, dynamic>;
          final loc = m['location'] as List;
          steps.add(NavStep(
            type: (m['type'] ?? '').toString(),
            modifier: (m['modifier'] ?? '').toString(),
            street: (s['name'] ?? '').toString(),
            exit: (m['exit'] as num?)?.toInt(),
            lengthM: ((s['distance'] as num?) ?? 0).toDouble(),
            at: LatLng((loc[1] as num).toDouble(), (loc[0] as num).toDouble()),
          ));
        }
      }
      final route = NavRoute._(
        coords,
        cum,
        steps,
        ((r['distance'] as num?) ?? cum.last).toDouble(),
        ((r['duration'] as num?) ?? 0).toDouble(),
      );
      // Snap every manoeuvre to a route vertex, moving forward only.
      var from = 0;
      for (final s in steps) {
        final idx = route._nearestVertex(s.at, from: from);
        s.polyIndex = idx;
        from = idx;
      }
      return route;
    } catch (_) {
      return null;
    }
  }

  /// A straight-line fallback when the routing service is unreachable.
  static NavRoute straight(LatLng a, LatLng b) {
    final d = _dist.as(LengthUnit.Meter, a, b);
    return NavRoute._(
      [a, b],
      [0, d],
      [
        NavStep(type: 'depart', modifier: '', street: '', exit: null, lengthM: d, at: a),
        NavStep(type: 'arrive', modifier: '', street: '', exit: null, lengthM: 0, at: b, polyIndex: 1),
      ],
      d,
      d / 8.3, // ~30 km/h
    );
  }

  static const Distance _dist = Distance();

  int _nearestVertex(LatLng p, {int from = 0}) {
    var best = from;
    var bestD = double.infinity;
    for (var i = from; i < points.length; i++) {
      final d = _dist.as(LengthUnit.Meter, p, points[i]);
      if (d < bestD) {
        bestD = d;
        best = i;
      }
    }
    return best;
  }

  /// Where the traveller is on the route.
  NavProgress progress(LatLng p, {int hint = 0}) {
    // Search a forward window first (cheap, avoids jumping on looping roads);
    // fall back to the whole route when the window is far from the position.
    final start = math.max(0, hint - 5);
    final end = math.min(points.length, hint + 400);
    var idx = start;
    var best = double.infinity;
    for (var i = start; i < end; i++) {
      final d = _dist.as(LengthUnit.Meter, p, points[i]);
      if (d < best) {
        best = d;
        idx = i;
      }
    }
    if (best > 80) {
      idx = _nearestVertex(p);
    }
    final off = _distanceToPath(p, idx);
    final done = cum[idx];
    final remaining = math.max(0.0, cum.last - done);
    final total = cum.last <= 0 ? 1.0 : cum.last;
    final seconds = durationS * (remaining / total);
    return NavProgress(idx, off, remaining, seconds);
  }

  /// Distance (m) from [p] to the route segments around vertex [idx].
  double _distanceToPath(LatLng p, int idx) {
    var best = double.infinity;
    for (var i = math.max(0, idx - 1); i <= math.min(points.length - 2, idx); i++) {
      best = math.min(best, _distToSegment(p, points[i], points[i + 1]));
    }
    if (best == double.infinity) best = _dist.as(LengthUnit.Meter, p, points[idx]);
    return best;
  }

  static double _distToSegment(LatLng p, LatLng a, LatLng b) {
    // Local equirectangular projection (good enough over a few hundred metres).
    final lat0 = a.latitudeInRad;
    const r = 6371000.0;
    double x(LatLng q) => q.longitudeInRad * math.cos(lat0) * r;
    double y(LatLng q) => q.latitudeInRad * r;
    final px = x(p), py = y(p), ax = x(a), ay = y(a), bx = x(b), by = y(b);
    final dx = bx - ax, dy = by - ay;
    final len2 = dx * dx + dy * dy;
    var t = len2 == 0 ? 0.0 : ((px - ax) * dx + (py - ay) * dy) / len2;
    t = t.clamp(0.0, 1.0);
    final cx = ax + t * dx, cy = ay + t * dy;
    return math.sqrt((px - cx) * (px - cx) + (py - cy) * (py - cy));
  }

  /// The next manoeuvre ahead of vertex [idx] (never the "depart" step).
  int nextStepIndex(int idx) {
    for (var i = 1; i < steps.length; i++) {
      if (steps[i].polyIndex > idx) return i;
    }
    return steps.length - 1;
  }

  /// Metres along the route from vertex [idx] to the given step's manoeuvre.
  double metresToStep(int idx, int stepIndex) =>
      math.max(0.0, cum[steps[stepIndex].polyIndex] - cum[idx]);
}

class NavProgress {
  final int index; // nearest route vertex
  final double offRouteM; // how far the position is from the route
  final double remainingM;
  final double remainingS;
  const NavProgress(this.index, this.offRouteM, this.remainingM, this.remainingS);
}

/// Text + icons for a manoeuvre, in English or Swahili.
class NavText {
  static String distance(double m, bool en) {
    if (m >= 1000) return '${(m / 1000).toStringAsFixed(m >= 10000 ? 0 : 1)} km';
    if (m < 30) return '${m.round()} m';
    final step = m < 200 ? 10 : 50;
    return '${(m / step).round() * step} m';
  }

  static String duration(double seconds, bool en) {
    final min = seconds / 60;
    if (min < 1) return en ? '< 1 min' : 'Chini ya dak 1';
    if (min < 60) return '${min.round()} ${en ? 'min' : 'dak'}';
    final h = min ~/ 60;
    final m = (min % 60).round();
    return '$h ${en ? 'h' : 'saa'} $m ${en ? 'min' : 'dak'}';
  }

  static String _dir(String modifier, bool en) {
    switch (modifier) {
      case 'left':
        return en ? 'left' : 'kushoto';
      case 'right':
        return en ? 'right' : 'kulia';
      case 'slight left':
        return en ? 'slightly left' : 'kidogo kushoto';
      case 'slight right':
        return en ? 'slightly right' : 'kidogo kulia';
      case 'sharp left':
        return en ? 'sharp left' : 'kabisa kushoto';
      case 'sharp right':
        return en ? 'sharp right' : 'kabisa kulia';
      default:
        return '';
    }
  }

  /// Short spoken-style instruction, e.g. "Turn left onto Mandela Rd".
  static String instruction(NavStep s, bool en) {
    final onto = s.street.trim().isEmpty ? '' : (en ? ' onto ${s.street}' : ' kuingia ${s.street}');
    final dir = _dir(s.modifier, en);
    switch (s.type) {
      case 'depart':
        return en ? 'Head out$onto' : 'Anza safari$onto';
      case 'arrive':
        return en ? 'You have arrived' : 'Umefika ulipokuwa unaenda';
      case 'roundabout':
      case 'rotary':
      case 'roundabout turn':
        final n = s.exit;
        if (n != null) {
          return en ? 'At the roundabout, take exit $n$onto' : 'Kwenye mzunguko, chukua njia ya $n$onto';
        }
        return en ? 'Enter the roundabout$onto' : 'Ingia kwenye mzunguko$onto';
      case 'exit roundabout':
      case 'exit rotary':
        return en ? 'Exit the roundabout$onto' : 'Toka kwenye mzunguko$onto';
      case 'merge':
        return en ? 'Merge${dir.isEmpty ? '' : ' $dir'}$onto' : 'Unganisha${dir.isEmpty ? '' : ' $dir'}$onto';
      case 'fork':
        return en ? 'Keep ${dir.isEmpty ? 'straight' : dir} at the fork$onto' : 'Baki ${dir.isEmpty ? 'mbele' : dir} kwenye mgawanyiko$onto';
      case 'on ramp':
      case 'off ramp':
        return en ? 'Take the ramp${dir.isEmpty ? '' : ' $dir'}$onto' : 'Chukua njia ya kuingia/kutoka${dir.isEmpty ? '' : ' $dir'}$onto';
      case 'end of road':
        return en ? 'At the end of the road, turn ${dir.isEmpty ? 'around' : dir}$onto' : 'Mwisho wa barabara, geuka ${dir.isEmpty ? 'nyuma' : dir}$onto';
      default: // turn, new name, continue, notification
        if (s.modifier == 'uturn') return en ? 'Make a U-turn$onto' : 'Rudi nyuma (U-turn)$onto';
        if (dir.isEmpty || s.modifier == 'straight') {
          return en ? 'Continue straight$onto' : 'Endelea mbele$onto';
        }
        return en ? 'Turn $dir$onto' : 'Geuka $dir$onto';
    }
  }

  static IconData icon(NavStep s) {
    switch (s.type) {
      case 'arrive':
        return Icons.flag_rounded;
      case 'depart':
        return Icons.navigation_rounded;
      case 'roundabout':
      case 'rotary':
      case 'roundabout turn':
      case 'exit roundabout':
      case 'exit rotary':
        return Icons.roundabout_right_rounded;
    }
    switch (s.modifier) {
      case 'left':
        return Icons.turn_left_rounded;
      case 'right':
        return Icons.turn_right_rounded;
      case 'slight left':
        return Icons.turn_slight_left_rounded;
      case 'slight right':
        return Icons.turn_slight_right_rounded;
      case 'sharp left':
        return Icons.turn_sharp_left_rounded;
      case 'sharp right':
        return Icons.turn_sharp_right_rounded;
      case 'uturn':
        return Icons.u_turn_left_rounded;
      default:
        return Icons.straight_rounded;
    }
  }
}

import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import '../services/session_manager.dart';
import '../widgets/app_image.dart';
import '../widgets/skeleton_loader.dart';
import 'seller_profile_screen.dart';
import 'service_details_screen.dart';

class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});

  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  late Future<List<ServiceItem>> _servicesFuture;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _servicesFuture = _loadServices();
    SessionManager.sessionNotifier.addListener(_onSessionChanged);
  }

  // Hearts toggled on Home / Category / Details update this list at once.
  void _onSessionChanged() {
    if (mounted) setState(() {});
  }

  /// Fetches a wide page so saved services outside the first 20 are found too;
  /// everything seen before (Home, Category) is already in the shared registry.
  Future<List<ServiceItem>> _loadServices() async {
    final fetched = await ApiService.fetchServices(size: 200);
    return fetched.isNotEmpty ? fetched : ApiService.knownServices.values.toList();
  }

  /// Only the services the user saved, in the order they were saved.
  List<ServiceItem> _saved(List<ServiceItem> all) {
    final byId = {...ApiService.knownServices, for (final s in all) s.id: s};
    return [
      for (final id in SessionManager.getFavoriteIds().reversed)
        if (byId[id] != null) byId[id]!,
    ];
  }

  @override
  void dispose() {
    SessionManager.sessionNotifier.removeListener(_onSessionChanged);
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          AppStrings.favoritesTitle,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(48),
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                decoration: BoxDecoration(
                  color: AppColors.borderLight,
                  borderRadius: BorderRadius.circular(25),
                ),
                child: TabBar(
                  controller: _tabController,
                  indicator: BoxDecoration(
                    borderRadius: BorderRadius.circular(25),
                    color: AppColors.primary,
                  ),
                  labelColor: Colors.white,
                  unselectedLabelColor: AppColors.textSecondary,
                  labelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
                  dividerColor: Colors.transparent,
                  indicatorSize: TabBarIndicatorSize.tab,
                  tabs: const [
                    Tab(text: 'Services'),
                    Tab(text: 'Providers'),
                  ],
                ),
              ),
              const Divider(height: 1, color: AppColors.borderLight),
            ],
          ),
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // 1. Services Tab
          FutureBuilder<List<ServiceItem>>(
            future: _servicesFuture,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const VerticalListCardSkeleton();
              }
              return _buildServicesList(_saved(snapshot.data ?? []));
            },
          ),

          // 2. Providers Tab: the providers behind the saved services
          FutureBuilder<List<ServiceItem>>(
            future: _servicesFuture,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const VerticalListCardSkeleton();
              }
              return _buildProvidersList(_saved(snapshot.data ?? []));
            },
          ),
        ],
      ),
    );
  }

  Widget _buildServicesList(List<ServiceItem> items) {
    if (items.isEmpty) {
      return Center(child: Text(AppStrings.favoritesNoItems, style: const TextStyle(color: AppColors.textSecondary)));
    }

    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: items.length,
      separatorBuilder: (_, _) => const SizedBox(height: 12),
      itemBuilder: (context, index) {
        final item = items[index];
        final imagePath = item.imageUrls.isNotEmpty
            ? item.imageUrls.first
            : (index % 2 == 0 ? 'assets/images/banner.jpg' : 'assets/images/provider1.jpg');

        return GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ServiceDetailsScreen(service: item)),
            );
          },
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.border),
            ),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: AppImage(
                    imagePath,
                    width: 68,
                    height: 68,
                    fit: BoxFit.cover,
                    errorBuilder: (ctx, err, stack) => Container(color: AppColors.borderLight),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        item.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        '${item.stageName}  •  ${item.category}',
                        style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          const Icon(Icons.star_rounded, size: 14, color: AppColors.goldStar),
                          const SizedBox(width: 2),
                          Text(
                            '${item.rating}',
                            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                          ),
                          Text(
                            ' (${item.reviewsCount})',
                            style: const TextStyle(fontSize: 11, color: AppColors.textMuted),
                          ),
                          const Spacer(),
                          Text(
                            item.priceText,
                            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: AppColors.primary),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: const Icon(Icons.favorite_rounded, color: AppColors.danger, size: 20),
                  onPressed: () async {
                    await SessionManager.toggleFavorite(item.id);
                    setState(() {});
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildProvidersList(List<ServiceItem> saved) {
    if (saved.isEmpty) {
      return Center(child: Text(AppStrings.favoritesNoItems, style: const TextStyle(color: AppColors.textSecondary)));
    }

    // One row per provider (by seller id, else stage name), keeping their saved services.
    final Map<String, List<ServiceItem>> byProvider = {};
    for (final it in saved) {
      byProvider.putIfAbsent(it.sellerId?.toString() ?? it.stageName, () => []).add(it);
    }
    final groups = byProvider.values.toList();

    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: groups.length,
      separatorBuilder: (_, _) => const SizedBox(height: 12),
      itemBuilder: (context, index) {
        final services = groups[index];
        final p = services.first;
        final avatar = (p.sellerAvatar ?? '').isNotEmpty
            ? p.sellerAvatar!
            : (p.imageUrls.isNotEmpty ? p.imageUrls.first : 'assets/images/zeen_avatar.jpg');

        return InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => SellerProfileScreen(provider: p)),
          ),
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.border),
            ),
            child: Row(
              children: [
                ClipOval(
                  child: SizedBox(
                    width: 48,
                    height: 48,
                    child: AppImage(
                      avatar,
                      fit: BoxFit.cover,
                      errorBuilder: (ctx, err, stack) => Container(
                        color: AppColors.borderLight,
                        child: const Icon(Icons.person, color: AppColors.textMuted),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        p.stageName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        services.length == 1 ? p.category : '${services.length} saved services',
                        style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                      ),
                      const SizedBox(height: 3),
                      Row(
                        children: [
                          const Icon(Icons.star_rounded, size: 14, color: AppColors.goldStar),
                          const SizedBox(width: 2),
                          Text(
                            '${p.rating}',
                            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                          ),
                          Text(
                            ' (${p.reviewsCount}) • ${p.distance}',
                            style: const TextStyle(fontSize: 11, color: AppColors.textMuted),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.favorite_rounded, color: AppColors.danger, size: 20),
                  onPressed: () async {
                    for (final svc in services) {
                      if (SessionManager.isFavorite(svc.id)) await SessionManager.toggleFavorite(svc.id);
                    }
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

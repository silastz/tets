import 'package:flutter/material.dart';

/// An identity document a user can verify with. Every kind is uploaded as the
/// same two server document types, `id_front` and `id_back`, and the kind
/// itself is sent along as the `idKind` field so reviewers know what they are
/// looking at. Kinds without a back side (passport) only need the front.
class IdKind {
  final String id;
  final String en;
  final String sw;
  final bool hasBack;
  final IconData icon;
  const IdKind(this.id, this.en, this.sw, this.icon, {this.hasBack = true});

  String title(bool isEn) => isEn ? en : sw;
}

class IdKinds {
  IdKinds._();

  static const List<IdKind> all = [
    IdKind('nida', 'NIDA ID', 'Kitambulisho cha NIDA', Icons.badge_outlined),
    IdKind('voter', 'Voter ID', 'Kitambulisho cha Mpiga Kura', Icons.how_to_vote_outlined),
    IdKind('driving_licence', 'Driving licence', 'Leseni ya Udereva', Icons.drive_eta_outlined),
    IdKind('passport', 'Passport', 'Pasipoti', Icons.menu_book_outlined, hasBack: false),
  ];

  static const String defaultId = 'nida';

  static IdKind byId(String? id) => all.firstWhere((k) => k.id == id, orElse: () => all.first);
}

import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:url_launcher/url_launcher.dart';

import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../security/secure_http.dart';
import '../services/gps_service.dart';
import '../services/navigation_engine.dart';

/// In-app navigation (like Bolt / Uber): route preview, then turn-by-turn
/// guidance with a live, heading-following camera, next-turn banner, ETA,
/// automatic re-routing and arrival detection. No external maps app is opened.
///
/// Uses OpenStreetMap tiles and the public OSRM router (no API key). When the
/// provider has no saved coordinates the address is looked up with Nominatim.
class MapTrackingScreen extends StatefulWidget {
  final String providerName;
  final String serviceTitle;
  final String address;
  final double? providerLat;
  final double? providerLng;

  /// Start turn-by-turn guidance as soon as the route is ready
  /// (used by the "Navigate" buttons). Otherwise a preview is shown first.
  final bool startNavigating;

  const MapTrackingScreen({
    super.key,
    required this.providerName,
    required this.serviceTitle,
    required this.address,
    this.providerLat,
    this.providerLng,
    this.startNavigating = false,
  });

  @override
  State<MapTrackingScreen> createState() => _MapTrackingScreenState();
}

class _MapTrackingScreenState extends State<MapTrackingScreen> {
  static const LatLng _fallbackCenter = LatLng(-6.7924, 39.2083); // Dar es Salaam
  static const double _offRouteMetres = 60;
  static const double _arriveMetres = 35;
  static const Duration _rerouteCooldown = Duration(seconds: 10);

  final MapController _map = MapController();
  StreamSubscription<Position>? _posSub;

  LatLng? _me;
  LatLng? _dest;
  NavRoute? _route;
  NavProgress? _progress;
  int _nextStep = 1;
  double _heading = 0;

  bool _mapReady = false;
  bool _loadingRoute = false;
  bool _routeFailed = false;
  bool _locationDenied = false;
  bool _navigating = false;
  bool _arrived = false;
  bool _follow = false;
  LatLng? _lastRouteFrom;
  DateTime _lastReroute = DateTime.fromMillisecondsSinceEpoch(0);
  bool _autoStartPending = false;

  bool get _en => AppStrings.isEnglish;

  @override
  void initState() {
    super.initState();
    _autoStartPending = widget.startNavigating;
    if (widget.providerLat != null && widget.providerLng != null) {
      _dest = LatLng(widget.providerLat!, widget.providerLng!);
    }
    if (GpsService.hasFix) _me = LatLng(GpsService.lat!, GpsService.lng!);
    _init();
  }

  @override
  void dispose() {
    _posSub?.cancel();
    super.dispose();
  }

  Future<void> _init() async {
    if (_dest == null) await _geocodeAddress();
    await _startTracking();
    if (_me != null && _dest != null && _route == null) {
      _lastRouteFrom = _me;
      await _fetchRoute(_me!, _dest!);
    }
  }

  // ───────────────────────── location ─────────────────────────

  Future<void> _startTracking() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        if (mounted) setState(() => _locationDenied = true);
        return;
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        if (mounted) setState(() => _locationDenied = true);
        return;
      }
      _posSub?.cancel();
      _posSub = Geolocator.getPositionStream(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.best, distanceFilter: 5),
      ).listen(_onPosition, onError: (_) {});

      final first = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 12)),
      );
      _onPosition(first);
    } catch (_) {
      // keep whatever fix we already have
    }
  }

  void _onPosition(Position p) {
    if (!mounted) return;
    final here = LatLng(p.latitude, p.longitude);
    if (p.speed >= 1.0 && p.heading >= 0) _heading = p.heading;
    setState(() {
      _me = here;
      _locationDenied = false;
    });
    final dest = _dest;
    if (dest == null) return;

    if (_route == null) {
      if (!_loadingRoute) {
        _lastRouteFrom = here;
        _fetchRoute(here, dest);
      }
      return;
    }

    if (_arrived) return;
    final route = _route!;
    final prog = route.progress(here, hint: _progress?.index ?? 0);
    final toDest = const Distance().as(LengthUnit.Meter, here, dest);
    setState(() {
      _progress = prog;
      _nextStep = route.nextStepIndex(prog.index);
    });

    if (_navigating) {
      if (toDest <= _arriveMetres || prog.remainingM <= _arriveMetres) {
        setState(() {
          _arrived = true;
          _follow = false;
        });
        return;
      }
      if (prog.offRouteM > _offRouteMetres &&
          !_loadingRoute &&
          DateTime.now().difference(_lastReroute) > _rerouteCooldown) {
        _lastReroute = DateTime.now();
        _fetchRoute(here, dest, rerouting: true);
      }
      if (_follow) _moveCamera(here);
    } else {
      // Preview: refresh only after moving a good distance.
      final last = _lastRouteFrom;
      if (last == null || const Distance().as(LengthUnit.Meter, last, here) > 150) {
        _lastRouteFrom = here;
        _fetchRoute(here, dest);
      }
    }
  }

  // ───────────────────────── routing ─────────────────────────

  Future<void> _geocodeAddress() async {
    final q = widget.address.trim();
    if (q.isEmpty) return;
    try {
      final uri = Uri.https('nominatim.openstreetmap.org', '/search', {'format': 'json', 'limit': '1', 'q': q});
      final res = await SecureHttp.client
          .get(uri, headers: {'User-Agent': 'Ungana/1.0 (com.unganalink.app)'})
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final list = json.decode(res.body) as List;
        if (list.isNotEmpty) {
          final m = list.first as Map<String, dynamic>;
          final lat = double.tryParse(m['lat'].toString());
          final lng = double.tryParse(m['lon'].toString());
          if (lat != null && lng != null && mounted) setState(() => _dest = LatLng(lat, lng));
        }
      }
    } catch (_) {}
  }

  Future<void> _fetchRoute(LatLng from, LatLng to, {bool rerouting = false}) async {
    if (!mounted) return;
    setState(() {
      _loadingRoute = true;
      _routeFailed = false;
    });
    NavRoute? route;
    try {
      final uri = Uri.parse(
        'https://router.project-osrm.org/route/v1/driving/'
        '${from.longitude},${from.latitude};${to.longitude},${to.latitude}'
        '?overview=full&geometries=geojson&steps=true',
      );
      final res = await SecureHttp.client.get(uri).timeout(const Duration(seconds: 12));
      if (res.statusCode == 200) {
        final data = json.decode(res.body) as Map<String, dynamic>;
        final routes = data['routes'] as List?;
        if (routes != null && routes.isNotEmpty) {
          route = NavRoute.fromOsrm(routes.first as Map<String, dynamic>);
        }
      }
    } catch (_) {}
    if (!mounted) return;
    final failed = route == null;
    route ??= NavRoute.straight(from, to);
    final prog = route.progress(from);
    setState(() {
      _route = route;
      _progress = prog;
      _nextStep = route!.nextStepIndex(prog.index);
      _loadingRoute = false;
      _routeFailed = failed;
    });
    if (rerouting) {
      _snack(_en ? 'Route updated' : 'Njia imebadilishwa');
    } else if (_mapReady && !_navigating) {
      _fitBounds();
    }
    if (_autoStartPending) {
      _autoStartPending = false;
      _startNavigation();
    }
  }

  // ───────────────────────── camera / modes ─────────────────────────

  void _moveCamera(LatLng at) {
    try {
      _map.moveAndRotate(at, 17.5, -_heading);
    } catch (_) {}
  }

  void _fitBounds() {
    final me = _me, to = _dest;
    if (!_mapReady) return;
    try {
      _map.rotate(0);
      if (me != null && to != null) {
        _map.fitCamera(CameraFit.bounds(
          bounds: LatLngBounds.fromPoints([me, to]),
          padding: const EdgeInsets.fromLTRB(48, 100, 48, 300),
          maxZoom: 17,
        ));
      } else if (to != null) {
        _map.move(to, 15);
      }
    } catch (_) {}
  }

  void _startNavigation() {
    if (_route == null) return;
    setState(() {
      _navigating = true;
      _arrived = false;
      _follow = true;
    });
    final me = _me;
    if (me != null) _moveCamera(me);
  }

  void _stopNavigation() {
    setState(() {
      _navigating = false;
      _follow = false;
    });
    _fitBounds();
  }

  void _recenter() {
    final me = _me;
    if (me == null) return;
    setState(() => _follow = true);
    if (_navigating) {
      _moveCamera(me);
    } else {
      _map.move(me, 16);
    }
  }

  /// Optional: hand the trip over to an external maps app (Google Maps etc.).
  Future<void> _openExternalMaps() async {
    final to = _dest;
    final Uri uri;
    if (to != null) {
      uri = Uri.https('www.google.com', '/maps/dir/', {
        'api': '1',
        'destination': '${to.latitude},${to.longitude}',
        'travelmode': 'driving',
      });
    } else if (widget.address.trim().isNotEmpty) {
      uri = Uri.https('www.google.com', '/maps/search/', {'api': '1', 'query': widget.address.trim()});
    } else {
      _snack(_en ? 'No location available.' : 'Hakuna eneo linalopatikana.');
      return;
    }
    var ok = false;
    try {
      ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {}
    if (!ok) _snack(_en ? 'Could not open the maps app' : 'Imeshindwa kufungua programu ya ramani');
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 2)));
  }

  // ───────────────────────── UI ─────────────────────────

  @override
  Widget build(BuildContext context) {
    final dest = _dest;
    final center = _me ?? dest ?? _fallbackCenter;
    final route = _route;

    // Only the part of the route still ahead of the traveller is drawn.
    List<LatLng> ahead = const [];
    if (route != null) {
      final i = (_progress?.index ?? 0).clamp(0, route.points.length - 1).toInt();
      ahead = [if (_navigating && _me != null) _me!, ...route.points.sublist(i)];
    }

    return PopScope(
      canPop: !_navigating,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && _navigating) _confirmExit();
      },
      child: Scaffold(
        backgroundColor: AppColors.background,
        body: Stack(
          children: [
            FlutterMap(
              mapController: _map,
              options: MapOptions(
                initialCenter: center,
                initialZoom: 14,
                minZoom: 3,
                maxZoom: 19,
                onPositionChanged: (_, hasGesture) {
                  if (hasGesture && _follow) setState(() => _follow = false);
                },
                onMapReady: () {
                  _mapReady = true;
                  if (_navigating && _me != null) {
                    _moveCamera(_me!);
                  } else {
                    _fitBounds();
                  }
                },
              ),
              children: [
                TileLayer(
                  urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                  userAgentPackageName: 'com.unganalink.app',
                ),
                if (ahead.length >= 2)
                  PolylineLayer(polylines: [
                    Polyline(
                      points: ahead,
                      strokeWidth: _navigating ? 8 : 5,
                      color: AppColors.primary,
                      borderStrokeWidth: 2,
                      borderColor: Colors.white,
                    ),
                  ]),
                MarkerLayer(markers: [
                  if (dest != null)
                    Marker(
                      point: dest,
                      width: 48,
                      height: 56,
                      alignment: Alignment.topCenter,
                      rotate: true, // stay upright while the map turns
                      child: const Icon(Icons.location_on_rounded, size: 48, color: AppColors.danger),
                    ),
                  if (_me != null)
                    Marker(
                      point: _me!,
                      width: 44,
                      height: 44,
                      rotate: !_navigating,
                      child: _navigating ? _carMarker() : _meDot(),
                    ),
                ]),
                const SimpleAttributionWidget(source: Text('© OpenStreetMap contributors')),
              ],
            ),

            // Top: turn banner while navigating, title bar otherwise.
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                child: _navigating && !_arrived ? _turnBanner() : _titleBar(),
              ),
            ),

            // Map buttons
            Positioned(
              right: 12,
              bottom: _navigating ? 190 : 300,
              child: Column(
                children: [
                  if (!_navigating) ...[
                    _roundButton(Icons.alt_route_rounded, _fitBounds),
                    const SizedBox(height: 10),
                  ],
                  _roundButton(
                    _follow ? Icons.my_location_rounded : Icons.location_searching_rounded,
                    _recenter,
                    active: _follow,
                  ),
                ],
              ),
            ),

            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: _arrived ? _arrivedCard() : (_navigating ? _navBottomBar() : _previewCard()),
            ),
          ],
        ),
      ),
    );
  }

  Widget _meDot() => Container(
        margin: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: AppColors.primary,
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white, width: 3),
          boxShadow: [BoxShadow(color: AppColors.primary.withValues(alpha: 0.35), blurRadius: 10, spreadRadius: 4)],
        ),
      );

  /// Arrow that always points "up": the map itself rotates with the heading.
  Widget _carMarker() => Container(
        decoration: BoxDecoration(
          color: AppColors.primary,
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white, width: 3),
          boxShadow: const [BoxShadow(color: Color(0x55000000), blurRadius: 8, offset: Offset(0, 3))],
        ),
        child: const Icon(Icons.navigation_rounded, color: Colors.white, size: 24),
      );

  Widget _titleBar() {
    return Row(
      children: [
        _roundButton(Icons.arrow_back_rounded, () => Navigator.pop(context)),
        const SizedBox(width: 10),
        Expanded(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(14), boxShadow: _shadow),
            child: Row(
              children: [
                const Icon(Icons.navigation_rounded, size: 18, color: AppColors.primary),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _en ? 'Navigation' : 'Mwongozo wa Safari',
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                  ),
                ),
                if (_loadingRoute) const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _turnBanner() {
    final route = _route;
    final prog = _progress;
    if (route == null || prog == null) return _titleBar();
    final si = _nextStep.clamp(0, route.steps.length - 1).toInt();
    final step = route.steps[si];
    final metres = route.metresToStep(prog.index, si);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: AppColors.primaryDark,
        borderRadius: BorderRadius.circular(18),
        boxShadow: const [BoxShadow(color: Color(0x40000000), blurRadius: 14, offset: Offset(0, 4))],
      ),
      child: Row(
        children: [
          Icon(NavText.icon(step), color: Colors.white, size: 44),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  NavText.distance(metres, _en),
                  style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w900),
                ),
                Text(
                  NavText.instruction(step, _en),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
          if (_loadingRoute)
            const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)),
        ],
      ),
    );
  }

  Widget _sheet({required Widget child}) {
    return Container(
      padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).padding.bottom),
      decoration: const BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
        boxShadow: [BoxShadow(color: Color(0x1F000000), blurRadius: 16, offset: Offset(0, -4))],
      ),
      child: child,
    );
  }

  Widget _previewCard() {
    final prog = _progress;
    final ready = _route != null && prog != null;
    return _sheet(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: const BoxDecoration(color: AppColors.primaryLight, shape: BoxShape.circle),
                child: const Icon(Icons.storefront_rounded, color: AppColors.primary, size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(widget.providerName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                    if (widget.serviceTitle.trim().isNotEmpty)
                      Text(widget.serviceTitle,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              _stat(Icons.straighten_rounded, _en ? 'Distance' : 'Umbali',
                  ready ? NavText.distance(prog.remainingM, _en) : '--'),
              const SizedBox(width: 10),
              _stat(Icons.timer_outlined, _en ? 'ETA' : 'Muda', ready ? NavText.duration(prog.remainingS, _en) : '--'),
            ],
          ),
          if (widget.address.trim().isNotEmpty) ...[
            const SizedBox(height: 12),
            Row(
              children: [
                const Icon(Icons.location_on_outlined, size: 16, color: AppColors.textSecondary),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(widget.address,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                ),
              ],
            ),
          ],
          if (_dest == null && !_loadingRoute) ...[
            const SizedBox(height: 10),
            _notice(_en
                ? 'We could not find this provider\'s exact location yet.'
                : 'Hatukuweza kupata eneo kamili la mtoa huduma huyu bado.'),
          ],
          if (_routeFailed) ...[
            const SizedBox(height: 10),
            _notice(_en
                ? 'Road directions are unavailable (offline?). Showing a straight line.'
                : 'Maelekezo ya barabara hayapatikani (huna mtandao?). Inaonyesha mstari ulionyooka.'),
          ],
          if (_locationDenied) ...[
            const SizedBox(height: 10),
            _notice(
              _en ? 'Turn on location to see your position and the route.' : 'Washa eneo (location) ili uone nafasi yako na njia.',
              action: _en ? 'Enable' : 'Washa',
              onAction: () async {
                await Geolocator.openLocationSettings();
                _startTracking();
              },
            ),
          ],
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: ready ? _startNavigation : null,
              icon: const Icon(Icons.navigation_rounded, size: 18),
              label: Text(_en ? 'Start' : 'Anza Safari', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                foregroundColor: Colors.white,
                elevation: 0,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _openExternalMaps,
              icon: const Icon(Icons.map_rounded, size: 18),
              label: Text(_en ? 'Use Google Maps instead' : 'Tumia Ramani (Google Maps)',
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.primary,
                side: const BorderSide(color: AppColors.border),
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _navBottomBar() {
    final prog = _progress;
    final eta = prog == null ? null : DateTime.now().add(Duration(seconds: prog.remainingS.round()));
    String hhmm(DateTime t) => '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
    return _sheet(
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  prog == null ? '--' : NavText.duration(prog.remainingS, _en),
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AppColors.successDark),
                ),
                const SizedBox(height: 2),
                Text(
                  prog == null
                      ? ''
                      : '${NavText.distance(prog.remainingM, _en)}  •  ${_en ? 'Arrive' : 'Fika'} ${hhmm(eta!)}',
                  style: const TextStyle(fontSize: 13, color: AppColors.textSecondary, fontWeight: FontWeight.w600),
                ),
                Text(
                  widget.providerName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                ),
              ],
            ),
          ),
          IconButton(
            tooltip: _en ? 'Open in Google Maps' : 'Fungua Google Maps',
            onPressed: _openExternalMaps,
            icon: const Icon(Icons.map_rounded, color: AppColors.primary),
          ),
          const SizedBox(width: 4),
          ElevatedButton(
            onPressed: _confirmExit,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.danger,
              foregroundColor: Colors.white,
              elevation: 0,
              padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            child: Text(_en ? 'Exit' : 'Toka', style: const TextStyle(fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
  }

  Widget _arrivedCard() {
    return _sheet(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.check_circle_rounded, color: AppColors.success, size: 48),
          const SizedBox(height: 8),
          Text(_en ? 'You have arrived' : 'Umefika',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppColors.textPrimary)),
          const SizedBox(height: 4),
          Text(widget.providerName,
              textAlign: TextAlign.center, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () => Navigator.pop(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                foregroundColor: Colors.white,
                elevation: 0,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: Text(_en ? 'Done' : 'Sawa', style: const TextStyle(fontWeight: FontWeight.w800)),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _confirmExit() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(_en ? 'Stop navigation?' : 'Acha mwongozo wa safari?'),
        content: Text(_en ? 'You will leave turn-by-turn guidance.' : 'Utaacha kupata maelekezo ya kila zamu.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(_en ? 'Continue' : 'Endelea')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(_en ? 'Stop' : 'Acha', style: const TextStyle(color: AppColors.danger)),
          ),
        ],
      ),
    );
    if (ok == true && mounted) {
      _stopNavigation();
    }
  }

  Widget _stat(IconData icon, String label, String value) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: AppColors.background,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            Icon(icon, size: 18, color: AppColors.primary),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                Text(value, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _notice(String text, {String? action, VoidCallback? onAction}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(color: AppColors.warningLight, borderRadius: BorderRadius.circular(10)),
      child: Row(
        children: [
          const Icon(Icons.info_outline_rounded, size: 16, color: AppColors.warningDark),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 12, color: AppColors.warningDark))),
          if (action != null)
            TextButton(
              onPressed: onAction,
              style: TextButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 8), minimumSize: const Size(0, 30)),
              child: Text(action, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
            ),
        ],
      ),
    );
  }

  Widget _roundButton(IconData icon, VoidCallback onTap, {bool active = false}) {
    return Material(
      color: active ? AppColors.primary : AppColors.surface,
      shape: const CircleBorder(),
      elevation: 3,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(11),
          child: Icon(icon, size: 22, color: active ? Colors.white : AppColors.textPrimary),
        ),
      ),
    );
  }

  static const List<BoxShadow> _shadow = [BoxShadow(color: Color(0x1A000000), blurRadius: 10, offset: Offset(0, 3))];
}

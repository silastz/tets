import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../models/models.dart';
import '../constants/app_strings.dart';
import '../services/session_manager.dart';
import '../services/block_service.dart';
import '../widgets/block_user_dialog.dart';
import '../widgets/login_modal.dart';
import '../services/api_service.dart';
import '../widgets/app_image.dart';
import '../widgets/verification_badge.dart';
import '../widgets/call_options_sheet.dart';
import '../widgets/provider_contact_card.dart';
import '../widgets/sensitive_tag.dart';
import 'booking_request_screen.dart';
import 'chat_thread_screen.dart';

class SellerProfileScreen extends StatefulWidget {
  final ServiceItem provider;

  const SellerProfileScreen({
    super.key,
    required this.provider,
  });

  @override
  State<SellerProfileScreen> createState() => _SellerProfileScreenState();
}

class _SellerProfileScreenState extends State<SellerProfileScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  static const List<String> _fallbackImages = [
    'assets/images/banner.jpg',
    'assets/images/provider1.jpg',
    'assets/images/provider2.jpg',
  ];

  /// The provider's real services (same data Home / Category / Details show),
  /// always including the one the buyer came from.
  List<Map<String, String>> get _servicesOffered {
    final p = widget.provider;
    final mine = ApiService.knownServices.values
        .where((s) => s.id == p.id || (p.sellerId != null && s.sellerId == p.sellerId))
        .toList();
    if (!mine.any((s) => s.id == p.id)) mine.insert(0, p);
    return [
      for (int i = 0; i < mine.length; i++)
        {
          'id': mine[i].id,
          'title': mine[i].title,
          'duration': mine[i].durationText,
          'price': mine[i].priceText,
          'image': mine[i].imageUrls.isNotEmpty ? mine[i].imageUrls.first : _fallbackImages[i % _fallbackImages.length],
        },
    ];
  }

  String get _coverImage =>
      widget.provider.imageUrls.isNotEmpty ? widget.provider.imageUrls.first : 'assets/images/zeen_cover.jpg';

  String get _avatarImage => (widget.provider.sellerAvatar ?? '').isNotEmpty
      ? widget.provider.sellerAvatar!
      : 'assets/images/zeen_avatar.jpg';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 1. Top Cover Photo with Floating Avatar & Back Arrow
            SizedBox(
              height: 220,
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  // Full cover photo
                  Positioned.fill(
                    child: AppImage(
                      _coverImage,
                      fit: BoxFit.cover,
                      errorBuilder: (ctx, err, stack) => Container(
                        color: AppColors.slateDark,
                        child: const Icon(Icons.spa_rounded, color: Colors.white38, size: 60),
                      ),
                    ),
                  ),
                  // Back Button top left
                  Positioned(
                    top: MediaQuery.of(context).padding.top + 8,
                    left: 16,
                    child: GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.35),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.arrow_back_rounded, color: Colors.white, size: 20),
                      ),
                    ),
                  ),
                  // Block / unblock menu top right (not on your own profile)
                  if (widget.provider.sellerId != null &&
                      widget.provider.sellerId != 0 &&
                      widget.provider.sellerId != SessionManager.getUserIdValue())
                    Positioned(
                      top: MediaQuery.of(context).padding.top + 4,
                      right: 12,
                      child: ValueListenableBuilder<int>(
                        valueListenable: BlockService.changed,
                        builder: (ctx, _, _) {
                          final id = widget.provider.sellerId!;
                          final blocked = BlockService.isBlocked(id);
                          return Container(
                            decoration: BoxDecoration(color: Colors.black.withValues(alpha: 0.35), shape: BoxShape.circle),
                            child: PopupMenuButton<String>(
                              icon: const Icon(Icons.more_vert_rounded, color: Colors.white, size: 22),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              onSelected: (_) async {
                                if (!SessionManager.isLoggedIn()) {
                                  final ok = await LoginModal.show(context);
                                  if (ok != true || !context.mounted) return;
                                }
                                if (!context.mounted) return;
                                if (blocked) {
                                  await BlockUserDialog.confirmUnblock(context, userId: id, name: widget.provider.stageName);
                                } else {
                                  final done = await BlockUserDialog.confirmBlock(context, userId: id, name: widget.provider.stageName);
                                  if (done && context.mounted) Navigator.pop(context);
                                }
                              },
                              itemBuilder: (_) => [
                                PopupMenuItem(
                                  value: 'toggle',
                                  child: Row(
                                    children: [
                                      Icon(blocked ? Icons.lock_open_rounded : Icons.block_rounded,
                                          size: 18, color: blocked ? AppColors.primary : AppColors.danger),
                                      const SizedBox(width: 10),
                                      Text(
                                        blocked
                                            ? (AppStrings.isEnglish ? 'Unblock user' : 'Mfungulie mtumiaji')
                                            : (AppStrings.isEnglish ? 'Block user' : 'Mzuie mtumiaji'),
                                        style: TextStyle(fontWeight: FontWeight.w600, color: blocked ? AppColors.primary : AppColors.danger),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                  // Overlapping Circular Avatar bottom left
                  Positioned(
                    bottom: -32,
                    left: 20,
                    child: Container(
                      width: 76,
                      height: 76,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 3),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.12),
                            blurRadius: 8,
                            offset: const Offset(0, 3),
                          ),
                        ],
                      ),
                      child: ClipOval(
                        child: AppImage(
                          _avatarImage,
                          fit: BoxFit.cover,
                          errorBuilder: (ctx, err, stack) => Container(
                            color: AppColors.primary,
                            child: const Icon(Icons.person, color: Colors.white, size: 40),
                          ),
                        ),
                      ),
                    ),
                  ),
                  // Verification pill bottom right (colour follows the provider's level)
                  if (widget.provider.isVerified)
                    Positioned(
                      bottom: 12,
                      right: 18,
                      child: VerificationPill(level: widget.provider.verificationLevel),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 38),

            // 2. Profile Info Section
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Title + Blue Check Badge
                  Row(
                    children: [
                      Text(
                        widget.provider.stageName.isNotEmpty ? widget.provider.stageName : widget.provider.title,
                        style: const TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.w800,
                          color: AppColors.textPrimary,
                          letterSpacing: -0.3,
                        ),
                      ),
                      if (widget.provider.isVerified) ...[
                        const SizedBox(width: 5),
                        VerificationBadge(level: widget.provider.verificationLevel, size: 18),
                      ],
                    ],
                  ),
                  const SizedBox(height: 5),

                  // Rating with Star
                  Row(
                    children: [
                      const Icon(Icons.star_rounded, color: AppColors.categoryElectrical, size: 17),
                      const SizedBox(width: 3),
                      Text(
                        '${widget.provider.rating}',
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: AppColors.goldStar,
                        ),
                      ),
                      const SizedBox(width: 3),
                      Text(
                        '(${widget.provider.reviewsCount} reviews)',
                        style: const TextStyle(
                          fontSize: 12,
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),

                  // Member since info
                  Row(
                    children: const [
                      Icon(Icons.person_outline_rounded, size: 14, color: AppColors.textSecondary),
                      SizedBox(width: 4),
                      Text(
                        'Member since March 2025',
                        style: TextStyle(
                          fontSize: 11,
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),

                  // Stats Boxes: 24 Completed Services / 28 Total Bookings
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          decoration: BoxDecoration(
                            color: AppColors.background,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: AppColors.border),
                          ),
                          child: Row(
                            children: const [
                              Icon(Icons.verified_user_outlined, size: 20, color: AppColors.textPrimary),
                              SizedBox(width: 10),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    '24',
                                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                                  ),
                                  Text(
                                    'Completed Services',
                                    style: TextStyle(fontSize: 10, color: AppColors.textSecondary),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          decoration: BoxDecoration(
                            color: AppColors.background,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: AppColors.border),
                          ),
                          child: Row(
                            children: const [
                              Icon(Icons.calendar_today_outlined, size: 18, color: AppColors.textPrimary),
                              SizedBox(width: 10),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    '28',
                                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                                  ),
                                  Text(
                                    'Total Bookings',
                                    style: TextStyle(fontSize: 10, color: AppColors.textSecondary),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // Action Buttons: Blue "Message" Pill & White Call Button (respects lock)
                  Row(
                    children: [
                      Expanded(
                        child: SizedBox(
                          height: 44,
                          child: ElevatedButton.icon(
                            onPressed: () => ChatThreadScreen.open(
                              context,
                              recipientId: widget.provider.sellerId,
                              name: widget.provider.stageName,
                            ),
                            icon: const Icon(Icons.chat_bubble_rounded, size: 16),
                            label: const Text('Message'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.primary,
                              foregroundColor: Colors.white,
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(24),
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Container(
                        height: 44,
                        width: 52,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(color: AppColors.border),
                        ),
                        child: IconButton(
                          icon: const Icon(Icons.phone_rounded, color: AppColors.primary, size: 18),
                          onPressed: () => CallOptionsSheet.show(context, widget.provider),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            // Contact & socials (hidden while the provider's profile / service is Locked)
            ProviderContactCard(provider: widget.provider),
            if (widget.provider.is18Plus)
              const Padding(
                padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                child: Align(alignment: Alignment.centerLeft, child: SensitiveTag()),
              ),
            const SizedBox(height: 14),

            // 3. Tab Bar: Services, Portfolio, Reviews, About
            Container(
              decoration: const BoxDecoration(
                border: Border(
                  bottom: BorderSide(color: AppColors.border, width: 1),
                ),
              ),
              child: TabBar(
                controller: _tabController,
                indicatorColor: AppColors.primary,
                indicatorWeight: 2.5,
                labelColor: AppColors.primary,
                unselectedLabelColor: AppColors.textSecondary,
                labelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
                unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w500, fontSize: 13),
                tabs: const [
                  Tab(text: 'Services'),
                  Tab(text: 'Portfolio'),
                  Tab(text: 'Reviews'),
                  Tab(text: 'About'),
                ],
              ),
            ),

            // 4. Services Section Title
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 10),
              child: const Text(
                'Services',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                  color: AppColors.textPrimary,
                ),
              ),
            ),

            // 5. Services List with Thumbnails matching Screen 4
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                children: _servicesOffered.map((svc) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: InkWell(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            // The tapped service itself, so the booking charges ITS price and id.
                            builder: (_) => BookingRequestScreen(
                              provider: ApiService.knownServices[svc['id']] ?? widget.provider,
                              serviceTitle: svc['title']!,
                              priceText: svc['price']!,
                              durationText: svc['duration']!,
                            ),
                          ),
                        );
                      },
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Row(
                          children: [
                            // Left Rounded Photo Thumbnail
                            ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: SizedBox(
                                width: 54,
                                height: 54,
                                child: AppImage(
                                  svc['image']!,
                                  fit: BoxFit.cover,
                                  errorBuilder: (ctx, err, stack) => Container(
                                    color: AppColors.border,
                                    child: const Icon(Icons.spa_rounded, color: AppColors.textMuted),
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 14),
                            // Title & Price subtitle
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    svc['title']!,
                                    style: const TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w700,
                                      color: AppColors.textPrimary,
                                    ),
                                  ),
                                  const SizedBox(height: 3),
                                  Text(
                                    [svc['duration'], svc['price']].where((e) => (e ?? '').trim().isNotEmpty).join(' • '),
                                    style: const TextStyle(
                                      fontSize: 11,
                                      color: AppColors.textSecondary,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            // Chevron right rounded inside circle
                            Container(
                              width: 28,
                              height: 28,
                              decoration: const BoxDecoration(
                                color: AppColors.background,
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted, size: 18),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/location_service.dart';
import '../services/gps_service.dart';
import '../services/permission_service.dart';
import '../services/session_manager.dart';

class StartupPermissionsModal extends StatelessWidget {
  const StartupPermissionsModal({super.key});

  static bool _shownThisLaunch = false;

  /// Runs on every app launch: shows the prompt again whenever location or
  /// notifications are still not allowed. Once both are granted it stays quiet.
  static Future<void> checkAndShow(BuildContext context) async {
    if (_shownThisLaunch) return;
    if (await PermissionService.allGranted()) return;
    _shownThisLaunch = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (context.mounted) show(context);
    });
  }

  static Future<void> show(BuildContext context) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      isDismissible: false,
      enableDrag: false,
      backgroundColor: Colors.transparent,
      builder: (_) => const StartupPermissionsModal(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Drag Handle
            Center(
              child: Container(
                width: 44,
                height: 4,
                decoration: BoxDecoration(
                  color: AppColors.border,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 18),

            // Top Icon Badge
            Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: AppColors.primaryLight,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Icon(
                    Icons.verified_user_rounded,
                    color: AppColors.primary,
                    size: 26,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        AppStrings.permWelcomeTitle,
                        style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w800,
                          color: AppColors.textPrimary,
                          letterSpacing: -0.3,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        AppStrings.appName,
                        style: const TextStyle(
                          fontSize: 12,
                          color: AppColors.primary,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            Text(
              AppStrings.permWelcomeSubtitle,
              style: const TextStyle(
                fontSize: 13,
                color: AppColors.textSecondary,
                height: 1.4,
              ),
            ),
            const SizedBox(height: 20),

            // 1. Location Permission Card
            _buildPermissionItem(
              icon: Icons.location_on_rounded,
              iconColor: AppColors.primary,
              iconBg: AppColors.primaryLight,
              title: AppStrings.permLocationTitle,
              desc: AppStrings.permLocationDesc,
            ),
            const SizedBox(height: 12),

            // 2. Notification Permission Card
            _buildPermissionItem(
              icon: Icons.notifications_active_rounded,
              iconColor: const Color(0xFFF59E0B),
              iconBg: const Color(0xFFFEF3C7),
              title: AppStrings.permNotificationTitle,
              desc: AppStrings.permNotificationDesc,
            ),
            const SizedBox(height: 24),

            // Primary "Allow & Continue" Button
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                onPressed: () async {
                  // Previously denied for good: the OS won't ask again, so open Settings.
                  if (await PermissionService.needsSettings()) {
                    await PermissionService.openSettings();
                    if (context.mounted) Navigator.pop(context);
                    return;
                  }
                  // Real OS permission dialogs: location first, then notifications
                  final locationGranted = await PermissionService.requestLocation();
                  await PermissionService.requestNotifications();
                  await SessionManager.markStartupPermissionsPrompted();
                  if (context.mounted) Navigator.pop(context);
                  // Detect the user's city only when location was allowed
                  if (locationGranted) {
                    LocationService.detectCurrentLocation(forceRefresh: true);
                    GpsService.refresh(forceSync: true);
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                child: Text(
                  AppStrings.permAllowButton,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 10),

            // Secondary "Maybe Later" Button
            Center(
              child: TextButton(
                onPressed: () async {
                  await SessionManager.markStartupPermissionsPrompted();
                  if (context.mounted) Navigator.pop(context);
                },
                child: Text(
                  AppStrings.permMaybeLaterButton,
                  style: const TextStyle(
                    color: AppColors.textSecondary,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPermissionItem({
    required IconData icon,
    required Color iconColor,
    required Color iconBg,
    required String title,
    required String desc,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.background,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: iconBg,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: iconColor, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  desc,
                  style: const TextStyle(
                    fontSize: 11,
                    color: AppColors.textSecondary,
                    height: 1.35,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

import '../constants/app_strings.dart';

/// Rules for NEW passwords (sign-up and reset). Login never applies them, so old accounts still work.
///
/// Common passwords are caught even when disguised:
///   "Password1", "P@ssw0rd!", "qwerty2024", "Ungana#123", "Simba1234", "abcd1234", "12341234"
class PasswordPolicy {
  PasswordPolicy._();

  static const int minLength = 8;

  /// Most-used passwords worldwide + East-African favourites + app words (lowercase, no symbols).
  static const Set<String> _common = {
    // global top
    'password', 'passw0rd', 'pass', 'passcode', 'letmein', 'welcome', 'login', 'admin', 'administrator',
    'root', 'master', 'secret', 'qwerty', 'qwertyuiop', 'qwertyui', 'asdfgh', 'asdfghjk', 'asdfghjkl',
    'zxcvbn', 'zxcvbnm', 'azerty', 'iloveyou', 'iloveu', 'monkey', 'dragon', 'football', 'baseball',
    'soccer', 'superman', 'batman', 'trustno1', 'sunshine', 'princess', 'shadow', 'michael', 'jennifer',
    'jordan', 'harley', 'ranger', 'buster', 'hunter', 'freedom', 'whatever', 'starwars', 'cheese',
    'killer', 'access', 'flower', 'hello', 'hellohello', 'default', 'guest', 'test', 'testing', 'test1234',
    'user', 'changeme', 'abc123', 'abcd1234', 'abcdefgh', 'abcdefg1', 'abc12345', 'a1b2c3d4', 'aa123456',
    'qazwsx', 'qazwsxedc', '1q2w3e4r', '1q2w3e', 'q1w2e3r4', '1qaz2wsx', 'zaq12wsx', 'googledummy',
    'computer', 'internet', 'mypassword', 'myname', 'nopassword', 'newpassword', 'password1', 'password12',
    'password123', 'password1234', 'welcome1', 'welcome123', 'letmein1', 'admin123', 'admin1234',
    // East Africa / Swahili
    'nenosiri', 'nenosiri1', 'nenosiri123', 'siri', 'siri1234', 'karibu', 'karibu123', 'asante', 'asante123',
    'mungu', 'mungu123', 'mungu1234', 'mungumkubwa', 'yesu', 'yesu123', 'bwana', 'baraka', 'baraka123',
    'upendo', 'upendo123', 'mama', 'mama1234', 'baba', 'baba1234', 'simba', 'simba123', 'simba1234',
    'tanzania', 'tanzania1', 'tanzania123', 'kenya', 'kenya123', 'uganda', 'uganda123', 'rwanda', 'rwanda123',
    'dodoma', 'dodoma123', 'dar', 'darsalaam', 'arusha', 'mwanza', 'zanzibar', 'zanzibar1', 'nairobi',
    'kampala', 'kilimanjaro', 'jambo', 'jambo123', 'hakuna', 'hakunamatata', 'pesa', 'pesa123', 'pesa1234',
    'mpesa', 'mpesa123', 'tigopesa', 'airtel', 'airtelmoney', 'vodacom', 'halotel', 'crdb', 'nmb',
    // this app
    'ungana', 'ungana1', 'ungana12', 'ungana123', 'ungana1234', 'nearby', 'nearby123', 'nearbyservices',
    'techware', 'techwareafrica',
  };

  static const List<String> _keyboardRows = [
    '1234567890', 'qwertyuiop', 'asdfghjkl', 'zxcvbnm', '1qaz2wsx3edc', 'qazwsxedc', '0987654321',
    'poiuytrewq', 'lkjhgfdsa', 'mnbvcxz',
  ];

  /// "P@ssw0rd" -> "password"
  static String _deLeet(String s) {
    const map = {'@': 'a', '4': 'a', '3': 'e', '1': 'i', '!': 'i', '|': 'i', '0': 'o', '5': 's', r'$': 's', '7': 't', '+': 't', '8': 'b', '9': 'g'};
    final b = StringBuffer();
    for (final c in s.split('')) {
      b.write(map[c] ?? c);
    }
    return b.toString();
  }

  /// Removes trailing digits/symbols and a leading digit run ("simba2024!" -> "simba").
  static String _core(String s) => s.replaceAll(RegExp(r'^[\d\W_]+|[\d\W_]+$'), '');

  static bool _isCommon(String password) {
    final lower = password.toLowerCase();
    final plain = lower.replaceAll(RegExp(r'[^a-z0-9]'), '');
    final candidates = <String>{
      lower,
      plain,
      _core(lower),
      _deLeet(lower).replaceAll(RegExp(r'[^a-z0-9]'), ''),
      _core(_deLeet(lower)),
      _core(plain),
    }..removeWhere((e) => e.isEmpty);
    if (candidates.any(_common.contains)) return true;
    // common word + digits/year, e.g. "password2024", "qwerty!!!", "iloveyou99"
    for (final c in candidates) {
      for (final w in _common) {
        if (w.length >= 5 && c.startsWith(w) && c.length - w.length <= 5) return true;
      }
    }
    return false;
  }

  /// One character repeated (aaaaaaaa) or a short chunk repeated (abab1abab1, 12341234).
  static bool _isRepetitive(String p) {
    if (RegExp(r'^(.)\1+$').hasMatch(p)) return true;
    for (var n = 2; n <= p.length ~/ 2; n++) {
      final chunk = p.substring(0, n);
      final reps = (p.length / n).ceil();
      if (chunk * reps == p || (chunk * reps).startsWith(p)) return true;
    }
    return false;
  }

  /// 12345678, 87654321, abcdefgh, qwertyui, 1qaz2wsx ... (a run of 6+ of the password's chars)
  static bool _isSequence(String p) {
    final lower = p.toLowerCase();
    final stripped = lower.replaceAll(RegExp(r'[^a-z0-9]'), '');
    if (stripped.length < 6) return false;
    const abc = 'abcdefghijklmnopqrstuvwxyz';
    const digitsSeq = '01234567890123456789';
    for (final seq in [abc, digitsSeq, ..._keyboardRows]) {
      final rev = seq.split('').reversed.join();
      for (final s in [seq, rev]) {
        // the whole password (ignoring symbols) lives inside one sequence, or starts with 6+ of it
        if (s.contains(stripped)) return true;
        for (var i = 0; i + 6 <= s.length; i++) {
          if (stripped.startsWith(s.substring(i, i + 6))) return true;
        }
      }
    }
    return false;
  }

  /// Returns an error message (already translated) or null when the password is acceptable.
  static String? validate(String password, {String? phoneOrId}) {
    if (password.length < minLength) return AppStrings.authPasswordHint;
    final hasLetter = RegExp(r'[A-Za-z]').hasMatch(password);
    final hasDigit = RegExp(r'\d').hasMatch(password);
    if (!hasLetter || !hasDigit) return AppStrings.authPasswordHint;
    // At least 4 different characters.
    if (password.split('').toSet().length < 4) return AppStrings.authPasswordWeakError;
    if (_isCommon(password) || _isRepetitive(password.toLowerCase()) || _isSequence(password)) {
      return AppStrings.authPasswordWeakError;
    }
    if (phoneOrId != null && phoneOrId.trim().isNotEmpty) {
      final digits = phoneOrId.replaceAll(RegExp(r'\D'), '');
      final id = phoneOrId.toLowerCase().trim();
      final lower = password.toLowerCase();
      if (digits.length >= 6 && password.replaceAll(RegExp(r'\D'), '').contains(digits.substring(digits.length - 6))) {
        return AppStrings.authPasswordWeakError; // contains the user's own number
      }
      if (id.length >= 4 && !id.startsWith('+') && lower.contains(id)) return AppStrings.authPasswordWeakError;
    }
    return null;
  }
}

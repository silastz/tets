import 'dart:math' as math;
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import '../widgets/app_image.dart';
import '../widgets/video_player_screen.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/location_service.dart';
import '../services/permission_service.dart';
import '../services/session_manager.dart';

/// Full-page Add / Edit Service flow (replaces the old bottom-sheet modal).
/// Looks and behaves like the "Register as Service Provider" page:
/// app bar + step indicator + labelled fields + bottom Continue button.
///
/// Pass [existing] (a service map from fetchSellerServices) to edit.
/// Pops with `true` when a service was saved.
class AddEditServiceScreen extends StatefulWidget {
  final Map<String, dynamic>? existing;

  const AddEditServiceScreen({super.key, this.existing});

  @override
  State<AddEditServiceScreen> createState() => _AddEditServiceScreenState();
}

class _AddEditServiceScreenState extends State<AddEditServiceScreen> {
  static const List<String> _categories = ['Cleaning', 'Beauty', 'Plumbing', 'Electrical', 'Repair', 'Food', 'General'];

  /// Quick-pick features per category (tap to add; sellers can also type their own).
  static const List<String> _foodFeatures = [
    'Soup', 'Pizza', 'Eggs', 'Sandwich', 'Burger', 'Chips', 'Chicken', 'Fish',
    'Rice', 'Pilau', 'Ugali', 'Chapati', 'Samosa', 'Mandazi', 'Salad', 'Pasta',
    'Juice', 'Smoothie', 'Coffee', 'Tea', 'Cake', 'Ice Cream',
  ];
  static const Map<String, List<String>> _featureSuggestions = {
    'Cleaning': ['Home Cleaning', 'Office Cleaning', 'Laundry', 'Carpet Cleaning', 'Window Cleaning', 'Deep Cleaning'],
    'Beauty': ['Haircut', 'Braiding', 'Makeup', 'Manicure', 'Pedicure', 'Facial', 'Massage'],
    'Plumbing': ['Pipe Repair', 'Leak Fixing', 'Drain Cleaning', 'Water Heater', 'Tap Installation'],
    'Electrical': ['Wiring', 'Lighting', 'Socket Repair', 'CCTV Installation', 'Solar Setup'],
    'Repair': ['Phone Repair', 'Laptop Repair', 'Appliance Repair', 'Furniture Repair', 'Car Repair'],
    'General': ['Home Visit', 'Delivery', 'Same-day Service', 'Free Quote', 'Warranty'],
  };

  final _titleController = TextEditingController();
  final _descController = TextEditingController();
  final _priceController = TextEditingController();
  final _phoneController = TextEditingController();
  final _instagramController = TextEditingController();
  final _facebookController = TextEditingController();
  final _tiktokController = TextEditingController();
  final _xController = TextEditingController();
  final _youtubeController = TextEditingController();
  final _emailController = TextEditingController();
  final _areaController = TextEditingController();

  static const List<String> _dayKeys = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  static const List<String> _radiusOptions = ['2 km', '5 km', '10 km', '15 km', '20 km', 'All city'];
  static const List<String> _priceTypes = ['FIXED', 'STARTING_FROM', 'PER_HOUR'];
  static final List<int> _durations = [30, 45, 60, 90, 120, 180, 240];

  String _city = LocationService.supportedRegions.first;
  String _radius = '5 km';
  String _priceType = 'STARTING_FROM';
  int _duration = 60;
  bool _hasDuration = false; // default: price only, no duration
  final Set<String> _days = {'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'};
  TimeOfDay _from = const TimeOfDay(hour: 8, minute: 0);
  TimeOfDay _to = const TimeOfDay(hour: 18, minute: 0);

  String _category = 'Cleaning';
  bool _isInfoLocked = true;
  bool _is18Plus = false;
  bool _isSubmitting = false;
  int _step = 0; // 0: Details, 1: Pricing & Contacts, 2: Photos & Video
  final List<String> _features = [];
  final _featureController = TextEditingController();
  final List<String> _images = []; // index 0 is the featured (cover) photo
  final List<_PendingUpload> _pendingPhotos = [];
  int get _uploadingPhotos => _pendingPhotos.length;
  static const int _maxPhotos = 8;
  final List<String> _videos = [];
  final List<_PendingUpload> _pendingVideos = [];
  static const int _maxVideos = 6;
  static const int _maxVideoMb = 100;
  static const int _maxVideoSeconds = 60;
  final ImagePicker _picker = ImagePicker();

  bool get _isEdit => widget.existing != null;
  bool get _isEn => AppStrings.isEnglish;

  @override
  void initState() {
    super.initState();
    final saved = LocationService.currentCity;
    if (saved.isNotEmpty) _city = saved;
    final e = widget.existing;
    if (e != null) {
      _city = (e['city'] ?? _city).toString();
      _areaController.text = (e['area'] ?? '').toString();
      _emailController.text = (e['email'] ?? '').toString();
      _instagramController.text = (e['instagramUsername'] ?? '').toString();
      _facebookController.text = (e['facebookUsername'] ?? '').toString();
      _tiktokController.text = (e['tiktokUsername'] ?? '').toString();
      _xController.text = (e['xUsername'] ?? '').toString();
      _youtubeController.text = (e['youtubeUsername'] ?? '').toString();
      final r = e['serviceRadiusKm'];
      if (r is num && _radiusOptions.contains('${r.toInt()} km')) _radius = '${r.toInt()} km';
      final pt = e['priceType']?.toString();
      if (pt != null && _priceTypes.contains(pt)) _priceType = pt;
      final dm = e['durationMinutes'];
      if (dm is num && dm.toInt() > 0) {
        _hasDuration = true;
        _duration = dm.toInt();
        if (!_durations.contains(_duration)) _durations.add(_duration); // keep a custom saved value
      }
      final ad = e['availableDays'];
      if (ad is List && ad.isNotEmpty) {
        _days
          ..clear()
          ..addAll(ad.map((x) => x.toString()).where(_dayKeys.contains));
      }
      _from = _parseTime(e['availableFrom']?.toString()) ?? _from;
      _to = _parseTime(e['availableTo']?.toString()) ?? _to;
      _titleController.text = (e['title'] ?? '').toString();
      _descController.text = (e['description'] ?? '').toString();
      final price = (e['price'] as num?)?.toInt();
      _priceController.text = price != null && price > 0 ? price.toString() : '';
      _phoneController.text = (e['phone'] ?? e['whatsappPhone'] ?? '').toString();
      _category = (e['category'] ?? 'General').toString();
      _isInfoLocked = e['isInfoLocked'] != false;
      _is18Plus = e['is18Plus'] == true;
      final fl = e['features'];
      if (fl is List) {
        _features.addAll(fl.map((x) => (x is Map ? (x['name'] ?? '') : x).toString().trim()).where((x) => x.isNotEmpty));
      }
      _images.addAll(((e['imageUrls'] as List?) ?? const []).map((x) => x.toString()));
      final feat = (e['featuredImageUrl'] ?? e['featuredImage'] ?? e['coverImage'])?.toString();
      if (feat != null && feat.isNotEmpty) {
        final fi = _images.indexOf(feat);
        if (fi > 0) _images.insert(0, _images.removeAt(fi));
      }
      _videos.addAll(((e['videoUrls'] as List?) ?? const []).map((x) => x.toString()).where((x) => x.startsWith('http')));
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descController.dispose();
    _priceController.dispose();
    _phoneController.dispose();
    _instagramController.dispose();
    _facebookController.dispose();
    _tiktokController.dispose();
    _xController.dispose();
    _youtubeController.dispose();
    _emailController.dispose();
    _areaController.dispose();
    _featureController.dispose();
    super.dispose();
  }

  void _snack(String msg, {Color? color}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: color));
  }

  TimeOfDay? _parseTime(String? v) {
    if (v == null) return null;
    final m = RegExp(r'^(\d{1,2}):(\d{2})').firstMatch(v);
    if (m == null) return null;
    final h = int.parse(m.group(1)!), mi = int.parse(m.group(2)!);
    if (h > 23 || mi > 59) return null;
    return TimeOfDay(hour: h, minute: mi);
  }

  String _fmt24(TimeOfDay t) =>
      '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

  bool _validEmail(String v) => RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(v);

  /// Error message if [step] is not fulfilled yet, else null.
  String? _stepError(int step) {
    switch (step) {
      case 0:
        if (_titleController.text.trim().length < 3) return AppStrings.sellServiceTitleHint;
        if (_city.trim().isEmpty) return _isEn ? 'Select the city of your service' : 'Chagua mji wa huduma yako';
        if (_descController.text.trim().length < 20) {
          return _isEn
              ? 'Describe your service (at least 20 characters)'
              : 'Eleza huduma yako (angalau herufi 20)';
        }
        return null;
      case 1:
        final price = double.tryParse(_priceController.text.replaceAll(',', '').trim()) ?? 0;
        if (price <= 0) return _isEn ? 'Enter a valid starting price' : 'Weka bei sahihi ya huduma';
        final digits = _phoneController.text.replaceAll(RegExp(r'\D'), '');
        if (digits.length < 9) {
          return _isEn ? 'Enter a valid phone / WhatsApp number' : 'Weka namba sahihi ya simu / WhatsApp';
        }
        final email = _emailController.text.trim();
        if (email.isNotEmpty && !_validEmail(email)) {
          return _isEn ? 'Enter a valid email address' : 'Weka barua pepe sahihi';
        }
        if (_days.isEmpty) {
          return _isEn ? 'Select at least one available day' : 'Chagua angalau siku moja unayopatikana';
        }
        if (_from.hour * 60 + _from.minute >= _to.hour * 60 + _to.minute) {
          return _isEn ? 'Closing time must be after opening time' : 'Muda wa kufunga lazima uwe baada ya kufungua';
        }
        return null;
      case 2:
        if (_images.isEmpty) return _isEn ? 'Add at least one service photo' : 'Ongeza angalau picha moja ya huduma';
        return null;
      default:
        return null;
    }
  }

  /// Jump to [target] only when every step before it is fulfilled.
  void _goToStep(int target) {
    if (target == _step) return;
    if (target > _step) {
      for (int i = 0; i < target; i++) {
        final err = _stepError(i);
        if (err != null) {
          setState(() => _step = i);
          _snack(err);
          return;
        }
      }
    }
    setState(() => _step = target);
  }

  Future<void> _onContinue() async {
    final err = _stepError(_step);
    if (err != null) {
      _snack(err);
      return;
    }
    if (_step < 2) {
      setState(() => _step++);
      return;
    }
    await _submit();
  }

  Future<void> _submit() async {
    final title = _titleController.text.trim();
    final desc = _descController.text.trim();
    final price = double.tryParse(_priceController.text.replaceAll(',', '').trim()) ?? 0;
    final phone = _phoneController.text.trim();

    if (_uploadingPhotos > 0 || _pendingVideos.isNotEmpty) {
      _snack(_isEn ? 'Please wait, your uploads are still in progress' : 'Subiri, faili bado zinapakiwa');
      return;
    }

    for (int i = 0; i < 3; i++) {
      final err = _stepError(i);
      if (err != null) {
        setState(() => _step = i);
        _snack(err);
        return;
      }
    }

    final navigator = Navigator.of(context);
    final messenger = ScaffoldMessenger.of(context);
    setState(() => _isSubmitting = true);

    final Map<String, dynamic>? res;
    if (_isEdit) {
      res = await ApiService.updateServicePost(
        id: widget.existing!['id'].toString(),
        title: title,
        description: desc.isNotEmpty ? desc : 'Huduma ya ubora kutoka kwa mtaalamu.',
        category: _category,
        price: price,
        phone: phone.isNotEmpty ? phone : null,
        whatsappPhone: phone.isNotEmpty ? phone : null,
        isInfoLocked: _isInfoLocked,
        imageUrls: _images,
        videoUrls: _videos,
        is18Plus: _is18Plus,
        city: _city,
        email: _emailController.text.trim().isNotEmpty ? _emailController.text.trim() : null,
        area: _areaController.text,
        serviceRadiusKm: _radius == 'All city' ? 0 : int.tryParse(_radius.replaceAll(RegExp(r'\D'), '')),
        priceType: _priceType,
        durationMinutes: _hasDuration ? _duration : null,
        availableDays: _dayKeys.where(_days.contains).toList(),
        availableFrom: _fmt24(_from),
        availableTo: _fmt24(_to),
        instagramUsername: _instagramController.text,
        facebookUsername: _facebookController.text,
        tiktokUsername: _tiktokController.text,
        xUsername: _xController.text,
        youtubeUsername: _youtubeController.text,
        features: List<String>.from(_features),
        featuredImageUrl: _images.isNotEmpty ? _images.first : null,
      );
    } else {
      res = await ApiService.createServicePost(
        title: title,
        description: desc.isNotEmpty ? desc : 'Huduma ya ubora kutoka kwa mtaalamu.',
        category: _category,
        price: price,
        phone: phone.isNotEmpty ? phone : null,
        whatsappPhone: phone.isNotEmpty ? phone : null,
        isInfoLocked: _isInfoLocked,
        imageUrls: _images,
        videoUrls: _videos,
        is18Plus: _is18Plus,
        city: _city,
        email: _emailController.text.trim().isNotEmpty ? _emailController.text.trim() : null,
        area: _areaController.text,
        serviceRadiusKm: _radius == 'All city' ? 0 : int.tryParse(_radius.replaceAll(RegExp(r'\D'), '')),
        priceType: _priceType,
        durationMinutes: _hasDuration ? _duration : null,
        availableDays: _dayKeys.where(_days.contains).toList(),
        availableFrom: _fmt24(_from),
        availableTo: _fmt24(_to),
        instagramUsername: _instagramController.text,
        facebookUsername: _facebookController.text,
        tiktokUsername: _tiktokController.text,
        xUsername: _xController.text,
        youtubeUsername: _youtubeController.text,
        features: List<String>.from(_features),
        featuredImageUrl: _images.isNotEmpty ? _images.first : null,
      );
    }

    if (res != null) {
      if (!_isEdit) await SessionManager.updateRole('ROLE_SELLER');
      messenger.showSnackBar(
        SnackBar(
          backgroundColor: AppColors.success,
          content: Text(_isEdit ? (_isEn ? 'Service updated' : 'Huduma imehaririwa') : AppStrings.sellPublishSuccess),
        ),
      );
      navigator.pop(true);
    } else {
      if (mounted) setState(() => _isSubmitting = false);
      messenger.showSnackBar(
        SnackBar(backgroundColor: AppColors.danger, content: Text(ApiService.lastServiceError ?? AppStrings.sellPublishError)),
      );
    }
  }

  // ---------------------------------------------------------------
  // BUILD
  // ---------------------------------------------------------------
  @override
  Widget build(BuildContext context) {
    final cats = _categories.contains(_category) ? _categories : [..._categories, _category];

    return PopScope(
      canPop: _step == 0,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop && _step > 0) setState(() => _step--);
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          centerTitle: false,
          titleSpacing: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18, color: AppColors.textPrimary),
            onPressed: () {
              if (_step > 0) {
                setState(() => _step--);
              } else {
                Navigator.pop(context);
              }
            },
          ),
          title: Text(
            _isEdit ? (_isEn ? 'Edit Service' : 'Hariri Huduma') : AppStrings.sellPostNewTitle,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
          ),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(1),
            child: Container(color: AppColors.borderLight, height: 1),
          ),
        ),
        body: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: Column(
                children: [
                  _buildStepIndicator(),
                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                      child: _buildStepContent(cats),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      border: Border(top: BorderSide(color: AppColors.borderLight)),
                    ),
                    child: SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        onPressed: _isSubmitting ? null : _onContinue,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primary,
                          elevation: 0,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        child: _isSubmitting
                            ? const SizedBox(
                                width: 22,
                                height: 22,
                                child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.2),
                              )
                            : Text(
                                _step == 2
                                    ? (_isEdit ? (_isEn ? 'Save Changes' : 'Hifadhi Mabadiliko') : AppStrings.sellPublishButton)
                                    : AppStrings.regBtnContinue,
                                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: Colors.white),
                              ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStepIndicator() {
    final labels = [
      _isEn ? 'Details' : 'Taarifa',
      _isEn ? 'Pricing' : 'Bei',
      _isEn ? 'Media' : 'Picha & Video',
    ];

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: AppColors.borderLight)),
      ),
      child: Row(
        children: List.generate(labels.length, (index) {
          final isCompleted = _step > index;
          final isCurrent = _step == index;

          return Expanded(
            child: Row(
              children: [
                Expanded(
                  child: InkWell(
                    onTap: () => _goToStep(index),
                    borderRadius: BorderRadius.circular(8),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 28,
                          height: 28,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: (isCompleted || isCurrent) ? AppColors.primary : Colors.white,
                            border: Border.all(
                              color: (isCompleted || isCurrent) ? AppColors.primary : AppColors.border,
                              width: 1.5,
                            ),
                          ),
                          child: Center(
                            child: isCompleted
                                ? const Icon(Icons.check, size: 16, color: Colors.white)
                                : Text(
                                    '${index + 1}',
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      color: isCurrent ? Colors.white : AppColors.textMuted,
                                    ),
                                  ),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          labels[index],
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: isCurrent ? FontWeight.w700 : FontWeight.w500,
                            color: isCurrent ? AppColors.primary : AppColors.textSecondary,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ),
                if (index < labels.length - 1)
                  Container(
                    width: 20,
                    height: 1.5,
                    color: _step > index ? AppColors.primary : AppColors.border,
                  ),
              ],
            ),
          );
        }),
      ),
    );
  }

  Widget _buildStepContent(List<String> cats) {
    switch (_step) {
      case 0:
        return _stepDetails(cats);
      case 1:
        return _stepPricing();
      default:
        return _stepMedia();
    }
  }

  // ---------------- Step 1: Service Details ----------------
  Widget _stepDetails(List<String> cats) {
    final regions = LocationService.supportedRegions.contains(_city)
        ? LocationService.supportedRegions
        : [...LocationService.supportedRegions, _city];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionHeader(
          '1. ${_isEn ? 'Service Details' : 'Taarifa za Huduma'}',
          _isEn ? 'Tell clients about your service' : 'Waeleze wateja kuhusu huduma yako',
        ),
        _inputField(
          controller: _titleController,
          label: AppStrings.sellServiceTitleLabel,
          hint: _isEn ? 'e.g. Professional Full Body Massage' : 'Mfano: Professional Full Body Massage',
          icon: Icons.design_services_outlined,
        ),
        const SizedBox(height: 14),
        _label(_isEn ? 'Category' : 'Kundi la Huduma (Category)'),
        const SizedBox(height: 6),
        DropdownButtonFormField<String>(
          initialValue: _category,
          icon: const Icon(Icons.keyboard_arrow_down_rounded, color: AppColors.textSecondary),
          decoration: _decoration(hint: '', icon: Icons.category_outlined),
          items: cats.map((c) => DropdownMenuItem(value: c, child: Text(c, style: const TextStyle(fontSize: 14)))).toList(),
          onChanged: (v) {
            if (v != null) setState(() => _category = v);
          },
        ),
        const SizedBox(height: 14),
        _inputField(
          controller: _descController,
          label: _isEn ? 'Service Description' : 'Maelezo ya Huduma (Service Description)',
          hint: _isEn
              ? 'Describe your service, experience and packages...'
              : 'Eleza kwa kina huduma yako, uzoefu na vitu vinavyojumuishwa...',
          icon: Icons.notes_rounded,
          maxLines: 4,
        ),
        const SizedBox(height: 14),
        _buildFeaturesSection(),
        const SizedBox(height: 14),
        _label(_isEn ? 'City / Region' : 'Mji / Mkoa'),
        const SizedBox(height: 6),
        DropdownButtonFormField<String>(
          initialValue: _city,
          isExpanded: true,
          icon: const Icon(Icons.keyboard_arrow_down_rounded, color: AppColors.textSecondary),
          decoration: _decoration(hint: '', icon: Icons.location_city_outlined),
          items: regions.map((c) => DropdownMenuItem(value: c, child: Text(c, style: const TextStyle(fontSize: 14)))).toList(),
          onChanged: (v) {
            if (v != null) setState(() => _city = v);
          },
        ),
        const SizedBox(height: 14),
        _inputField(
          controller: _areaController,
          label: _isEn ? 'Area / Street (optional)' : 'Eneo / Mtaa (si lazima)',
          hint: _isEn ? 'e.g. Mikocheni, near Shoppers Plaza' : 'Mfano: Mikocheni, karibu na Shoppers Plaza',
          icon: Icons.location_on_outlined,
        ),
        const SizedBox(height: 14),
        _label(_isEn ? 'Service Area Radius' : 'Umbali wa Huduma (Radius)'),
        const SizedBox(height: 6),
        DropdownButtonFormField<String>(
          initialValue: _radius,
          icon: const Icon(Icons.keyboard_arrow_down_rounded, color: AppColors.textSecondary),
          decoration: _decoration(hint: '', icon: Icons.social_distance_outlined),
          items: _radiusOptions
              .map((r) => DropdownMenuItem(
                    value: r,
                    child: Text(r == 'All city' ? (_isEn ? 'Whole city' : 'Mji mzima') : r, style: const TextStyle(fontSize: 14)),
                  ))
              .toList(),
          onChanged: (v) {
            if (v != null) setState(() => _radius = v);
          },
        ),
      ],
    );
  }

  // ---------------- Features (Soup, Pizza, Eggs, Sandwich, ...) ----------------
  List<String> get _suggestedFeatures =>
      _category == 'Food' ? _foodFeatures : (_featureSuggestions[_category] ?? const <String>[]);

  bool _hasFeature(String f) => _features.any((e) => e.toLowerCase() == f.toLowerCase());

  void _toggleFeature(String f) {
    setState(() {
      if (_hasFeature(f)) {
        _features.removeWhere((e) => e.toLowerCase() == f.toLowerCase());
      } else if (_features.length < 30) {
        _features.add(f);
      }
    });
  }

  void _addCustomFeature() {
    // Allow several at once: "Soup, Pizza, Eggs"
    final parts = _featureController.text
        .split(RegExp(r'[,\n]'))
        .map((x) => x.trim())
        .where((x) => x.isNotEmpty && x.length <= 40);
    setState(() {
      for (final f in parts) {
        if (!_hasFeature(f) && _features.length < 30) _features.add(f);
      }
    });
    _featureController.clear();
  }

  Widget _buildFeaturesSection() {
    final suggestions = _suggestedFeatures;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _label(_isEn ? 'Service Features (optional)' : 'Vitu Unavyotoa (si lazima)'),
        const SizedBox(height: 2),
        Text(
          _category == 'Food'
              ? (_isEn ? 'Tap the items you sell: soup, pizza, eggs, sandwich...' : 'Gusa vyakula unavyouza: supu, pizza, mayai, sandwich...')
              : (_isEn ? 'Tap what your service includes, or add your own' : 'Gusa unachotoa, au ongeza chako'),
          style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
        ),
        const SizedBox(height: 8),
        if (suggestions.isNotEmpty)
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: suggestions.map((f) {
              final on = _hasFeature(f);
              return FilterChip(
                label: Text(f, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: on ? AppColors.primary : AppColors.textSecondary)),
                selected: on,
                onSelected: (_) => _toggleFeature(f),
                showCheckmark: true,
                checkmarkColor: AppColors.primary,
                selectedColor: AppColors.primaryLight,
                backgroundColor: AppColors.surface,
                side: BorderSide(color: on ? AppColors.primary : AppColors.border),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                visualDensity: VisualDensity.compact,
              );
            }).toList(),
          ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _featureController,
                textCapitalization: TextCapitalization.sentences,
                textInputAction: TextInputAction.done,
                onSubmitted: (_) => _addCustomFeature(),
                decoration: _decoration(
                  hint: _isEn ? 'Add your own (e.g. Chicken Wings)' : 'Ongeza chako (mfano: Mabawa ya Kuku)',
                  icon: Icons.add_circle_outline_rounded,
                ),
              ),
            ),
            const SizedBox(width: 8),
            SizedBox(
              height: 44,
              child: ElevatedButton(
                onPressed: _addCustomFeature,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: Text(_isEn ? 'Add' : 'Ongeza', style: const TextStyle(fontWeight: FontWeight.w700)),
              ),
            ),
          ],
        ),
        // Everything selected or typed (including items from other categories)
        if (_features.isNotEmpty) ...[
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _features
                .map((f) => InputChip(
                      label: Text(f, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.primary)),
                      onDeleted: () => _toggleFeature(f),
                      deleteIconColor: AppColors.primary,
                      backgroundColor: AppColors.primaryLight,
                      side: BorderSide.none,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                      visualDensity: VisualDensity.compact,
                    ))
                .toList(),
          ),
        ],
      ],
    );
  }

  String _priceTypeLabel(String t) {
    switch (t) {
      case 'FIXED':
        return _isEn ? 'Fixed price' : 'Bei maalum';
      case 'PER_HOUR':
        return _isEn ? 'Per hour' : 'Kwa saa';
      default:
        return _isEn ? 'Starting from' : 'Kuanzia';
    }
  }

  String _dayLabel(String d) {
    const sw = {'Mon': 'Jum2', 'Tue': 'Jum3', 'Wed': 'Jum4', 'Thu': 'Alh', 'Fri': 'Ijum', 'Sat': 'Jmos', 'Sun': 'Jpili'};
    return _isEn ? d : (sw[d] ?? d);
  }

  Future<void> _pickTime(bool isFrom) async {
    final picked = await showTimePicker(context: context, initialTime: isFrom ? _from : _to);
    if (picked != null) setState(() => isFrom ? _from = picked : _to = picked);
  }

  Widget _timeBox(String label, TimeOfDay t, bool isFrom) {
    return Expanded(
      child: InkWell(
        onTap: () => _pickTime(isFrom),
        borderRadius: BorderRadius.circular(10),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.border),
          ),
          child: Row(
            children: [
              const Icon(Icons.schedule_rounded, size: 18, color: AppColors.textSecondary),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(label, style: const TextStyle(fontSize: 10, color: AppColors.textMuted)),
                    Text(_fmt24(t), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ---------------- Step 2: Pricing & Contacts ----------------
  Widget _stepPricing() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionHeader(
          '2. ${_isEn ? 'Pricing & Contacts' : 'Bei & Mawasiliano'}',
          _isEn ? 'Set your price and how clients reach you' : 'Weka bei na jinsi wateja watakavyokufikia',
        ),
        _inputField(
          controller: _priceController,
          label: _isEn ? 'Price (TSh)' : 'Bei ya Huduma (TSh)',
          hint: '50,000',
          icon: Icons.payments_outlined,
          keyboardType: TextInputType.number,
        ),
        const SizedBox(height: 14),
        _label(_isEn ? 'Price Type' : 'Aina ya Bei'),
        const SizedBox(height: 6),
        DropdownButtonFormField<String>(
          initialValue: _priceType,
          icon: const Icon(Icons.keyboard_arrow_down_rounded, color: AppColors.textSecondary),
          decoration: _decoration(hint: '', icon: Icons.sell_outlined),
          items: _priceTypes.map((t) => DropdownMenuItem(value: t, child: Text(_priceTypeLabel(t), style: const TextStyle(fontSize: 14)))).toList(),
          onChanged: (v) {
            if (v != null) setState(() => _priceType = v);
          },
        ),
        const SizedBox(height: 14),
        _label(_isEn ? 'How is the price given?' : 'Bei inatolewa vipi?'),
        const SizedBox(height: 6),
        SegmentedButton<bool>(
          showSelectedIcon: false,
          segments: [
            ButtonSegment(value: false, label: Text(_isEn ? 'Price only' : 'Bei tu', style: const TextStyle(fontSize: 12))),
            ButtonSegment(value: true, label: Text(_isEn ? 'Price per duration' : 'Bei kwa muda', style: const TextStyle(fontSize: 12))),
          ],
          selected: {_hasDuration},
          onSelectionChanged: (v) => setState(() => _hasDuration = v.first),
        ),
        const SizedBox(height: 6),
        Text(
          _hasDuration
              ? (_isEn ? 'The price above is for the duration you choose below.' : 'Bei iliyo juu ni ya muda utakaochagua hapa chini.')
              : (_isEn ? 'No duration is shown. Customers see the price only.' : 'Muda hauonyeshwi. Wateja wanaona bei tu.'),
          style: const TextStyle(fontSize: 11, height: 1.4, color: AppColors.textSecondary),
        ),
        if (_hasDuration) ...[
          const SizedBox(height: 14),
          _label(_isEn ? 'Service Duration' : 'Muda wa Huduma'),
          const SizedBox(height: 6),
          DropdownButtonFormField<int>(
            initialValue: _duration,
            icon: const Icon(Icons.keyboard_arrow_down_rounded, color: AppColors.textSecondary),
            decoration: _decoration(hint: '', icon: Icons.timer_outlined),
            items: (_durations.toList()..sort())
                .map((m) => DropdownMenuItem(
                      value: m,
                      child: Text(m >= 60 && m % 60 == 0 ? '${m ~/ 60} ${_isEn ? 'hr' : 'saa'}' : '$m min', style: const TextStyle(fontSize: 14)),
                    ))
                .toList(),
            onChanged: (v) {
              if (v != null) setState(() => _duration = v);
            },
          ),
        ],
        const SizedBox(height: 14),
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Text(
            _isEn
                ? 'Leave contacts and social links empty to use the ones on your profile.'
                : 'Acha mawasiliano na mitandao wazi ili kutumia ya wasifu wako.',
            style: const TextStyle(fontSize: 11, height: 1.4, color: AppColors.textSecondary),
          ),
        ),
        _inputField(
          controller: _phoneController,
          label: _isEn ? 'Phone Number / WhatsApp' : 'Namba ya Simu / WhatsApp',
          hint: SessionManager.getPhone().trim().isNotEmpty ? SessionManager.getPhone().trim() : '+255 712 345 678',
          icon: Icons.phone_outlined,
          keyboardType: TextInputType.phone,
        ),
        const SizedBox(height: 14),
        _inputField(
          controller: _emailController,
          label: _isEn ? 'Email (optional)' : 'Barua Pepe (si lazima)',
          hint: 'name@example.com',
          icon: Icons.mail_outline_rounded,
          keyboardType: TextInputType.emailAddress,
        ),
        const SizedBox(height: 18),
        _label(_isEn ? 'Available Days' : 'Siku Unazopatikana'),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: _dayKeys.map((d) {
            final on = _days.contains(d);
            return FilterChip(
              label: Text(_dayLabel(d), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: on ? Colors.white : AppColors.textPrimary)),
              selected: on,
              showCheckmark: false,
              selectedColor: AppColors.primary,
              backgroundColor: Colors.white,
              side: BorderSide(color: on ? AppColors.primary : AppColors.border),
              onSelected: (v) => setState(() => v ? _days.add(d) : _days.remove(d)),
            );
          }).toList(),
        ),
        const SizedBox(height: 14),
        _label(_isEn ? 'Working Hours' : 'Saa za Kazi'),
        const SizedBox(height: 8),
        Row(
          children: [
            _timeBox(_isEn ? 'Opens' : 'Kufungua', _from, true),
            const SizedBox(width: 10),
            _timeBox(_isEn ? 'Closes' : 'Kufunga', _to, false),
          ],
        ),
        const SizedBox(height: 18),
        _label(_isEn ? 'Social Links (optional)' : 'Mitandao ya Kijamii (si lazima)'),
        const SizedBox(height: 8),
        _inputField(
          controller: _instagramController,
          label: 'Instagram',
          hint: 'mybrand',
          icon: Icons.alternate_email_rounded,
        ),
        const SizedBox(height: 10),
        _inputField(controller: _facebookController, label: 'Facebook', hint: 'mybrand', icon: Icons.alternate_email_rounded),
        const SizedBox(height: 10),
        _inputField(controller: _tiktokController, label: 'TikTok', hint: 'mybrand', icon: Icons.alternate_email_rounded),
        const SizedBox(height: 10),
        _inputField(controller: _xController, label: 'X (Twitter)', hint: 'mybrand', icon: Icons.alternate_email_rounded),
        const SizedBox(height: 10),
        _inputField(controller: _youtubeController, label: 'YouTube', hint: 'mybrand', icon: Icons.alternate_email_rounded),
        const SizedBox(height: 18),
        _switchCard(
          icon: Icons.lock_outline_rounded,
          iconColor: AppColors.primary,
          title: AppStrings.sellPrivacyLockTitle,
          subtitle: _isEn
              ? 'Hide phone and social contacts until client requests service'
              : 'Ficha namba na mitandao mpaka mteja atakapoomba huduma',
          value: _isInfoLocked,
          activeColor: AppColors.primary,
          onChanged: (v) => setState(() => _isInfoLocked = v),
        ),
        const SizedBox(height: 10),
        _switchCard(
          icon: Icons.eighteen_up_rating_rounded,
          iconColor: _is18Plus ? AppColors.danger : AppColors.textSecondary,
          title: _isEn ? 'Adult Content (18+)' : 'Maudhui ya Watu Wazima (18+)',
          subtitle: _isEn
              ? 'This service contains 18+ content and will be visible without filter'
              : 'Huduma hii ina maudhui ya 18+ na itaonekana bila kizuizi',
          value: _is18Plus,
          activeColor: AppColors.danger,
          highlight: _is18Plus,
          onChanged: (v) => setState(() => _is18Plus = v),
        ),
      ],
    );
  }

  // ---------------- Step 3: Media (photos + videos) ----------------
  Widget _stepMedia() {
    final photoFilled = _images.length + _pendingPhotos.length;
    final photoSlots = photoFilled >= _maxPhotos ? _maxPhotos : math.max(4, photoFilled + 1);
    final videoFilled = _videos.length + _pendingVideos.length;
    final videoSlots = videoFilled >= _maxVideos ? _maxVideos : math.max(2, videoFilled + 1);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                _isEn ? 'Upload Service Images' : 'Pakia Picha za Huduma',
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
              ),
            ),
            _countChip('${_images.length}/$_maxPhotos'),
          ],
        ),
        const SizedBox(height: 6),
        Text(
          _isEn ? 'Add high quality photos of your service.' : 'Ongeza picha bora za huduma yako.',
          style: const TextStyle(fontSize: 14, color: AppColors.textSecondary),
        ),
        const SizedBox(height: 18),
        GridView.count(
          crossAxisCount: 2,
          mainAxisSpacing: 14,
          crossAxisSpacing: 14,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          children: List.generate(photoSlots, (i) {
            if (i < _images.length) return _photoTile(i);
            if (i < photoFilled) return _pendingTile(_pendingPhotos[i - _images.length], video: false);
            return _AddMediaTile(
              icon: Icons.photo_camera_outlined,
              label: _isEn ? 'Add Photo' : 'Ongeza Picha',
              onTap: _addPhoto,
            );
          }),
        ),
        if (_images.length > 1) ...[
          const SizedBox(height: 10),
          Text(
            _isEn
                ? 'The first photo is your cover image. Tap the star on any photo to make it the cover.'
                : 'Picha ya kwanza ndiyo picha kuu. Gusa nyota kwenye picha yoyote kuiweka kuwa kuu.',
            style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
          ),
        ],
        const SizedBox(height: 22),
        Text(
          _isEn ? 'Tips for great photos:' : 'Vidokezo vya picha nzuri:',
          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        const SizedBox(height: 8),
        for (final tip in (_isEn
            ? const ['Use natural lighting', 'Show your workspace or result', 'Upload clear and high-quality images']
            : const ['Tumia mwanga wa asili', 'Onyesha eneo lako la kazi au matokeo', 'Pakia picha safi zenye ubora wa juu']))
          Padding(
            padding: const EdgeInsets.only(bottom: 5),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Padding(
                  padding: EdgeInsets.only(top: 6, right: 10, left: 4),
                  child: Icon(Icons.circle, size: 5, color: AppColors.primary),
                ),
                Expanded(child: Text(tip, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary))),
              ],
            ),
          ),
        const SizedBox(height: 26),
        const Divider(height: 1, color: AppColors.borderLight),
        const SizedBox(height: 22),
        Row(
          children: [
            Expanded(
              child: Text(
                _isEn ? 'Upload Service Videos' : 'Pakia Video za Huduma',
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
              ),
            ),
            _countChip('${_videos.length}/$_maxVideos'),
          ],
        ),
        const SizedBox(height: 6),
        Text(
          _isEn
              ? 'Optional. Short clips (up to $_maxVideoSeconds seconds, $_maxVideoMb MB) help clients trust you.'
              : 'Hiari. Video fupi (hadi sekunde $_maxVideoSeconds, MB $_maxVideoMb) huwapa wateja imani.',
          style: const TextStyle(fontSize: 14, color: AppColors.textSecondary),
        ),
        const SizedBox(height: 18),
        GridView.count(
          crossAxisCount: 2,
          mainAxisSpacing: 14,
          crossAxisSpacing: 14,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          children: List.generate(videoSlots, (i) {
            if (i < _videos.length) return _videoTile(i);
            if (i < videoFilled) return _pendingTile(_pendingVideos[i - _videos.length], video: true);
            return _AddMediaTile(
              icon: Icons.videocam_outlined,
              label: _isEn ? 'Add Video' : 'Ongeza Video',
              onTap: _addVideo,
            );
          }),
        ),
        const SizedBox(height: 8),
      ],
    );
  }

  Widget _countChip(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: AppColors.primaryLight, borderRadius: BorderRadius.circular(8)),
      child: Text(text, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.primary)),
    );
  }

  Widget _photoTile(int i) {
    final featured = i == 0;
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: featured ? AppColors.primary : AppColors.border, width: featured ? 2 : 1),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: AppImage(
              _images[i],
              fit: BoxFit.cover,
              errorBuilder: (_, _, _) => Container(
                color: AppColors.border,
                child: const Icon(Icons.broken_image_outlined, color: AppColors.textMuted, size: 30),
              ),
            ),
          ),
        ),
        Positioned(left: 8, bottom: 8, child: featured ? _coverChip() : _starButton(() => _setFeatured(i))),
        Positioned(top: 8, right: 8, child: _removeDot(() => setState(() => _images.removeAt(i)))),
      ],
    );
  }

  Widget _coverChip() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(8)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.star_rounded, size: 12, color: Colors.white),
          const SizedBox(width: 3),
          Text(_isEn ? 'Cover' : 'Kuu', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: Colors.white)),
        ],
      ),
    );
  }

  Widget _starButton(VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(5),
        decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
        child: const Icon(Icons.star_border_rounded, size: 16, color: Colors.white),
      ),
    );
  }

  Widget _videoTile(int i) {
    final url = _videos[i];
    return Stack(
      fit: StackFit.expand,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: GestureDetector(
            onTap: () => VideoPlayerScreen.open(
              context,
              url: url,
              title: 'Video ${i + 1}',
            ),
            child: _VideoThumb(url: url),
          ),
        ),
        Positioned(top: 8, right: 8, child: _removeDot(() => setState(() => _videos.removeAt(i)))),
      ],
    );
  }

  Widget _pendingTile(_PendingUpload u, {required bool video}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (u.bytes != null)
            Image.memory(u.bytes!, fit: BoxFit.cover)
          else
            Container(color: video ? AppColors.slateDark : AppColors.primaryLight),
          Container(color: Colors.black45),
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white)),
                const SizedBox(height: 8),
                Text(
                  _isEn ? 'Uploading...' : 'Inapakia...',
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.white),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------
  // Shared UI helpers (same look as the registration page)
  // ---------------------------------------------------------------
  Widget _sectionHeader(String title, String subtitle) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
          const SizedBox(height: 4),
          Text(subtitle, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
        ],
      ),
    );
  }

  Widget _label(String text) {
    return Text(text, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary));
  }

  InputDecoration _decoration({required String hint, required IconData icon}) {
    return InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(fontSize: 13, color: AppColors.textMuted),
      prefixIcon: Icon(icon, size: 18, color: AppColors.textSecondary),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      isDense: true,
    );
  }

  Widget _inputField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
    int maxLines = 1,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _label(label),
        const SizedBox(height: 6),
        TextField(
          controller: controller,
          keyboardType: keyboardType,
          maxLines: maxLines,
          decoration: _decoration(hint: hint, icon: icon),
        ),
      ],
    );
  }

  Widget _switchCard({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String subtitle,
    required bool value,
    required Color activeColor,
    required ValueChanged<bool> onChanged,
    bool highlight = false,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: highlight ? AppColors.dangerLight : AppColors.background,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: highlight ? AppColors.danger.withValues(alpha: 0.5) : AppColors.border),
      ),
      child: Row(
        children: [
          Icon(icon, size: 20, color: iconColor),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(subtitle, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
              ],
            ),
          ),
          Switch.adaptive(value: value, activeTrackColor: activeColor, onChanged: onChanged),
        ],
      ),
    );
  }

  // ---------------- Media: permissions, pick, upload ----------------
  void _setFeatured(int index) {
    if (index <= 0 || index >= _images.length) return;
    setState(() {
      final img = _images.removeAt(index);
      _images.insert(0, img);
    });
  }

  Future<ImageSource?> _chooseSource({required bool video}) {
    return showModalBottomSheet<ImageSource>(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 10),
            Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2))),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 6),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  video ? (_isEn ? 'Add a video' : 'Ongeza video') : (_isEn ? 'Add a photo' : 'Ongeza picha'),
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library_outlined, color: AppColors.primary),
              title: Text(video
                  ? (_isEn ? 'Choose video from gallery' : 'Chagua video kutoka Gallery')
                  : (_isEn ? 'Choose from gallery' : 'Chagua kutoka Gallery')),
              onTap: () => Navigator.pop(ctx, ImageSource.gallery),
            ),
            ListTile(
              leading: Icon(video ? Icons.videocam_outlined : Icons.photo_camera_outlined, color: AppColors.primary),
              title: Text(video
                  ? (_isEn ? 'Record a video' : 'Rekodi video')
                  : (_isEn ? 'Take a photo' : 'Piga picha')),
              onTap: () => Navigator.pop(ctx, ImageSource.camera),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  /// Asks for the camera / gallery permission when it isn't allowed yet.
  /// Returns true when the picker may be opened.
  Future<bool> _ensureAccess(ImageSource source, {required bool video}) async {
    final isCamera = source == ImageSource.camera;
    final access = isCamera
        ? await MediaPermissions.camera(recordVideo: video)
        : await MediaPermissions.library(video: video);
    if (!mounted) return false;
    if (access == MediaAccess.granted) return true;

    final permanent = access == MediaAccess.permanentlyDenied;
    final what = isCamera
        ? (_isEn ? 'camera' : 'kamera')
        : (_isEn ? 'photos and videos' : 'picha na video');
    final retry = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          isCamera
              ? (_isEn ? 'Camera access needed' : 'Ruhusa ya kamera inahitajika')
              : (_isEn ? 'Gallery access needed' : 'Ruhusa ya gallery inahitajika'),
          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
        ),
        content: Text(
          permanent
              ? (_isEn
                  ? 'Access to your $what is turned off. Open Settings and allow it to upload service media.'
                  : 'Ruhusa ya $what imezimwa. Fungua Mipangilio na uiruhusu ili kupakia picha/video.')
              : (_isEn
                  ? 'Nearby Services needs access to your $what to add photos and videos to your service.'
                  : 'Nearby Services inahitaji ruhusa ya $what ili kuongeza picha na video kwenye huduma yako.'),
          style: const TextStyle(fontSize: 13.5, height: 1.4),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(_isEn ? 'Not now' : 'Si sasa'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(
              permanent ? (_isEn ? 'Open Settings' : 'Fungua Mipangilio') : (_isEn ? 'Allow' : 'Ruhusu'),
              style: const TextStyle(fontWeight: FontWeight.w800),
            ),
          ),
        ],
      ),
    );
    if (retry != true || !mounted) return false;
    if (permanent) {
      await PermissionService.openSettings();
      return false;
    }
    return _ensureAccess(source, video: video);
  }

  Future<void> _addPhoto() async {
    if (_images.length + _pendingPhotos.length >= _maxPhotos) {
      _snack(_isEn ? 'You can add up to $_maxPhotos photos' : 'Unaweza kuongeza hadi picha $_maxPhotos');
      return;
    }
    final source = await _chooseSource(video: false);
    if (source == null || !mounted) return;
    if (!await _ensureAccess(source, video: false)) return;
    await _pickPhotos(source);
  }

  Future<void> _pickPhotos(ImageSource source) async {
    final room = _maxPhotos - _images.length - _pendingPhotos.length;
    if (room <= 0) return;
    List<XFile> files = [];
    try {
      if (source == ImageSource.gallery && room > 1) {
        // image_picker requires limit >= 2, so a single free slot uses pickImage.
        files = await _picker.pickMultiImage(maxWidth: 1600, imageQuality: 85, limit: room);
      } else {
        final f = await _picker.pickImage(source: source, maxWidth: 1600, imageQuality: 85);
        if (f != null) files = [f];
      }
    } catch (_) {
      _snack(_isEn ? 'Could not open the photo picker' : 'Imeshindikana kufungua picha');
      return;
    }
    if (files.isEmpty || !mounted) return;
    files = files.take(room).toList();

    final pending = [for (final _ in files) _PendingUpload()];
    setState(() => _pendingPhotos.addAll(pending));
    for (var i = 0; i < files.length; i++) {
      files[i].readAsBytes().then((b) {
        if (mounted && _pendingPhotos.contains(pending[i])) setState(() => pending[i].bytes = b);
      }).catchError((_) {});
    }

    var failed = 0;
    String? firstError;
    for (var i = 0; i < files.length; i++) {
      final res = await ApiService.uploadServiceImage(files[i].path);
      if (!mounted) return;
      setState(() {
        _pendingPhotos.remove(pending[i]);
        if (res.url != null) {
          _images.add(res.url!);
        } else {
          failed++;
          firstError ??= res.error;
        }
      });
    }
    if (failed > 0 && mounted) {
      _snack(_isEn
          ? '$failed photo(s) not uploaded. ${firstError ?? ''}'.trim()
          : 'Picha $failed hazikupakiwa. ${firstError ?? ''}'.trim());
    }
  }

  Future<void> _addVideo() async {
    if (_videos.length + _pendingVideos.length >= _maxVideos) {
      _snack(_isEn ? 'You can add up to $_maxVideos videos' : 'Unaweza kuongeza hadi video $_maxVideos');
      return;
    }
    final source = await _chooseSource(video: true);
    if (source == null || !mounted) return;
    if (!await _ensureAccess(source, video: true)) return;
    await _pickVideo(source);
  }

  Future<void> _pickVideo(ImageSource source) async {
    XFile? file;
    try {
      file = await _picker.pickVideo(source: source, maxDuration: const Duration(seconds: _maxVideoSeconds));
    } catch (_) {
      _snack(_isEn ? 'Could not open the video picker' : 'Imeshindikana kufungua video');
      return;
    }
    if (file == null || !mounted) return;

    final size = await file.length();
    if (size > _maxVideoMb * 1024 * 1024) {
      _snack(_isEn ? 'Video is too large. Maximum is $_maxVideoMb MB.' : 'Video ni kubwa mno. Kiwango cha juu ni MB $_maxVideoMb.');
      return;
    }
    if (!mounted) return;

    final pending = _PendingUpload();
    setState(() => _pendingVideos.add(pending));
    final res = await ApiService.uploadServiceVideo(file.path);
    if (!mounted) return;
    setState(() {
      _pendingVideos.remove(pending);
      if (res.url != null) _videos.add(res.url!);
    });
    if (res.url == null) {
      _snack(_isEn
          ? 'Video not uploaded. ${res.error ?? ''}'.trim()
          : 'Video haikupakiwa. ${res.error ?? ''}'.trim());
    }
  }

  Widget _removeDot(VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 26,
        height: 26,
        decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: 0.9), shape: BoxShape.circle),
        child: const Icon(Icons.close_rounded, size: 15, color: Colors.white),
      ),
    );
  }
}

/// A photo/video that is currently uploading (optional preview bytes for photos).
class _PendingUpload {
  Uint8List? bytes;
}

/// Dashed "Add Photo / Add Video" tile from the design.
class _AddMediaTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _AddMediaTile({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: CustomPaint(
        painter: _DashedRRectPainter(color: AppColors.primary.withValues(alpha: 0.4), radius: 16),
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.primary.withValues(alpha: 0.05),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 36, color: AppColors.primary),
              const SizedBox(height: 10),
              Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.primary)),
            ],
          ),
        ),
      ),
    );
  }
}

class _DashedRRectPainter extends CustomPainter {
  final Color color;
  final double radius;

  const _DashedRRectPainter({required this.color, required this.radius});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    final rrect = RRect.fromRectAndRadius(Offset.zero & size, Radius.circular(radius)).deflate(0.75);
    final path = Path()..addRRect(rrect);
    for (final metric in path.computeMetrics()) {
      var d = 0.0;
      while (d < metric.length) {
        canvas.drawPath(metric.extractPath(d, math.min(d + 6, metric.length)), paint);
        d += 10;
      }
    }
  }

  @override
  bool shouldRepaint(covariant _DashedRRectPainter old) => old.color != color || old.radius != radius;
}

/// First frame of an uploaded video with a play button (falls back to a dark tile).
class _VideoThumb extends StatefulWidget {
  final String url;

  const _VideoThumb({required this.url});

  @override
  State<_VideoThumb> createState() => _VideoThumbState();
}

class _VideoThumbState extends State<_VideoThumb> {
  VideoPlayerController? _controller;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    if (widget.url.startsWith('http')) {
      final c = VideoPlayerController.networkUrl(Uri.parse(widget.url));
      _controller = c;
      c.initialize().then((_) {
        if (!mounted) return;
        c.setVolume(0);
        setState(() => _ready = true);
      }).catchError((_) {});
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  String _fmt(Duration d) {
    final m = d.inMinutes;
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final c = _controller;
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: AppColors.slateDark),
        if (_ready && c != null)
          FittedBox(
            fit: BoxFit.cover,
            clipBehavior: Clip.hardEdge,
            child: SizedBox(
              width: c.value.size.width,
              height: c.value.size.height,
              child: VideoPlayer(c),
            ),
          ),
        Container(color: Colors.black26),
        Center(
          child: Container(
            width: 46,
            height: 46,
            decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
            child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 30),
          ),
        ),
        if (_ready && c != null)
          Positioned(
            left: 8,
            bottom: 8,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(6)),
              child: Text(_fmt(c.value.duration), style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: Colors.white)),
            ),
          ),
      ],
    );
  }
}

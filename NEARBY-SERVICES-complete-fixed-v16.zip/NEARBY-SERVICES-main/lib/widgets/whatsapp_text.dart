import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';

/// Renders text with WhatsApp-style formatting.
///
/// Inline:  *bold*   _italic_   ~strikethrough~   `monospace`   ```block```
/// Lines:   1. numbered list      - bullet list (or * item)      > quote
///
/// Like WhatsApp, an inline marker only formats when it hugs the text (no
/// space just inside it) and sits at a word boundary, so `snake_case_name`
/// or `2 * 3 * 4` stay untouched. Inline markers can be nested, e.g. `*_both_*`,
/// and never span a line break.
///
/// When [maxLines] is set (card previews) lists and quotes are flattened into
/// one text with simple prefixes so the ellipsis still works.
class WhatsAppText extends StatelessWidget {
  final String text;
  final TextStyle? style;
  final int? maxLines;
  final TextOverflow? overflow;
  final TextAlign? textAlign;

  const WhatsAppText(
    this.text, {
    super.key,
    this.style,
    this.maxLines,
    this.overflow,
    this.textAlign,
  });

  @override
  Widget build(BuildContext context) {
    final blocks = WhatsAppFormat.blocks(text);
    final structured = blocks.any((b) => b.kind != WaKind.text);

    // Simple / preview mode: one Text.rich (keeps maxLines + ellipsis working).
    if (!structured || maxLines != null) {
      return Text.rich(
        TextSpan(children: WhatsAppFormat.flatSpans(blocks)),
        style: style,
        maxLines: maxLines,
        overflow: overflow,
        textAlign: textAlign,
      );
    }

    final base = DefaultTextStyle.of(context).style.merge(style);
    final quoteStyle = base.copyWith(color: base.color?.withValues(alpha: 0.8));
    final rows = <Widget>[];

    for (final b in blocks) {
      switch (b.kind) {
        case WaKind.blank:
          rows.add(SizedBox(height: (base.fontSize ?? 14) * 0.6));
          break;
        case WaKind.text:
          rows.add(Text.rich(TextSpan(children: b.spans), textAlign: textAlign));
          break;
        case WaKind.bullet:
        case WaKind.number:
          rows.add(Padding(
            padding: const EdgeInsets.only(left: 4, top: 1, bottom: 1),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: b.kind == WaKind.number ? 24 : 16,
                  child: Text(b.kind == WaKind.number ? '${b.label}.' : '\u2022'),
                ),
                Expanded(child: Text.rich(TextSpan(children: b.spans), textAlign: textAlign)),
              ],
            ),
          ));
          break;
        case WaKind.quote:
          rows.add(Padding(
            padding: const EdgeInsets.symmetric(vertical: 2),
            child: Container(
              padding: const EdgeInsets.only(left: 9),
              decoration: const BoxDecoration(
                border: Border(left: BorderSide(color: AppColors.border, width: 3)),
              ),
              child: DefaultTextStyle.merge(
                style: quoteStyle,
                child: Text.rich(TextSpan(children: b.spans), textAlign: textAlign),
              ),
            ),
          ));
          break;
      }
    }

    return DefaultTextStyle.merge(
      style: style,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: rows,
      ),
    );
  }
}

enum WaKind { text, blank, bullet, number, quote }

/// One line-level block (a line of text, a list item, or a quote line).
class WaBlock {
  final WaKind kind;
  final String label; // list number
  final List<InlineSpan> spans;
  const WaBlock(this.kind, this.spans, {this.label = ''});
}

class WhatsAppFormat {
  WhatsAppFormat._();

  static const _markers = ['*', '_', '~', '`'];

  /// Parses [text] into styled spans.
  static List<InlineSpan> parse(String text) => _parse(text, const TextStyle());

  static final _reQuote = RegExp(r'^\s*>\s?(.*)$');
  static final _reNumber = RegExp(r'^\s*(\d{1,3})[.)]\s+(\S.*)$');
  static final _reBullet = RegExp(r'^\s*[-\u2022*]\s+(\S.*)$');

  /// Splits [text] into line blocks (text, bullet, number, quote) with inline spans.
  static List<WaBlock> blocks(String text) {
    final out = <WaBlock>[];
    for (final line in text.replaceAll('\r\n', '\n').split('\n')) {
      if (line.trim().isEmpty) {
        out.add(const WaBlock(WaKind.blank, []));
        continue;
      }
      Match? m;
      if ((m = _reQuote.firstMatch(line)) != null) {
        out.add(WaBlock(WaKind.quote, parse(m!.group(1)!)));
      } else if ((m = _reNumber.firstMatch(line)) != null) {
        out.add(WaBlock(WaKind.number, parse(m!.group(2)!), label: m.group(1)!));
      } else if ((m = _reBullet.firstMatch(line)) != null) {
        out.add(WaBlock(WaKind.bullet, parse(m!.group(1)!)));
      } else {
        out.add(WaBlock(WaKind.text, parse(line)));
      }
    }
    return out;
  }

  /// All blocks as one span list (line breaks kept, lists/quotes get prefixes).
  static List<InlineSpan> flatSpans(List<WaBlock> blocks) {
    final spans = <InlineSpan>[];
    for (var i = 0; i < blocks.length; i++) {
      final b = blocks[i];
      if (i > 0) spans.add(const TextSpan(text: '\n'));
      switch (b.kind) {
        case WaKind.bullet:
          spans.add(const TextSpan(text: '\u2022 '));
          break;
        case WaKind.number:
          spans.add(TextSpan(text: '${b.label}. '));
          break;
        case WaKind.quote:
          spans.add(const TextSpan(text: '\u258E '));
          break;
        default:
          break;
      }
      spans.addAll(b.spans);
    }
    return spans;
  }

  /// The text without any formatting markers (for notifications, chat previews, etc).
  static String plain(String text) {
    final out = StringBuffer();
    for (final sp in flatSpans(blocks(text))) {
      if (sp is TextSpan && sp.text != null) out.write(sp.text);
    }
    return out.toString();
  }

  static bool _isSpace(String? c) => c == null || c.trim().isEmpty;

  static bool _isWordChar(String? c) {
    if (c == null || c.isEmpty) return false;
    return RegExp(r'[\p{L}\p{N}]', unicode: true).hasMatch(c);
  }

  static String? _at(String s, int i) => (i < 0 || i >= s.length) ? null : s[i];

  /// Index of the closing marker for an opening marker at [open], or -1.
  static int _findClose(String s, int open, String m) {
    for (var j = open + 2; j < s.length; j++) {
      final c = s[j];
      if (c == '\n') return -1; // formatting does not span lines
      if (c != m) continue;
      if (_isSpace(_at(s, j - 1))) continue; // no space just inside the closing marker
      if (_isWordChar(_at(s, j + 1))) continue; // must end at a word boundary
      return j;
    }
    return -1;
  }

  static TextStyle _styleFor(String m, TextStyle parent) {
    switch (m) {
      case '*':
        return parent.copyWith(fontWeight: FontWeight.w800);
      case '_':
        return parent.copyWith(fontStyle: FontStyle.italic);
      case '~':
        final d = parent.decoration;
        return parent.copyWith(
          decoration: d == null || d == TextDecoration.none
              ? TextDecoration.lineThrough
              : TextDecoration.combine([d, TextDecoration.lineThrough]),
        );
      default:
        return parent.copyWith(
          fontFamily: 'monospace',
          backgroundColor: AppColors.borderLight,
        );
    }
  }

  static List<InlineSpan> _parse(String s, TextStyle style) {
    final spans = <InlineSpan>[];
    final buf = StringBuffer();

    void flush() {
      if (buf.isEmpty) return;
      spans.add(TextSpan(text: buf.toString(), style: style));
      buf.clear();
    }

    var i = 0;
    while (i < s.length) {
      final c = s[i];

      // ```block``` (monospace, content is not parsed further)
      if (c == '`' && s.startsWith('```', i)) {
        final end = s.indexOf('```', i + 3);
        if (end > i + 3) {
          flush();
          spans.add(TextSpan(text: s.substring(i + 3, end).trim(), style: _styleFor('`', style)));
          i = end + 3;
          continue;
        }
      }

      if (_markers.contains(c)) {
        final prev = _at(s, i - 1);
        final next = _at(s, i + 1);
        final opens = !_isWordChar(prev) && !_isSpace(next) && next != c;
        if (opens) {
          final close = _findClose(s, i, c);
          if (close != -1) {
            flush();
            final inner = s.substring(i + 1, close);
            if (c == '`') {
              spans.add(TextSpan(text: inner, style: _styleFor(c, style)));
            } else {
              spans.addAll(_parse(inner, _styleFor(c, style)));
            }
            i = close + 1;
            continue;
          }
        }
      }

      buf.write(c);
      i++;
    }
    flush();
    return spans;
  }
}

/// Small helper shown under description/bio inputs. Tap "Formatting" for the full list.
class FormatHint extends StatelessWidget {
  const FormatHint({super.key});

  static void showHelp(BuildContext context) {
    final en = AppStrings.isEnglish;
    Widget row(String typed, Widget shown) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                width: 150,
                child: Text(typed, style: const TextStyle(fontFamily: 'monospace', fontSize: 12, color: AppColors.textSecondary)),
              ),
              Expanded(child: shown),
            ],
          ),
        );
    const st = TextStyle(fontSize: 13, color: AppColors.textPrimary);
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(en ? 'Text formatting' : 'Mpangilio wa maandishi',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
              const SizedBox(height: 8),
              row('*bold*', const WhatsAppText('*bold*', style: st)),
              row('_italic_', const WhatsAppText('_italic_', style: st)),
              row('~strikethrough~', const WhatsAppText('~strikethrough~', style: st)),
              row('`monospace`', const WhatsAppText('`monospace`', style: st)),
              row('1. first\n2. second', const WhatsAppText('1. first\n2. second', style: st)),
              row('- item\n- item', const WhatsAppText('- item\n- item', style: st)),
              row('> quote', const WhatsAppText('> quote', style: st)),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final en = AppStrings.isEnglish;
    const hintStyle = TextStyle(fontSize: 11, color: AppColors.textMuted);
    return Padding(
      padding: const EdgeInsets.only(top: 6),
      child: GestureDetector(
        onTap: () => showHelp(context),
        behavior: HitTestBehavior.opaque,
        child: Text.rich(
          TextSpan(
            style: hintStyle,
            children: [
              TextSpan(text: en ? 'Formatting: ' : 'Mpangilio: ', style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700)),
              const TextSpan(text: '*bold*', style: TextStyle(fontWeight: FontWeight.w800)),
              const TextSpan(text: '  '),
              const TextSpan(text: '_italic_', style: TextStyle(fontStyle: FontStyle.italic)),
              const TextSpan(text: '  '),
              const TextSpan(text: '~strike~', style: TextStyle(decoration: TextDecoration.lineThrough)),
              TextSpan(text: en ? '  \u2022  1. numbered  \u2022  - bullets  \u2022  > quote' : '  \u2022  1. namba  \u2022  - vitone  \u2022  > nukuu'),
            ],
          ),
        ),
      ),
    );
  }
}

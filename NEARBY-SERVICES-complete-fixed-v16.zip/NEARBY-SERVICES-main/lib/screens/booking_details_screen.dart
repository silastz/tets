import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import 'chats_screen.dart';
import 'map_tracking_screen.dart';
import '../widgets/cancel_booking_sheet.dart';
import '../constants/app_strings.dart';
import '../services/payment_flow.dart';
import '../widgets/payment_flow_widgets.dart';

class BookingDetailsScreen extends StatelessWidget {
  final Map<String, dynamic> bookingData;

  const BookingDetailsScreen({
    super.key,
    required this.bookingData,
  });

  @override
  Widget build(BuildContext context) {
    // rawStatus is the server status (e.g. AWAITING_PAYMENT); 'status' may be a display label.
    final status = (bookingData['rawStatus'] ?? bookingData['status'] ?? 'CONFIRMED').toString().toUpperCase();
    final payTx = bookingData['tx'] is Map<String, dynamic> ? bookingData['tx'] as Map<String, dynamic> : null;
    final showPay = payTx != null && (PaymentFlow.isOpen(status) || PaymentFlow.isUnpaidOnline(payTx));
    final en = AppStrings.isEnglish;
    final tx = payTx ?? const <String, dynamic>{};
    String clean(dynamic v) => (v ?? '').toString().trim();

    // Real values from the booking / transaction only; anything unknown is hidden.
    DateTime? when;
    for (final k in const ['scheduledAt', 'bookingDate', 'startTime', 'createdAt']) {
      final d = DateTime.tryParse(clean(tx[k]));
      if (d != null) { when = d.toLocal(); break; }
    }
    String two(int v) => v.toString().padLeft(2, '0');
    final serviceTitle = clean(bookingData['serviceTitle']).isNotEmpty
        ? bookingData['serviceTitle']
        : clean(tx['serviceTitle']).isNotEmpty ? tx['serviceTitle'] : (en ? 'Service' : 'Huduma');
    final providerName = clean(bookingData['providerName']).isNotEmpty
        ? bookingData['providerName']
        : (en ? 'Provider' : 'Mtoa huduma');
    final rating = clean(bookingData['rating']);
    final reviewsCount = clean(bookingData['reviewsCount']);
    final date = clean(bookingData['date']).isNotEmpty
        ? clean(bookingData['date'])
        : (when == null ? '' : '${when.day}/${when.month}/${when.year}');
    final time = clean(bookingData['time']).isNotEmpty
        ? clean(bookingData['time'])
        : (when == null ? '' : '${two(when.hour)}:${two(when.minute)}');
    final txPlace = clean(tx['address']).isNotEmpty ? clean(tx['address']) : clean(tx['location']).isNotEmpty ? clean(tx['location']) : clean(tx['city']);
    final location = clean(bookingData['location']).isNotEmpty ? clean(bookingData['location']) : txPlace;
    final price = clean(bookingData['price']).isNotEmpty ? bookingData['price'] : clean(tx['amount']);
    final duration = bookingData['duration'] ?? '';
    final txMode = clean(tx['serviceMode']);
    final mode = clean(bookingData['mode']).isNotEmpty
        ? clean(bookingData['mode'])
        : txMode == 'customer_comes'
            ? (en ? 'Customer comes to provider' : 'Mteja anakuja kwa mtoa huduma')
            : txMode == 'provider_travels'
                ? (en ? 'Provider travels to customer' : 'Mtoa huduma anasafiri kwa mteja')
                : '';
    final address = clean(bookingData['address']).isNotEmpty ? clean(bookingData['address']) : txPlace;
    final image = bookingData['image'] ?? 'assets/images/banner.jpg';
    final ref = (bookingData['ref'] ?? '').toString();
    final isCancelled = status.contains('CANCEL');
    final isRejected = status.contains('REJECT');
    final isCompleted = status.contains('COMPLETE');
    final canCancel = ref.isNotEmpty && BookingCancel.canCancel(status);
    final badgeColor = PaymentFlow.isOpen(status)
        ? PaymentFlow.color(status)
        : (isCancelled || isRejected) ? AppColors.danger : (status.contains('PENDING') ? AppColors.warning : AppColors.success);
    final badgeLabel = PaymentFlow.isOpen(status)
        ? PaymentFlow.label(status)
        : isCancelled
        ? 'Cancelled'
        : isRejected
            ? 'Rejected'
            : isCompleted
                ? 'Completed'
                : (status.contains('PENDING') ? 'Pending' : 'Confirmed');

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Booking Details',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
          ),
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 16, top: 12, bottom: 12),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: badgeColor,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon((isCancelled || isRejected) ? Icons.cancel_rounded : Icons.check_circle_rounded, color: Colors.white, size: 14),
                const SizedBox(width: 4),
                Text(
                  badgeLabel,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Gallery / Cover Images
            Row(
              children: [
                Expanded(
                  flex: 3,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(14),
                    child: Image.asset(
                      image,
                      height: 140,
                      fit: BoxFit.cover,
                      errorBuilder: (ctx, err, stack) => Container(
                        height: 140,
                        color: AppColors.borderLight,
                        child: const Icon(Icons.image_outlined, size: 40, color: AppColors.textMuted),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  flex: 2,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(14),
                    child: Image.asset(
                      'assets/images/provider1.jpg',
                      height: 140,
                      fit: BoxFit.cover,
                      errorBuilder: (ctx, err, stack) => Container(
                        height: 140,
                        color: AppColors.borderLight,
                        child: const Icon(Icons.image_outlined, size: 40, color: AppColors.textMuted),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            if (showPay) ...[
              PaymentFlowPanel(
                tx: payTx!,
                isBuyer: bookingData['isBuyer'] != false,
                onChanged: () => Navigator.pop(context, true), // list refreshes
              ),
              const SizedBox(height: 16),
            ],

            // Service Title & Provider info
            Text(
              serviceTitle,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                Text(
                  providerName,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: AppColors.primary,
                  ),
                ),
                const SizedBox(width: 4),
                const Icon(Icons.verified_rounded, size: 16, color: AppColors.primary),
              ],
            ),
            const SizedBox(height: 6),
            if (rating.isNotEmpty)
              Row(
                children: [
                  const Icon(Icons.star_rounded, size: 16, color: AppColors.goldStar),
                  const SizedBox(width: 4),
                  Text(
                    reviewsCount.isEmpty ? rating : '$rating ($reviewsCount reviews)',
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textSecondary,
                    ),
                  ),
                ],
              ),
            const SizedBox(height: 16),

            // Date, Time & Location Card (only the rows we really know)
            if (date.isNotEmpty || time.isNotEmpty || location.isNotEmpty)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppColors.border),
                ),
                child: Column(
                  children: [
                    for (final r in <(IconData, String)>[
                      (Icons.calendar_today_outlined, date),
                      (Icons.access_time_rounded, time),
                      (Icons.location_on_outlined, location),
                    ].where((r) => r.$2.isNotEmpty).toList().asMap().entries)
                      Padding(
                        padding: EdgeInsets.only(top: r.key == 0 ? 0 : 10),
                        child: Row(
                          children: [
                            Icon(r.value.$1, size: 16, color: AppColors.textSecondary),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                r.value.$2,
                                style: const TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
            const SizedBox(height: 20),

            // Booking Information Section Table
            const Text(
              'Booking Information',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w800,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                children: [
                  _buildInfoRow('Service', serviceTitle),
                  _buildDivider(),
                  _buildInfoRow('Provider', providerName),
                  _buildDivider(),
                  _buildInfoRow('Price', price, isPrimary: true),
                  if (duration.toString().trim().isNotEmpty) ...[
                    _buildDivider(),
                    _buildInfoRow('Duration', duration),
                  ],
                  if (mode.isNotEmpty) ...[
                    _buildDivider(),
                    _buildInfoRow('Mode', mode),
                  ],
                  if (address.isNotEmpty) ...[
                    _buildDivider(),
                    _buildInfoRow('Address', address),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Track on map
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () {
                  final lat = (bookingData['providerLat'] as num?)?.toDouble();
                  final lng = (bookingData['providerLng'] as num?)?.toDouble();
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => MapTrackingScreen(
                        providerName: providerName.toString(),
                        serviceTitle: serviceTitle.toString(),
                        address: address.toString(),
                        providerLat: lat,
                        providerLng: lng,
                      ),
                    ),
                  );
                },
                icon: const Icon(Icons.map_rounded, size: 18),
                label: Text(
                  AppStrings.isEnglish ? 'Track on Map' : 'Fuatilia kwenye Ramani',
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryLight,
                  foregroundColor: AppColors.primary,
                  elevation: 0,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ),
            const SizedBox(height: 12),

            // Action Buttons: Cancel Booking & Chat
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: canCancel
                        ? () async {
                            final done = await CancelBookingSheet.show(
                              context,
                              transactionRef: ref,
                              serviceTitle: serviceTitle.toString(),
                              status: status,
                            );
                            if (done == true && context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  backgroundColor: AppColors.danger,
                                  content: Text(AppStrings.isEnglish ? 'Booking cancelled' : 'Oda imeghairiwa'),
                                ),
                              );
                              Navigator.pop(context, true);
                            }
                          }
                        : null,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.danger,
                      disabledForegroundColor: AppColors.textDisabled,
                      side: BorderSide(color: canCancel ? AppColors.danger : AppColors.border),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    child: const Text(
                      'Cancel Booking',
                      style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const ChatsScreen()),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    child: const Text(
                      'Chat',
                      style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value, {bool isPrimary = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
          ),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.end,
              style: TextStyle(
                fontSize: 13,
                fontWeight: isPrimary ? FontWeight.w800 : FontWeight.w700,
                color: isPrimary ? AppColors.primary : AppColors.textPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDivider() {
    return const Divider(height: 1, color: AppColors.borderLight);
  }
}

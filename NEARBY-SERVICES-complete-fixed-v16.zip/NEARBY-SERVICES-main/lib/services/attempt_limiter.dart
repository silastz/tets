import 'package:shared_preferences/shared_preferences.dart';

/// Client-side brute-force brake for login / OTP / password-reset / PIN and resend.
/// After [maxFailures] wrong attempts for the same key, further attempts are
/// blocked with an escalating cool-down (30s, 60s, 2m ... up to 15m).
///
/// Lock-outs now SURVIVE an app restart (kept on the device, keys are hashed so no phone
/// numbers are stored), so closing and reopening the app no longer resets the counter.
/// This only slows down casual abuse; the server must still enforce its own limits.
class AttemptLimiter {
  static const int maxFailures = 5;
  static const _prefKey = 'attempt_limiter_v1';
  static const _staleAfter = Duration(hours: 24);

  static final Map<String, int> _failures = {};
  static final Map<String, DateTime> _lastFailure = {};
  static final Map<String, DateTime> _lockedUntil = {};
  static final Map<String, DateTime> _cooldowns = {};
  static SharedPreferences? _prefs;

  /// Call once at app start (before runApp). Safe to skip: it then works in memory only.
  static Future<void> init() async {
    try {
      _prefs = await SharedPreferences.getInstance();
      final raw = _prefs!.getStringList(_prefKey) ?? const <String>[];
      final now = DateTime.now();
      for (final line in raw) {
        final p = line.split('|'); // key|failures|lastFailureMs|lockedUntilMs
        if (p.length != 4) continue;
        final last = DateTime.fromMillisecondsSinceEpoch(int.tryParse(p[2]) ?? 0);
        if (now.difference(last) > _staleAfter) continue;
        _failures[p[0]] = int.tryParse(p[1]) ?? 0;
        _lastFailure[p[0]] = last;
        final lock = DateTime.fromMillisecondsSinceEpoch(int.tryParse(p[3]) ?? 0);
        if (lock.isAfter(now)) _lockedUntil[p[0]] = lock;
      }
    } catch (_) {/* memory-only is fine */}
  }

  /// FNV-1a, so raw identifiers (phone numbers) are never written to disk.
  static String _h(String key) {
    var h = 0x811c9dc5;
    for (final c in key.codeUnits) {
      h ^= c;
      h = (h * 0x01000193) & 0xFFFFFFFF;
    }
    return h.toRadixString(16);
  }

  static void _save() {
    final p = _prefs;
    if (p == null) return;
    final lines = <String>[
      for (final e in _failures.entries)
        '${e.key}|${e.value}|${(_lastFailure[e.key] ?? DateTime.now()).millisecondsSinceEpoch}|'
            '${(_lockedUntil[e.key] ?? DateTime.fromMillisecondsSinceEpoch(0)).millisecondsSinceEpoch}',
    ];
    p.setStringList(_prefKey, lines); // fire and forget
  }

  /// Seconds the caller must still wait, or 0 if the attempt may proceed.
  static int secondsLocked(String key) {
    final k = _h(key);
    final until = _lockedUntil[k];
    if (until == null) return 0;
    final left = until.difference(DateTime.now()).inSeconds + 1;
    if (left <= 0) {
      _lockedUntil.remove(k);
      return 0;
    }
    return left;
  }

  static void recordFailure(String key) {
    final k = _h(key);
    final last = _lastFailure[k];
    if (last != null && DateTime.now().difference(last) > _staleAfter) _failures.remove(k);
    final n = (_failures[k] ?? 0) + 1;
    _failures[k] = n;
    _lastFailure[k] = DateTime.now();
    if (n >= maxFailures) {
      final step = n - maxFailures; // 0,1,2...
      final seconds = (30 * (1 << (step > 5 ? 5 : step))).clamp(30, 900);
      _lockedUntil[k] = DateTime.now().add(Duration(seconds: seconds));
    }
    _save();
  }

  static void recordSuccess(String key) {
    final k = _h(key);
    _failures.remove(k);
    _lastFailure.remove(k);
    _lockedUntil.remove(k);
    _save();
  }

  /// Seconds left on a send cool-down WITHOUT starting one (0 = allowed).
  static int cooldownLeft(String key) {
    final until = _cooldowns[_h(key)];
    if (until == null) return 0;
    final left = until.difference(DateTime.now()).inSeconds + 1;
    return left > 0 ? left : 0;
  }

  /// Start the cool-down. Call only after the send actually succeeded.
  static void startCooldown(String key, {int seconds = 30}) {
    _cooldowns[_h(key)] = DateTime.now().add(Duration(seconds: seconds));
  }

  /// Old combined API (used by sign-up screens): returns seconds left, or 0 and starts a
  /// new cool-down when the action is allowed.
  static int cooldown(String key, {int seconds = 30}) {
    final left = cooldownLeft(key);
    if (left > 0) return left;
    startCooldown(key, seconds: seconds);
    return 0;
  }
}

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart' show CameraDevice, ImageSource;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/media_picker.dart';
import '../services/security_settings.dart';
import '../services/session_manager.dart';
import '../widgets/app_image.dart';
import '../widgets/app_ui.dart';
import '../widgets/location_picker_sheet.dart';
import '../widgets/login_modal.dart';
import '../widgets/profile_completion_card.dart';
import '../services/block_service.dart';
import 'accept_invitation_screen.dart';
import 'blocked_users_screen.dart';
import 'favorites_screen.dart';
import 'help_support_screen.dart';
import 'invite_trusted_screen.dart';
import 'my_reviews_screen.dart';
import 'location_service_radius_screen.dart';
import 'nida_verification_screen.dart';
import 'notifications_screen.dart';
import 'payment_methods_screen.dart';
import 'payments_screen.dart';
import 'pocket_fund_screen.dart';
import 'profile_photo_screen.dart';
import 'provider_documents_screen.dart';
import 'register_provider_screen.dart';
import 'registration_fee_screen.dart';
import 'requests_screen.dart';
import 'sell_manage_services_screen.dart';
import 'seller_earnings_screen.dart';
import 'settings_security_screen.dart';
import '../widgets/language_selector_sheet.dart';
import '../services/data_sync.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  double _walletBalance = 0;
  bool _isLoadingWallet = false;
  bool _uploadingAvatar = false;
  int _serviceCount = 0;
  int _pendingInvites = 0; // invitations waiting for me to accept

  @override
  void initState() {
    super.initState();
    _fetchUserWallet();
    _fetchServiceCount();
    _fetchPendingInvites();
    _checkRegistrationFee();
    // Rebuild when city / badge / role change elsewhere in the app.
    SessionManager.sessionNotifier.addListener(_onSessionChanged);
    DataSync.changed.addListener(_onDataChanged);
  }

  void _onSessionChanged() {
    if (mounted) setState(() {});
  }

  // Wallet / services changed elsewhere (deposit, booking release, new service...).
  void _onDataChanged() {
    if (!mounted) return;
    _fetchUserWallet();
    _fetchServiceCount();
    _fetchPendingInvites();
  }

  @override
  void dispose() {
    DataSync.changed.removeListener(_onDataChanged);
    SessionManager.sessionNotifier.removeListener(_onSessionChanged);
    super.dispose();
  }

  Future<void> _fetchServiceCount() async {
    if (!SessionManager.isLoggedIn() || !SessionManager.isSeller()) return;
    final list = await ApiService.fetchSellerServices();
    if (mounted) setState(() => _serviceCount = list.length);
  }

  Future<void> _fetchPendingInvites() async {
    if (!SessionManager.isLoggedIn() || !SessionManager.isSeller() || SessionManager.getBadge() == 'BLUE_TICK') {
      if (mounted && _pendingInvites != 0) setState(() => _pendingInvites = 0);
      return;
    }
    final list = await ApiService.fetchPendingReceivedInvitations();
    if (mounted) setState(() => _pendingInvites = list.length);
  }

  /// Older accounts have no local fee flag: ask the server once.
  Future<void> _checkRegistrationFee() async {
    if (!SessionManager.isLoggedIn() || !SessionManager.isSeller()) return;
    if (SessionManager.getRegFeePaid() != null) return;
    final res = await ApiService.getRegistrationFeeStatus();
    if (res != null && res['paid'] is bool) {
      await SessionManager.setRegFeePaid(res['paid'] as bool);
    }
  }

  void _open(Widget screen) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => screen)).then((_) {
      if (!mounted) return;
      _fetchUserWallet();
      _fetchServiceCount();
      _fetchPendingInvites();
      setState(() {});
    });
  }

  /// Pick a photo, upload it, and show it as the profile picture.
  Future<void> _changeAvatar([ImageSource? source]) async {
    if (_uploadingAvatar) return;
    final isEn = AppStrings.isEnglish;
    final messenger = ScaffoldMessenger.of(context);
    final file = await MediaPicker.pickImage(
      context,
      title: isEn ? 'Profile photo' : 'Picha ya wasifu',
      maxWidth: 1024,
      preferredCamera: CameraDevice.front,
      source: source,
    );
    if (file == null || !mounted) return;
    setState(() => _uploadingAvatar = true);
    final res = await ApiService.uploadAvatar(file.path);
    if (!mounted) return;
    setState(() => _uploadingAvatar = false);
    messenger.showSnackBar(SnackBar(
      backgroundColor: res.ok ? AppColors.success : AppColors.danger,
      content: Text(res.ok
          ? (isEn ? 'Profile photo updated.' : 'Picha ya wasifu imesasishwa.')
          : (res.error ?? (isEn ? 'Could not upload the photo.' : 'Imeshindwa kupakia picha.'))),
    ));
  }

  /// WhatsApp-style photo page: view the photo, change it (camera/gallery) or remove it.
  Future<void> _openPhotoOptions({required String stageName}) async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => ProfilePhotoScreen(name: stageName)));
    if (mounted) setState(() {});
  }

  /// Round profile picture: the uploaded photo, or the first letter of the
  /// name. Tapping it (signed in) changes the photo.
  Widget _avatar({required bool isLoggedIn, required String stageName}) {
    final url = isLoggedIn ? SessionManager.getAvatarUrl() : '';
    final initial = isLoggedIn && stageName.isNotEmpty ? stageName.substring(0, 1).toUpperCase() : '?';
    final letter = Center(
      child: Text(initial, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
    );
    return GestureDetector(
      onTap: isLoggedIn ? () => _openPhotoOptions(stageName: stageName) : null,
      child: SizedBox(
        width: 60,
        height: 60,
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Container(
              width: 60,
              height: 60,
              clipBehavior: Clip.antiAlias,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isLoggedIn ? AppColors.primary : AppColors.textMuted,
              ),
              child: url.isEmpty
                  ? letter
                  : AppImage(url, fit: BoxFit.cover, width: 60, height: 60, errorBuilder: (_, _, _) => letter),
            ),
            if (_uploadingAvatar)
              Positioned.fill(
                child: DecoratedBox(
                  decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.black38),
                  child: const Center(
                    child: SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    ),
                  ),
                ),
              )
            else if (isLoggedIn)
              Positioned(
                right: -2,
                bottom: -2,
                child: Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    shape: BoxShape.circle,
                    border: Border.all(color: AppColors.border),
                  ),
                  child: const Icon(Icons.photo_camera_rounded, size: 12, color: AppColors.primary),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _addPhone() async {
    final isEn = AppStrings.isEnglish;
    final ctrl = TextEditingController(text: SessionManager.getPhone());
    String? error;
    final saved = await AppPage.show<String>(
      context,
      title: isEn ? 'Phone number' : 'Namba ya simu',
      subtitle: isEn ? 'So providers and support can reach you.' : 'Ili watoa huduma na msaada wakufikie.',
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => Column(
          children: [
            AppTextField(
              controller: ctrl,
              icon: Icons.phone_outlined,
              keyboardType: TextInputType.phone,
              hint: '+255 7XX XXX XXX',
              errorText: error,
            ),
            const SizedBox(height: 20),
            AppButton.primary(
              label: isEn ? 'Save' : 'Hifadhi',
              onPressed: () {
                final value = ctrl.text.trim();
                if (value.replaceAll(RegExp(r'[^0-9]'), '').length < 9) {
                  setD(() => error = isEn ? 'Enter a valid phone number' : 'Weka namba sahihi ya simu');
                  return;
                }
                Navigator.pop(ctx, value);
              },
            ),
          ],
        ),
      ),
    );
    if (saved != null) {
      await SessionManager.savePhone(saved);
      if (mounted) setState(() {});
    }
  }

  List<ProfileTask> _tasks({required bool isSeller}) {
    final isEn = AppStrings.isEnglish;
    final badge = SessionManager.getBadge();
    final verified = badge == 'BLUE_TICK' || badge == 'GREEN_BADGE';
    return [
      ProfileTask(
        title: isEn ? 'Add phone number' : 'Weka namba ya simu',
        hint: isEn ? 'So providers and support can reach you' : 'Ili watoa huduma na msaada wakufikie',
        icon: Icons.phone_outlined,
        done: SessionManager.getPhone().trim().isNotEmpty,
        onTap: _addPhone,
      ),
      ProfileTask(
        title: isEn ? 'Choose your city' : 'Chagua mji wako',
        hint: isEn ? 'See services near you' : 'Ona huduma zilizo karibu nawe',
        icon: Icons.location_city_outlined,
        done: SessionManager.hasUserCity(),
        onTap: () => LocationPickerSheet.show(context),
      ),
      ProfileTask(
        title: isEn ? 'Add your social links' : 'Weka mitandao yako ya kijamii',
        hint: isEn ? 'WhatsApp, Instagram, TikTok and more' : 'WhatsApp, Instagram, TikTok na zaidi',
        icon: Icons.alternate_email_rounded,
        done: SessionManager.socialKeys.any((k) => SessionManager.getSocial(k).isNotEmpty),
        onTap: _editSocials,
      ),
      if (isSeller) ...[
        ProfileTask(
          title: isEn ? 'Pay the one-time fee' : 'Lipa ada ya mara moja',
          hint: isEn ? 'Activates your provider account' : 'Huwasha akaunti yako ya mtoa huduma',
          icon: Icons.receipt_long_outlined,
          done: SessionManager.getRegFeePaid() != false,
          onTap: () => _open(const RegistrationFeeScreen()),
        ),
        ProfileTask(
          title: isEn ? 'Verify your identity' : 'Thibitisha utambulisho wako',
          hint: isEn ? 'Get a verified badge and more trust' : 'Pata alama ya uthibitisho na imani zaidi',
          icon: Icons.verified_user_outlined,
          done: verified,
          onTap: () => _open(const NidaVerificationScreen()),
        ),
        ProfileTask(
          title: isEn ? 'Upload your documents' : 'Pakia nyaraka zako',
          hint: isEn ? 'ID photos and selfie to finish verification' : 'Picha za kitambulisho na selfie kukamilisha uthibitisho',
          icon: Icons.upload_file_rounded,
          done: verified || ProviderDocumentsScreen.requiredIds.every(SessionManager.getSubmittedDocs().contains),
          onTap: () => _open(const ProviderDocumentsScreen()),
        ),
        ProfileTask(
          title: isEn ? 'Add your first service' : 'Weka huduma yako ya kwanza',
          hint: isEn ? 'Customers can only book listed services' : 'Wateja wanaweza kuoda huduma zilizowekwa tu',
          icon: Icons.add_business_outlined,
          done: _serviceCount > 0,
          onTap: () => _open(const SellManageServicesScreen()),
        ),
        ProfileTask(
          title: isEn ? 'Unlock your profile so customers can reach you' : 'Fungua wasifu wako ili wateja wakufikie',
          hint: isEn ? 'Settings → Privacy & Security → Profile' : 'Mipangilio → Faragha na Usalama → Wasifu',
          icon: Icons.lock_open_rounded,
          done: !SecuritySettings.profileLocked,
          onTap: () => _open(const SettingsSecurityScreen()),
        ),
      ] else
        ProfileTask(
          title: isEn ? 'Save a favorite service' : 'Hifadhi huduma pendwa',
          hint: isEn ? 'Tap the bookmark on any service' : 'Bonyeza alama ya kuhifadhi kwenye huduma yoyote',
          icon: Icons.favorite_border_rounded,
          done: SessionManager.getFavoriteIds().isNotEmpty,
          onTap: () => _open(const FavoritesScreen()),
        ),
    ];
  }

  Widget _feeBanner() {
    final isEn = AppStrings.isEnglish;
    final amount = SessionManager.registrationFee
        .toString()
        .replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},');
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.dangerLight,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.danger.withValues(alpha: 0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                child: const Icon(Icons.receipt_long_rounded, color: AppColors.dangerDark, size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            isEn ? 'One-time fee' : 'Ada ya mara moja',
                            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                          ),
                        ),
                        StatusPill(text: isEn ? 'Unpaid' : 'Haijalipwa', color: AppColors.dangerDark),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      isEn
                          ? 'Pay TSh $amount once to activate your provider account.'
                          : 'Lipa TSh $amount mara moja kuwasha akaunti yako ya mtoa huduma.',
                      style: const TextStyle(fontSize: 12, height: 1.35, color: AppColors.slateMuted),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 42,
            child: ElevatedButton(
              onPressed: () => _open(const RegistrationFeeScreen()),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.dangerDark,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: Text(isEn ? 'Pay Now' : 'Lipa Sasa', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _unverifiedBanner() {
    final isEn = AppStrings.isEnglish;
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.warningLight,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.warning.withValues(alpha: 0.35)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                child: const Icon(Icons.gpp_maybe_outlined, color: AppColors.warningDark, size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      isEn ? 'Your profile is not verified' : 'Wasifu wako haujathibitishwa',
                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      isEn
                          ? 'Verify with your NIDA to build trust with customers.'
                          : 'Thibitisha kwa NIDA ili upate imani ya wateja.',
                      style: const TextStyle(fontSize: 12, height: 1.35, color: AppColors.slateMuted),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 42,
            child: ElevatedButton(
              onPressed: () => _open(const NidaVerificationScreen()),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.warningDark,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: Text(isEn ? 'Verify now' : 'Thibitisha sasa', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            height: 42,
            child: OutlinedButton.icon(
              onPressed: () => _open(const ProviderDocumentsScreen()),
              icon: const Icon(Icons.upload_file_rounded, size: 18, color: AppColors.warningDark),
              label: Text(isEn ? 'Upload documents' : 'Pakia nyaraka',
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.warningDark)),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppColors.warningDark),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  static const _socialMeta = <String, ({IconData icon, Color color, String en, String sw, String hint})>{
    'whatsapp': (icon: FontAwesomeIcons.whatsapp, color: Color(0xFF25D366), en: 'WhatsApp', sw: 'WhatsApp', hint: '+255 7XX XXX XXX'),
    'instagram': (icon: FontAwesomeIcons.instagram, color: Color(0xFFDD2A7B), en: 'Instagram', sw: 'Instagram', hint: '@username'),
    'facebook': (icon: FontAwesomeIcons.facebookF, color: Color(0xFF1877F2), en: 'Facebook', sw: 'Facebook', hint: 'username'),
    'x': (icon: FontAwesomeIcons.xTwitter, color: Colors.black, en: 'X', sw: 'X', hint: '@username'),
    'tiktok': (icon: FontAwesomeIcons.tiktok, color: Colors.black, en: 'TikTok', sw: 'TikTok', hint: '@username'),
    'youtube': (icon: FontAwesomeIcons.youtube, color: Color(0xFFFF0000), en: 'YouTube', sw: 'YouTube', hint: '@channel'),
  };

  Future<void> _editSocials() async {
    final isEn = AppStrings.isEnglish;
    final ctrls = {for (final k in SessionManager.socialKeys) k: TextEditingController(text: SessionManager.getSocial(k))};
    final saved = await AppPage.show<bool>(
      context,
      title: isEn ? 'Social links' : 'Mitandao ya kijamii',
      subtitle: isEn ? 'Shown on your profile while it is Unlocked.' : 'Huonekana kwenye wasifu wako ukiwa wazi.',
      builder: (ctx) => Column(
        children: [
          for (final k in SessionManager.socialKeys) ...[
            AppTextField(
              controller: ctrls[k]!,
              icon: _socialMeta[k]!.icon,
              hint: '${_socialMeta[k]!.en} (${_socialMeta[k]!.hint})',
            ),
            const SizedBox(height: 10),
          ],
          const SizedBox(height: 6),
          AppButton.primary(label: isEn ? 'Save' : 'Hifadhi', onPressed: () => Navigator.pop(ctx, true)),
        ],
      ),
    );
    if (saved == true) {
      for (final k in SessionManager.socialKeys) {
        await SessionManager.saveSocial(k, ctrls[k]!.text);
      }
    }
    if (mounted) setState(() {});
  }

  Widget _contactCard() {
    final isEn = AppStrings.isEnglish;
    final locked = SecuritySettings.profileLocked;
    final phone = SessionManager.getPhone().trim();
    final socials = [
      for (final k in SessionManager.socialKeys)
        if (SessionManager.getSocial(k).isNotEmpty) k,
    ];

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(locked ? Icons.lock_outline_rounded : Icons.lock_open_rounded,
                  size: 20, color: locked ? AppColors.textSecondary : AppColors.primary),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  isEn ? 'Contact & Socials' : 'Mawasiliano na Mitandao',
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                ),
              ),
              StatusPill(
                text: locked ? (isEn ? 'Locked' : 'Imefungwa') : (isEn ? 'Unlocked' : 'Iko wazi'),
                color: locked ? AppColors.textSecondary : AppColors.successDark,
              ),
            ],
          ),
          const SizedBox(height: 10),
          if (locked) ...[
            Text(
              isEn
                  ? 'Your phone number and social links are hidden. Unlock your profile in Settings to show them.'
                  : 'Namba yako ya simu na mitandao vimefichwa. Fungua wasifu kwenye Mipangilio ili vionekane.',
              style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textSecondary),
            ),
            const SizedBox(height: 8),
            TextButton(
              onPressed: () => _open(const SettingsSecurityScreen()),
              style: TextButton.styleFrom(padding: EdgeInsets.zero, minimumSize: const Size(0, 30)),
              child: Text(isEn ? 'Open Settings' : 'Fungua Mipangilio', style: const TextStyle(fontWeight: FontWeight.w700)),
            ),
          ] else ...[
            InkWell(
              onTap: _addPhone,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  children: [
                    const Icon(Icons.phone_outlined, size: 18, color: AppColors.textPrimary),
                    const SizedBox(width: 10),
                    Text(
                      phone.isEmpty ? (isEn ? 'Add phone number' : 'Weka namba ya simu') : phone,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: phone.isEmpty ? AppColors.primary : AppColors.textPrimary,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 6),
            if (socials.isEmpty)
              Text(
                isEn ? 'No social links added yet.' : 'Bado hujaweka mitandao ya kijamii.',
                style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
              )
            else
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final k in socials)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: _socialMeta[k]!.color.withValues(alpha: 0.08),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          FaIcon(_socialMeta[k]!.icon, size: 13, color: _socialMeta[k]!.color),
                          const SizedBox(width: 6),
                          Text(
                            SessionManager.getSocial(k),
                            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            const SizedBox(height: 6),
            TextButton(
              onPressed: _editSocials,
              style: TextButton.styleFrom(padding: EdgeInsets.zero, minimumSize: const Size(0, 30)),
              child: Text(isEn ? 'Edit social links' : 'Hariri mitandao', style: const TextStyle(fontWeight: FontWeight.w700)),
            ),
          ],
        ],
      ),
    );
  }

  /// Three-dot menu in the profile header (replaces the old Sign Out button).
  Widget _profileMenu() {
    final isEn = AppStrings.isEnglish;
    PopupMenuItem<String> item(String value, IconData icon, String label, {Color? color}) {
      return PopupMenuItem<String>(
        value: value,
        child: Row(
          children: [
            Icon(icon, size: 20, color: color ?? AppColors.textSecondary),
            const SizedBox(width: 12),
            Text(label, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: color ?? AppColors.textPrimary)),
          ],
        ),
      );
    }

    return PopupMenuButton<String>(
      tooltip: isEn ? 'More options' : 'Chaguo zaidi',
      icon: const Icon(Icons.more_vert_rounded, color: AppColors.textPrimary),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      onSelected: _onMenuSelected,
      itemBuilder: (_) => [
        item('edit', Icons.edit_outlined, isEn ? 'Edit profile' : 'Hariri wasifu'),
        item('language', Icons.language_rounded, AppStrings.profileLanguageTitle),
        item('settings', Icons.security_outlined, isEn ? 'Settings & Security' : 'Mipangilio na Usalama'),
        item('help', Icons.help_outline_rounded, AppStrings.profileHelpTitle),
        const PopupMenuDivider(),
        item('signout', Icons.logout_rounded, AppStrings.profileSignOutAction, color: AppColors.danger),
      ],
    );
  }

  void _onMenuSelected(String value) {
    switch (value) {
      case 'edit':
        _showEditProfileSheet();
        break;
      case 'language':
        _showLanguageSelector();
        break;
      case 'settings':
        _open(const SettingsSecurityScreen());
        break;
      case 'help':
        _open(const HelpSupportScreen());
        break;
      case 'signout':
        _confirmSignOut();
        break;
    }
  }

  /// Everything a person can change about their own profile, in one place.
  void _showEditProfileSheet() {
    final isEn = AppStrings.isEnglish;
    Widget row(IconData icon, String title, VoidCallback onTap) {
      return ListTile(
        leading: Icon(icon, color: AppColors.primary),
        title: Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        trailing: const Icon(Icons.chevron_right_rounded, color: AppColors.textSecondary),
        onTap: () {
          Navigator.pop(context);
          onTap();
        },
      );
    }

    AppPage.show<void>(
      context,
      title: isEn ? 'Edit profile' : 'Hariri wasifu',
      builder: (_) => Column(
        children: [
          row(Icons.photo_camera_outlined, isEn ? 'Change profile photo' : 'Badilisha picha ya wasifu', _changeAvatar),
          row(Icons.phone_outlined, isEn ? 'Phone number' : 'Namba ya simu', _addPhone),
          row(Icons.location_city_outlined, isEn ? 'City' : 'Mji', () => LocationPickerSheet.show(context)),
          row(Icons.alternate_email_rounded, isEn ? 'Social links' : 'Mitandao ya kijamii', _editSocials),
        ],
      ),
    );
  }

  Future<void> _confirmSignOut() async {
    final isEn = AppStrings.isEnglish;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(AppStrings.profileSignOutAction),
        content: Text(isEn ? 'Are you sure you want to sign out?' : 'Una uhakika unataka kuondoka kwenye akaunti yako?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(isEn ? 'Cancel' : 'Ghairi')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(AppStrings.profileSignOutAction, style: const TextStyle(color: AppColors.danger)),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    await SessionManager.clearSession();
    if (mounted) setState(() {});
  }

  void _showLanguageSelector() {
    LanguageSelectorSheet.show(context);
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppLanguage>(
      valueListenable: AppStrings.currentLanguage,
      builder: (context, _, _) {
        final isLoggedIn = SessionManager.isLoggedIn();
        final stageName = SessionManager.getStageName();
        // Profile content depends on who is using the app.
        final isSeller = isLoggedIn && SessionManager.isSeller();
        final isBuyer = isLoggedIn && !isSeller;
        // Verification badges belong to providers only.
        final badge = isSeller ? SessionManager.getBadge() : 'NONE';
        final hasBlueTick = badge == 'BLUE_TICK';
        final hasGreenBadge = badge == 'GREEN_BADGE';

        return Scaffold(
          backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        title: Text(
          AppStrings.profileTitle,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.border, height: 1),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // User Card with Stage Name (Legal NIDA Name remains strictly Private)
            Container(
              color: AppColors.surface,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              child: Row(
                children: [
                  _avatar(isLoggedIn: isLoggedIn, stageName: stageName),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(
                              isLoggedIn ? stageName : AppStrings.profileGuestTitle,
                              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                            ),
                            if (hasBlueTick || hasGreenBadge) ...[
                              const SizedBox(width: 4),
                              Icon(Icons.verified_rounded, size: 16, color: hasBlueTick ? AppColors.primary : AppColors.success),
                            ],
                          ],
                        ),
                        const SizedBox(height: 2),
                        Text(
                          isLoggedIn
                              ? (isSeller ? 'Mtoa Huduma (Seller)' : 'Mteja / Mnunuzi (Buyer)')
                              : AppStrings.profileGuestSubtitle,
                          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.primary),
                        ),
                        if (isLoggedIn) ...[
                          const SizedBox(height: 2),
                          Text(
                            [
                              if (!SecuritySettings.profileLocked && SessionManager.getPhone().trim().isNotEmpty)
                                SessionManager.getPhone().trim(),
                              if (SessionManager.hasUserCity()) SessionManager.getUserCity(),
                            ].join('  •  '),
                            style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                          ),
                        ],
                        const SizedBox(height: 4),
                        if (isSeller)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: (hasBlueTick || hasGreenBadge ? AppColors.success : AppColors.warning).withValues(alpha: 0.12),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  hasBlueTick || hasGreenBadge ? Icons.check_circle_rounded : Icons.info_outline_rounded,
                                  size: 12,
                                  color: hasBlueTick || hasGreenBadge ? AppColors.success : AppColors.warning,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  hasBlueTick ? AppStrings.badgeBlueTick : (hasGreenBadge ? AppStrings.badgeGreenBadge : AppStrings.badgeUnverified),
                                  style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                    color: hasBlueTick || hasGreenBadge ? AppColors.success : AppColors.warning,
                                  ),
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                  if (isLoggedIn)
                    _profileMenu()
                  else
                    OutlinedButton(
                      onPressed: () async {
                        await LoginModal.show(context);
                        _fetchUserWallet();
                        if (mounted) setState(() {});
                      },
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: AppColors.primary),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      ),
                      child: Text(
                        AppStrings.profileSignInAction,
                        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.primary),
                      ),
                    ),
                ],
              ),
            ),
            // Providers who have not paid the one-time fee yet.
            if (isSeller && SessionManager.getRegFeePaid() == false) _feeBanner(),
            // Unverified providers are sent to the verification page.
            if (isSeller && !hasBlueTick && !hasGreenBadge) _unverifiedBanner(),
            // Missing profile data (phone, city, verification, first service / favorite).
            if (isLoggedIn) ProfileCompletionCard(tasks: _tasks(isSeller: isSeller)),
            // Contact + socials: shown only while the profile is Unlocked (Settings).
            if (isLoggedIn) _contactCard(),
            const SizedBox(height: 12),

            // GUEST: favorites (saved on this device) + sign-in
            if (!isLoggedIn)
              _section([
                _buildProfileOption(
                  icon: Icons.favorite_border_rounded,
                  title: AppStrings.profileFavoritesTitle,
                  subtitle: AppStrings.profileFavoritesSubtitle,
                  trailingBadge: SessionManager.getFavoriteIds().isEmpty ? null : '${SessionManager.getFavoriteIds().length}',
                  onTap: () => _open(const FavoritesScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.login_rounded,
                  title: AppStrings.profileSignInAction,
                  subtitle: AppStrings.profileGuestSubtitle,
                  trailingBadge: AppStrings.isEnglish ? 'Free' : 'Bure',
                  badgeColor: AppColors.primary,
                  onTap: () async {
                    await LoginModal.show(context);
                    _fetchUserWallet();
                    _fetchServiceCount();
                    if (mounted) setState(() {});
                  },
                ),
              ]),

            // MY ACTIVITY (all signed-in users)
            if (isLoggedIn)
              _section([
                _buildProfileOption(
                  icon: Icons.favorite_border_rounded,
                  title: AppStrings.profileFavoritesTitle,
                  subtitle: AppStrings.profileFavoritesSubtitle,
                  trailingBadge: SessionManager.getFavoriteIds().isEmpty ? null : '${SessionManager.getFavoriteIds().length}',
                  onTap: () => _open(const FavoritesScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.receipt_long_outlined,
                  title: AppStrings.isEnglish ? (isSeller ? 'Requests & Bookings' : 'My Requests') : (isSeller ? 'Maombi na Oda' : 'Maombi Yangu'),
                  subtitle: AppStrings.isEnglish ? 'Track your bookings' : 'Fuatilia oda zako',
                  onTap: () => _open(const RequestsScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.payments_outlined,
                  title: AppStrings.isEnglish ? 'Payments' : 'Malipo',
                  subtitle: AppStrings.isEnglish
                      ? (isSeller ? 'Payments from your customers' : 'Your payment history')
                      : (isSeller ? 'Malipo kutoka kwa wateja wako' : 'Historia ya malipo yako'),
                  onTap: () => _open(const PaymentsScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.star_outline_rounded,
                  title: AppStrings.isEnglish ? 'Reviews' : 'Maoni',
                  subtitle: AppStrings.isEnglish
                      ? (isSeller ? 'Rate customers and see your reviews' : 'Rate providers and see your reviews')
                      : (isSeller ? 'Pima wateja na uone maoni yako' : 'Pima watoa huduma na uone maoni yako'),
                  onTap: () => _open(const MyReviewsScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.notifications_none_rounded,
                  title: AppStrings.isEnglish ? 'Notifications' : 'Arifa',
                  onTap: () => _open(const NotificationsScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.block_rounded,
                  title: AppStrings.isEnglish ? 'Blocked Users' : 'Watumiaji Walizuiwa',
                  subtitle: AppStrings.isEnglish ? 'Manage people you blocked' : 'Simamia watu uliowazuia',
                  trailingBadge: BlockService.count == 0 ? null : '${BlockService.count}',
                  onTap: () => _open(const BlockedUsersScreen()),
                ),
              ]),

            // PROVIDER business tools
            if (isSeller) ...[
              const SizedBox(height: 12),
              _section([
                _buildProfileOption(
                  icon: Icons.design_services_outlined,
                  title: AppStrings.isEnglish ? 'My Services' : 'Huduma Zangu',
                  subtitle: AppStrings.isEnglish ? 'Add and manage your listings' : 'Ongeza na simamia huduma zako',
                  trailingBadge: _serviceCount > 0 ? '$_serviceCount' : null,
                  onTap: () => _open(const SellManageServicesScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.bar_chart_rounded,
                  title: AppStrings.isEnglish ? 'Earnings' : 'Mapato',
                  subtitle: AppStrings.isEnglish ? 'Completed bookings and payments' : 'Oda zilizokamilika na malipo',
                  onTap: () => _open(const SellerEarningsScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.verified_user_outlined,
                  title: AppStrings.profileNidaTitle,
                  subtitle: AppStrings.profileNidaSubtitle,
                  trailingBadge: hasBlueTick ? 'Blue Tick' : (hasGreenBadge ? 'Green Badge' : (AppStrings.isEnglish ? 'Not verified' : 'Bado')),
                  badgeColor: (hasBlueTick || hasGreenBadge) ? AppColors.success : AppColors.warning,
                  onTap: () => _open(const NidaVerificationScreen()),
                ),
                if (hasBlueTick) ...[
                  _buildDivider(),
                  _buildProfileOption(
                    icon: Icons.group_add_outlined,
                    title: AppStrings.isEnglish ? 'Invite someone you trust' : 'Alika unayemwamini',
                    subtitle: AppStrings.isEnglish ? 'Give a friend with a NIN a Blue Tick' : 'Mpe rafiki mwenye NIN Blue Tick',
                    onTap: () => _open(const InviteTrustedScreen()),
                  ),
                ] else ...[
                  _buildDivider(),
                  _buildProfileOption(
                    icon: Icons.mark_email_read_outlined,
                    title: AppStrings.isEnglish ? 'I have an invitation' : 'Nina mwaliko',
                    subtitle: AppStrings.isEnglish ? 'Enter the code and your NIN to get a Blue Tick' : 'Weka msimbo na NIN yako upate Blue Tick',
                    trailingBadge: _pendingInvites > 0 ? '$_pendingInvites' : null,
                    badgeColor: AppColors.warning,
                    onTap: () => _open(const AcceptInvitationScreen()),
                  ),
                ],
                if (!hasBlueTick && !hasGreenBadge) ...[
                  _buildDivider(),
                  _buildProfileOption(
                    icon: Icons.upload_file_rounded,
                    title: AppStrings.isEnglish ? 'Documents' : 'Nyaraka',
                    subtitle: AppStrings.isEnglish ? 'Upload your ID and certificates' : 'Pakia kitambulisho na vyeti vyako',
                    trailingBadge:
                        '${ProviderDocumentsScreen.requiredIds.where(SessionManager.getSubmittedDocs().contains).length}/${ProviderDocumentsScreen.requiredIds.length}',
                    badgeColor: AppColors.warning,
                    onTap: () => _open(const ProviderDocumentsScreen()),
                  ),
                ],
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.location_on_outlined,
                  title: AppStrings.profileLocationTitle,
                  subtitle: AppStrings.profileLocationSubtitle,
                  onTap: () => LocationServiceRadiusSheet.show(context),
                ),
              ]),
            ],

            // WALLET + upgrade (signed-in)
            if (isLoggedIn) ...[
              const SizedBox(height: 12),
              _section([
                _buildProfileOption(
                  icon: Icons.account_balance_wallet_outlined,
                  title: AppStrings.profileWalletTitle,
                  subtitle: AppStrings.profileWalletSubtitle,
                  trailingBadge: _isLoadingWallet
                      ? '...'
                      : '${AppStrings.currency} ${_walletBalance.toInt().toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]},')}',
                  badgeColor: AppColors.success,
                  onTap: () => _open(const PocketFundScreen()),
                ),
                if (isBuyer) ...[
                  _buildDivider(),
                  _buildProfileOption(
                    icon: Icons.credit_card_rounded,
                    title: AppStrings.isEnglish ? 'Payment Methods' : 'Njia za Malipo',
                    subtitle: AppStrings.isEnglish ? 'M-Pesa, Airtel Money, Tigo Pesa, card' : 'M-Pesa, Airtel Money, Tigo Pesa, kadi',
                    onTap: () => _open(const PaymentMethodsScreen()),
                  ),
                ],
                if (isBuyer) ...[
                  _buildDivider(),
                  _buildProfileOption(
                    icon: Icons.storefront_rounded,
                    title: AppStrings.profileBecomeSeller,
                    subtitle: AppStrings.profileBecomeSellerSubtitle,
                    trailingBadge: 'Upgrade',
                    badgeColor: AppColors.primary,
                    onTap: () async {
                      final upgraded = await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const RegisterProviderScreen(isUpgradeFromBuyer: true),
                        ),
                      );
                      if (upgraded == true && mounted) {
                        _fetchServiceCount();
                        setState(() {});
                      }
                    },
                  ),
                ],
              ]),
            ],

            // GENERAL
            const SizedBox(height: 12),
            _section([
              _buildProfileOption(
                icon: Icons.language_rounded,
                title: AppStrings.profileLanguageTitle,
                subtitle: AppStrings.isEnglish ? 'English' : 'Kiswahili',
                trailingBadge: AppStrings.isEnglish ? 'EN' : 'SW',
                badgeColor: AppColors.primary,
                onTap: _showLanguageSelector,
              ),
              if (isLoggedIn) ...[
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.security_outlined,
                  title: 'Settings & Security',
                  subtitle: 'Privacy, password and security',
                  onTap: () => _open(const SettingsSecurityScreen()),
                ),
              ],
              _buildDivider(),
              _buildProfileOption(
                icon: Icons.help_outline_rounded,
                title: AppStrings.profileHelpTitle,
                onTap: () => _open(const HelpSupportScreen()),
              ),
            ]),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
      },
    );
  }

  Widget _buildProfileOption({
    required IconData icon,
    required String title,
    String? subtitle,
    String? trailingBadge,
    Color? badgeColor,
    required VoidCallback onTap,
  }) {
    return ListTile(
      onTap: onTap,
      leading: Icon(icon, color: AppColors.textPrimary, size: 22),
      title: Text(
        title,
        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
      ),
      subtitle: subtitle != null
          ? Text(subtitle, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary))
          : null,
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (trailingBadge != null)
            Container(
              margin: const EdgeInsets.only(right: 6),
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: (badgeColor ?? AppColors.primary).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                trailingBadge,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  color: badgeColor ?? AppColors.primary,
                ),
              ),
            ),
          const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted, size: 20),
        ],
      ),
    );
  }

  Widget _section(List<Widget> children) {
    return Material(color: AppColors.surface, child: Column(children: children));
  }

  Widget _buildDivider() {
    return const Divider(height: 1, thickness: 1, indent: 56, color: AppColors.borderLight);
  }
}

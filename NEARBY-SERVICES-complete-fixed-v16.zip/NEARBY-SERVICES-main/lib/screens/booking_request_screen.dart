import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import '../services/payment_methods_service.dart';
import '../services/session_manager.dart';
import '../widgets/login_modal.dart';
import '../widgets/card_payment_dialog.dart';

class BookingRequestScreen extends StatefulWidget {
  final ServiceItem provider;
  final String serviceTitle;
  final String priceText;
  final String durationText;

  /// Set when the seller agreed to a price offer: the booking is made at this price
  /// and [offerId] lets the server check it (the server, not this app, decides the amount).
  final int? agreedAmount;
  final String? offerId;

  const BookingRequestScreen({
    super.key,
    required this.provider,
    required this.serviceTitle,
    required this.priceText,
    required this.durationText,
    this.agreedAmount,
    this.offerId,
  });

  @override
  State<BookingRequestScreen> createState() => _BookingRequestScreenState();
}

class _BookingRequestScreenState extends State<BookingRequestScreen> {
  DateTime _selectedDateTime = DateTime.now().add(const Duration(days: 1));
  TimeOfDay _selectedTimeOfDay = const TimeOfDay(hour: 10, minute: 0);
  /// Where the service happens, from what the provider set (null when they didn't say).
  String? get _locationOption {
    final en = AppStrings.isEnglish;
    switch (widget.provider.serviceMode) {
      case 'customer_comes':
        return en ? 'You visit the provider' : 'Unamtembelea mtoa huduma';
      case 'provider_travels':
        return en ? 'Provider comes to you' : 'Mtoa huduma anakufuata';
      case 'both':
        return en ? 'Visit them or they come to you' : 'Mnaweza kukutana popote';
      default:
        return null;
    }
  }
  final TextEditingController _noteController = TextEditingController();

  /// What this booking costs: the agreed offer price, else the service's current price.
  double get _amount => (widget.agreedAmount ?? widget.provider.priceAmount).toDouble();
  bool get _hasAgreedPrice => widget.agreedAmount != null && (widget.offerId ?? '').isNotEmpty;

  String _selectedPaymentMethod = 'POCKET_FUND'; // 'POCKET_FUND' or 'DIRECT'
  // When paying DIRECT online: 'mobile_money', 'card' or 'lipa' (Lipa Kwa Simu)
  String _directChannel = 'mobile_money';
  // When paying OFFLINE: 'cash' (pay at the service) or 'transfer' (send money to the provider)
  String _offlineChannel = 'cash';
  final TextEditingController _payPhoneController = TextEditingController();
  bool _isLoading = false;

  @override
  void dispose() {
    _payPhoneController.dispose();
    _noteController.dispose();
    super.dispose();
  }

  String _money(int v) =>
      'TSh ${v.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]},')}';

  /// 'Price agreed with the seller: TSh 40,000 (listed TSh 50,000)'
  String _agreedBannerText() {
    final en = AppStrings.isEnglish;
    final listed = widget.provider.listedPriceAmount > 0 ? widget.provider.listedPriceAmount : widget.provider.priceAmount;
    final agreed = widget.agreedAmount ?? listed;
    final tail = listed > agreed ? (en ? ' (listed ${_money(listed)})' : ' (bei ya kawaida ${_money(listed)})') : '';
    return en
        ? 'Price agreed with the seller: ${_money(agreed)}$tail'
        : 'Bei mliyokubaliana na muuzaji: ${_money(agreed)}$tail';
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDateTime,
      firstDate: now,
      lastDate: now.add(const Duration(days: 90)),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: AppColors.primary,
              onPrimary: Colors.white,
              surface: AppColors.surface,
              onSurface: AppColors.textPrimary,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null) {
      setState(() => _selectedDateTime = picked);
    }
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(
      context: context,
      initialTime: _selectedTimeOfDay,
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: AppColors.primary,
              onPrimary: Colors.white,
              surface: AppColors.surface,
              onSurface: AppColors.textPrimary,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null) {
      setState(() => _selectedTimeOfDay = picked);
    }
  }

  String get _formattedDate {
    final d = _selectedDateTime;
    return '${d.day}/${d.month}/${d.year}';
  }

  String get _formattedTime {
    final h = _selectedTimeOfDay.hour.toString().padLeft(2, '0');
    final m = _selectedTimeOfDay.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }

  // ---- Direct payment helpers (Mobile Money / Card / Lipa Kwa Simu) ----
  Widget _buildChannelOption({
    required String id,
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    bool offline = false, // true: this tile picks the offline channel (cash / transfer)
  }) {
    final selected = offline ? _offlineChannel == id : _directChannel == id;
    return InkWell(
      onTap: () => setState(() {
        if (offline) {
          _offlineChannel = id;
        } else {
          _directChannel = id;
        }
      }),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selected ? AppColors.primary : AppColors.border,
            width: selected ? 1.6 : 1.0,
          ),
        ),
        child: Row(
          children: [
            Icon(
              selected ? Icons.radio_button_checked : Icons.radio_button_off,
              size: 20,
              color: selected ? AppColors.primary : AppColors.textMuted,
            ),
            const SizedBox(width: 10),
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: color, size: 18),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                  const SizedBox(height: 2),
                  Text(subtitle, style: const TextStyle(fontSize: 10, color: AppColors.textSecondary)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPayPhoneField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          AppStrings.isEnglish ? 'Mobile Number to Pay' : 'Namba ya Simu ya Kulipia',
          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
        ),
        const SizedBox(height: 6),
        TextField(
          controller: _payPhoneController,
          keyboardType: TextInputType.phone,
          decoration: InputDecoration(
            hintText: '712 345 678',
            hintStyle: const TextStyle(fontSize: 13, color: AppColors.textMuted),
            prefixIcon: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(width: 12),
                const Icon(Icons.phone_outlined, size: 18, color: AppColors.textSecondary),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(color: AppColors.background, borderRadius: BorderRadius.circular(4)),
                  child: const Text('🇹🇿 +255', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                ),
                const SizedBox(width: 8),
                Container(height: 18, width: 1, color: AppColors.border),
                const SizedBox(width: 8),
              ],
            ),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            isDense: true,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          AppStrings.isEnglish
              ? 'You will get a payment prompt on this number (M-Pesa, Airtel Money, Tigo Pesa or Halopesa).'
              : 'Utapokea ombi la malipo kwenye namba hii (M-Pesa, Airtel Money, Tigo Pesa au Halopesa).',
          style: const TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.4),
        ),
      ],
    );
  }

  Widget _buildPaymentNote(String text) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.background,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.info_outline_rounded, size: 16, color: AppColors.textSecondary),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, height: 1.4))),
        ],
      ),
    );
  }

  Future<void> _sendBookingRequest() async {
    // Signed-in users only (a guest would just get a generic error from the server).
    if (!SessionManager.isLoggedIn()) {
      final ok = await LoginModal.show(context);
      if (ok != true || !mounted) return;
    }
    final providerId = widget.provider.sellerId;
    if (providerId == null || providerId == 0) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        backgroundColor: AppColors.danger,
        content: Text(AppStrings.isEnglish
            ? "This service can't take requests right now. Please try again later."
            : 'Huduma hii haiwezi kupokea maombi kwa sasa. Tafadhali jaribu tena baadaye.'),
      ));
      return;
    }
    // The number the payment prompt goes to (255XXXXXXXXX), checked like every other payment screen.
    String? payPhone;
    if (_selectedPaymentMethod == 'DIRECT' && _directChannel == 'mobile_money') {
      payPhone = PaymentMethodsService.normalizeTzNumber(_payPhoneController.text);
      if (payPhone == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(AppStrings.isEnglish
                ? 'Enter a valid Tanzanian mobile number to pay with.'
                : 'Weka namba sahihi ya simu ya Tanzania utakayotumia kulipa.'),
          ),
        );
        return;
      }
    }

    setState(() => _isLoading = true);

    final sellerId = providerId;
    final serviceId = int.tryParse(widget.provider.id);

    final place = _locationOption;
    final bookingDetails =
        'Date: $_formattedDate, Time: $_formattedTime.${place != null ? ' Place: $place.' : ''} ${_noteController.text.trim()}';

    final res = await ApiService.createEscrow(
      sellerId: sellerId,
      serviceId: serviceId,
      amount: _amount,
      paymentMethod: _selectedPaymentMethod,
      directChannel: _selectedPaymentMethod == 'DIRECT' ? _directChannel : null,
      offlineChannel: _selectedPaymentMethod == 'OFFLINE' ? _offlineChannel : null,
      offerId: _hasAgreedPrice ? widget.offerId : null,
      notes: bookingDetails.trim(),
    );

    // Card: the booking exists now, so charge it against its reference.
    if (res != null && mounted && _selectedPaymentMethod == 'DIRECT' && _directChannel == 'card') {
      final ref = (res['transactionRef'] ?? '').toString();
      final paid = await CardPayment.pay(
        context,
        amount: _amount,
        purpose: 'BOOKING',
        reference: ref,
        description: '${widget.serviceTitle} - ${widget.provider.stageName}',
      );
      if (!mounted) return;
      if (!paid) {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(AppStrings.isEnglish
              ? 'Request sent but card payment was not completed. Pay from your Requests.'
              : 'Ombi limetumwa lakini malipo ya kadi hayajakamilika. Lipa kupitia Maombi yako.'),
        ));
        Navigator.pop(context);
        return;
      }
    }

    // Mobile money: the booking exists now, so send the payment prompt to the number the buyer typed.
    if (res != null && mounted && payPhone != null) {
      final ref = (res['transactionRef'] ?? '').toString();
      final prompt = await ApiService.requestMobilePayment(
        amount: _amount,
        purpose: 'BOOKING',
        reference: ref,
        phone: '+$payPhone',
      );
      if (!mounted) return;
      if (prompt == null) {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(AppStrings.isEnglish
              ? 'Request sent but the payment prompt could not be sent. Pay from your Requests.'
              : 'Ombi limetumwa lakini ombi la malipo halikutumwa. Lipa kupitia Maombi yako.'),
        ));
        Navigator.pop(context);
        return;
      }
    }

    setState(() => _isLoading = false);

    if (res != null && mounted) {
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Row(
            children: [
              const Icon(Icons.verified_user_rounded, color: AppColors.success),
              const SizedBox(width: 8),
              Text(AppStrings.bookingSuccessTitle),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('${widget.serviceTitle} - ${widget.provider.stageName}'),
              const SizedBox(height: 8),
              Text(
                '${AppStrings.sellPriceLabel}: ${widget.priceText}\nKumbukumbu: ${res['transactionRef'] ?? 'ESC-REF'}',
                style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 8),
              Text(
                _selectedPaymentMethod == 'OFFLINE'
                    ? (AppStrings.isEnglish
                        ? 'The provider will review your request. If they ask you to pay first you will get an alert with the payment details. You pay them directly, tap "I have paid", and they confirm.'
                        : 'Mtoa huduma atapitia ombi lako. Akikuomba ulipe kwanza utapata taarifa pamoja na maelezo ya malipo. Unalipa moja kwa moja, unabonyeza "Nimelipa", naye anathibitisha.')
                    : AppStrings.bookingSuccessSubtitle,
                style: const TextStyle(fontSize: 11, color: AppColors.successDark),
              ),
            ],
          ),
          actions: [
            ElevatedButton(
              onPressed: () {
                Navigator.pop(ctx);
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              ),
              child: Text(AppStrings.confirm, style: const TextStyle(color: Colors.white)),
            ),
          ],
        ),
      );
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: AppColors.danger,
          content: Text(AppStrings.error),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          AppStrings.bookingTitle,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Provider Header Info Row with Avatar
            Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: SizedBox(
                    width: 52,
                    height: 52,
                    child: Image.asset(
                      'assets/images/zeen_avatar.jpg',
                      fit: BoxFit.cover,
                      errorBuilder: (ctx, err, stack) => Container(
                        color: AppColors.borderLight,
                        child: const Icon(Icons.person, color: AppColors.textSecondary),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.provider.title,
                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        const Icon(Icons.star_rounded, size: 14, color: AppColors.goldStar),
                        const SizedBox(width: 2),
                        Text(
                          widget.provider.ratingText,
                          style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                        ),
                        const SizedBox(width: 2),
                        Text(
                          widget.provider.reviewsLabel,
                          style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                        ),
                      ],
                    ),
                    const SizedBox(height: 1),
                    Row(
                      children: [
                        const Icon(Icons.location_on_outlined, size: 12, color: AppColors.textSecondary),
                        const SizedBox(width: 2),
                        Text(
                          widget.provider.distance,
                          style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 18),
            const Divider(height: 1, color: AppColors.borderLight),
            const SizedBox(height: 16),

            // Service Section
            Text(
              AppStrings.navServices,
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: SizedBox(
                    width: 48,
                    height: 48,
                    child: Image.asset(
                      'assets/images/banner.jpg',
                      fit: BoxFit.cover,
                      errorBuilder: (ctx, err, stack) => Container(
                        color: AppColors.borderLight,
                        child: const Icon(Icons.spa_rounded, color: AppColors.textSecondary),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.serviceTitle,
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      [widget.durationText, widget.priceText].where((e) => e.trim().isNotEmpty).join(' • '),
                      style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                    ),
                  ],
                ),
              ],
            ),
            if (_hasAgreedPrice) ...[
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.successLight,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.local_offer_rounded, size: 18, color: AppColors.successDark),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        _agreedBannerText(),
                        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.successDark),
                      ),
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 18),
            const Divider(height: 1, color: AppColors.borderLight),
            const SizedBox(height: 16),

            // Date & Time
            Text(
              AppStrings.bookingSelectDate,
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
            ),
            const SizedBox(height: 10),
            InkWell(
              onTap: _pickDate,
              borderRadius: BorderRadius.circular(8),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  children: [
                    const Icon(Icons.calendar_today_rounded, size: 16, color: AppColors.primary),
                    const SizedBox(width: 8),
                    Text(
                      _formattedDate,
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                    ),
                    const Spacer(),
                    const Icon(Icons.edit_calendar_outlined, size: 16, color: AppColors.textSecondary),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            InkWell(
              onTap: _pickTime,
              borderRadius: BorderRadius.circular(8),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  children: [
                    const Icon(Icons.access_time_rounded, size: 16, color: AppColors.primary),
                    const SizedBox(width: 8),
                    Text(
                      _formattedTime,
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                    ),
                    const Spacer(),
                    const Icon(Icons.more_time_rounded, size: 16, color: AppColors.textSecondary),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 18),
            const Divider(height: 1, color: AppColors.borderLight),
            const SizedBox(height: 16),

            // Location
            Text(
              AppStrings.profileLocationTitle,
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
            ),
            const SizedBox(height: 10),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.location_on_outlined, size: 16, color: AppColors.textSecondary),
                const SizedBox(width: 8),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _locationOption ?? (AppStrings.isEnglish ? 'Agree the place with the provider' : 'Kubaliana eneo na mtoa huduma'),
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                    ),
                    if ((widget.provider.city ?? '').trim().isNotEmpty) ...[
                      const SizedBox(height: 1),
                      Text(
                        widget.provider.city!.trim(),
                        style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                      ),
                    ],
                  ],
                ),
              ],
            ),
            // Payment Method & Escrow Security Box
            Text(
              AppStrings.bookingSummaryTitle,
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
            ),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.successLight,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.success.withValues(alpha: 0.3)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.verified_user_rounded, color: AppColors.successDark, size: 22),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      AppStrings.bookingEscrowGuarantee,
                      style: const TextStyle(fontSize: 11, color: AppColors.successDark, fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),

            // Payment Mode Selectors: Pocket Fund vs Direct
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _selectedPaymentMethod = 'POCKET_FUND'),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
                      decoration: BoxDecoration(
                        color: _selectedPaymentMethod == 'POCKET_FUND' ? AppColors.primaryLight : AppColors.background,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: _selectedPaymentMethod == 'POCKET_FUND' ? AppColors.primary : AppColors.border,
                          width: _selectedPaymentMethod == 'POCKET_FUND' ? 1.5 : 1,
                        ),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            _selectedPaymentMethod == 'POCKET_FUND' ? Icons.radio_button_checked : Icons.radio_button_off,
                            size: 18,
                            color: AppColors.primary,
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: const [
                                Text('Pocket Fund', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                                Text('Wallet Balance', style: TextStyle(fontSize: 10, color: AppColors.textSecondary)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _selectedPaymentMethod = 'DIRECT'),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
                      decoration: BoxDecoration(
                        color: _selectedPaymentMethod == 'DIRECT' ? AppColors.primaryLight : AppColors.background,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: _selectedPaymentMethod == 'DIRECT' ? AppColors.primary : AppColors.border,
                          width: _selectedPaymentMethod == 'DIRECT' ? 1.5 : 1,
                        ),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            _selectedPaymentMethod == 'DIRECT' ? Icons.radio_button_checked : Icons.radio_button_off,
                            size: 18,
                            color: AppColors.primary,
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: const [
                                Text('Direct Online', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                                Text('Mobile Money / Card', style: TextStyle(fontSize: 10, color: AppColors.textSecondary)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 10),

            // Offline: pay cash, or send money to the provider yourself
            GestureDetector(
              onTap: () => setState(() => _selectedPaymentMethod = 'OFFLINE'),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
                decoration: BoxDecoration(
                  color: _selectedPaymentMethod == 'OFFLINE' ? AppColors.primaryLight : AppColors.background,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: _selectedPaymentMethod == 'OFFLINE' ? AppColors.primary : AppColors.border,
                    width: _selectedPaymentMethod == 'OFFLINE' ? 1.5 : 1,
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      _selectedPaymentMethod == 'OFFLINE' ? Icons.radio_button_checked : Icons.radio_button_off,
                      size: 18,
                      color: AppColors.primary,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            AppStrings.isEnglish ? 'Pay offline / cash' : 'Lipa nje ya app / pesa taslimu',
                            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                          ),
                          Text(
                            AppStrings.isEnglish ? 'Pay the provider directly' : 'Mlipe mtoa huduma moja kwa moja',
                            style: const TextStyle(fontSize: 10, color: AppColors.textSecondary),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            if (_selectedPaymentMethod == 'OFFLINE') ...[
              const SizedBox(height: 14),
              _buildChannelOption(
                id: 'cash',
                offline: true,
                title: AppStrings.isEnglish ? 'Cash at the service' : 'Pesa taslimu wakati wa huduma',
                subtitle: AppStrings.isEnglish ? 'Pay when you meet' : 'Lipa mkikutana',
                icon: Icons.payments_outlined,
                color: const Color(0xFF16A34A),
              ),
              const SizedBox(height: 8),
              _buildChannelOption(
                id: 'transfer',
                offline: true,
                title: AppStrings.isEnglish ? 'Send money to the provider' : 'Tuma pesa kwa mtoa huduma',
                subtitle: AppStrings.isEnglish ? 'Mobile money or bank, outside the app' : 'Pesa za simu au benki, nje ya app',
                icon: Icons.swap_horiz_rounded,
                color: const Color(0xFF1D4ED8),
              ),
              const SizedBox(height: 8),
              _buildPaymentNote(_offlineChannel == 'cash'
                  ? (AppStrings.isEnglish
                      ? 'No payment is taken in the app. The provider may still ask you to pay first.'
                      : 'Hakuna malipo yanayochukuliwa kwenye app. Mtoa huduma anaweza bado kukuomba ulipe kwanza.')
                  : (AppStrings.isEnglish
                      ? 'The provider sends you their payment details. After you pay, tap "I have paid" in Requests and they confirm it.'
                      : 'Mtoa huduma atakutumia maelezo ya malipo. Baada ya kulipa, bonyeza "Nimelipa" kwenye Maombi naye atathibitisha.')),
            ],

            // Direct online: choose Mobile Money, Card or Lipa Kwa Simu
            if (_selectedPaymentMethod == 'DIRECT') ...[
              const SizedBox(height: 14),
              Text(
                AppStrings.isEnglish ? 'Pay with' : 'Lipa kwa',
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
              ),
              const SizedBox(height: 10),
              _buildChannelOption(
                id: 'mobile_money',
                title: AppStrings.isEnglish ? 'Mobile Money' : 'Pesa za Simu (Mobile Money)',
                subtitle: 'M-Pesa • Airtel Money • Tigo Pesa • Halopesa',
                icon: Icons.phone_android_rounded,
                color: const Color(0xFF16A34A),
              ),
              if (_directChannel == 'mobile_money') ...[
                const SizedBox(height: 10),
                _buildPayPhoneField(),
              ],
              const SizedBox(height: 8),
              _buildChannelOption(
                id: 'card',
                title: AppStrings.isEnglish ? 'Card' : 'Kadi (Card)',
                subtitle: 'Visa • Mastercard',
                icon: Icons.credit_card_rounded,
                color: const Color(0xFF1D4ED8),
              ),
              if (_directChannel == 'card') ...[
                const SizedBox(height: 8),
                _buildPaymentNote(AppStrings.isEnglish
                    ? 'After you send the request you will pay on a secure card page. We never see or store your card details.'
                    : 'Baada ya kutuma ombi utalipa kwenye ukurasa salama wa kadi. Hatuoni wala kuhifadhi taarifa za kadi yako.'),
              ],
              const SizedBox(height: 8),
              _buildChannelOption(
                id: 'lipa',
                title: 'Lipa Kwa Simu',
                subtitle: AppStrings.isEnglish ? 'Pay with a Lipa Number' : 'Lipa kwa Namba ya Lipa',
                icon: Icons.dialpad_rounded,
                color: const Color(0xFFEA580C),
              ),
              if (_directChannel == 'lipa') ...[
                const SizedBox(height: 8),
                _buildPaymentNote(AppStrings.isEnglish
                    ? 'The Lipa Number and payment steps will be shown after you send the request.'
                    : 'Namba ya Lipa na hatua za kulipa zitaonyeshwa baada ya kutuma ombi.'),
              ],
            ],
            const SizedBox(height: 18),
            const Divider(height: 1, color: AppColors.borderLight),
            const SizedBox(height: 16),

            // Message (Optional)
            Text(
              AppStrings.bookingNotesLabel,
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
            ),
            const SizedBox(height: 10),
            Container(
              height: 80,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: AppColors.background,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppColors.border),
              ),
              child: TextField(
                controller: _noteController,
                maxLines: 3,
                decoration: InputDecoration(
                  hintText: AppStrings.bookingNotesHint,
                  hintStyle: const TextStyle(fontSize: 12, color: AppColors.textMuted),
                  border: InputBorder.none,
                  isDense: true,
                ),
              ),
            ),
            const SizedBox(height: 28),

            // Solid Blue Send Request CTA Button
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _sendBookingRequest,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  elevation: 0,
                ),
                child: _isLoading
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                      )
                    : Text(
                        '${AppStrings.bookingConfirmButton} (${widget.priceText})',
                        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

# Trusted invitation API (backend contract)

The app is wired to these endpoints. The server must enforce every rule; the app only displays results.
All calls use `Authorization: Bearer <token>`. Base: `/api`.

## POST /verification/invitations
Body: `{ "inviteePhone": "+255712345678" }`
Success 200: `{ "code": "AB12CD", ... }` (the app shows `<inviterUserId>-<code>` to the inviter).

Server rules:
- Caller must currently have `BLUE_TICK`, else 403 `INVITER_NOT_BLUE_TICK`.
- Reject self-invite (`SELF_INVITE`), invitee already verified (`ALREADY_VERIFIED`), same phone already invited (`ALREADY_INVITED`).
- Rate-limit per inviter (`INVITE_LIMIT_REACHED`, suggested 5 open invitations).
- Code: random, single use, expires (suggested 14 days), stored with inviter id and invitee phone.

## GET /verification/invitations
Returns a list (or `{ "invitations": [...] }`) of `{ code, status: PENDING|ACCEPTED|EXPIRED|CANCELLED, direction: SENT|RECEIVED, name?, phone?, inviterName? }`.

In-app invitations: rows with `direction: RECEIVED` and `status: PENDING` are those whose invited phone matches the caller's verified phone. They must include the full `code` (with inviter id prefix) and `inviterName` (stage name). The app lists them on the accept screen ("Use code") and shows a count on the Profile entry. Optionally also send a push notification when an invitation is created for a registered phone.

## POST /verification/invitations/accept
Body: `{ "code": "123-AB12CD", "nidaNumber": "<20 digits>" }` (the code includes the inviter id prefix).

Server rules, in one transaction:
- Code exists, unused, not expired, and the inviter still has `BLUE_TICK` (`INVITE_INVALID`).
- The accepting account's phone matches the invited phone (`INVITE_PHONE_MISMATCH`).
- NIN is exactly 20 digits (`INVALID_NIN`) and not used by another account (`NIN_ALREADY_USED`).
- Then: save the NIN, set the accepter's badge to `BLUE_TICK`, mark the invitation `ACCEPTED`, and write a record linking inviter and invitee ("vouched for") for audit.

Error body: `{ "message": "<CODE>" }`. The app maps these codes to English/Swahili text.

## Notes
- `POST /verification/blue-tick` with `inviterUserId` (existing `ApiService.applyBlueTick`) trusts a client-supplied inviter id. The new screens do not use it; the server should not grant a tick from that path.
- Decide whether someone who earned a tick by invitation may invite others. Allowing it creates chains of trust; consider a depth limit or a minimum account age.
- If an invitee later turns out to be fraudulent, the stored link lets you review the inviter too.

# Security & login update - summary

## Setup (do once)
1. `flutter pub get`, then `flutter analyze`.
2. Put your server's CA certificate in `assets/certs/pinned_ca.pem` (see `assets/certs/README.txt`).
3. Release build: `API_ORIGIN=https://your.server EXPECTED_SIGNER_SHA256=<hex> ./tool/build_release.sh appbundle`
4. Play Console: link a Cloud project and enable the Play Integrity API; verify tokens on the backend (`docs/play_integrity_backend.md`).
5. Server hardening: `docs/SECURITY_HARDENING.md`.

## New / changed
- Network: certificate pinning, no system proxy, no cleartext, user-CA not trusted (`lib/security/secure_http.dart`, `network_security_config.xml`, iOS ATS)
- URL hiding: obfuscated address, `--dart-define=API_ORIGIN`, Dart obfuscation (`security_config.dart`, `tool/`)
- Device: root / Frida / Xposed / debugger detection, re-scan on resume, signature (tamper) check, FLAG_SECURE (`MainActivity.kt`, `device_integrity.dart`, `integrity_guard.dart`)
- Play Integrity token on sensitive calls (`attestation.dart`)
- Login / forgot password: no account enumeration, strong password policy with common-password detection, persistent lock-outs, network errors no longer count as wrong attempts, safe JSON/status handling, mounted checks, resend countdown (30/60/120s)
- UI: auto spinners on action buttons (`AppButton`, `LoadingTextButton`, offers, orders, payments, top-up)

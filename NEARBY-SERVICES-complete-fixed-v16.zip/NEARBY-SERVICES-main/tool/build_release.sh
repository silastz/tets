#!/usr/bin/env bash
# Hardened release build: obfuscated Dart code, stripped symbols, server URL kept out of the repo.
# Usage: API_ORIGIN=https://your.server ./tool/build_release.sh [apk|appbundle|ios]
set -euo pipefail
TARGET="${1:-appbundle}"
: "${API_ORIGIN:?Set API_ORIGIN=https://your.server}"
mkdir -p build/symbols   # keep these PRIVATE (needed to de-obfuscate crash traces)
flutter build "$TARGET" --release \
  --obfuscate --split-debug-info=build/symbols \
  --dart-define=API_ORIGIN="$API_ORIGIN" \
  --dart-define=REQUIRE_PINNING="${REQUIRE_PINNING:-true}" \
  --dart-define=BLOCK_COMPROMISED=true \
  --dart-define=EXPECTED_SIGNER_SHA256="${EXPECTED_SIGNER_SHA256:-}"

import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../services/api_service.dart';
import '../services/data_sync.dart';

class SellerEarningsScreen extends StatefulWidget {
  final bool showBackButton;
  const SellerEarningsScreen({super.key, this.showBackButton = true});

  @override
  State<SellerEarningsScreen> createState() => _SellerEarningsScreenState();
}

class _SellerEarningsScreenState extends State<SellerEarningsScreen> {
  String _selectedPeriod = 'This Month';
  bool _isLoading = false;

  double _totalEarnings = 0.0;
  int _completedBookings = 0;
  int _pendingPayments = 0;
  double _withdrawnAmount = 0.0;

  List<Map<String, dynamic>> _recentEarnings = [];

  final List<Map<String, dynamic>> _defaultEarnings = [
    {
      'title': 'Massage Therapy',
      'amount': 'TSh 50,000',
      'date': 'Sep 24, 2025',
      'status': 'Paid',
      'avatar': 'assets/images/banner.jpg',
    },
    {
      'title': 'Barber Shop',
      'amount': 'TSh 30,000',
      'date': 'Sep 21, 2025',
      'status': 'Paid',
      'avatar': 'assets/images/provider1.jpg',
    },
  ];

  // Something was written to the server elsewhere (booking, accept, wallet, review...): re-fetch.
  void _onDataChanged() {
    if (mounted) _loadLiveEarnings();
  }

  @override
  void dispose() {
    DataSync.changed.removeListener(_onDataChanged);
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    DataSync.changed.addListener(_onDataChanged);
    _recentEarnings = List.from(_defaultEarnings);
    _loadLiveEarnings();
  }

  Future<void> _loadLiveEarnings() async {
    setState(() => _isLoading = true);
    final ordersFuture = ApiService.fetchSellerOrders();
    final walletFuture = ApiService.getWallet();

    final results = await Future.wait([ordersFuture, walletFuture]);
    final orders = results[0] as List<dynamic>? ?? [];
    final wallet = results[1] as Map<String, dynamic>?;

    if (mounted) {
      if (orders.isNotEmpty) {
        double total = 0.0;
        int completed = 0;
        int pending = 0;

        final mapped = orders.map((order) {
          final amt = (order['amount'] as num?)?.toDouble() ?? 0.0;
          final status = (order['status'] ?? 'PENDING_ACCEPTANCE').toString();
          final service = order['service'] ?? {};
          final title = service['title'] ?? 'Customer Booking';
          final date = order['createdAt'] != null
              ? order['createdAt'].toString().substring(0, 10)
              : 'Recent';

          if (status == 'COMPLETED' || status == 'RELEASED' || status == 'SATISFIED') {
            total += amt;
            completed++;
          } else if (status.contains('PENDING') || status == 'ACCEPTED') {
            pending++;
          }

          return {
            'title': title,
            'amount': 'TSh ${amt.toInt().toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},')}',
            'date': date,
            'status': status == 'COMPLETED' || status == 'RELEASED' ? 'Paid' : status,
            'avatar': 'assets/images/banner.jpg',
          };
        }).toList();

        setState(() {
          _recentEarnings = mapped;
          _totalEarnings = total;
          _completedBookings = completed;
          _pendingPayments = pending;
          if (wallet != null) {
            _withdrawnAmount = (wallet['withdrawn'] as num?)?.toDouble() ?? 0.0;
          }
          _isLoading = false;
        });
      } else {
        setState(() {
          if (wallet != null) {
            _totalEarnings = (wallet['balance'] as num?)?.toDouble() ?? 0.0;
          }
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: widget.showBackButton && Navigator.canPop(context)
            ? IconButton(
                icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
                onPressed: () => Navigator.pop(context),
              )
            : null,
        title: const Text(
          'Earnings',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
          ),
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 16, top: 10, bottom: 10),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: AppColors.borderLight,
              borderRadius: BorderRadius.circular(16),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: _selectedPeriod,
                icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 16, color: AppColors.textPrimary),
                style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                items: ['This Month', 'Last Month', 'All Time'].map((p) {
                  return DropdownMenuItem(value: p, child: Text(p));
                }).toList(),
                onChanged: (val) {
                  if (val != null) setState(() => _selectedPeriod = val);
                },
              ),
            ),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
            // Total Earnings Card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Total Earnings',
                    style: TextStyle(fontSize: 13, color: AppColors.textSecondary, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'TSh ${_totalEarnings.toInt().toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},')}',
                    style: const TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.w900,
                      color: AppColors.textPrimary,
                      letterSpacing: -0.5,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: const [
                      Icon(Icons.arrow_upward_rounded, size: 14, color: AppColors.success),
                      SizedBox(width: 4),
                      Text(
                        'Live from escrow orders',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: AppColors.success,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // 3 KPI Metrics Boxes (Completed Bookings, Pending Payments, Withdrawn)
            Row(
              children: [
                Expanded(
                  child: _buildMetricBox(
                    label: 'Completed Bookings',
                    value: '$_completedBookings',
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _buildMetricBox(
                    label: 'Pending Payments',
                    value: '$_pendingPayments',
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _buildMetricBox(
                    label: 'Withdrawn',
                    value: 'TSh ${_withdrawnAmount.toInt()}',
                    isCurrency: true,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 26),

            // Recent Earnings Section
            const Text(
              'Recent Earnings',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w800,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 12),

            ..._recentEarnings.map((e) {
              return Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppColors.border),
                ),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 20,
                      backgroundImage: AssetImage(e['avatar'] as String),
                      backgroundColor: AppColors.borderLight,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            e['title'] as String,
                            style: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            e['amount'] as String,
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            e['date'] as String,
                            style: const TextStyle(fontSize: 10, color: AppColors.textMuted),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF0FDF4),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Text(
                        'Paid',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: AppColors.success,
                        ),
                      ),
                    ),
                  ],
                ),
              );
            }),
            const SizedBox(height: 24),

            // Withdraw Funds Full-Width Action Button
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      backgroundColor: AppColors.success,
                      content: Text('Withdrawal request initialized to mobile money'),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: const Text(
                  'Withdraw Funds',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800),
                ),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildMetricBox({
    required String label,
    required String value,
    bool isCurrency = false,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 10, color: AppColors.textSecondary),
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: TextStyle(
              fontSize: isCurrency ? 11 : 16,
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
        ],
      ),
    );
  }
}

/// One boost package a provider can buy for a service (e.g. 3 days for TSh 5,000).
/// The server is the source of truth for plans and prices; [BoostPlan.defaults]
/// is only shown when the plans cannot be loaded.
class BoostPlan {
  final String id;
  final int days;
  final int price; // TZS

  const BoostPlan({required this.id, required this.days, required this.price});

  static const List<BoostPlan> defaults = [
    BoostPlan(id: 'boost_1d', days: 1, price: 2000),
    BoostPlan(id: 'boost_3d', days: 3, price: 5000),
    BoostPlan(id: 'boost_7d', days: 7, price: 10000),
  ];

  static BoostPlan? tryParse(dynamic raw) {
    if (raw is! Map) return null;
    final days = raw['days'] ?? raw['durationDays'];
    final price = raw['price'] ?? raw['amount'];
    final d = days is num ? days.toInt() : int.tryParse('${days ?? ''}');
    final p = price is num ? price.toInt() : int.tryParse('${price ?? ''}');
    if (d == null || d <= 0 || p == null || p <= 0) return null;
    final id = (raw['id'] ?? raw['planId'] ?? 'boost_${d}d').toString();
    return BoostPlan(id: id, days: d, price: p);
  }

  String get priceText => formatTzs(price);

  String label(bool isEn) {
    if (isEn) return days == 1 ? '1 day' : '$days days';
    return days == 1 ? 'Siku 1' : 'Siku $days';
  }

  static String formatTzs(num v) =>
      'TSh ${v.toInt().toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},')}';
}

/// Whether a service (raw seller JSON or parsed) is boosted right now, and until when.
class BoostInfo {
  final DateTime? until;
  final bool flag;

  const BoostInfo({this.until, this.flag = false});

  factory BoostInfo.fromJson(Map<String, dynamic> json) {
    final raw = json['boostedUntil'] ?? json['boostEndsAt'] ?? json['boostExpiresAt'] ?? json['sponsoredUntil'];
    final until = raw == null ? null : DateTime.tryParse(raw.toString());
    final flag = json['isBoosted'] == true || json['boosted'] == true || json['isSponsored'] == true || json['sponsored'] == true;
    return BoostInfo(until: until, flag: flag);
  }

  /// With an end time the clock decides; without one the server's flag decides.
  bool get active => until != null ? until!.isAfter(DateTime.now()) : flag;

  /// '2d left', '5h left', '12m left' (or Swahili), empty when not boosted or no end time.
  String left(bool isEn) {
    final u = until;
    if (!active || u == null) return '';
    final diff = u.difference(DateTime.now());
    if (diff.inDays >= 1) return isEn ? '${diff.inDays}d left' : 'Siku ${diff.inDays} zimebaki';
    if (diff.inHours >= 1) return isEn ? '${diff.inHours}h left' : 'Saa ${diff.inHours} zimebaki';
    final m = diff.inMinutes < 1 ? 1 : diff.inMinutes;
    return isEn ? '${m}m left' : 'Dakika $m zimebaki';
  }
}

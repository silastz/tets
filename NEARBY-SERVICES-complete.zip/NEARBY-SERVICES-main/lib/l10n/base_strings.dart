/// Abstract base class defining all localized string keys across the entire application.
/// Every language (e.g. en.dart, sw.dart, fr.dart) implements this interface.
abstract class BaseStrings {
  // 1. Common / Global
  String get appName;
  String get cancel;
  String get close;
  String get save;
  String get submit;
  String get confirm;
  String get back;
  String get retry;
  String get search;
  String get loading;
  String get success;
  String get error;
  String get guest;
  String get active;
  String get pending;
  String get completed;
  String get currency;
  String get viewAll;

  // 2. Navigation Bar
  String get navHome;
  String get authNumberNotVerifiedNotice;
  String get authTooManyAttempts;
  String get exitAppTitle;
  String get exitAppMessage;
  String get exitAppCancel;
  String get exitAppConfirm;
  String get loadingServices;
  String get navChats;
  String get navRequests;
  String get navSell;
  String get navServices;
  String get navEarnings;
  String get navProfile;
  String get navSearch;

  // 3. Home Screen
  String get homeHeaderLocationTitle;
  String get homeGreeting;
  String get homeGreetingSubtitle;
  String get homeSearchPlaceholder;
  String get homeChangeLocation;
  String get selectRegionTitle;
  String get detectingLocation;
  String get searchRegionHint;
  String get nearYouRadius;
  String get noServicesNearby;
  String get bookNow;
  String get bannerRelaxTitle;
  String get bannerRelaxSubtitle;
  String get bannerExploreNow;
  String get chipAll;
  String get chipNearby;
  String get chipTopRated;
  String get chipVerified;
  String get homeCategoriesTitle;
  String get homePopularServices;
  String get homeNearbyProviders;
  String get homeFeaturedProviders;
  String get homeVerifiedBadge;
  String get homeStartingFrom;
  String get homeAllServicesSeen;

  // Categories
  String get catMassage;
  String get catBeauty;
  String get catBarber;
  String get catCleaning;
  String get catPlumbing;
  String get catElectrical;
  String get catMechanic;
  String get catPhotography;
  String get catRepair;
  String get catGeneral;

  // 4. Auth & Login / Registration Modal
  String get authWelcomeBack;
  String get authWelcomeSubtitle;
  String get authCreateAccount;
  String get authCreateSubtitle;
  String get authLoginTab;
  String get authRegisterTab;
  String get authFullNameLabel;
  String get authFullNameHint;
  String get authPhoneLabel;
  String get authPhoneHint;
  String get authEmailLabel;
  String get authEmailHint;
  String get authPasswordLabel;
  String get authPasswordHint;
  String get authSellerAccountSwitch;
  String get authSellerSubtitle;
  String get authSignInButton;
  String get authRegisterButton;
  String get authVerifyOtpTitle;
  String get authVerifyPhoneOtpTitle;
  String get authOtpSentSubtitle;
  String get authPhoneOtpSentSubtitle;
  String get authOtpHint;
  String get authVerifyButton;
  String get authResendOtp;
  String get authInvalidOtpError;
  String get authLoginSuccess;
  String get authRegisterSuccess;
  String get authAlreadyHaveAccount;
  String get authDontHaveAccount;

  // Multi-step Service Provider Registration
  String get regProviderTitle;
  String get regStepBasic;
  String get regStepBusiness;
  String get regStepDocuments;
  String get regStepPayment;
  String get regBasicTitle;
  String get regBasicSubtitle;
  String get regBusinessTitle;
  String get regBusinessSubtitle;
  String get regBusinessNameLabel;
  String get regBusinessNameHint;
  String get regCategoryLabel;
  String get regCategoryHint;
  String get regDescLabel;
  String get regDescHint;
  String get regLocationLabel;
  String get regLocationHint;
  String get regRadiusLabel;
  String get regRadiusHint;
  String get regDocumentsTitle;
  String get regDocumentsSubtitle;
  String get regNidaDocTitle;
  String get regNidaDocSubtitle;
  String get regLicenseDocTitle;
  String get regLicenseDocSubtitle;
  String get regProfilePhotoTitle;
  String get regProfilePhotoSubtitle;
  String get regUploadPhoto;
  String get regUploadDoc;
  String get regDocSafeNotice;
  String get regPaymentTitle;
  String get regPaymentSubtitle;
  String get regFeeLabel;
  String get regFeeOneTime;
  String get regSelectPaymentMethod;
  String get regPaymentActivationNotice;
  String get regBtnContinue;
  String get regBtnPayAndContinue;
  String get regUpgradeFromBuyerBanner;
  String get regSuccessTitle;
  String get regSuccessMsg;
  String get profileBecomeSeller;
  String get profileBecomeSellerSubtitle;
  String get authForgotPasswordLink;
  String get authForgotPasswordTitle;
  String get authForgotPasswordSubtitle;
  String get authSendResetCodeButton;
  String get authResetPasswordTitle;
  String get authNewPasswordLabel;
  String get authResetPasswordButton;
  String get authBackToLogin;
  String get authAccountNotVerifiedError;
  String get authInvalidCredentialsError;
  String get authPhoneExistsError;
  String get authEmailExistsError;
  String get authUsernameExistsError;
  String get authUserNotFoundError;
  String get authInvalidPhoneError;
  String get authNetworkError;

  // Guest Access State
  String get guestTitle;
  String get guestSubtitle;
  String get guestAction;
  String get guestChatsDesc;
  String get guestRequestsDesc;
  String get guestSellDesc;

  // 5. Profile Screen
  String get profileTitle;
  String get profileGuestTitle;
  String get profileGuestSubtitle;
  String get profileSignInAction;
  String get profileSignOutAction;
  String get profileWalletTitle;
  String get profileWalletSubtitle;
  String get profileNidaTitle;
  String get profileNidaSubtitle;
  String get profileLocationTitle;
  String get profileLocationSubtitle;
  String get profileFavoritesTitle;
  String get profileFavoritesSubtitle;
  String get profilePrivacyTitle;
  String get profilePrivacySubtitle;
  String get profileHelpTitle;
  String get profileHelpSubtitle;
  String get profileLanguageTitle;

  // Badges
  String get badgeBlueTick;
  String get badgeGreenBadge;
  String get badgeUnverified;

  // 6. Sell & Manage Services Screen
  String get sellMyServicesTitle;
  String get sellAddService;
  String get sellTabActive;
  String get sellTabPending;
  String get sellTabInactive;
  String get sellNoServicesTitle;
  String get sellNoServicesSubtitle;
  String get sellPostNewTitle;
  String get sellServiceTitleLabel;
  String get sellServiceTitleHint;
  String get sellDescLabel;
  String get sellDescHint;
  String get sellCategoryLabel;
  String get sellPriceLabel;
  String get sellPriceHint;
  String get sellPhoneLabel;
  String get sellPrivacyLockTitle;
  String get sellPrivacyLockSubtitle;
  String get sellPublishButton;
  String get sellPublishSuccess;
  String get sellPublishError;
  String get sellContactsLockedBadge;

  // 7. Requests & Bookings Screen
  String get requestsTitle;
  String get requestsTabIncoming;
  String get requestsTabOutgoing;
  String get requestsNoRequests;
  String get requestsAcceptButton;
  String get requestsRejectButton;
  String get requestsReleaseButton;
  String get requestsAcceptedNotice;
  String get requestsReleasedNotice;
  String get requestsRejectedNotice;
  String get requestsEscrowSecured;

  // 8. Pocket Fund (Wallet) Screen
  String get walletTitle;
  String get walletAvailableBalance;
  String get walletLockedEscrow;
  String get walletDepositAction;
  String get walletWithdrawAction;
  String get walletHistoryTitle;
  String get walletNoTransactions;
  String get walletTopUpSheetTitle;
  String get walletTopUpPhoneHint;
  String get walletTopUpAmountHint;
  String get walletWithdrawSheetTitle;
  String get walletWithdrawSuccess;
  String get walletDepositSuccess;
  String get walletEscrowPolicy;
  String get walletSelectPaymentNetwork;
  String get walletWithdrawPhonePrompt;
  String get walletWithdrawAmountPrompt;
  String get walletWithdrawFailed;
  String get walletDepositFailed;
  String get walletConfirmWithdraw;

  // 9. NIDA Verification Screen
  String get nidaScreenTitle;
  String get nidaHeaderTitle;
  String get nidaHeaderSubtitle;
  String get nidaNumberLabel;
  String get nidaFirstNameLabel;
  String get nidaLastNameLabel;
  String get nidaGuarantorCodeLabel;
  String get nidaUploadIdPhoto;
  String get nidaUploadSelfie;
  String get nidaSubmitButton;
  String get nidaSuccessGreen;
  String get nidaSuccessBlue;

  // 10. Booking Request Screen
  String get bookingTitle;
  String get bookingSummaryTitle;
  String get bookingEscrowGuarantee;
  String get bookingSelectDate;
  String get bookingSelectTime;
  String get bookingNotesLabel;
  String get bookingNotesHint;
  String get bookingConfirmButton;
  String get bookingSuccessTitle;
  String get bookingSuccessSubtitle;

  // 11. Chats Screen
  String get chatsTitle;
  String get chatsNoMessages;
  String get chatsTypePlaceholder;
  String get chatsOnline;
  String get chatsSearchHint;
  String get chatsTabAll;
  String get chatsTabBookings;
  String get chatsTabRequests;

  // 12. Notifications Screen
  String get notificationsTitle;
  String get notificationsNoItems;
  String get notificationsMarkAllRead;

  // 13. Search & Filter Screen
   String get searchFilterTitle;
  String get searchFilterRadius;
  String get searchFilterRating;
  String get searchFilterApply;
  String get searchFilterReset;
  String get searchFilterBy;
  String get searchFilterAll;
  String get searchFilterAvailableNow;
  String get searchFilterVerifiedOnly;
  String get searchFilterDistance;
  String get searchFilterAnyDistance;
  String get searchFilterPriceRange;
  String get searchFilterAnyPrice;
  String get searchFilterAnyRating;
  String get searchFilterCategory;
  String get searchFilterAvailability;
  String get searchFilterAnyTime;
  String get searchFilterServiceType;
  String get searchFilterServiceTypeBoth;
  String get searchFilterSortBy;
  String get searchFilterNearestFirst;

  // 14. Location & Radius Screen
  String get locationRadiusTitle;
  String get locationRadiusSubtitle;
  String get locationRadiusKm;
  String get locationSaveButton;

  // Startup Permissions Modal
  String get permWelcomeTitle;
  String get permWelcomeSubtitle;
  String get permLocationTitle;
  String get permLocationDesc;
  String get permNotificationTitle;
  String get permNotificationDesc;
  String get permAllowButton;
  String get permMaybeLaterButton;

  // 15. Favorites Screen
  String get favoritesTitle;
  String get favoritesNoItems;

  // 16. Service Details & Seller Profile Screen
  String get detailsAboutService;
  String get detailsPricingOptions;
  String get detailsCustomerReviews;
  String get detailsBookNow;
  String get detailsCallNow;
  String get detailsWhatsApp;
  String get detailsSellerProfile;
  String get detailsExperience;
  String get detailsTotalOrders;
  String get detailsVerifiedProvider;
  String get detailsPerSession;
  String get detailsProfessional;
  String get detailsCleanSafe;
  String get detailsAvailableNow;
  String get detailsMemberSince;
  String get detailsViewProfile;
  String get detailsTabOverview;
  String get detailsTabPortfolio;
  String get detailsTabReviews;
  String get detailsTabAvailability;
  String get detailsTabLocation;
  String get detailsServiceDurationPrice;
  String get detailsChat;
  String get detailsLocked;
  String get detailsContactLockedAlert;
  String get nidaPrivacyGuarantee;
  String get nidaOption1Title;
  String get nidaOption1Subtitle;
  String get nidaOption2Title;
  String get nidaOption2Subtitle;
  String get nidaOption3Title;
  String get nidaOption3Subtitle;
  String get nidaIdPhotoCard;
  String get nidaSelfieCard;
  String get nidaUploaded;
  String get nidaGuarantorHint;
  String get nidaFailedGreen;
  String get nidaFailedBlue;
}

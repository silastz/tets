import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';

/// Small green presence dot. Place it on the corner of an avatar/photo
/// (usually inside a [Positioned]). Renders nothing when [online] is false,
/// so callers can drop it in without an `if`.
class OnlineDot extends StatelessWidget {
  final bool online;
  final double size;
  final Color borderColor;

  const OnlineDot({
    super.key,
    this.online = true,
    this.size = 12,
    this.borderColor = Colors.white,
  });

  @override
  Widget build(BuildContext context) {
    if (!online) return const SizedBox.shrink();
    return Semantics(
      label: AppStrings.chatsOnline,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: AppColors.onlineGreen,
          shape: BoxShape.circle,
          border: Border.all(color: borderColor, width: size >= 14 ? 2.5 : 2),
        ),
      ),
    );
  }
}

/// Pill with a dot and the localized "Online" label, for photo overlays
/// and inline status next to a provider name. Renders nothing when offline.
class OnlineBadge extends StatelessWidget {
  final bool online;
  final bool compact;

  /// Use a translucent dark background (for sitting on top of photos).
  final bool onPhoto;

  const OnlineBadge({
    super.key,
    this.online = true,
    this.compact = false,
    this.onPhoto = true,
  });

  @override
  Widget build(BuildContext context) {
    if (!online) return const SizedBox.shrink();
    final dot = compact ? 6.0 : 8.0;
    return Container(
      padding: EdgeInsets.symmetric(horizontal: compact ? 5 : 8, vertical: compact ? 2 : 3),
      decoration: BoxDecoration(
        color: onPhoto ? Colors.black.withValues(alpha: 0.55) : AppColors.onlineGreen.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: dot,
            height: dot,
            decoration: const BoxDecoration(color: AppColors.onlineGreen, shape: BoxShape.circle),
          ),
          SizedBox(width: compact ? 3 : 5),
          Text(
            AppStrings.chatsOnline,
            style: TextStyle(
              fontSize: compact ? 9 : 11,
              fontWeight: FontWeight.w700,
              color: onPhoto ? Colors.white : AppColors.onlineGreen,
            ),
          ),
        ],
      ),
    );
  }
}

# Discounts and price offers

The app side is done; the backend needs the fields, endpoints and rules below.
Negotiation happens **before** the booking. The agreed price is locked into the booking,
then the existing pay-first flow (`PAYMENT_FLOW.md`) runs unchanged on that amount.

```
Service page -> Offer -> seller accepts (or auto-accept) -> AGREED
   -> buyer books with offerId -> PENDING_ACCEPTANCE -> existing payment flow
```

Not in this version: counter-offers (seller proposing another price) and an
"extra discount if paid online" incentive.

## 1. Seller discount (public)

Seller sets it in Add/Edit Service. Sent with `POST /services` and `PUT /services/{id}`
(null clears the value, so the app always sends all five keys):

| Field | Type | Meaning |
|---|---|---|
| `discountPercent` | int 1-90 or null | % off the normal `price` |
| `discountValidUntil` | ISO-8601 or null | End of the sale; null = until removed |
| `allowOffers` | bool | Buyers may send price offers |
| `minOfferPrice` | number or null | **Private.** Offers below this are refused |
| `autoAcceptPrice` | number or null | **Private.** Offers at or above this are accepted at once |

Service JSON returned to everyone: `price` (normal price, unchanged), plus `salePrice`
(final price while the sale runs) and/or `discountPercent`, `discountValidUntil`, `allowOffers`.
The app shows `salePrice` (else works it out from the percent, rounded to TSh 100) with the
normal price struck through, and hides the sale once `discountValidUntil` has passed.
`minOfferPrice` and `autoAcceptPrice` must only be returned to the service owner.

## 2. Price offers

Statuses: `OFFERED`, `AGREED`, `REJECTED`, `WITHDRAWN`, `EXPIRED`, `BOOKED`.

| Who | Call | Effect |
|---|---|---|
| Buyer | `POST /offers` `{serviceId, sellerId, amount, listedPrice, message}` | Creates `OFFERED`; alerts seller. If `amount >= autoAcceptPrice` the status is `AGREED` straight away |
| Seller | `POST /offers/{id}/accept` | `OFFERED` -> `AGREED`; alerts buyer |
| Seller | `POST /offers/{id}/reject` `{reason?}` | `OFFERED` -> `REJECTED`; alerts buyer |
| Buyer | `POST /offers/{id}/withdraw` | `OFFERED` -> `WITHDRAWN` |
| Buyer | `GET /offers/mine` | Offers I sent (array) |
| Seller | `GET /offers/incoming` | Offers on my services (array) |

Offer JSON (what the app reads):
`id, status, serviceId, serviceTitle, listedPrice, amount, agreedAmount, message, createdAt,
expiresAt, bookingRef, buyer{name}, seller{stageName}`.
`expiresAt` is the deadline of the current step (answer deadline while `OFFERED`, booking
deadline while `AGREED`).

## 3. Booking with an agreed price

`POST /escrow/create` now also accepts `offerId`. When present the server **ignores the
`amount` the app sent** and uses the offer's `agreedAmount`.

The booking JSON should also carry `listedPrice`, `agreedAmount`, `discountAmount`, `offerId`
so earnings and disputes show the real numbers. Every payment method (Pocket Fund, mobile money,
card, offline instructions, "I have paid") uses the booking amount.

## Rules the server must enforce (the app cannot)

- `POST /offers`: buyer must be logged in, not the seller, and not blocked by the seller.
- `allowOffers` must be true. Otherwise refuse.
- `amount` must be > 0, not above the current price (sale price if a sale is running) and at
  least 30% of it.
- `amount < minOfferPrice` is refused with a generic message. **Never reveal the minimum.**
- One open offer (`OFFERED` or `AGREED`) per buyer per service. Suggest a limit of ~5 new
  offers per buyer per day.
- Only the seller of the service can accept/reject; only the buyer can withdraw.
- `OFFERED` expires 24 h after creation, `AGREED` expires 48 h after agreement
  (set `expiresAt`, then mark `EXPIRED` with a scheduled job).
- `offerId` on `/escrow/create`: must belong to this buyer and this seller/service, be `AGREED`,
  not expired, and unused. Then set it to `BOOKED` and store `bookingRef`. Reject a second use.
- If the booking is cancelled or rejected before it is paid, the offer stays `BOOKED`
  (the buyer must make a new offer). Choose otherwise if you prefer.
- The seller still accepts the booking (availability) as today; agreeing a price does not
  accept the booking.
- Commission: charge it on the **agreed** amount, whatever the payment method.

## Notifications (suggested)

New offer -> seller. Accepted / auto-agreed / declined -> buyer. Offer or agreement about to
expire (e.g. 2 h left) -> the party who must act.

import 'package:flutter_test/flutter_test.dart';
import 'package:jamiiapp/services/app_update_service.dart';

void main() {
  group('AppUpdateService.compareVersions', () {
    test('orders versions numerically, not as text', () {
      expect(AppUpdateService.compareVersions('1.10.0', '1.9.0'), 1);
      expect(AppUpdateService.compareVersions('1.0.0', '1.0.1'), -1);
      expect(AppUpdateService.compareVersions('2.0', '2.0.0'), 0);
    });
    test('ignores build suffix and leading v', () {
      expect(AppUpdateService.compareVersions('v1.2.0+5', '1.2.0'), 0);
    });
  });

  group('AppUpdateService.decide', () {
    const info = AppVersionInfo(latest: '1.2.0');
    test('same or older backend version: no dialog', () {
      expect(AppUpdateService.decide(installed: '1.2.0', info: info), isNull);
      expect(AppUpdateService.decide(installed: '1.3.0', info: info), isNull);
    });
    test('newer backend version: optional dialog', () {
      expect(AppUpdateService.decide(installed: '1.0.0', info: info), false);
    });
    test('"Later" hides that version only', () {
      expect(AppUpdateService.decide(installed: '1.0.0', info: info, skipped: '1.2.0'), isNull);
      const newer = AppVersionInfo(latest: '1.3.0');
      expect(AppUpdateService.decide(installed: '1.0.0', info: newer, skipped: '1.2.0'), false);
    });
    test('below minVersion or forceUpdate: required, even if skipped', () {
      const minInfo = AppVersionInfo(latest: '1.2.0', minSupported: '1.1.0');
      expect(AppUpdateService.decide(installed: '1.0.0', info: minInfo, skipped: '1.2.0'), true);
      const forced = AppVersionInfo(latest: '1.2.0', force: true);
      expect(AppUpdateService.decide(installed: '1.0.0', info: forced), true);
    });
  });

  test('AppVersionInfo.fromJson accepts plain and {data:{}} bodies', () {
    expect(AppVersionInfo.fromJson({'latestVersion': '1.4.0', 'forceUpdate': true})!.force, true);
    expect(AppVersionInfo.fromJson({'data': {'latestVersion': '1.4.0'}})!.latest, '1.4.0');
    expect(AppVersionInfo.fromJson({'nope': 1}), isNull);
  });
}

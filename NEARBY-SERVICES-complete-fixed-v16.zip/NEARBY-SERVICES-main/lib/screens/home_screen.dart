import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import '../services/gps_service.dart';
import '../services/location_service.dart';
import '../services/security_settings.dart';
import '../services/session_manager.dart';
import '../widgets/category_icon_painter.dart';
import '../widgets/app_image.dart';
import '../widgets/sensitive_tag.dart';
import '../widgets/boost_badge.dart';
import '../widgets/skeleton_loader.dart';
import '../widgets/verification_badge.dart';
import '../widgets/location_picker_sheet.dart';
import 'category_detail_screen.dart';
import 'notifications_screen.dart';
import '../services/notification_feed.dart';
import 'search_filter_screen.dart';
import 'service_details_screen.dart';
import 'pocket_fund_screen.dart';
import '../widgets/language_selector_sheet.dart';
import '../widgets/online_indicator.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedRadius = 2; // Default 2 km as shown in design
  int? _radiusFilter; // only sent to the server after the user picks a radius (default: show all, nearest first)

  // Dynamic Slide Banner Carousel
  late final PageController _bannerController;
  final ValueNotifier<int> _bannerIndexNotifier = ValueNotifier<int>(0);
  Timer? _bannerTimer;

  // Paginated Services List with auto-load on scroll
  late final ScrollController _scrollController;
  final List<ServiceItem> _services = [];
  bool _isLoadingInitial = true;
  /// True when nothing was found in the user's area and these are services from elsewhere.
  bool _elsewhere = false;
  /// True once the radius results are used up and the list continues with
  /// the same services from anywhere (shown under an "also available elsewhere" divider).
  bool _farPhase = false;
  /// How many items come before the divider.
  int _nearCount = 0;
  bool _isLoadingMore = false;
  bool _hasMore = true;
  int _currentPage = 0;
  final int _pageSize = 10;
  String _cachedCity = '';
  int _bannerSlideCount = 0; // number of service slides currently in the banner

  // Masonry (staggered) grid: each image keeps its own proportions.
  final Map<String, double> _imageRatios = {}; // image path -> width / height
  final Set<String> _ratioRequested = {};
  final Map<String, int> _masonryAssign = {}; // service id -> column (stable, no jumping)
  int _masonryColCount = 0;

  void _resolveImageRatio(String path) {
    if (_imageRatios.containsKey(path) || !_ratioRequested.add(path)) return;
    final ImageProvider provider =
        AppImage.isNetwork(path) ? NetworkImage(path) : AssetImage(path) as ImageProvider;
    final stream = provider.resolve(const ImageConfiguration());
    late final ImageStreamListener listener;
    listener = ImageStreamListener((info, _) {
      final ratio = info.image.width / info.image.height;
      stream.removeListener(listener);
      if (mounted) setState(() => _imageRatios[path] = ratio);
    }, onError: (_, __) => stream.removeListener(listener));
    stream.addListener(listener);
  }

  String _cardImagePath(ServiceItem service, int index) {
    if (service.imageUrls.isNotEmpty) return service.imageUrls.first;
    return (index % 2 == 0) ? 'assets/images/provider1.jpg' : 'assets/images/provider2.jpg';
  }

  // Natural proportions, limited so a very tall/wide photo can't dominate the feed.
  double _cardRatio(String path) => (_imageRatios[path] ?? 1.0).clamp(0.75, 1.5).toDouble();

  @override
  void initState() {
    super.initState();
    _bannerController = PageController();
    _scrollController = ScrollController()..addListener(_onScroll);
    _cachedCity = LocationService.activeLocationNotifier.value;

    _loadInitialServices();

    LocationService.activeLocationNotifier.addListener(_onLocationChanged);
    _lastAllowSensitive = SecuritySettings.allowSensitive;
    SecuritySettings.changed.addListener(_onSettingsChanged);
    _hadFix = GpsService.hasFix;
    GpsService.changed.addListener(_onGpsChanged);
    _startBannerAutoSlide();
    SessionManager.sessionNotifier.addListener(_onSessionChanged);
  }

  // Favorites (and other session data) changed elsewhere: redraw hearts.
  void _onSessionChanged() {
    if (mounted) setState(() {});
  }

  late bool _lastAllowSensitive;
  late bool _hadFix;

  /// The first GPS fix arrives after the list loaded: reload so distances and order are right.
  void _onGpsChanged() {
    if (_hadFix || !GpsService.hasFix) return;
    _hadFix = true;
    if (mounted) _loadInitialServices();
  }

  /// Re-fetch the landing page when 'Allow sensitive content' is switched.
  void _onSettingsChanged() {
    if (SecuritySettings.allowSensitive == _lastAllowSensitive) return;
    _lastAllowSensitive = SecuritySettings.allowSensitive;
    if (mounted) _loadInitialServices();
  }

  void _onScroll() {
    if (!_scrollController.hasClients) return;
    if (_scrollController.position.pixels >= _scrollController.position.maxScrollExtent - 250) {
      _loadMoreServices();
    }
  }

  /// 0 km in the radius picker means "Anywhere": no city and no radius.
  bool get _anywhere => _selectedRadius == 0;

  Future<({List<ServiceItem> items, bool hasMore, bool ok})> _fetchPage(int page, {required bool far}) {
    final unlimited = far || _elsewhere || _anywhere;
    return ApiService.fetchServicesPage(
      city: unlimited ? null : _cachedCity,
      radiusKm: unlimited ? null : _radiusFilter,
      page: page,
      size: _pageSize,
    );
  }

  /// First page that has something to show. Blocked-seller and 18+ items are
  /// removed after the server replies, so a page can come back empty while the
  /// server still has more: keep going (a few pages at most) instead of giving up.
  /// [pages] is how many pages were consumed, i.e. the next page to request.
  Future<({({List<ServiceItem> items, bool hasMore, bool ok}) res, int pages})> _firstVisiblePage({required bool far}) async {
    var page = 0;
    late ({List<ServiceItem> items, bool hasMore, bool ok}) res;
    do {
      res = await _fetchPage(page, far: far);
      page++;
    } while (mounted && res.ok && res.items.isEmpty && res.hasMore && page < 6);
    return (res: res, pages: page);
  }

  /// True while a pull-to-refresh reload is running, so scrolling can't append pages to the old list.
  bool _refreshing = false;

  /// Pull-to-refresh: re-detect location + GPS, then reload the feed in place
  /// (the current list stays on screen until the new one arrives).
  Future<void> _onPullToRefresh() async {
    await Future.wait([
      LocationService.detectCurrentLocation(forceRefresh: true),
      GpsService.refresh(),
    ]);
    _cachedCity = LocationService.activeLocationNotifier.value;
    NotificationFeed.refresh();
    await _loadInitialServices(silent: true);
  }

  Future<void> _loadInitialServices({bool silent = false}) async {
    final prevElsewhere = _elsewhere;
    final prevFarPhase = _farPhase;
    if (silent) {
      _refreshing = true;
      _elsewhere = false;
      _farPhase = false;
    } else {
      setState(() {
        _isLoadingInitial = true;
        _currentPage = 0;
        _hasMore = true;
        _masonryAssign.clear();
        _services.clear();
        _elsewhere = false;
        _farPhase = false;
        _nearCount = 0;
      });
    }

    var first = await _firstVisiblePage(far: false);
    var res = first.res;
    var pages = first.pages;
    var newItems = res.items;

    // Nothing in the user's region/country: show the same listings from anywhere.
    var elsewhere = false;
    if (newItems.isEmpty && res.ok && !_anywhere) {
      _elsewhere = true;
      first = await _firstVisiblePage(far: true);
      res = first.res;
      pages = first.pages;
      newItems = res.items;
      elsewhere = newItems.isNotEmpty;
      if (!elsewhere) _elsewhere = false;
    }

    if (!mounted) return;

    // Refresh failed (offline): keep what the user already sees.
    if (silent && !res.ok) {
      _elsewhere = prevElsewhere;
      _farPhase = prevFarPhase;
      _refreshing = false;
      return;
    }

    setState(() {
      _refreshing = false;
      _isLoadingInitial = false;
      _elsewhere = elsewhere;
      if (silent) {
        _masonryAssign.clear();
        _services.clear();
        _nearCount = 0;
      }
      if (newItems.isNotEmpty) {
        _services.addAll(newItems);
        _hasMore = res.hasMore; // server flag: blocked / 18+ items no longer end the list early
        _currentPage = pages;
      } else {
        _hasMore = false;
      }
    });

    // A short radius list: carry on with the same services from anywhere.
    if (_radiusFilter != null && !_anywhere && !elsewhere && newItems.isNotEmpty && !res.hasMore) {
      _startFarPhase();
    }
  }

  void _startFarPhase() {
    if (_farPhase || _elsewhere || _anywhere || _radiusFilter == null) {
      if (mounted) setState(() => _hasMore = false);
      return;
    }
    setState(() {
      _farPhase = true;
      _nearCount = _services.length;
      _currentPage = 0;
      _hasMore = true;
    });
    _loadMoreServices();
  }

  Future<void> _loadMoreServices() async {
    if (_isLoadingMore || !_hasMore || _isLoadingInitial || _refreshing) return;

    setState(() => _isLoadingMore = true);

    final res = await _fetchPage(_currentPage, far: _farPhase);
    final raw = res.items;

    if (!mounted) return;
    if (!res.ok) {
      // Network error: keep the list and try this page again on the next scroll
      // (instead of treating the list as finished).
      setState(() => _isLoadingMore = false);
      return;
    }
    final known = _services.map((x) => x.id).toSet();
    // The "anywhere" pages also contain the nearby ones: skip what is already shown.
    final fresh = _farPhase ? raw.where((x) => !known.contains(x.id)).toList() : raw;
    final exhausted = !res.hasMore;
    setState(() {
      _isLoadingMore = false;
      _services.addAll(fresh);
      _currentPage++;
      _hasMore = !exhausted;
    });
    if (exhausted && !_farPhase) {
      _startFarPhase();
    } else if (_farPhase && fresh.isEmpty && !exhausted) {
      _loadMoreServices(); // a page of only duplicates: keep going
    }
  }

  void _onLocationChanged() {
    final newCity = LocationService.activeLocationNotifier.value;
    if (newCity != _cachedCity) {
      _cachedCity = newCity;
      _loadInitialServices();
    }
  }

  void _startBannerAutoSlide() {
    _bannerTimer?.cancel();
    _bannerTimer = Timer.periodic(const Duration(seconds: 4), (timer) {
      if (_bannerController.hasClients) {
        if (_bannerSlideCount < 2) return;
        final nextPage = (_bannerIndexNotifier.value + 1) % _bannerSlideCount;
        _bannerController.animateToPage(
          nextPage,
          duration: const Duration(milliseconds: 600),
          curve: Curves.easeInOutCubic,
        );
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    LocationService.activeLocationNotifier.removeListener(_onLocationChanged);
    SecuritySettings.changed.removeListener(_onSettingsChanged);
    GpsService.changed.removeListener(_onGpsChanged);
    SessionManager.sessionNotifier.removeListener(_onSessionChanged);
    _bannerTimer?.cancel();
    _bannerController.dispose();
    _bannerIndexNotifier.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppLanguage>(
      valueListenable: AppStrings.currentLanguage,
      builder: (context, _, child) {
        return Scaffold(
          backgroundColor: AppColors.background,
          body: _isLoadingInitial
              ? _buildInitialLoadingSkeleton()
              : RefreshIndicator(
            color: AppColors.primary,
            onRefresh: _onPullToRefresh,
            child: SingleChildScrollView(
            controller: _scrollController,
            physics: const AlwaysScrollableScrollPhysics(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 1. Curved Primary Blue Header with Greeting, Location, Bell & Search Capsule
                _buildTopCurvedHeader(context),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 16),

                      // 2. Promotional Hero Banner ("Professional Services Right Near You")
                      _buildPromotionalBanner(context),
                      const SizedBox(height: 22),

                      // 3. Category Grid Header ("Categories" + "See All")
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            AppStrings.homeCategoriesTitle,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                              color: AppColors.textPrimary,
                              letterSpacing: -0.3,
                            ),
                          ),
                          GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => const CategoryDetailScreen(categoryTitle: 'All Categories'),
                                ),
                              );
                            },
                            child: Text(
                              AppStrings.viewAll,
                              style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w700,
                                color: AppColors.primary,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),

                      // 4. Categories 2x4 Grid
                      _buildCategoriesGrid(context),
                      const SizedBox(height: 26),

                      // 5. "Nearby Services" Section Header
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            AppStrings.homeNearbyProviders,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                              color: AppColors.textPrimary,
                              letterSpacing: -0.3,
                            ),
                          ),
                          GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => const CategoryDetailScreen(categoryTitle: 'Nearby Services'),
                                ),
                              );
                            },
                            child: Text(
                              AppStrings.viewAll,
                              style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w700,
                                color: AppColors.primary,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),

                      // 6. Paginated Services List (Auto-loads more on scroll)
                      _buildPaginatedServicesSection(context),
                      const SizedBox(height: 30),
                    ],
                  ),
                ),
              ],
            ),
            ),
          ),
        );
      },
    );
  }

  // -------------------------------------------------------------
  // TOP CURVED HEADER
  // -------------------------------------------------------------
  Widget _buildTopCurvedHeader(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        color: AppColors.primary,
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(28),
          bottomRight: Radius.circular(28),
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 22),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Top Action Row: Profile Avatar (Left) + Location Selector + Language & Bell (Right)
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Left: User Avatar Profile Button & Quick Location Dropdown
                  Row(
                    children: [
                      // Earnings shortcut: shown ONLY for sellers/providers.
                      // Guests and buyers have no top profile/avatar button.
                      ValueListenableBuilder<int>(
                        valueListenable: SessionManager.sessionNotifier,
                        builder: (context, _, __) {
                          final showEarnings =
                              SessionManager.isLoggedIn() && SessionManager.isSeller();
                          if (!showEarnings) return const SizedBox.shrink();
                          return Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (_) => const PocketFundScreen()),
                                );
                              },
                              child: Container(
                                width: 38,
                                height: 38,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white.withValues(alpha: 0.18),
                                  border: Border.all(color: Colors.white, width: 2),
                                ),
                                child: const Icon(
                                  Icons.account_balance_wallet_rounded,
                                  size: 20,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          );
                        },
                      ),

                      // Location Selector Dropdown
                      ValueListenableBuilder<String>(
                        valueListenable: LocationService.activeLocationNotifier,
                        builder: (context, currentCity, _) {
                          return InkWell(
                            onTap: () => LocationPickerSheet.show(context),
                            borderRadius: BorderRadius.circular(20),
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                              decoration: BoxDecoration(
                                color: Colors.white.withValues(alpha: 0.18),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(Icons.location_on_rounded, size: 15, color: Colors.white),
                                  const SizedBox(width: 4),
                                  Text(
                                    currentCity,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 12,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  const SizedBox(width: 2),
                                  const Icon(Icons.keyboard_arrow_down_rounded, size: 15, color: Colors.white),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ],
                  ),

                  // Right Icons: Language Toggle + Notification Bell (badge 3)
                  Row(
                    children: [
                      // Quick Language Switcher
                      InkWell(
                        onTap: () => LanguageSelectorSheet.show(context),
                        borderRadius: BorderRadius.circular(16),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.18),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(AppStrings.isEnglish ? '🇬🇧' : '🇹🇿', style: const TextStyle(fontSize: 12)),
                              const SizedBox(width: 4),
                              Text(
                                AppStrings.isEnglish ? 'EN' : 'SW',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),

                      // Notification Bell with Badge
                      GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => const NotificationsScreen()),
                          );
                        },
                        child: Stack(
                          clipBehavior: Clip.none,
                          children: [
                            Container(
                              width: 36,
                              height: 36,
                              decoration: BoxDecoration(
                                color: Colors.white.withValues(alpha: 0.18),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                Icons.notifications_none_rounded,
                                size: 20,
                                color: Colors.white,
                              ),
                            ),
                            Positioned(
                              top: -2,
                              right: -2,
                              child: ValueListenableBuilder<int>(
                                valueListenable: NotificationFeed.unread,
                                builder: (context, count, _) {
                                  if (count <= 0) return const SizedBox.shrink();
                                  return Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                                    decoration: const BoxDecoration(
                                      color: AppColors.danger,
                                      borderRadius: BorderRadius.all(Radius.circular(10)),
                                    ),
                                    constraints: const BoxConstraints(minWidth: 16, minHeight: 16),
                                    child: Center(
                                      child: Text(
                                        count > 99 ? '99+' : '$count',
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 9,
                                          fontWeight: FontWeight.bold,
                                          height: 1.0,
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 18),

              // Greeting Headlines: "Hi, Karibu!" + "Find trusted services near you"
              Text(
                AppStrings.homeGreeting,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 26,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.5,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                AppStrings.homeGreetingSubtitle,
                style: TextStyle(
                  color: Colors.white.withValues(alpha: 0.88),
                  fontSize: 13,
                  fontWeight: FontWeight.w400,
                ),
              ),
              const SizedBox(height: 18),

              // Search Bar Capsule with Integrated Distance Selector
              _buildSearchAndRadiusCapsule(context),
            ],
          ),
        ),
      ),
    );
  }

  // -------------------------------------------------------------
  // SEARCH & RADIUS CAPSULE
  // -------------------------------------------------------------
  Widget _buildSearchAndRadiusCapsule(BuildContext context) {
    return Container(
      height: 48,
      padding: const EdgeInsets.only(left: 14, right: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          const Icon(Icons.search_rounded, color: AppColors.textMuted, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const SearchFilterScreen()),
                );
              },
              child: Text(
                AppStrings.homeSearchPlaceholder,
                style: const TextStyle(
                  fontSize: 13,
                  color: AppColors.textMuted,
                  fontWeight: FontWeight.w500,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ),

          // Inline Radius Dropdown Capsule (e.g. "2 km ⌄")
          PopupMenuButton<int>(
            initialValue: _selectedRadius,
            tooltip: 'Filter distance radius',
            onSelected: (val) {
              setState(() {
                _selectedRadius = val;
                _radiusFilter = val == 0 ? null : val; // 0 = Anywhere
              });
              // The banner is rebuilt for the new radius: start from its first slide.
              _bannerIndexNotifier.value = 0;
              if (_bannerController.hasClients) _bannerController.jumpToPage(0);
              _loadInitialServices();
            },
            itemBuilder: (ctx) => [
              PopupMenuItem(value: 0, child: Text(AppStrings.isEnglish ? 'Anywhere' : 'Popote')),
              const PopupMenuItem(value: 1, child: Text('1 km radius')),
              const PopupMenuItem(value: 2, child: Text('2 km radius')),
              const PopupMenuItem(value: 5, child: Text('5 km radius')),
              const PopupMenuItem(value: 10, child: Text('10 km radius')),
              const PopupMenuItem(value: 25, child: Text('25 km radius')),
            ],
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: AppColors.primaryLight,
                borderRadius: BorderRadius.circular(18),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.gps_fixed_rounded, size: 13, color: AppColors.primary),
                  const SizedBox(width: 4),
                  Text(
                    _anywhere ? (AppStrings.isEnglish ? 'Anywhere' : 'Popote') : '$_selectedRadius km',
                    style: const TextStyle(
                      color: AppColors.primary,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(width: 2),
                  const Icon(Icons.keyboard_arrow_down_rounded, size: 14, color: AppColors.primary),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // -------------------------------------------------------------
  // PROMOTIONAL DYNAMIC SLIDE HERO BANNER CAROUSEL
  // -------------------------------------------------------------
  Widget _buildPromotionalBanner(BuildContext context) {
    // Banner slides are the most popular services inside the chosen radius
    // (the "km" capsule next to search). Popularity = rating weighted by how many
    // reviews back it; sponsored only breaks ties. Tapping a slide opens the service.
    double popularity(ServiceItem x) => x.rating * math.log(1 + x.reviewsCount);
    final inRadius = _services.where((x) {
      final d = x.distanceKm;
      // Without a GPS distance the service is already limited to the city.
      return _elsewhere || _anywhere || d == null || d <= _selectedRadius;
    }).toList()
      ..sort((x, y) {
        final c = popularity(y).compareTo(popularity(x));
        if (c != 0) return c;
        if (x.isSponsored != y.isSponsored) return x.isSponsored ? -1 : 1;
        return (x.distanceKm ?? double.infinity).compareTo(y.distanceKm ?? double.infinity);
      });
    final featured = inRadius.take(3).toList();
    _bannerSlideCount = featured.length;
    if (featured.isEmpty) return const SizedBox.shrink();

    const palettes = [
      {
        'gradient': [Color(0xFF0F2B20), Color(0xFF1E4636)],
        'buttonColor': Color(0xFFFBBF24),
        'buttonTextColor': Color(0xFF1E293B),
      },
      {
        'gradient': [Color(0xFF4A154B), Color(0xFF6B1D6D)],
        'buttonColor': Color(0xFF38BDF8),
        'buttonTextColor': Colors.white,
      },
      {
        'gradient': [Color(0xFF0C2461), Color(0xFF1E3799)],
        'buttonColor': Color(0xFFFBBF24),
        'buttonTextColor': Color(0xFF1E293B),
      },
    ];

    final slides = [
      for (int i = 0; i < featured.length; i++)
        {
          'service': featured[i],
          'title': featured[i].title,
          'subtitle': '${featured[i].providerName} • ${featured[i].priceText} • ${featured[i].distance}',
          'buttonText': AppStrings.bannerExploreNow,
          'image': _cardImagePath(featured[i], i),
          ...palettes[i % palettes.length],
        },
    ];

    return Column(
      children: [
        SizedBox(
          height: 150,
          child: PageView.builder(
            controller: _bannerController,
            onPageChanged: (idx) => _bannerIndexNotifier.value = idx,
            itemCount: slides.length,
            itemBuilder: (ctx, index) {
              final slide = slides[index];
              final gradientColors = slide['gradient'] as List<Color>;
              final buttonColor = slide['buttonColor'] as Color;
              final buttonTextColor = slide['buttonTextColor'] as Color;

              // The whole slide opens the service, not just the button.
              return GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => ServiceDetailsScreen(service: slide['service'] as ServiceItem)),
                ),
                child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 1),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: gradientColors,
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: gradientColors.first.withValues(alpha: 0.22),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Stack(
                    children: [
                      // Right Side Hero Photo
                      Positioned(
                        right: 0,
                        top: 0,
                        bottom: 0,
                        width: 175,
                        child: AppImage(
                          slide['image'] as String,
                          fit: BoxFit.cover,
                          errorBuilder: (ctx, err, stack) => Container(
                            color: Colors.black26,
                            child: const Icon(Icons.spa_rounded, color: Colors.white24, size: 50),
                          ),
                        ),
                      ),

                      // Gradient Mask for crisp text contrast
                      Positioned.fill(
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                gradientColors.first,
                                gradientColors.first.withValues(alpha: 0.95),
                                gradientColors.first.withValues(alpha: 0.5),
                                Colors.transparent,
                              ],
                              stops: const [0.0, 0.48, 0.72, 1.0],
                              begin: Alignment.centerLeft,
                              end: Alignment.centerRight,
                            ),
                          ),
                        ),
                      ),

                      // Content & Action Button
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              slide['title'] as String,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                                height: 1.2,
                              ),
                            ),
                            const SizedBox(height: 5),
                            Text(
                              slide['subtitle'] as String,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Color(0xFFCBD5E1),
                                fontSize: 11,
                                fontWeight: FontWeight.w500,
                                height: 1.25,
                              ),
                            ),
                            const SizedBox(height: 12),
                            GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => ServiceDetailsScreen(
                                      service: slide['service'] as ServiceItem,
                                    ),
                                  ),
                                );
                              },
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                                decoration: BoxDecoration(
                                  color: buttonColor,
                                  borderRadius: BorderRadius.circular(18),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withValues(alpha: 0.15),
                                      blurRadius: 4,
                                      offset: const Offset(0, 2),
                                    ),
                                  ],
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      slide['buttonText'] as String,
                                      style: TextStyle(
                                        color: buttonTextColor,
                                        fontSize: 11,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                    const SizedBox(width: 4),
                                    Icon(Icons.arrow_forward_rounded, size: 12, color: buttonTextColor),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                ),
              );
            },
          ),
        ),

        // Carousel Indicator Dots
        const SizedBox(height: 8),
        ValueListenableBuilder<int>(
          valueListenable: _bannerIndexNotifier,
          builder: (context, activeIndex, _) {
            return Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(slides.length, (idx) {
                final isActive = activeIndex == idx;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: isActive ? 18 : 6,
                  height: 6,
                  decoration: BoxDecoration(
                    color: isActive ? AppColors.primary : AppColors.border,
                    borderRadius: BorderRadius.circular(3),
                  ),
                );
              }),
            );
          },
        ),
      ],
    );
  }

  // -------------------------------------------------------------
  // CATEGORIES GRID (Responsive: 1 row on wide screens, 2 rows on mobile)
  // -------------------------------------------------------------
  Widget _buildCategoriesGrid(BuildContext context) {
    final allCategories = [
      {'name': AppStrings.catMassage, 'apiKey': 'Massage', 'color': AppColors.categoryMassage},
      {'name': AppStrings.catBeauty, 'apiKey': 'Beauty', 'color': AppColors.categoryBeauty},
      {'name': AppStrings.catBarber, 'apiKey': 'Barber', 'color': AppColors.categoryBarber},
      {'name': AppStrings.catCleaning, 'apiKey': 'Cleaning', 'color': AppColors.categoryCleaning},
      {'name': AppStrings.catPlumbing, 'apiKey': 'Plumbing', 'color': AppColors.categoryPlumbing},
      {'name': AppStrings.catElectrical, 'apiKey': 'Electrical', 'color': AppColors.categoryElectrical},
      {'name': AppStrings.catMechanic, 'apiKey': 'Mechanic', 'color': AppColors.categoryMechanic},
      {'name': AppStrings.catPhotography, 'apiKey': 'Photography', 'color': AppColors.categoryPhotography},
    ];

    return LayoutBuilder(
      builder: (context, constraints) {
        final isWideScreen = constraints.maxWidth >= 600;

        if (isWideScreen) {
          // On big screens: all categories appear on the SAME single row
          return Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: allCategories.map((cat) => _buildCategoryTile(context, cat)).toList(),
          );
        }

        // On smaller screens: 2 rows of 4
        final row1 = allCategories.sublist(0, 4);
        final row2 = allCategories.sublist(4, 8);

        return Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: row1.map((cat) => _buildCategoryTile(context, cat)).toList(),
            ),
            const SizedBox(height: 14),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: row2.map((cat) => _buildCategoryTile(context, cat)).toList(),
            ),
          ],
        );
      },
    );
  }

  Widget _buildCategoryTile(BuildContext context, Map<String, dynamic> cat) {
    final displayName = cat['name'] as String;
    final apiKey = cat['apiKey'] as String;
    final color = cat['color'] as Color;

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => CategoryDetailScreen(
              categoryTitle: displayName,
              categoryApiKey: apiKey,
            ),
          ),
        );
      },
      child: SizedBox(
        width: 72,
        child: Column(
          children: [
            Container(
              width: 54,
              height: 54,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: color.withValues(alpha: 0.28),
                    blurRadius: 8,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: CustomPaint(
                painter: CategoryBadgePainter(category: apiKey),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              displayName,
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  // -------------------------------------------------------------
  // RICH SERVICE CARDS (NEARBY & POPULAR SERVICES)
  // Respects original user-uploaded image aspect ratio
  // -------------------------------------------------------------
  // -------------------------------------------------------------
  // PAGINATED SERVICES SECTION (LANDING PAGE AUTO-LOAD ON SCROLL)
  // Replaces the old static/popular duplicate sections
  // -------------------------------------------------------------
  // Full-page placeholder shown while the first batch of data loads,
  // so the app never looks static/offline when it opens.
  Widget _buildInitialLoadingSkeleton() {
    return SingleChildScrollView(
      physics: const NeverScrollableScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            padding: EdgeInsets.fromLTRB(16, MediaQuery.of(context).padding.top + 16, 16, 24),
            decoration: const BoxDecoration(
              color: AppColors.primary,
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: const [
                    SkeletonShimmer(width: 150, height: 18, borderRadius: 6),
                    SkeletonShimmer.circular(size: 36),
                  ],
                ),
                const SizedBox(height: 18),
                const SkeletonShimmer(width: double.infinity, height: 46, borderRadius: 24),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 16),
                const SkeletonShimmer(width: double.infinity, height: 140, borderRadius: 18),
                const SizedBox(height: 22),
                const SkeletonShimmer(width: 120, height: 18, borderRadius: 6),
                const SizedBox(height: 14),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: List.generate(
                    4,
                    (_) => const Column(
                      children: [
                        SkeletonShimmer.circular(size: 56),
                        SizedBox(height: 8),
                        SkeletonShimmer(width: 48, height: 10, borderRadius: 4),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                const SkeletonShimmer(width: 160, height: 18, borderRadius: 6),
                const SizedBox(height: 12),
                const HorizontalCardSkeleton(),
                const SizedBox(height: 16),
                Center(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const SizedBox(
                        width: 14,
                        height: 14,
                        child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.primary),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        AppStrings.loadingServices,
                        style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _groupHeader({required bool near}) {
    final en = AppStrings.isEnglish;
    return Padding(
      padding: EdgeInsets.only(bottom: 10, top: near ? 0 : 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!near) ...[
            const Divider(height: 1, color: AppColors.border),
            const SizedBox(height: 14),
          ],
          Row(
            children: [
              Icon(near ? Icons.near_me_rounded : Icons.public_rounded, size: 16, color: AppColors.primary),
              const SizedBox(width: 6),
              Text(
                near ? (en ? 'Near you' : 'Karibu nawe') : (en ? 'Also available elsewhere' : 'Pia zinapatikana maeneo mengine'),
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(left: 22, top: 2),
            child: Text(
              near
                  ? (en ? 'Within $_selectedRadius km' : 'Ndani ya km $_selectedRadius')
                  : (en ? 'Outside $_selectedRadius km' : 'Nje ya km $_selectedRadius'),
              style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPaginatedServicesSection(BuildContext context) {
    if (_isLoadingInitial) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 12),
        child: HorizontalCardSkeleton(),
      );
    }

    if (_services.isEmpty) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 36, horizontal: 16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          children: [
            const Icon(Icons.search_off_rounded, size: 42, color: AppColors.textMuted),
            const SizedBox(height: 10),
            Text(
              AppStrings.noServicesNearby,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: AppColors.textSecondary,
              ),
            ),
          ],
        ),
      );
    }

    return Column(
      children: [
        if (_elsewhere)
          Container(
            width: double.infinity,
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.primary.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                const Icon(Icons.public_rounded, size: 18, color: AppColors.primary),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    AppStrings.isEnglish
                        ? 'No providers in $_cachedCity yet. Showing services available elsewhere.'
                        : 'Hakuna watoa huduma $_cachedCity bado. Tunaonyesha huduma za maeneo mengine.',
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                  ),
                ),
              ],
            ),
          ),
        LayoutBuilder(
          builder: (context, constraints) {
            // Adaptive grid: 2 columns on mobile, 3-4 columns on tablet/web
            final crossAxisCount = constraints.maxWidth > 900
                ? 4
                : constraints.maxWidth > 600
                    ? 3
                    : 2;

            Widget cardFor(int index) {
                final service = _services[index];
                final isFav = SessionManager.isFavorite(service.id);
                final imagePath = _cardImagePath(service, index);
                _resolveImageRatio(imagePath);

                return GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ServiceDetailsScreen(service: service),
                      ),
                    );
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppColors.border),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.04),
                          blurRadius: 8,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // 1. Top Image with Badges & Favorite Icon
                        ClipRRect(
                            borderRadius: const BorderRadius.vertical(top: Radius.circular(15)),
                            child: AspectRatio(
                              aspectRatio: _cardRatio(imagePath),
                              child: Stack(
                              fit: StackFit.expand,
                              children: [
                                Container(
                                  color: service.themeColor.withValues(alpha: 0.1),
                                  child: AppImage(
                                    imagePath,
                                    fit: BoxFit.cover,
                                    errorBuilder: (ctx, err, stack) => Center(
                                      child: Icon(service.icon, color: service.themeColor, size: 40),
                                    ),
                                  ),
                                ),

                                if (service.is18Plus)
                                  const Positioned(top: 6, left: 6, child: SensitiveTag(compact: true)),

                                if (service.isBoosted)
                                  Positioned(top: service.is18Plus ? 28 : 6, left: 6, child: const BoostBadge(compact: true)),

                                if (service.isOnline)
                                  const Positioned(bottom: 6, left: 6, child: OnlineBadge(compact: true)),

                                // Top Right: Favorite Heart Toggle Button
                                Positioned(
                                  top: 6,
                                  right: 6,
                                  child: GestureDetector(
                                    onTap: () => SessionManager.toggleFavorite(service.id),
                                    child: Container(
                                      width: 26,
                                      height: 26,
                                      decoration: BoxDecoration(
                                        color: Colors.white.withValues(alpha: 0.9),
                                        shape: BoxShape.circle,
                                      ),
                                      child: Icon(
                                        isFav ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                                        size: 15,
                                        color: isFav ? AppColors.danger : AppColors.textSecondary,
                                      ),
                                    ),
                                  ),
                                ),

                                // Bottom Left overlay: Distance Pill
                                Positioned(
                                  bottom: 6,
                                  left: 6,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                                    decoration: BoxDecoration(
                                      color: Colors.black.withValues(alpha: 0.65),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        const Icon(Icons.location_on, size: 9, color: Colors.white),
                                        const SizedBox(width: 2),
                                        Text(
                                          service.distance,
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 8,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                              ),
                            ),
                          ),

                        // 2. Card Body Details (height follows its content)
                        Padding(
                            padding: const EdgeInsets.all(8),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                // Category Pill & Rating
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Flexible(
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                                        decoration: BoxDecoration(
                                          color: AppColors.background,
                                          borderRadius: BorderRadius.circular(4),
                                          border: Border.all(color: AppColors.border),
                                        ),
                                        child: Text(
                                          service.category,
                                          style: const TextStyle(
                                            fontSize: 8,
                                            fontWeight: FontWeight.w700,
                                            color: AppColors.textSecondary,
                                          ),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ),
                                    Row(
                                      children: [
                                        const Icon(Icons.star_rounded, size: 12, color: Color(0xFFFBBF24)),
                                        const SizedBox(width: 2),
                                        Text(
                                          service.ratingText,
                                          style: const TextStyle(
                                            fontSize: 10,
                                            fontWeight: FontWeight.w800,
                                            color: AppColors.textPrimary,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),

                                const SizedBox(height: 6),
                                // Service Title
                                Text(
                                  service.title,
                                  style: const TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w800,
                                    color: AppColors.textPrimary,
                                    height: 1.15,
                                  ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),

                                const SizedBox(height: 4),
                                // Price & Duration
                                Text(
                                  service.priceWithDuration,
                                  style: const TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w800,
                                    color: AppColors.primary,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),

                                const SizedBox(height: 6),
                                // Seller Avatar & Name Footer
                                Row(
                                  children: [
                                    Container(
                                      width: 16,
                                      height: 16,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        border: Border.all(color: AppColors.border),
                                        image: const DecorationImage(
                                          image: AssetImage('assets/images/zeen_avatar.jpg'),
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 4),
                                    Expanded(
                                      child: Text(
                                        service.providerName,
                                        style: const TextStyle(
                                          fontSize: 10,
                                          fontWeight: FontWeight.w600,
                                          color: AppColors.textSecondary,
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                    if (service.hasBlueTick) ...[
                                      const SizedBox(width: 2),
                                      VerificationBadge(level: service.verificationLevel, size: 11, showGreen: false),
                                    ],
                                  ],
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                );
            }

            // Place each card in the currently shortest column (assignment is remembered,
            // so cards never jump between columns while images finish loading).
            if (_masonryColCount != crossAxisCount) {
              _masonryAssign.clear();
              _masonryColCount = crossAxisCount;
            }
            Widget group(List<int> idxs) {
            final heights = List<double>.filled(crossAxisCount, 0);
            final columns = List.generate(crossAxisCount, (_) => <int>[]);
            for (final i in idxs) {
              final id = _services[i].id;
              var col = _masonryAssign[id];
              if (col == null) {
                col = 0;
                for (int c = 1; c < crossAxisCount; c++) {
                  if (heights[c] < heights[col!]) col = c;
                }
                _masonryAssign[id] = col!;
              }
              columns[col].add(i);
              heights[col] += 1 / _cardRatio(_cardImagePath(_services[i], i)) + 0.6;
            }

            return Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (int c = 0; c < crossAxisCount; c++) ...[
                  if (c > 0) const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      children: [
                        for (final i in columns[c])
                          Padding(
                            padding: const EdgeInsets.only(bottom: 14),
                            child: cardFor(i),
                          ),
                      ],
                    ),
                  ),
                ],
              ],
            );
            }

            final split = _farPhase && !_elsewhere && _nearCount > 0 && _nearCount < _services.length;
            if (!split) return group([for (int i = 0; i < _services.length; i++) i]);
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _groupHeader(near: true),
                group([for (int i = 0; i < _nearCount; i++) i]),
                const SizedBox(height: 6),
                _groupHeader(near: false),
                group([for (int i = _nearCount; i < _services.length; i++) i]),
              ],
            );
          },
        ),

        // Infinite Scroll Loading Indicator
        if (_isLoadingMore) ...[
          const SizedBox(height: 18),
          const Center(
            child: SizedBox(
              width: 24,
              height: 24,
              child: CircularProgressIndicator(
                strokeWidth: 2.5,
                color: AppColors.primary,
              ),
            ),
          ),
        ] else if (!_hasMore && _services.isNotEmpty) ...[
          const SizedBox(height: 18),
          Center(
            child: Text(
              AppStrings.homeAllServicesSeen,
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w500,
                color: AppColors.textMuted,
              ),
            ),
          ),
        ],
      ],
    );
  }
}

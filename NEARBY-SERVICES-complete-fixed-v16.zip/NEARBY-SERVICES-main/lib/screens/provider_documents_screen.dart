import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart' show CameraDevice;
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/id_kinds.dart';
import '../services/api_service.dart';
import '../services/media_picker.dart';
import '../services/session_manager.dart';
import '../widgets/app_ui.dart';

class _DocType {
  final String id;
  final String titleEn;
  final String titleSw;
  final String hintEn;
  final String hintSw;
  final IconData icon;
  final bool required;

  /// Face checks are taken live with the front camera (no gallery).
  final bool cameraOnly;
  const _DocType(this.id, this.titleEn, this.titleSw, this.hintEn, this.hintSw, this.icon,
      {this.required = true, this.cameraOnly = false});
}

/// Documents a provider uploads to finish their profile / get verified:
/// an identity document (front and back), a face check, and optional
/// business papers.
class ProviderDocumentsScreen extends StatefulWidget {
  const ProviderDocumentsScreen({super.key});

  /// Required document ids (used by the profile checklist). A passport has no
  /// back side, so it only needs the front.
  static List<String> get requiredIds => [
        'id_front',
        if (IdKinds.byId(SessionManager.getIdKind()).hasBack) 'id_back',
        'selfie_with_id',
      ];

  @override
  State<ProviderDocumentsScreen> createState() => _ProviderDocumentsScreenState();
}

class _ProviderDocumentsScreenState extends State<ProviderDocumentsScreen> {
  static const _faceDocs = <_DocType>[
    _DocType('face_photo', 'Face photo', 'Picha ya uso',
        'Look straight at the camera in good light. No hat or sunglasses.',
        'Tazama kamera moja kwa moja mwangaza mzuri. Bila kofia au miwani.', Icons.face_retouching_natural_rounded,
        required: false, cameraOnly: true),
    _DocType('selfie_with_id', 'Selfie holding your ID', 'Picha yako ukishika kitambulisho',
        'Your face and the ID must both be readable', 'Uso wako na kitambulisho vionekane vizuri', Icons.face_rounded,
        cameraOnly: true),
  ];

  static const _businessDocs = <_DocType>[
    _DocType('business_license', 'Business licence', 'Leseni ya biashara',
        'Optional - adds trust with customers', 'Hiari - huongeza imani ya wateja', Icons.business_center_outlined,
        required: false),
    _DocType('tin_certificate', 'TIN certificate', 'Cheti cha TIN',
        'Optional - your tax number certificate', 'Hiari - cheti cha namba ya mlipakodi', Icons.receipt_long_outlined,
        required: false),
    _DocType('certificate', 'Professional certificate', 'Cheti cha ujuzi',
        'Optional - training or trade certificate', 'Hiari - cheti cha mafunzo au ufundi', Icons.workspace_premium_outlined,
        required: false),
  ];

  late String _kind = SessionManager.getIdKind();

  /// Front (and back, when the document has one) of the chosen ID.
  List<_DocType> get _idDocs {
    final k = IdKinds.byId(_kind);
    return [
      _DocType('id_front', k.hasBack ? '${k.en} - front' : '${k.en} - photo page',
          k.hasBack ? '${k.sw} - mbele' : '${k.sw} - ukurasa wa picha',
          'Clear photo, all four corners visible', 'Picha wazi, pembe zote nne zionekane', k.icon),
      if (k.hasBack)
        _DocType('id_back', '${k.en} - back', '${k.sw} - nyuma',
            'Clear photo, no glare', 'Picha wazi, bila mng\'ao', k.icon),
    ];
  }

  bool _loading = true;
  bool _loadFailed = false;
  String? _uploading;
  // type -> {status, reason}
  final Map<String, Map<String, String>> _server = {};

  bool get _isEn => AppStrings.isEnglish;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final list = await ApiService.fetchVerificationDocuments();
    if (!mounted) return;
    setState(() {
      _loadFailed = list == null;
      _server.clear();
      for (final e in list ?? const []) {
        if (e is Map && e['type'] != null) {
          _server[e['type'].toString()] = {
            'status': (e['status'] ?? 'PENDING').toString().toUpperCase(),
            'reason': (e['reason'] ?? '').toString(),
          };
        }
      }
      _loading = false;
    });
  }

  /// MISSING | PENDING | APPROVED | REJECTED
  String _statusOf(String id) {
    final s = _server[id]?['status'];
    if (s != null) {
      if (s == 'APPROVED' || s == 'VERIFIED') return 'APPROVED';
      if (s == 'REJECTED') return 'REJECTED';
      return 'PENDING';
    }
    return SessionManager.getSubmittedDocs().contains(id) ? 'PENDING' : 'MISSING';
  }

  Future<void> _pickAndUpload(_DocType doc) async {
    final messenger = ScaffoldMessenger.of(context);
    final isId = doc.id == 'id_front' || doc.id == 'id_back';
    final file = await MediaPicker.pickImage(
      context,
      title: _isEn ? doc.titleEn : doc.titleSw,
      cameraOnly: doc.cameraOnly,
      preferredCamera: doc.cameraOnly ? CameraDevice.front : CameraDevice.rear,
      maxWidth: doc.cameraOnly ? 1280 : 1800,
    );
    if (file == null || !mounted) return;

    setState(() => _uploading = doc.id);
    final res = await ApiService.uploadVerificationDocument(
      type: doc.id,
      filePath: file.path,
      idKind: isId ? _kind : null,
    );
    if (res.ok) await SessionManager.addSubmittedDoc(doc.id);
    if (!mounted) return;
    setState(() => _uploading = null);
    messenger.showSnackBar(SnackBar(
      backgroundColor: res.ok ? AppColors.success : AppColors.danger,
      content: Text(res.ok
          ? (_isEn ? 'Uploaded. We will review it shortly.' : 'Imepakiwa. Tutaipitia hivi karibuni.')
          : (res.error ?? (_isEn ? 'Upload failed. Check your connection and try again.' : 'Imeshindwa kupakia. Angalia mtandao kisha jaribu tena.'))),
    ));
    if (res.ok) _load();
  }

  @override
  Widget build(BuildContext context) {
    final requiredIds = ProviderDocumentsScreen.requiredIds;
    final done = requiredIds.where((id) => _statusOf(id) != 'MISSING').length;
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          _isEn ? 'Documents' : 'Nyaraka',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _isEn ? '$done of ${requiredIds.length} required documents sent' : 'Nyaraka $done kati ya ${requiredIds.length} zimetumwa',
                          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                        ),
                        const SizedBox(height: 10),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(6),
                          child: LinearProgressIndicator(
                            value: done / requiredIds.length,
                            minHeight: 8,
                            backgroundColor: AppColors.borderLight,
                            color: AppColors.primary,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          _isEn
                              ? 'Upload clear photos of your documents to finish your profile and earn a verified badge.'
                              : 'Pakia picha wazi za nyaraka zako ili kukamilisha wasifu na kupata alama ya uthibitisho.',
                          style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textSecondary),
                        ),
                      ],
                    ),
                  ),
                  if (_loadFailed) ...[
                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppColors.warningLight,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        _isEn
                            ? 'Could not load your document status. Pull down to try again.'
                            : 'Imeshindwa kupakia hali ya nyaraka zako. Vuta chini ujaribu tena.',
                        style: const TextStyle(fontSize: 12, color: AppColors.warningDark),
                      ),
                    ),
                  ],
                  const SizedBox(height: 16),
                  _section(
                    title: _isEn ? 'Identity document' : 'Kitambulisho',
                    subtitle: _isEn
                        ? 'Choose the ID you will use, then add a photo of each side.'
                        : 'Chagua kitambulisho utakachotumia, kisha weka picha ya kila upande.',
                    header: _idKindPicker(),
                    docs: _idDocs,
                  ),
                  const SizedBox(height: 16),
                  _section(
                    title: _isEn ? 'Face verification' : 'Uthibitisho wa uso',
                    subtitle: _isEn
                        ? 'Taken live with the camera so we know it is really you.'
                        : 'Hupigwa moja kwa moja kwa kamera ili tujue ni wewe kweli.',
                    docs: _faceDocs,
                  ),
                  const SizedBox(height: 16),
                  _section(
                    title: _isEn ? 'Business documents' : 'Nyaraka za biashara',
                    subtitle: _isEn ? 'Optional, but they help customers trust you.' : 'Hiari, lakini zinasaidia wateja kukuamini.',
                    docs: _businessDocs,
                  ),
                  const SizedBox(height: 14),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(Icons.lock_outline_rounded, size: 16, color: AppColors.textSecondary),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          _isEn
                              ? 'Your documents are only used for verification and are never shown to customers.'
                              : 'Nyaraka zako zinatumika kwa uthibitisho tu na hazionyeshwi kwa wateja.',
                          style: const TextStyle(fontSize: 11, height: 1.4, color: AppColors.textSecondary),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
    );
  }

  /// A titled card holding a group of document tiles.
  Widget _section({
    required String title,
    required String subtitle,
    required List<_DocType> docs,
    Widget? header,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                const SizedBox(height: 2),
                Text(subtitle, style: const TextStyle(fontSize: 11, height: 1.4, color: AppColors.textSecondary)),
              ],
            ),
          ),
          if (header != null) header,
          const Divider(height: 1, color: AppColors.borderLight),
          for (var i = 0; i < docs.length; i++) ...[
            _docTile(docs[i]),
            if (i < docs.length - 1) const Divider(height: 1, indent: 64, color: AppColors.borderLight),
          ],
        ],
      ),
    );
  }

  /// NIDA / Voter ID / Driving licence / Passport. Locked once a photo of the
  /// current ID is under review or approved, so the kind always matches it.
  Widget _idKindPicker() {
    final locked = _statusOf('id_front') == 'PENDING' || _statusOf('id_front') == 'APPROVED';
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 6, 16, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 4,
            children: [
              for (final k in IdKinds.all)
                ChoiceChip(
                  label: Text(k.title(_isEn), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: _kind == k.id ? Colors.white : AppColors.textPrimary)),
                  selected: _kind == k.id,
                  selectedColor: AppColors.primary,
                  showCheckmark: false,
                  onSelected: (locked || _uploading != null)
                      ? null
                      : (_) async {
                          setState(() => _kind = k.id);
                          await SessionManager.saveIdKind(k.id);
                        },
                ),
            ],
          ),
          if (locked)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text(
                _isEn ? 'Your ID is being reviewed, so its type cannot be changed now.' : 'Kitambulisho chako kinakaguliwa, kwa hiyo aina haiwezi kubadilishwa sasa.',
                style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
              ),
            ),
        ],
      ),
    );
  }

  Widget _docTile(_DocType d) {
    final status = _statusOf(d.id);
    final busy = _uploading == d.id;
    final reason = _server[d.id]?['reason'] ?? '';

    late final String label;
    late final Color color;
    switch (status) {
      case 'APPROVED':
        label = _isEn ? 'Approved' : 'Imekubaliwa';
        color = AppColors.successDark;
        break;
      case 'PENDING':
        label = _isEn ? 'Under review' : 'Inakaguliwa';
        color = AppColors.warningDark;
        break;
      case 'REJECTED':
        label = _isEn ? 'Rejected' : 'Imekataliwa';
        color = AppColors.danger;
        break;
      default:
        label = d.required ? (_isEn ? 'Required' : 'Inahitajika') : (_isEn ? 'Optional' : 'Hiari');
        color = AppColors.textSecondary;
    }

    final canUpload = status == 'MISSING' || status == 'REJECTED';
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
        child: Icon(d.icon, color: AppColors.primary, size: 22),
      ),
      title: Text(_isEn ? d.titleEn : d.titleSw,
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
      subtitle: Padding(
        padding: const EdgeInsets.only(top: 2),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(_isEn ? d.hintEn : d.hintSw, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
            if (status == 'REJECTED' && reason.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 2),
                child: Text(reason, style: const TextStyle(fontSize: 11, color: AppColors.danger)),
              ),
            const SizedBox(height: 4),
            Align(alignment: Alignment.centerLeft, child: StatusPill(text: label, color: color)),
          ],
        ),
      ),
      trailing: busy
          ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.primary))
          : (canUpload
              ? OutlinedButton(
                  onPressed: _uploading == null ? () => _pickAndUpload(d) : null,
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: AppColors.primary),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    minimumSize: const Size(0, 32),
                  ),
                  child: Text(
                    status == 'REJECTED' ? (_isEn ? 'Re-upload' : 'Pakia tena') : (_isEn ? 'Upload' : 'Pakia'),
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.primary),
                  ),
                )
              : Icon(status == 'APPROVED' ? Icons.check_circle_rounded : Icons.hourglass_bottom_rounded, color: color, size: 22)),
    );
  }
}

import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/services.dart';

import 'security_config.dart';

/// Google Play Integrity token for sensitive requests (login, OTP, wallet, escrow, payments, boosts).
///
/// Fail-open by design: if Google Play Services is missing, offline or slow, no header is added and
/// the user notices nothing. The BACKEND decides what to do with a missing/invalid token
/// (see docs/play_integrity_backend.md). Only Android; other platforms add nothing.
class Attestation {
  Attestation._();
  static const MethodChannel _ch = MethodChannel('ungana/security');

  static const _sensitive = <String>[
    '/auth/login', '/auth/register', '/auth/verify-otp', '/auth/phone/verify-otp',
    '/auth/forgot-password', '/auth/reset-password',
    '/wallet/', '/escrow/', '/payments/', '/boosts/activate',
  ];

  static bool _isSensitive(Uri url) => _sensitive.any(url.path.contains);

  static String _nonce() {
    final r = Random.secure();
    final bytes = List<int>.generate(24, (_) => r.nextInt(256));
    return base64UrlEncode(bytes).replaceAll('=', '');
  }

  /// Returns [headers] plus X-Integrity-Token / X-Integrity-Nonce when applicable.
  static Future<Map<String, String>?> attach(Uri url, Map<String, String>? headers) async {
    if (!SecurityConfig.attestation || !_isSensitive(url)) return headers;
    try {
      final nonce = _nonce();
      final token = await _ch
          .invokeMethod<String>('integrityToken', nonce)
          .timeout(const Duration(seconds: 5));
      if (token == null || token.isEmpty) return headers;
      return {
        ...?headers,
        'X-Integrity-Token': token,
        'X-Integrity-Nonce': nonce,
      };
    } on MissingPluginException {
      return headers;
    } catch (_) {
      return headers;
    }
  }
}

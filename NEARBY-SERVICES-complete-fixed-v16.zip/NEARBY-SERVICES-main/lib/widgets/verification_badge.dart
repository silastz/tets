import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/models.dart';

/// Single source of truth for the provider verification marks.
/// A provider has exactly ONE level, so only ONE mark is ever drawn and the
/// blue and green marks can never appear together for the same provider:
///   blueNidaPhotoWithId -> blue
///   greenNidaNumber     -> green
///   none                -> nothing
class VerificationBadge extends StatelessWidget {
  final VerificationLevel level;
  final double size;

  /// Landing/list surfaces show the blue tick only; set false to hide the green badge there.
  final bool showGreen;

  const VerificationBadge({
    super.key,
    required this.level,
    this.size = 14,
    this.showGreen = true,
  });

  @override
  Widget build(BuildContext context) {
    switch (level) {
      case VerificationLevel.blueNidaPhotoWithId:
        return Icon(Icons.verified_rounded, size: size, color: AppColors.primary);
      case VerificationLevel.greenNidaNumber:
        if (!showGreen) return const SizedBox.shrink();
        return Icon(Icons.verified_rounded, size: size, color: AppColors.success);
      case VerificationLevel.none:
        return const SizedBox.shrink();
    }
  }
}

/// Pill version ("Verified") driven by the provider's real level.
/// Renders nothing for unverified providers, blue for blue tick, green for green badge.
class VerificationPill extends StatelessWidget {
  final VerificationLevel level;
  final String? label;

  /// Small variant for thumbnails/list cards.
  final bool compact;

  const VerificationPill({super.key, required this.level, this.label, this.compact = false});

  @override
  Widget build(BuildContext context) {
    if (level == VerificationLevel.none) return const SizedBox.shrink();
    final isBlue = level == VerificationLevel.blueNidaPhotoWithId;
    return Container(
      padding: compact
          ? const EdgeInsets.symmetric(horizontal: 5, vertical: 2)
          : const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: isBlue ? AppColors.primary : AppColors.success,
        borderRadius: BorderRadius.circular(compact ? 6 : 20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.verified_rounded, color: Colors.white, size: compact ? 9 : 14),
          SizedBox(width: compact ? 2 : 4),
          Text(
            label ?? AppStrings.detailsVerifiedProvider,
            style: TextStyle(color: Colors.white, fontSize: compact ? 8 : 11, fontWeight: FontWeight.w700),
          ),
        ],
      ),
    );
  }
}

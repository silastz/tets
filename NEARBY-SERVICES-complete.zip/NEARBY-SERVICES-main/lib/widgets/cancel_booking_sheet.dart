import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';

/// Helpers for cancelling a booking / request.
class BookingCancel {
  BookingCancel._();

  /// Only open bookings can be cancelled (not completed, rejected or already cancelled).
  static bool canCancel(String? status) {
    final s = (status ?? '').toUpperCase();
    if (s.isEmpty) return false;
    if (s.contains('CANCEL') || s.contains('REJECT') || s.contains('COMPLETE') || s.contains('RELEASE') || s.contains('REFUND') || s.contains('DISPUTE')) {
      return false;
    }
    return s.contains('PENDING') || s.contains('ACCEPT') || s.contains('CONFIRM') || s.contains('PAID') || s.contains('HELD');
  }

  static bool isCancelled(String? status) => (status ?? '').toUpperCase().contains('CANCEL');
}

/// Bottom sheet: pick a reason, confirm, and cancel the booking on the server.
/// Resolves to true when the booking was cancelled.
class CancelBookingSheet extends StatefulWidget {
  final String transactionRef;
  final String serviceTitle;
  final String status;

  const CancelBookingSheet({
    super.key,
    required this.transactionRef,
    required this.serviceTitle,
    required this.status,
  });

  static Future<bool?> show(
    BuildContext context, {
    required String transactionRef,
    required String serviceTitle,
    required String status,
  }) {
    return showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => CancelBookingSheet(transactionRef: transactionRef, serviceTitle: serviceTitle, status: status),
    );
  }

  @override
  State<CancelBookingSheet> createState() => _CancelBookingSheetState();
}

class _CancelBookingSheetState extends State<CancelBookingSheet> {
  static const _reasonsEn = [
    'I changed my mind',
    'Found another provider',
    'Schedule conflict',
    'Booked by mistake',
    'Price or payment issue',
    'Other',
  ];
  static const _reasonsSw = [
    'Nimebadili mawazo',
    'Nimepata mtoa huduma mwingine',
    'Ratiba haikubaliani',
    'Nimeweka oda kwa makosa',
    'Tatizo la bei au malipo',
    'Nyingine',
  ];

  int? _selected;
  final _otherController = TextEditingController();
  bool _busy = false;
  String? _error;

  bool get _en => AppStrings.isEnglish;
  bool get _isPending => widget.status.toUpperCase().contains('PENDING');

  @override
  void dispose() {
    _otherController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_selected == null) {
      setState(() => _error = _en ? 'Please choose a reason' : 'Tafadhali chagua sababu');
      return;
    }
    final isOther = _selected == _reasonsEn.length - 1;
    final reason = isOther && _otherController.text.trim().isNotEmpty
        ? _otherController.text.trim()
        : _reasonsEn[_selected!];

    setState(() {
      _busy = true;
      _error = null;
    });
    final res = await ApiService.cancelEscrowRequest(widget.transactionRef, reason: reason);
    if (!mounted) return;
    if (res != null) {
      Navigator.pop(context, true);
    } else {
      setState(() {
        _busy = false;
        _error = _en ? 'Could not cancel. Please try again.' : 'Imeshindikana kughairi. Jaribu tena.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final reasons = _en ? _reasonsEn : _reasonsSw;
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return Container(
      constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.9),
      padding: EdgeInsets.fromLTRB(20, 14, 20, 20 + bottom),
      decoration: const BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: const BoxDecoration(color: AppColors.dangerLight, shape: BoxShape.circle),
                  child: const Icon(Icons.event_busy_rounded, color: AppColors.danger, size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _en ? 'Cancel booking?' : 'Ghairi oda?',
                        style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                      ),
                      Text(
                        widget.serviceTitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: AppColors.warningLight, borderRadius: BorderRadius.circular(10)),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.info_outline_rounded, size: 16, color: AppColors.warningDark),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _isPending
                          ? (_en
                              ? 'The provider has not accepted yet. Any money held in escrow for this booking is returned to you.'
                              : 'Mtoa huduma bado hajakubali. Pesa yoyote iliyoshikiliwa kwa oda hii itarudishwa kwako.')
                          : (_en
                              ? 'The provider already accepted this booking and will be notified. Refunds follow the booking terms.'
                              : 'Mtoa huduma tayari amekubali oda hii na ataarifiwa. Marejesho yanafuata masharti ya oda.'),
                      style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.warningDark),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Text(_en ? 'Why are you cancelling?' : 'Kwa nini unaghairi?',
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
            const SizedBox(height: 4),
            for (int i = 0; i < reasons.length; i++)
              InkWell(
                onTap: _busy ? null : () => setState(() {
                  _selected = i;
                  _error = null;
                }),
                borderRadius: BorderRadius.circular(8),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Row(
                    children: [
                      Icon(
                        _selected == i ? Icons.radio_button_checked : Icons.radio_button_off,
                        size: 20,
                        color: _selected == i ? AppColors.danger : AppColors.textMuted,
                      ),
                      const SizedBox(width: 10),
                      Expanded(child: Text(reasons[i], style: const TextStyle(fontSize: 13, color: AppColors.textPrimary))),
                    ],
                  ),
                ),
              ),
            if (_selected == reasons.length - 1) ...[
              const SizedBox(height: 6),
              TextField(
                controller: _otherController,
                maxLines: 2,
                maxLength: 200,
                decoration: InputDecoration(
                  hintText: _en ? 'Tell us more (optional)' : 'Tuambie zaidi (si lazima)',
                  hintStyle: const TextStyle(fontSize: 13, color: AppColors.textMuted),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  isDense: true,
                ),
              ),
            ],
            if (_error != null) ...[
              const SizedBox(height: 4),
              Text(_error!, style: const TextStyle(fontSize: 12, color: AppColors.danger, fontWeight: FontWeight.w600)),
            ],
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: _busy ? null : () => Navigator.pop(context, false),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.textPrimary,
                      side: const BorderSide(color: AppColors.border),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    child: Text(_en ? 'Keep Booking' : 'Endelea na Oda', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: _busy ? null : _submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.danger,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    child: _busy
                        ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                        : Text(_en ? 'Cancel Booking' : 'Ghairi Oda', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

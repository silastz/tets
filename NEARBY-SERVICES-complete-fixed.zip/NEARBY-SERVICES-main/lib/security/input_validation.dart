import '../constants/app_strings.dart';

/// One set of input rules for every registration screen (sign-up, provider
/// registration, invitation, payment phone). Each validator returns a ready,
/// translated error message, or null when the value is acceptable.
///
/// These checks only stop mistakes and casual abuse on the device; the server
/// must still validate everything it receives.
class InputValidation {
  static bool get _en => AppStrings.isEnglish;

  // Limits (also used for TextField.maxLength / inputFormatters).
  static const int nameMin = 2;
  static const int nameMax = 60;
  static const int emailMax = 120;
  static const int passwordMax = 64;
  static const int otpLength = 6;
  static const int ninLength = 20;
  static const int businessNameMax = 80;
  static const int descriptionMax = 500;

  /// Removes control characters and collapses repeated spaces.
  static String cleanText(String s) =>
      s.replaceAll(RegExp(r'[\u0000-\u001F\u007F\u200B-\u200F\u202A-\u202E\u2066-\u2069]'), '').replaceAll(RegExp(r'\s+'), ' ').trim();

  /// Person name: letters (any language), spaces, . ' - only. No digits, links or markup.
  static String? name(String raw) {
    final v = cleanText(raw);
    if (v.isEmpty) return AppStrings.authFullNameHint;
    if (v.length < nameMin || v.length > nameMax) {
      return _en ? 'Name must be $nameMin-$nameMax characters.' : 'Jina liwe na herufi $nameMin-$nameMax.';
    }
    if (!RegExp(r"^[\p{L}][\p{L}\p{M} .'\-]*$", unicode: true).hasMatch(v)) {
      return _en ? 'Use letters only in the name.' : 'Tumia herufi tu kwenye jina.';
    }
    return null;
  }

  /// Business / shop name: letters, digits and common punctuation; no markup or links.
  static String? businessName(String raw, String emptyMessage) {
    final v = cleanText(raw);
    if (v.isEmpty) return emptyMessage;
    if (v.length < 2 || v.length > businessNameMax) {
      return _en ? 'Business name must be 2-$businessNameMax characters.' : 'Jina la biashara liwe na herufi 2-$businessNameMax.';
    }
    if (RegExp(r'[<>{}\[\]\\|^`]').hasMatch(v) || RegExp(r'https?://|www\.', caseSensitive: false).hasMatch(v)) {
      return _en ? 'Remove special characters or links from the name.' : 'Ondoa alama maalum au viungo kwenye jina.';
    }
    return null;
  }

  /// Free text (description): length and markup only.
  static String? description(String raw) {
    final v = raw.trim();
    if (v.length > descriptionMax) {
      return _en ? 'Description is too long (max $descriptionMax).' : 'Maelezo ni marefu mno (juu $descriptionMax).';
    }
    if (RegExp(r'<\s*\/?\s*(script|iframe|object|embed)', caseSensitive: false).hasMatch(v)) {
      return _en ? 'Remove special characters from the description.' : 'Ondoa alama maalum kwenye maelezo.';
    }
    return null;
  }

  /// Optional e-mail (empty is fine).
  static String? emailOptional(String raw) {
    final v = raw.trim();
    if (v.isEmpty) return null;
    if (v.length > emailMax || !RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]{2,}$').hasMatch(v)) {
      return AppStrings.authEmailInvalid;
    }
    return null;
  }

  static String normalizeEmail(String raw) => raw.trim().toLowerCase();

  /// Digits of a phone number, without the "+".
  static String digitsOf(String s) => s.replaceAll(RegExp(r'\D'), '');

  /// International number like +255712345678. TZ / KE need exactly 9 digits after the code.
  static String? phoneE164(String phone) {
    final d = digitsOf(phone);
    if (!phone.startsWith('+') || d.length < 10 || d.length > 15) return AppStrings.authInvalidPhoneError;
    if (d.startsWith('255') || d.startsWith('254')) {
      if (d.length != 12) return AppStrings.authInvalidPhoneError;
      // Mobile numbers in TZ/KE never start with 0 after the country code.
      if (d[3] == '0') return AppStrings.authInvalidPhoneError;
    }
    return null;
  }

  /// Password: policy is enforced by PasswordPolicy; this adds a maximum length
  /// (stops huge inputs) and rejects passwords with leading/trailing spaces
  /// (they would be silently trimmed and then never match at login).
  static String? passwordShape(String raw) {
    if (raw.length > passwordMax) {
      return _en ? 'Password is too long (max $passwordMax).' : 'Nenosiri ni refu mno (juu $passwordMax).';
    }
    if (raw != raw.trim()) {
      return _en ? 'Password cannot start or end with a space.' : 'Nenosiri haliwezi kuanza au kuisha na nafasi.';
    }
    return null;
  }

  static String? otp(String raw) {
    final v = raw.trim();
    if (!RegExp(r'^\d{6}$').hasMatch(v)) return AppStrings.authOtpHint;
    return null;
  }

  /// Tanzanian national ID (NIN): exactly 20 digits.
  static String? nin(String raw) {
    if (digitsOf(raw).length != ninLength) {
      return _en ? 'The NIN must be exactly 20 digits.' : 'NIN lazima iwe na tarakimu 20.';
    }
    return null;
  }

  /// Invitation code: letters, digits and dashes, 4-24 characters.
  static String? inviteCode(String raw) {
    final v = raw.trim();
    if (!RegExp(r'^[A-Za-z0-9\-]{4,24}$').hasMatch(v)) {
      return _en ? 'Enter a valid invitation code.' : 'Weka msimbo sahihi wa mwaliko.';
    }
    return null;
  }

  /// Message for a failed server call that is safe to show to the user:
  /// never raw exception text, stack traces, HTML or very long strings.
  static String safeServerMessage(Object? raw) {
    final fallback = AppStrings.error;
    if (raw == null) return fallback;
    final s = raw.toString().trim();
    if (s.isEmpty || s.length > 200) return fallback;
    if (s.contains('<') || s.contains('Exception') || s.contains('SocketException') || s.contains('at ') && s.contains('.dart')) {
      return fallback;
    }
    return s;
  }
}

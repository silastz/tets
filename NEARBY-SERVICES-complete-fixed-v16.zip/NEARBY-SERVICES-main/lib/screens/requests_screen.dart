import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/session_manager.dart';
import '../widgets/skeleton_loader.dart';
import '../widgets/guest_state_placeholder.dart';
import '../widgets/cancel_booking_sheet.dart';
import 'booking_details_screen.dart';
import '../services/data_sync.dart';
import '../services/payment_flow.dart';
import '../widgets/payment_flow_widgets.dart';
import '../widgets/offer_flow_widgets.dart';

class RequestsScreen extends StatefulWidget {
  const RequestsScreen({super.key});

  @override
  State<RequestsScreen> createState() => _RequestsScreenState();
}

class _RequestsScreenState extends State<RequestsScreen> {
  // Navigation tabs: 'My Requests' (Buyer) vs 'Incoming' (Seller) vs 'Outgoing' (Seller Outgoing)
  String _activeTab = 'My Requests'; 
  String _statusFilter = 'All'; // 'All', 'Pending', 'Accepted', 'Completed'
  // Offers tab: 'Received' (price offers on my services) or 'Sent' (offers I made as a buyer).
  String _offerView = SessionManager.getRole() == 'ROLE_SELLER' ? 'Received' : 'Sent';
  bool _isLoading = true;
  List<dynamic> _transactions = [];

  // Something was written to the server elsewhere (booking, accept, wallet, review...): re-fetch.
  void _onDataChanged() {
    if (mounted) _loadData();
  }

  @override
  void dispose() {
    DataSync.changed.removeListener(_onDataChanged);
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    DataSync.changed.addListener(_onDataChanged);
    final role = SessionManager.getRole();
    if (role == 'ROLE_SELLER') {
      _activeTab = 'Incoming';
    } else {
      _activeTab = 'My Requests';
    }
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    List<dynamic> list;
    if (_activeTab == 'Offers') {
      list = _offerView == 'Received' ? await ApiService.fetchIncomingOffers() : await ApiService.fetchMyOffers();
    } else if (_activeTab == 'Incoming') {
      list = await ApiService.fetchSellerOrders();
    } else {
      list = await ApiService.fetchBuyerTransactions();
    }
    if (mounted) {
      setState(() {
        _transactions = list;
        _isLoading = false;
      });
    }
  }

  /// 'accept:REF' / 'reject:REF' while that call runs (spinner on that button only).
  String _acting = '';

  Future<void> _acceptOrder(String ref) async {
    if (_acting.isNotEmpty) return;
    setState(() => _acting = 'accept:$ref');
    final res = await ApiService.acceptEscrowRequest(ref);
    if (mounted) setState(() => _acting = '');
    if (res != null && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(AppStrings.requestsAcceptedNotice),
          backgroundColor: AppColors.success,
        ),
      );
      _loadData();
    }
  }

  Future<void> _cancelBooking(String ref, String serviceTitle, String status) async {
    if (ref.isEmpty) return;
    final done = await CancelBookingSheet.show(
      context,
      transactionRef: ref,
      serviceTitle: serviceTitle,
      status: status,
    );
    if (done == true && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(AppStrings.isEnglish ? 'Booking cancelled' : 'Oda imeghairiwa'),
          backgroundColor: AppColors.danger,
        ),
      );
      _loadData();
    }
  }

  Future<void> _rejectOrder(String ref) async {
    if (_acting.isNotEmpty) return;
    setState(() => _acting = 'reject:$ref');
    final res = await ApiService.rejectEscrowRequest(ref);
    if (mounted) setState(() => _acting = '');
    if (res != null && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(AppStrings.requestsRejectedNotice),
          backgroundColor: AppColors.danger,
        ),
      );
      _loadData();
    }
  }



  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppLanguage>(
      valueListenable: AppStrings.currentLanguage,
      builder: (context, _, _) {
        final isSeller = SessionManager.getRole() == 'ROLE_SELLER';

        return Scaffold(
          backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        title: Text(
          _activeTab == 'Offers'
              ? (AppStrings.isEnglish ? 'Price Offers' : 'Ofa za Bei')
              : isSeller && _activeTab == 'Incoming'
              ? 'Incoming Requests'
              : (isSeller && _activeTab == 'Outgoing'
                  ? 'Outgoing Requests'
                  : AppStrings.requestsTitle),
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: !SessionManager.isLoggedIn()
          ? GuestStatePlaceholder(
              icon: Icons.receipt_long_outlined,
              title: AppStrings.guestTitle,
              description: AppStrings.guestRequestsDesc,
              onLoginSuccess: () {
                _loadData();
                setState(() {});
              },
            )
          : Column(
              children: [
                // 1. Primary Segmented Tabs
                Container(
                  color: AppColors.surface,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  child: Row(
                    children: isSeller
                        ? [
                            Expanded(
                              child: _buildTopTab(
                                label: 'Incoming',
                                isSelected: _activeTab == 'Incoming',
                                onTap: () {
                                  if (_activeTab != 'Incoming') {
                                    setState(() => _activeTab = 'Incoming');
                                    _loadData();
                                  }
                                },
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _buildTopTab(
                                label: 'Outgoing',
                                isSelected: _activeTab == 'Outgoing',
                                onTap: () {
                                  if (_activeTab != 'Outgoing') {
                                    setState(() => _activeTab = 'Outgoing');
                                    _loadData();
                                  }
                                },
                              ),
                            ),
                            const SizedBox(width: 12),
                            _offersTabButton(),
                          ]
                        : [
                            Expanded(
                              child: _buildTopTab(
                                label: 'My Requests',
                                isSelected: _activeTab == 'My Requests',
                                onTap: () {
                                  if (_activeTab != 'My Requests') {
                                    setState(() => _activeTab = 'My Requests');
                                    _loadData();
                                  }
                                },
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _buildTopTab(
                                label: 'Incoming',
                                isSelected: _activeTab == 'Incoming',
                                onTap: () {
                                  if (_activeTab != 'Incoming') {
                                    setState(() => _activeTab = 'Incoming');
                                    _loadData();
                                  }
                                },
                              ),
                            ),
                            const SizedBox(width: 12),
                            _offersTabButton(),
                          ],
                  ),
                ),

                // 2. Status Filter Pills Bar (Buyer 'My Requests' mode - matches Screen 1)
                if (_activeTab == 'My Requests')
                  Container(
                    color: AppColors.surface,
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: ['All', 'Pending', 'Accepted', 'Completed', 'Cancelled'].map((filter) {
                          final isSelected = _statusFilter == filter;
                          return Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: GestureDetector(
                              onTap: () => setState(() => _statusFilter = filter),
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                                decoration: BoxDecoration(
                                  color: isSelected ? AppColors.primary : AppColors.borderLight,
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: Text(
                                  filter,
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                    color: isSelected ? Colors.white : AppColors.textSecondary,
                                  ),
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ),

                if (_activeTab == 'Offers')
                  Container(
                    color: AppColors.surface,
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                    child: Row(
                      children: ['Received', 'Sent'].map((view) {
                        final isSelected = _offerView == view;
                        return Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: GestureDetector(
                            onTap: () {
                              if (_offerView == view) return;
                              setState(() => _offerView = view);
                              _loadData();
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                              decoration: BoxDecoration(
                                color: isSelected ? AppColors.primary : AppColors.borderLight,
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: Text(
                                view == 'Received'
                                    ? (AppStrings.isEnglish ? 'Received' : 'Zilizopokelewa')
                                    : (AppStrings.isEnglish ? 'Sent' : 'Zilizotumwa'),
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: isSelected ? Colors.white : AppColors.textSecondary,
                                ),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),

                const Divider(height: 1, color: AppColors.borderLight),

                // 3. Requests List
                Expanded(
                  child: _isLoading
                      ? ListView.separated(
                          padding: const EdgeInsets.all(16),
                          itemCount: 3,
                          separatorBuilder: (_, _) => const SizedBox(height: 14),
                          itemBuilder: (_, _) => const VerticalListCardSkeleton(),
                        )
                      : _filteredTransactions.isEmpty
                          ? Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Icon(Icons.inbox_outlined, size: 48, color: AppColors.textMuted),
                                  const SizedBox(height: 12),
                                  Text(
                                    _activeTab == 'Offers'
                                        ? (AppStrings.isEnglish ? 'No price offers yet' : 'Hakuna ofa za bei bado')
                                        : AppStrings.requestsNoRequests,
                                    style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
                                  ),
                                  const SizedBox(height: 12),
                                  OutlinedButton.icon(
                                    onPressed: _loadData,
                                    icon: const Icon(Icons.refresh_rounded, size: 16),
                                    label: Text(AppStrings.retry),
                                    style: OutlinedButton.styleFrom(
                                      foregroundColor: AppColors.primary,
                                      side: const BorderSide(color: AppColors.primary),
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : RefreshIndicator(
                              onRefresh: _loadData,
                              child: ListView.separated(
                                padding: const EdgeInsets.all(16),
                                itemCount: _filteredTransactions.length,
                                separatorBuilder: (_, _) => const SizedBox(height: 14),
                                itemBuilder: (context, index) {
                                  final tx = _filteredTransactions[index] as Map<String, dynamic>;
                                  if (_activeTab == 'Offers') {
                                    return OfferCard(
                                      key: ValueKey('offer-${tx['id']}-${tx['status']}'),
                                      offer: tx,
                                      isSeller: _offerView == 'Received',
                                      onChanged: _loadData,
                                    );
                                  } else if (_activeTab == 'My Requests') {
                                    return _buildBuyerRequestCard(tx, index);
                                  } else if (_activeTab == 'Incoming') {
                                    return _buildSellerIncomingCard(tx, index);
                                  } else {
                                    return _buildSellerOutgoingCard(tx, index);
                                  }
                                },
                              ),
                            ),
                ),
              ],
            ),
    );
      },
    );
  }

  Widget _offersTabButton() {
    return Expanded(
      child: _buildTopTab(
        label: AppStrings.isEnglish ? 'Offers' : 'Ofa',
        isSelected: _activeTab == 'Offers',
        onTap: () {
          if (_activeTab != 'Offers') {
            setState(() => _activeTab = 'Offers');
            _loadData();
          }
        },
      ),
    );
  }

  List<dynamic> get _filteredTransactions {
    if (_activeTab != 'My Requests' || _statusFilter == 'All') {
      return _transactions;
    }
    return _transactions.where((tx) {
      final status = (tx['status'] ?? '').toString().toUpperCase();
      if (_statusFilter == 'Pending') return status.contains('PENDING') || PaymentFlow.isOpen(status);
      if (_statusFilter == 'Accepted') return status.contains('ACCEPTED');
      if (_statusFilter == 'Completed') return status.contains('COMPLETED');
      if (_statusFilter == 'Cancelled') return status.contains('CANCEL');
      return true;
    }).toList();
  }

  Widget _buildTopTab({
    required String label,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.primary : AppColors.borderLight,
          borderRadius: BorderRadius.circular(20),
        ),
        alignment: Alignment.center,
        child: Text(
          label,
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w700,
            color: isSelected ? Colors.white : AppColors.textSecondary,
          ),
        ),
      ),
    );
  }

  // ---- Real values only: no made-up names, times or prices on request cards ----
  String get _anonProvider => AppStrings.isEnglish ? 'Provider' : 'Mtoa huduma';
  String get _anonBuyer => AppStrings.isEnglish ? 'Customer' : 'Mteja';
  String get _anonService => AppStrings.isEnglish ? 'Service' : 'Huduma';

  /// When the booking is for (or was made), taken from the server data; '' when unknown.
  String _txWhen(Map<String, dynamic> tx) {
    for (final k in const ['scheduledAt', 'bookingDate', 'startTime', 'createdAt']) {
      final raw = tx[k];
      if (raw == null) continue;
      final d = DateTime.tryParse(raw.toString());
      if (d == null) continue;
      final l = d.toLocal();
      String two(int v) => v.toString().padLeft(2, '0');
      return '${l.day}/${l.month}/${l.year}, ${two(l.hour)}:${two(l.minute)}';
    }
    return '';
  }

  /// ' • 60 min' when the server sends a duration, else ''.
  String _txDuration(Map<String, dynamic> tx) {
    final m = tx['durationMinutes'] ?? tx['duration'];
    final n = m is num ? m.toInt() : int.tryParse('${m ?? ''}');
    final t = ApiService.formatDuration(n);
    return t.isEmpty ? '' : ' • $t';
  }

  /// (label, background, colour) for a raw transaction status.
  (String, Color, Color) _statusStyle(String status) {
    final payState = PaymentFlow.stateOf(status);
    if (payState != PayState.none) {
      final c = PaymentFlow.color(status);
      return (PaymentFlow.label(status), c.withValues(alpha: 0.12), c);
    }
    if (status.contains('ACCEPTED')) return ('Accepted', const Color(0xFFF0FDF4), AppColors.success);
    if (status.contains('COMPLETED')) return ('Completed', const Color(0xFFEFF6FF), AppColors.primary);
    if (status.contains('CANCEL')) return ('Cancelled', const Color(0xFFFEF2F2), AppColors.danger);
    if (status.contains('REJECT')) return ('Rejected', const Color(0xFFFEF2F2), AppColors.danger);
    return ('Pending', const Color(0xFFFFF7ED), const Color(0xFFF97316));
  }

  // SCREEN 1: Buyer Request Card (Matches Photo 1)
  Widget _buildBuyerRequestCard(Map<String, dynamic> tx, int index) {
    final seller = tx['seller'] ?? {};
    final providerName = seller['stageName'] ?? _anonProvider;
    final serviceTitle = tx['serviceTitle'] ?? _anonService;
    final status = (tx['status'] ?? 'PENDING_ACCEPTANCE').toString().toUpperCase();
    final amount = (tx['amount'] as num?)?.toDouble() ?? 0.0;
    final amountFormatted = 'TSh ${amount.toInt().toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]},')}';
    final image = index % 2 == 0 ? 'assets/images/banner.jpg' : 'assets/images/provider1.jpg';

    Color statusBg = const Color(0xFFFFF7ED);
    Color statusColor = const Color(0xFFF97316);
    String statusLabel = 'Pending';

    final payState = PaymentFlow.stateOf(status);
    if (payState != PayState.none) {
      statusColor = PaymentFlow.color(status);
      statusBg = statusColor.withValues(alpha: 0.12);
      statusLabel = PaymentFlow.label(status);
    } else if (status.contains('ACCEPTED')) {
      statusBg = const Color(0xFFF0FDF4);
      statusColor = AppColors.success;
      statusLabel = 'Accepted';
    } else if (status.contains('COMPLETED')) {
      statusBg = const Color(0xFFEFF6FF);
      statusColor = AppColors.primary;
      statusLabel = 'Completed';
    } else if (status.contains('CANCEL')) {
      statusBg = const Color(0xFFFEF2F2);
      statusColor = AppColors.danger;
      statusLabel = 'Cancelled';
    } else if (status.contains('REJECT')) {
      statusBg = const Color(0xFFFEF2F2);
      statusColor = AppColors.danger;
      statusLabel = 'Rejected';
    }
    final bookingRef = (tx['transactionRef'] ?? '').toString();
    final canCancel = BookingCancel.canCancel(status) && bookingRef.isNotEmpty;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.asset(
                  image,
                  width: 60,
                  height: 60,
                  fit: BoxFit.cover,
                  errorBuilder: (ctx, err, stack) => Container(
                    width: 60,
                    height: 60,
                    color: AppColors.borderLight,
                    child: const Icon(Icons.spa_rounded, color: AppColors.textMuted),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      serviceTitle,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      providerName,
                      style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '$amountFormatted${_txDuration(tx)}',
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 4),
                    if (_txWhen(tx).isNotEmpty)
                  Row(children: [
                      Icon(Icons.calendar_today_outlined, size: 12, color: AppColors.textMuted),
                      const SizedBox(width: 4),
                      Flexible(child: Text(_txWhen(tx), style: const TextStyle(fontSize: 11, color: AppColors.textMuted))),
                  ]),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: statusBg,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  statusLabel,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: statusColor,
                  ),
                ),
              ),
            ],
          ),
          if (payState != PayState.none || PaymentFlow.isUnpaidOnline(tx)) ...[
            const SizedBox(height: 12),
            PaymentFlowPanel(tx: tx, isBuyer: true, onChanged: _loadData),
          ],
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: SizedBox(
                  height: 36,
                  child: OutlinedButton(
                    onPressed: () async {
                      final changed = await Navigator.push<bool>(
                        context,
                        MaterialPageRoute(
                          builder: (_) => BookingDetailsScreen(
                            bookingData: {
                              'serviceTitle': serviceTitle,
                              'providerName': providerName,
                              'price': amountFormatted,
                              'status': statusLabel,
                              'rawStatus': status,
                              'tx': tx,
                              'isBuyer': true,
                              'ref': bookingRef,
                              'image': image,
                              'providerLat': seller['latitude'] ?? tx['latitude'],
                              'providerLng': seller['longitude'] ?? tx['longitude'],
                            },
                          ),
                        ),
                      );
                      if (changed == true && mounted) _loadData();
                    },
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.primary,
                      side: const BorderSide(color: AppColors.primary),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                    child: const Text('View', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: SizedBox(
                  height: 36,
                  child: OutlinedButton(
                    onPressed: canCancel ? () => _cancelBooking(bookingRef, serviceTitle, status) : null,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.danger,
                      disabledForegroundColor: AppColors.textDisabled,
                      side: BorderSide(color: canCancel ? AppColors.danger : AppColors.border),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                    child: const Text('Cancel', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // SCREEN 2: Seller Incoming Request Card (Matches Photo 2)
  Widget _buildSellerIncomingCard(Map<String, dynamic> tx, int index) {
    final buyer = tx['buyer'] ?? {};
    final buyerName = buyer['stageName'] ?? _anonBuyer;
    final serviceTitle = tx['serviceTitle'] ?? _anonService;
    final amount = (tx['amount'] as num?)?.toDouble() ?? 0.0;
    final amountFormatted = 'TSh ${amount.toInt().toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]},')}';
    final ref = (tx['transactionRef'] ?? '').toString();
    final incomingStatus = (tx['status'] ?? 'PENDING_ACCEPTANCE').toString().toUpperCase();
    final message = (tx['customerNote'] ?? '').toString().trim();

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                radius: 20,
                backgroundImage: const AssetImage('assets/images/provider1.jpg'),
                backgroundColor: AppColors.borderLight,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          buyerName,
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        const SizedBox(width: 4),
                        Container(
                          width: 6,
                          height: 6,
                          decoration: const BoxDecoration(
                            color: AppColors.success,
                            shape: BoxShape.circle,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Wants: $serviceTitle',
                      style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '$amountFormatted${_txDuration(tx)}',
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 3),
                    if (_txWhen(tx).isNotEmpty)
                  Row(children: [
                      Icon(Icons.location_on_outlined, size: 12, color: AppColors.textMuted),
                      const SizedBox(width: 2),
                      Flexible(child: Text(_txWhen(tx), style: const TextStyle(fontSize: 11, color: AppColors.textMuted))),
                  ]),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: AppColors.primary,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  PaymentFlow.isOpen(incomingStatus) ? PaymentFlow.label(incomingStatus) : 'New',
                  style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.white),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),

          // Message bubble (only when the customer wrote one)
          if (message.isNotEmpty) ...[
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.borderLight.withValues(alpha: 0.5),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              message,
              style: const TextStyle(
                fontSize: 12,
                color: AppColors.textPrimary,
                fontStyle: FontStyle.italic,
              ),
            ),
          ),
          ],
          const SizedBox(height: 12),

          if (incomingStatus.contains('PENDING') && ref.isNotEmpty) ...[
            if (PaymentFlow.isUnpaidOnline(tx)) ...[
              PaymentFlowPanel(tx: tx, isBuyer: false, onChanged: _loadData),
              const SizedBox(height: 8),
            ],
            SizedBox(
              width: double.infinity,
              height: 36,
              child: OutlinedButton.icon(
                onPressed: () async {
                  final sent = await AskPaymentSheet.show(context, transactionRef: ref, amountText: amountFormatted);
                  if (sent && mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Text(AppStrings.isEnglish
                          ? 'Payment request sent. The buyer has been alerted.'
                          : 'Ombi la malipo limetumwa. Mnunuzi amearifiwa.'),
                    ));
                    _loadData();
                  }
                },
                icon: const Icon(Icons.payments_outlined, size: 16),
                label: Text(
                  AppStrings.isEnglish ? 'Ask buyer to pay first' : 'Mwombe mnunuzi alipe kwanza',
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
                ),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.primary,
                  side: const BorderSide(color: AppColors.primary),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
              ),
            ),
            const SizedBox(height: 8),
          ],
          if (PaymentFlow.isOpen(incomingStatus)) ...[
            PaymentFlowPanel(tx: tx, isBuyer: false, onChanged: _loadData),
            if (BookingCancel.canCancel(incomingStatus) && ref.isNotEmpty) ...[
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                height: 36,
                child: OutlinedButton(
                  onPressed: () => _cancelBooking(ref, serviceTitle.toString(), incomingStatus),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.danger,
                    side: const BorderSide(color: AppColors.danger),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  child: Text(AppStrings.isEnglish ? 'Cancel Booking' : 'Ghairi Oda', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                ),
              ),
            ],
          ] else if (incomingStatus.contains('PENDING'))
            // Accept / Reject Buttons
            Row(
              children: [
                Expanded(
                  child: SizedBox(
                    height: 36,
                    child: ElevatedButton(
                      onPressed: (PaymentFlow.isUnpaidOnline(tx) || _acting.isNotEmpty) ? null : () => _acceptOrder(ref),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.success,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                      child: _acting == 'accept:$ref'
                          ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                          : const Text('Accept', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: SizedBox(
                    height: 36,
                    child: OutlinedButton(
                      onPressed: _acting.isNotEmpty ? null : () => _rejectOrder(ref),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: AppColors.danger,
                        side: const BorderSide(color: AppColors.danger),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                      child: _acting == 'reject:$ref'
                          ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.danger))
                          : const Text('Reject', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                    ),
                  ),
                ),
              ],
            )
          else if (BookingCancel.canCancel(incomingStatus) && ref.isNotEmpty)
            SizedBox(
              width: double.infinity,
              height: 36,
              child: OutlinedButton(
                onPressed: () => _cancelBooking(ref, serviceTitle.toString(), incomingStatus),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.danger,
                  side: const BorderSide(color: AppColors.danger),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: Text(AppStrings.isEnglish ? 'Cancel Booking' : 'Ghairi Oda', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
              ),
            )
          else
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 8),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: incomingStatus.contains('CANCEL') || incomingStatus.contains('REJECT') ? const Color(0xFFFEF2F2) : AppColors.borderLight,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                incomingStatus.contains('CANCEL')
                    ? (AppStrings.isEnglish ? 'Cancelled' : 'Imeghairiwa')
                    : incomingStatus.contains('REJECT')
                        ? (AppStrings.isEnglish ? 'Rejected' : 'Imekataliwa')
                        : incomingStatus.contains('COMPLETE')
                            ? (AppStrings.isEnglish ? 'Completed' : 'Imekamilika')
                            : incomingStatus,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: incomingStatus.contains('CANCEL') || incomingStatus.contains('REJECT') ? AppColors.danger : AppColors.textSecondary,
                ),
              ),
            ),
        ],
      ),
    );
  }

  // SCREEN 3: Seller Outgoing Request Card (Matches Photo 3)
  Widget _buildSellerOutgoingCard(Map<String, dynamic> tx, int index) {
    final buyer = tx['buyer'] ?? {};
    final name = buyer['stageName'] ?? _anonBuyer;
    final serviceTitle = tx['serviceTitle'] ?? _anonService;
    final amount = (tx['amount'] as num?)?.toDouble() ?? 0.0;
    final amountFormatted = 'TSh ${amount.toInt().toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]},')}';

    // Status badge from the real transaction status.
    final (statusLabel, statusBg, statusColor) =
        _statusStyle((tx['status'] ?? 'PENDING_ACCEPTANCE').toString().toUpperCase());

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                radius: 20,
                backgroundImage: AssetImage(index % 2 == 0 ? 'assets/images/zeen_avatar.jpg' : 'assets/images/provider2.jpg'),
                backgroundColor: AppColors.borderLight,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      serviceTitle,
                      style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '$amountFormatted${_txDuration(tx)}',
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 3),
                    if (_txWhen(tx).isNotEmpty)
                  Row(children: [
                      Icon(Icons.access_time_rounded, size: 12, color: AppColors.textMuted),
                      const SizedBox(width: 2),
                      Flexible(child: Text(_txWhen(tx), style: const TextStyle(fontSize: 11, color: AppColors.textMuted))),
                  ]),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: statusBg,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  statusLabel,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: statusColor,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // View Details Single Full-Width Button matching Screen 3
          SizedBox(
            width: double.infinity,
            height: 36,
            child: OutlinedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => BookingDetailsScreen(
                      bookingData: {
                        'serviceTitle': serviceTitle,
                        'providerName': name,
                        'price': amountFormatted,
                        'status': statusLabel,
                        'image': index % 2 == 0 ? 'assets/images/banner.jpg' : 'assets/images/provider1.jpg',
                        'providerLat': buyer['latitude'] ?? tx['latitude'],
                        'providerLng': buyer['longitude'] ?? tx['longitude'],
                      },
                    ),
                  ),
                );
              },
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.primary,
                side: const BorderSide(color: AppColors.primary),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              ),
              child: const Text('View Details', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
            ),
          ),
        ],
      ),
    );
  }
}

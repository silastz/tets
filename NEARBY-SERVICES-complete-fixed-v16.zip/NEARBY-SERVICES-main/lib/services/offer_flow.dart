import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';

/// Where a price offer is.
enum OfferState { offered, agreed, rejected, withdrawn, expired, booked, unknown }

/// Status vocabulary + helpers for the discount / offer flow (see NEGOTIATION_FLOW.md).
///
///   OFFERED    buyer proposed a price, the seller has not answered
///   AGREED     seller accepted (by hand or by their auto-accept price); the buyer can book at that price
///   REJECTED   seller said no
///   WITHDRAWN  buyer took it back
///   EXPIRED    nobody acted in time
///   BOOKED     the agreed price was used to create a booking
class OfferFlow {
  OfferFlow._();

  static String _up(dynamic v) => (v ?? '').toString().toUpperCase().trim();

  static OfferState stateOf(dynamic status) {
    switch (_up(status)) {
      case 'OFFERED':
      case 'PENDING':
        return OfferState.offered;
      case 'AGREED':
      case 'ACCEPTED':
        return OfferState.agreed;
      case 'REJECTED':
      case 'DECLINED':
        return OfferState.rejected;
      case 'WITHDRAWN':
      case 'CANCELLED':
        return OfferState.withdrawn;
      case 'EXPIRED':
        return OfferState.expired;
      case 'BOOKED':
        return OfferState.booked;
    }
    return OfferState.unknown;
  }

  static String label(dynamic status) {
    final en = AppStrings.isEnglish;
    switch (stateOf(status)) {
      case OfferState.offered:
        return en ? 'Waiting for seller' : 'Inasubiri muuzaji';
      case OfferState.agreed:
        return en ? 'Price agreed' : 'Bei imekubaliwa';
      case OfferState.rejected:
        return en ? 'Declined' : 'Imekataliwa';
      case OfferState.withdrawn:
        return en ? 'Withdrawn' : 'Imerudishwa';
      case OfferState.expired:
        return en ? 'Expired' : 'Muda umeisha';
      case OfferState.booked:
        return en ? 'Booked' : 'Imewekewa oda';
      case OfferState.unknown:
        return _up(status);
    }
  }

  static Color color(dynamic status) {
    switch (stateOf(status)) {
      case OfferState.offered:
        return AppColors.warningDark;
      case OfferState.agreed:
        return AppColors.successDark;
      case OfferState.booked:
        return AppColors.primary;
      case OfferState.rejected:
        return AppColors.danger;
      case OfferState.withdrawn:
      case OfferState.expired:
      case OfferState.unknown:
        return AppColors.textSecondary;
    }
  }

  static num? _n(dynamic v) => v is num ? v : num.tryParse('${v ?? ''}');

  /// The price that applies now: the agreed price once there is one, else the buyer's proposal.
  static num amountOf(Map o) => _n(o['agreedAmount']) ?? _n(o['amount']) ?? 0;

  static num listedOf(Map o) => _n(o['listedPrice']) ?? 0;

  static DateTime? expiresAt(Map o) => DateTime.tryParse('${o['expiresAt'] ?? ''}')?.toLocal();

  /// Open (or agreed) but past its time: the server will expire it, show it as expired meanwhile.
  static bool isLapsed(Map o) {
    final s = stateOf(o['status']);
    if (s != OfferState.offered && s != OfferState.agreed) return false;
    final e = expiresAt(o);
    return e != null && !e.isAfter(DateTime.now());
  }

  /// The status to show, with a lapsed offer shown as expired.
  static String shownStatus(Map o) => isLapsed(o) ? 'EXPIRED' : '${o['status'] ?? ''}';

  /// 'Expires in 5 h' / 'Inaisha baada ya dakika 20'.
  static String timeLeft(Map o) {
    final e = expiresAt(o);
    if (e == null) return '';
    final d = e.difference(DateTime.now());
    if (d.isNegative) return '';
    final en = AppStrings.isEnglish;
    final txt = d.inHours >= 1
        ? (en ? '${d.inHours} h' : 'saa ${d.inHours}')
        : (en ? '${d.inMinutes.clamp(1, 59)} min' : 'dakika ${d.inMinutes.clamp(1, 59)}');
    return en ? 'Expires in $txt' : 'Inaisha baada ya $txt';
  }

  static String money(num v) =>
      'TSh ${v.toInt().toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},')}';

  /// Percent below the listed price (0 when unknown).
  static int percentOff(Map o) {
    final l = listedOf(o), a = amountOf(o);
    if (l <= 0 || a >= l) return 0;
    return (((l - a) * 100) / l).round();
  }
}

import 'dart:async';
import 'package:app_links/app_links.dart';
import 'package:flutter/material.dart';
import '../constants/app_strings.dart';
import '../screens/accept_invitation_screen.dart';
import '../security/security_config.dart';
import '../screens/service_details_screen.dart';
import '../widgets/login_modal.dart';
import 'api_service.dart';
import 'session_manager.dart';

/// Opens the right screen when the app is started from a link:
///   https://nearbyservices.techwareafrica.tech/i/<code>   invitation
///   https://nearbyservices.techwareafrica.tech/s/<id>     a shared service
///   nearbyservices://invite/<code>  and  nearbyservices://service/<id>
/// Setup (assetlinks / apple-app-site-association): docs/deep_links_setup.md
class DeepLinkService {
  static String get host => SecurityConfig.host;
  static const String scheme = 'nearbyservices';

  static String inviteLink(String code) => 'https://$host/i/${Uri.encodeComponent(code)}';
  static String serviceLink(String id) => 'https://$host/s/${Uri.encodeComponent(id)}';

  static GlobalKey<NavigatorState>? _navKey;
  static StreamSubscription<Uri>? _sub;
  static String? _pendingInviteCode; // link opened while signed out

  /// Call once after runApp, passing the app's navigator key.
  static Future<void> start(GlobalKey<NavigatorState> navKey) async {
    _navKey = navKey;
    final links = AppLinks();
    try {
      final first = await links.getInitialLink();
      if (first != null) _later(first);
    } catch (_) {}
    _sub ??= links.uriLinkStream.listen(_later, onError: (_) {});
    // Opening the invitation that was waiting for sign-in.
    SessionManager.sessionNotifier.addListener(_resumePending);
  }

  // Let the first frame build before pushing a route.
  static void _later(Uri uri) => Future.delayed(const Duration(milliseconds: 600), () => handle(uri));

  /// Pulls the target out of a link; null when it is not one of ours.
  static ({String kind, String value})? parse(Uri uri) {
    final okHttps = (uri.scheme == 'https' || uri.scheme == 'http') && uri.host == host;
    if (!okHttps && uri.scheme != scheme) return null;
    final segs = <String>[
      if (uri.scheme == scheme && uri.host.isNotEmpty) uri.host, // nearbyservices://invite/CODE
      ...uri.pathSegments.where((s) => s.isNotEmpty),
    ];
    if (segs.length < 2) return null;
    final value = segs[1].trim();
    if (value.isEmpty) return null;
    switch (segs[0]) {
      case 'i':
      case 'invite':
        return (kind: 'invite', value: value);
      case 's':
      case 'service':
        return (kind: 'service', value: value);
    }
    return null;
  }

  static Future<void> handle(Uri uri) async {
    final target = parse(uri);
    final nav = _navKey?.currentState;
    final ctx = _navKey?.currentContext;
    if (target == null || nav == null || ctx == null) return;
    if (target.kind == 'invite') {
      await _openInvite(target.value);
    } else {
      await _openService(target.value);
    }
  }

  static Future<void> _openInvite(String code) async {
    final nav = _navKey?.currentState;
    final ctx = _navKey?.currentContext;
    if (nav == null || ctx == null) return;
    final clean = code.trim().toUpperCase();
    if (!SessionManager.isLoggedIn()) {
      _pendingInviteCode = clean;
      _snack(AppStrings.isEnglish ? 'Sign in or create an account to accept your invitation.' : 'Ingia au fungua akaunti ili ukubali mwaliko wako.');
      await LoginModal.show(ctx);
      return;
    }
    nav.push(MaterialPageRoute(builder: (_) => AcceptInvitationScreen(initialCode: clean)));
  }

  static void _resumePending() {
    final code = _pendingInviteCode;
    if (code == null || !SessionManager.isLoggedIn()) return;
    _pendingInviteCode = null;
    _later(Uri.parse(inviteLink(code)));
  }

  static Future<void> _openService(String id) async {
    final nav = _navKey?.currentState;
    if (nav == null) return;
    final item = await ApiService.fetchServiceById(id);
    if (item == null) {
      _snack(AppStrings.isEnglish ? 'This service is no longer available.' : 'Huduma hii haipatikani tena.');
      return;
    }
    nav.push(MaterialPageRoute(builder: (_) => ServiceDetailsScreen(service: item)));
  }

  static void _snack(String text) {
    final ctx = _navKey?.currentContext;
    if (ctx == null) return;
    ScaffoldMessenger.maybeOf(ctx)?.showSnackBar(SnackBar(content: Text(text)));
  }
}

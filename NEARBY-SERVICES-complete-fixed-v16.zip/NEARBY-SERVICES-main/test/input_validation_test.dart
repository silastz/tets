import 'package:flutter_test/flutter_test.dart';
import 'package:jamiiapp/security/input_validation.dart';

void main() {
  group('name', () {
    test('accepts normal names', () {
      expect(InputValidation.name('Amina Juma'), isNull);
      expect(InputValidation.name("Mary-Anne O'Neil"), isNull);
    });
    test('rejects digits, markup, links and empty', () {
      expect(InputValidation.name(''), isNotNull);
      expect(InputValidation.name('A'), isNotNull);
      expect(InputValidation.name('Bob123'), isNotNull);
      expect(InputValidation.name('<script>alert(1)</script>'), isNotNull);
      expect(InputValidation.name('www.spam.com'), isNotNull);
    });
  });

  group('phone', () {
    test('Tanzania needs 9 digits after +255, not starting with 0', () {
      expect(InputValidation.phoneE164('+255712345678'), isNull);
      expect(InputValidation.phoneE164('+25571234567'), isNotNull);
      expect(InputValidation.phoneE164('+2550712345678'), isNotNull);
      expect(InputValidation.phoneE164('0712345678'), isNotNull); // must already be international
    });
    test('other supported countries', () {
      expect(InputValidation.phoneE164('+254712345678'), isNull); // Kenya
      expect(InputValidation.phoneE164('+256712345678'), isNull); // Uganda
      expect(InputValidation.phoneE164('+250788123456'), isNull); // Rwanda
      expect(InputValidation.phoneE164('+25671234567'), isNotNull); // Uganda, one digit short
      expect(InputValidation.phoneE164('+25779123456'), isNull); // Burundi (8 digits)
    });
  });

  group('codes and ids', () {
    test('otp is exactly 6 digits', () {
      expect(InputValidation.otp('123456'), isNull);
      expect(InputValidation.otp('12345'), isNotNull);
      expect(InputValidation.otp('12a456'), isNotNull);
    });
    test('nin is exactly 20 digits', () {
      expect(InputValidation.nin('12345678901234567890'), isNull);
      expect(InputValidation.nin('1234'), isNotNull);
    });
    test('invite code allows letters, digits, dashes only', () {
      expect(InputValidation.inviteCode('123-ABC456'), isNull);
      expect(InputValidation.inviteCode('ab'), isNotNull);
      expect(InputValidation.inviteCode('AB CD;DROP'), isNotNull);
    });
  });

  group('password shape and server messages', () {
    test('no edge spaces, bounded length', () {
      expect(InputValidation.passwordShape(' abc12345'), isNotNull);
      expect(InputValidation.passwordShape('a' * 65), isNotNull);
      expect(InputValidation.passwordShape('Goodpass9x'), isNull);
    });
    test('raw exceptions and HTML never reach the user', () {
      expect(InputValidation.safeServerMessage('<html>500</html>'), isNot(contains('<')));
      expect(InputValidation.safeServerMessage('SocketException: failed'), isNot(contains('Socket')));
      expect(InputValidation.safeServerMessage('Phone already registered'), 'Phone already registered');
    });
  });
}

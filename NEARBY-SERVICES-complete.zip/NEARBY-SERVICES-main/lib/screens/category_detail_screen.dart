import 'dart:async';
import 'package:flutter/material.dart';
import '../widgets/verification_badge.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/models.dart';
import '../models/service_filters.dart';
import '../models/service_search.dart';
import '../services/api_service.dart';
import '../services/session_manager.dart';
import '../services/location_service.dart';
import '../services/gps_service.dart';
import '../services/security_settings.dart';
import '../widgets/sensitive_tag.dart';
import '../widgets/boost_badge.dart';
import '../widgets/skeleton_loader.dart';
import 'service_details_screen.dart';
import '../widgets/online_indicator.dart';

class CategoryDetailScreen extends StatefulWidget {
  final String categoryTitle;
  final String? categoryApiKey;
  final String? searchQuery;
  final ServiceFilters? filters;
  final VoidCallback? onBackToHome;

  const CategoryDetailScreen({
    super.key,
    this.categoryTitle = 'Massage',
    this.categoryApiKey,
    this.searchQuery,
    this.filters,
    this.onBackToHome,
  });

  @override
  State<CategoryDetailScreen> createState() => _CategoryDetailScreenState();
}

class _CategoryDetailScreenState extends State<CategoryDetailScreen> {
  // 'ALL', 'NEARBY', 'TOP_RATED', 'VERIFIED'
  String _activeChip = 'ALL';
  // Results load page by page, automatically as the user scrolls.
  static const int _pageSize = 20;
  final ScrollController _scroll = ScrollController();
  List<ServiceItem> _all = [];
  bool _loadingInitial = true;
  bool _loadingMore = false;
  bool _loadMoreFailed = false;
  bool _initialFailed = false; // first page failed (network) and nothing is shown
  bool _nearHasMore = true; // "my area / radius" stream
  bool _farHasMore = true; // "anywhere" stream
  int _nearPage = 0;
  int _farPage = 0;
  int _gen = 0; // bumped on every new search so late replies are ignored
  String? _reqCategory;
  String? _reqQuery;
  bool get _hasMore => _nearHasMore || _farHasMore;

  // In-page search (searches inside the current category)
  late final TextEditingController _searchController;
  Timer? _searchDebounce;
  String _query = '';
  late ServiceFilters _filters;

  @override
  void initState() {
    super.initState();
    _query = (widget.searchQuery ?? '').trim();
    _filters = widget.filters ?? const ServiceFilters();
    _searchController = TextEditingController(text: _query);
    _scroll.addListener(_onScroll);
    _loadCategoryServices();
    SessionManager.sessionNotifier.addListener(_onSessionChanged);
  }

  void _onScroll() {
    if (!_scroll.hasClients) return;
    if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 300) {
      _fetchNext();
    }
  }

  void _onSessionChanged() {
    if (mounted) setState(() {}); // favorites changed elsewhere
  }

  @override
  void dispose() {
    SessionManager.sessionNotifier.removeListener(_onSessionChanged);
    _searchDebounce?.cancel();
    _searchController.dispose();
    _scroll.dispose();
    super.dispose();
  }

  /// Radius that separates "near you" from "available elsewhere".
  double get _radiusKm => _filters.maxDistanceKm ?? ServiceSearch.defaultNearbyKm;

  void _loadCategoryServices() {
    // Typing just a category word ("plumber", "kinyozi") runs a category search.
    final resolved = ServiceCategories.resolve(
      _query,
      widget.categoryApiKey ?? _normalizeCategory(widget.categoryTitle),
    );
    _reqCategory = resolved.category;
    _reqQuery = resolved.query;
    _gen++;
    _all = [];
    _nearPage = 0;
    _farPage = 0;
    _nearHasMore = true;
    _farHasMore = true;
    _loadingInitial = true;
    _loadingMore = false;
    _loadMoreFailed = false;
    _initialFailed = false;
    _fetchNext(initial: true);
  }

  /// Fetches the next page of both lookups in parallel: the user's area/radius
  /// first, and the same service or category from anywhere, so a service missing
  /// in the user's region or country still shows up (under an "available
  /// elsewhere" divider). Each lookup keeps its own page counter.
  Future<void> _fetchNext({bool initial = false}) async {
    if (!initial && (_loadingMore || _loadingInitial || !_hasMore)) return;
    final gen = _gen;
    if (!initial) {
      setState(() {
        _loadingMore = true;
        _loadMoreFailed = false;
      });
    }
    final city = LocationService.currentCity;
    final nearReq = _nearHasMore
        ? ApiService.fetchServicesPage(
            category: _reqCategory,
            query: _reqQuery,
            city: GpsService.hasFix || city.isEmpty ? null : city,
            radiusKm: _radiusKm.round(),
            page: _nearPage,
            size: _pageSize,
          )
        : null;
    final farReq = _farHasMore
        ? ApiService.fetchServicesPage(
            category: _reqCategory,
            query: _reqQuery,
            page: _farPage,
            size: _pageSize,
          )
        : null;
    final near = nearReq == null ? null : await nearReq;
    final far = farReq == null ? null : await farReq;
    if (!mounted || gen != _gen) return;
    setState(() {
      var failed = false;
      if (near != null) {
        if (near.ok) {
          _nearPage++;
          _nearHasMore = near.hasMore;
        } else {
          failed = true;
        }
      }
      if (far != null) {
        if (far.ok) {
          _farPage++;
          _farHasMore = far.hasMore;
        } else {
          failed = true;
        }
      }
      _all = ServiceSearch.mergeById(_all, [...?near?.items, ...?far?.items]);
      _loadingInitial = false;
      _loadingMore = false;
      _loadMoreFailed = failed;
      _initialFailed = initial && failed && _all.isEmpty;
    });
    // Few results left after filters: the list may be too short to scroll, so
    // keep loading until it fills the screen (or there is nothing more).
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || gen != _gen || !_hasMore || _loadMoreFailed) return;
      if (!_scroll.hasClients || _scroll.position.maxScrollExtent <= 0) _fetchNext();
    });
  }

  void _clearFilters() {
    setState(() {
      _filters = const ServiceFilters();
      _loadCategoryServices();
    });
  }

  List<String> _activeFilterLabels() {
    final en = AppStrings.isEnglish;
    final f = _filters;
    String tsh(int v) => v.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},');
    final out = <String>[];
    if (f.verifiedOnly) out.add(AppStrings.searchFilterVerifiedOnly);
    if (f.maxDistanceKm != null) out.add(en ? 'Within ${f.maxDistanceKm!.round()} km' : 'Ndani ya km ${f.maxDistanceKm!.round()}');
    if (f.minPrice != null && f.maxPrice != null) {
      out.add('TSh ${tsh(f.minPrice!)} - ${tsh(f.maxPrice!)}');
    } else if (f.maxPrice != null) {
      out.add(en ? 'Under TSh ${tsh(f.maxPrice!)}' : 'Chini ya TSh ${tsh(f.maxPrice!)}');
    } else if (f.minPrice != null) {
      out.add(en ? 'Above TSh ${tsh(f.minPrice!)}' : 'Zaidi ya TSh ${tsh(f.minPrice!)}');
    }
    if (f.minRating != null) out.add('${f.minRating!.toStringAsFixed(1)} ★+');
    switch (f.availability) {
      case AvailabilityFilter.any: break;
      case AvailabilityFilter.now: out.add(AppStrings.searchFilterAvailableNow); break;
      case AvailabilityFilter.today: out.add(en ? 'Today' : 'Leo'); break;
      case AvailabilityFilter.tomorrow: out.add(en ? 'Tomorrow' : 'Kesho'); break;
      case AvailabilityFilter.weekend: out.add(en ? 'Weekend' : 'Wikendi'); break;
    }
    if (f.serviceType == ServiceTypeFilter.customerComes) out.add(en ? 'Customer comes' : 'Mteja anakuja');
    if (f.serviceType == ServiceTypeFilter.iTravel) out.add(en ? 'Provider travels' : 'Mtoa huduma anasafiri');
    switch (f.sort) {
      case SortOption.nearest: break;
      case SortOption.lowestPrice: out.add(en ? 'Lowest price' : 'Bei ya chini'); break;
      case SortOption.highestRating: out.add(en ? 'Highest rating' : 'Ukadiriaji wa juu'); break;
      case SortOption.mostPopular: out.add(en ? 'Most popular' : 'Maarufu zaidi'); break;
    }
    return out;
  }

  void _onSearchChanged(String value) {
    setState(() {}); // refresh the clear (X) button
    _searchDebounce?.cancel();
    _searchDebounce = Timer(const Duration(milliseconds: 450), () => _runSearch(value));
  }

  void _runSearch(String value) {
    _searchDebounce?.cancel();
    final q = value.trim();
    if (!mounted || q == _query) return;
    setState(() {
      _query = q;
      _loadCategoryServices();
    });
  }

  String _normalizeCategory(String input) {
    final clean = input.trim().toLowerCase();
    if (clean.contains('massage') || clean.contains('masaji')) return 'Massage';
    if (clean.contains('beauty') || clean.contains('urembo') || clean.contains('saloon')) return 'Beauty';
    if (clean.contains('barber') || clean.contains('kinyozi')) return 'Barber';
    if (clean.contains('clean') || clean.contains('usafi')) return 'Cleaning';
    if (clean.contains('plumb') || clean.contains('bomba')) return 'Plumbing';
    if (clean.contains('elect') || clean.contains('umeme')) return 'Electrical';
    if (clean.contains('mech') || clean.contains('gereji') || clean.contains('fundi')) return 'Mechanic';
    if (clean.contains('photo') || clean.contains('picha')) return 'Photography';
    if (clean.contains('repair') || clean.contains('ukarabati')) return 'Repair';
    return input;
  }

  /// Applies the Search & Filter choices (all except distance, which is the
  /// divider) and the quick chips, then splits near / elsewhere.
  ServiceSearchResult _applyFilter(List<ServiceItem> items) {
    final filtered = _filters.withoutDistance().apply(items);
    final split = ServiceSearch.split(
      filtered,
      radiusKm: _radiusKm,
      userCity: LocationService.currentCity,
    );

    List<ServiceItem> chip(List<ServiceItem> l) {
      switch (_activeChip) {
        case 'TOP_RATED':
          return List<ServiceItem>.from(l)..sort((a, b) => b.rating.compareTo(a.rating));
        case 'VERIFIED':
          return l.where((it) => it.isVerified).toList();
        default:
          return l;
      }
    }

    if (_activeChip == 'NEARBY') {
      final near = List<ServiceItem>.from(split.nearby)
        ..sort((a, b) => (a.distanceKm ?? double.infinity).compareTo(b.distanceKm ?? double.infinity));
      return ServiceSearchResult(near, const []);
    }
    return ServiceSearchResult(chip(split.nearby), chip(split.elsewhere));
  }

  String get _whatLabel {
    final en = AppStrings.isEnglish;
    if (_query.isNotEmpty) return '"$_query"';
    if (widget.categoryTitle != 'All') return widget.categoryTitle;
    return en ? 'services' : 'huduma';
  }

  /// Flat list for the ListView: cards plus the divider headers / notice.
  List<Object> _buildEntries(ServiceSearchResult r) {
    final en = AppStrings.isEnglish;
    final km = _radiusKm.round();
    final city = LocationService.currentCity;
    final where = GpsService.hasFix
        ? (en ? 'Within $km km of you' : 'Ndani ya km $km kutoka ulipo')
        : (en ? 'In $city' : 'Katika $city');
    final out = <Object>[];
    if (r.nearby.isEmpty && r.elsewhere.isNotEmpty) {
      out.add(_Notice(en
          ? 'No $_whatLabel found ${GpsService.hasFix ? 'within $km km' : 'in $city'}. Showing providers available elsewhere.'
          : 'Hakuna $_whatLabel ${GpsService.hasFix ? 'ndani ya km $km' : 'katika $city'}. Tunaonyesha watoa huduma wa maeneo mengine.'));
      out.add(_SectionHeader(
        en ? 'Available elsewhere' : 'Zinapatikana maeneo mengine',
        _hasMore ? '${r.elsewhere.length}+' : '${r.elsewhere.length}',
      ));
      out.addAll(r.elsewhere);
      return out;
    }
    if (r.hasBoth) {
      out.add(_SectionHeader(en ? 'Near you' : 'Karibu nawe', where, count: _hasMore ? null : r.nearby.length));
    }
    out.addAll(r.nearby);
    if (r.elsewhere.isNotEmpty) {
      out.add(_SectionHeader(
        en ? 'Also available elsewhere' : 'Pia zinapatikana maeneo mengine',
        en ? 'Outside your area' : 'Nje ya eneo lako',
        count: _hasMore ? null : r.elsewhere.length,
        divider: r.nearby.isNotEmpty,
      ));
      out.addAll(r.elsewhere);
    }
    return out;
  }

  /// Bottom of the results: a spinner while the next page loads. After a network
  /// error it shows a short note; scrolling again retries automatically.
  Widget _buildLoadMoreFooter() {
    if (_loadMoreFailed && !_loadingMore) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 16),
        child: Center(
          child: Text(
            AppStrings.isEnglish ? 'Could not load more. Scroll to retry.' : 'Imeshindwa kupakia zaidi. Telezesha kujaribu tena.',
            style: const TextStyle(fontSize: 12, color: AppColors.textMuted),
          ),
        ),
      );
    }
    return const Padding(
      padding: EdgeInsets.symmetric(vertical: 16),
      child: Center(
        child: SizedBox(
          width: 22,
          height: 22,
          child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.primary),
        ),
      ),
    );
  }

  Widget _buildNotice(String text) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.primary.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.info_outline_rounded, size: 18, color: AppColors.primary),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(_SectionHeader h) {
    return Padding(
      padding: EdgeInsets.only(bottom: 10, top: h.divider ? 6 : 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (h.divider) ...[
            const Divider(height: 1, color: AppColors.border),
            const SizedBox(height: 14),
          ],
          Row(
            children: [
              Icon(
                h.divider ? Icons.public_rounded : Icons.near_me_rounded,
                size: 16,
                color: AppColors.primary,
              ),
              const SizedBox(width: 6),
              Text(
                h.count != null ? '${h.title} (${h.count})' : h.title,
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
              ),
            ],
          ),
          if (h.subtitle != null)
            Padding(
              padding: const EdgeInsets.only(left: 22, top: 2),
              child: Text(
                h.subtitle!,
                style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
              ),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppLanguage>(
      valueListenable: AppStrings.currentLanguage,
      builder: (context, _, child) {
        final filterChips = [
          {'key': 'ALL', 'label': AppStrings.chipAll},
          {'key': 'NEARBY', 'label': AppStrings.chipNearby},
          {'key': 'TOP_RATED', 'label': AppStrings.chipTopRated},
          {'key': 'VERIFIED', 'label': AppStrings.chipVerified},
        ];

        return Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            backgroundColor: AppColors.surface,
            elevation: 0,
            leading: (widget.onBackToHome != null || Navigator.canPop(context))
                ? IconButton(
                    icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
                    onPressed: () {
                      if (widget.onBackToHome != null) {
                        widget.onBackToHome!();
                      } else if (Navigator.canPop(context)) {
                        Navigator.pop(context);
                      }
                    },
                  )
                : null,
            title: Text(
              widget.categoryTitle == 'All' ? AppStrings.search : widget.categoryTitle,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: AppColors.textPrimary,
              ),
            ),
            bottom: PreferredSize(
              preferredSize: const Size.fromHeight(1),
              child: Container(color: AppColors.borderLight, height: 1),
            ),
          ),
          body: Column(
            children: [
              // Search box (searches within this category)
              Container(
                color: AppColors.surface,
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
                child: TextField(
                  controller: _searchController,
                  onChanged: _onSearchChanged,
                  onSubmitted: _runSearch,
                  textInputAction: TextInputAction.search,
                  style: const TextStyle(fontSize: 14, color: AppColors.textPrimary),
                  decoration: InputDecoration(
                    hintText: AppStrings.isEnglish
                        ? 'Search in ${widget.categoryTitle == 'All' ? 'services' : widget.categoryTitle}...'
                        : 'Tafuta ndani ya ${widget.categoryTitle == 'All' ? 'huduma' : widget.categoryTitle}...',
                    hintStyle: const TextStyle(fontSize: 13, color: AppColors.textMuted),
                    prefixIcon: const Icon(Icons.search_rounded, size: 20, color: AppColors.textSecondary),
                    suffixIcon: _searchController.text.isEmpty
                        ? null
                        : IconButton(
                            icon: const Icon(Icons.close_rounded, size: 18, color: AppColors.textSecondary),
                            onPressed: () {
                              _searchController.clear();
                              _runSearch('');
                              setState(() {});
                            },
                          ),
                    filled: true,
                    fillColor: AppColors.borderLight,
                    isDense: true,
                    contentPadding: const EdgeInsets.symmetric(vertical: 10),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),

              // Filter Chips Row (All, Nearby, Top Rated, Verified)
              Container(
                color: AppColors.surface,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                child: Row(
                  children: filterChips.map((chip) {
                    final chipKey = chip['key']!;
                    final chipLabel = chip['label']!;
                    final isSelected = _activeChip == chipKey;

                    return Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: GestureDetector(
                        onTap: () => setState(() => _activeChip = chipKey),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                          decoration: BoxDecoration(
                            color: isSelected ? AppColors.primary : AppColors.borderLight,
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Text(
                            chipLabel,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: isSelected ? Colors.white : AppColors.textSecondary,
                            ),
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
              const Divider(height: 1, color: AppColors.borderLight),

              // Filters chosen on the Search & Filter screen
              if (_filters.isActive)
                Container(
                  width: double.infinity,
                  color: AppColors.surface,
                  padding: const EdgeInsets.fromLTRB(16, 8, 8, 8),
                  child: Row(
                    children: [
                      Expanded(
                        child: Wrap(
                          spacing: 6,
                          runSpacing: 4,
                          children: _activeFilterLabels()
                              .map((l) => Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: AppColors.primary.withValues(alpha: 0.1),
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Text(
                                      l,
                                      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.primary),
                                    ),
                                  ))
                              .toList(),
                        ),
                      ),
                      TextButton(
                        onPressed: _clearFilters,
                        child: Text(
                          AppStrings.searchFilterReset,
                          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                        ),
                      ),
                    ],
                  ),
                ),
              if (_filters.isActive) const Divider(height: 1, color: AppColors.borderLight),

              // Vertical List of Service Cards
              Expanded(
                child: Builder(
                  builder: (context) {
                    if (_loadingInitial) {
                      return const VerticalListCardSkeleton();
                    }

                    final rawItems = _all;

                    final results = _applyFilter(rawItems);

                    if (results.isEmpty && _initialFailed) {
                      final en = AppStrings.isEnglish;
                      return Center(
                        child: Padding(
                          padding: const EdgeInsets.all(24.0),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.wifi_off_rounded, size: 40, color: AppColors.textSecondary),
                              const SizedBox(height: 12),
                              Text(
                                en ? 'Could not load services. Check your connection.' : 'Imeshindwa kupakia huduma. Angalia mtandao wako.',
                                textAlign: TextAlign.center,
                                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textSecondary),
                              ),
                              const SizedBox(height: 10),
                              OutlinedButton.icon(
                                onPressed: () => setState(_loadCategoryServices),
                                icon: const Icon(Icons.refresh_rounded, size: 18),
                                label: Text(en ? 'Retry' : 'Jaribu tena'),
                              ),
                            ],
                          ),
                        ),
                      );
                    }

                    if (results.isEmpty) {
                      return Center(
                        child: Padding(
                          padding: const EdgeInsets.all(24.0),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.search_off_rounded, size: 40, color: AppColors.textSecondary),
                              const SizedBox(height: 12),
                              Text(
                                (rawItems.isNotEmpty && (_filters.isActive || _activeChip != 'ALL'))
                                    ? (AppStrings.isEnglish
                                        ? 'No services match your filters'
                                        : 'Hakuna huduma zinazolingana na vichujio vyako')
                                    : _query.isNotEmpty
                                    ? (AppStrings.isEnglish
                                        ? 'No results for "$_query"'
                                        : 'Hakuna matokeo ya "$_query"')
                                    : '${AppStrings.noServicesNearby} (${widget.categoryTitle})',
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.textSecondary,
                                ),
                              ),
                              if (_hasMore && !_loadMoreFailed) ...[
                                const SizedBox(height: 10),
                                _buildLoadMoreFooter(),
                              ],
                              if (_activeChip == 'NEARBY' && rawItems.isNotEmpty) ...[
                                const SizedBox(height: 10),
                                TextButton(
                                  onPressed: () => setState(() => _activeChip = 'ALL'),
                                  child: Text(AppStrings.isEnglish ? 'Show from anywhere' : 'Onyesha kutoka popote'),
                                ),
                              ],
                              if (!SecuritySettings.allowSensitive) ...[
                                const SizedBox(height: 6),
                                Text(
                                  AppStrings.isEnglish
                                      ? 'Sensitive (18+) services are hidden. You can allow them in Settings.'
                                      : 'Huduma nyeti (18+) zimefichwa. Unaweza kuziruhusu kwenye Mipangilio.',
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(fontSize: 11, color: AppColors.textMuted),
                                ),
                              ],
                            ],
                          ),
                        ),
                      );
                    }

                    final entries = _buildEntries(results);
                    final showFooter = _hasMore || _loadingMore;
                    return ListView.builder(
                      controller: _scroll,
                      padding: const EdgeInsets.all(16),
                      itemCount: entries.length + (showFooter ? 1 : 0),
                      itemBuilder: (context, index) {
                        if (index == entries.length) return _buildLoadMoreFooter();
                        final e = entries[index];
                        if (e is _SectionHeader) return _buildSectionHeader(e);
                        if (e is _Notice) return _buildNotice(e.text);
                        final item = e as ServiceItem;
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 14),
                          child: _buildServiceCard(context, item, index),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildServiceCard(BuildContext context, ServiceItem item, int index) {
    final isFav = SessionManager.isFavorite(item.id);
    final imagePath = index % 2 == 0 ? 'assets/images/banner.jpg' : 'assets/images/provider1.jpg';

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ServiceDetailsScreen(service: item),
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: SizedBox(
                width: 78,
                height: 78,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.asset(
                      imagePath,
                      fit: BoxFit.cover,
                      errorBuilder: (ctx, err, stack) => Container(
                        color: item.themeColor.withValues(alpha: 0.15),
                        child: Icon(item.icon, color: item.themeColor, size: 30),
                      ),
                    ),
                    if (item.is18Plus)
                      const Positioned(top: 4, right: 4, child: SensitiveTag(compact: true)),
                    if (item.isOnline)
                      const Positioned(bottom: 4, left: 4, child: OnlineBadge(compact: true)),
                    if (item.isVerified)
                      Positioned(
                        top: 4,
                        left: 4,
                        child: VerificationPill(
                          level: item.verificationLevel,
                          compact: true,
                        ),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          item.title,
                          style: const TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                            color: AppColors.textPrimary,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      GestureDetector(
                        onTap: () => SessionManager.toggleFavorite(item.id),
                        child: Icon(
                          isFav ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                          size: 18,
                          color: isFav ? AppColors.danger : AppColors.textMuted,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          item.stageName,
                          style: const TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            color: AppColors.primary,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (item.isBoosted) ...[
                        const SizedBox(width: 6),
                        const BoostBadge(compact: true),
                      ],
                    ],
                  ),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      const Icon(Icons.star_rounded, size: 14, color: AppColors.warning),
                      const SizedBox(width: 3),
                      Text(
                        item.ratingText,
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      Text(
                        item.hasReviews ? ' (${item.reviewsCount})' : '',
                        style: const TextStyle(
                          fontSize: 11,
                          color: AppColors.textSecondary,
                        ),
                      ),
                      const SizedBox(width: 8),
                      const Icon(Icons.location_on_rounded, size: 12, color: AppColors.textSecondary),
                      const SizedBox(width: 2),
                      Flexible(
                        child: Text(
                          item.distance,
                          style: const TextStyle(
                            fontSize: 11,
                            color: AppColors.textSecondary,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        item.priceText,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      Text(
                        item.durationText,
                        style: const TextStyle(
                          fontSize: 11,
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionHeader {
  final String title;
  final String? subtitle;
  final int? count;
  final bool divider;
  const _SectionHeader(this.title, this.subtitle, {this.count, this.divider = false});
}

class _Notice {
  final String text;
  const _Notice(this.text);
}

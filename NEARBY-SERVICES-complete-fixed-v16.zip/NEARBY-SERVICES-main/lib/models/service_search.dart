import 'models.dart';

/// Category keywords (English + Swahili) so typing "plumber" or "kinyozi" in the
/// search box behaves exactly like picking the Plumbing / Barber category.
class ServiceCategories {
  static const List<String> keys = [
    'Massage', 'Beauty', 'Barber', 'Cleaning', 'Plumbing',
    'Electrical', 'Mechanic', 'Photography', 'Repair', 'General',
  ];

  static const Map<String, List<String>> _keywords = {
    'Massage': ['massage', 'masaji', 'spa'],
    'Beauty': ['beauty', 'urembo', 'saloon', 'salon', 'makeup', 'hair'],
    'Barber': ['barber', 'barbershop', 'kinyozi'],
    'Cleaning': ['cleaning', 'cleaner', 'clean', 'usafi'],
    'Plumbing': ['plumbing', 'plumber', 'bomba', 'fundi bomba'],
    'Electrical': ['electrical', 'electrician', 'umeme', 'fundi umeme'],
    'Mechanic': ['mechanic', 'garage', 'gereji', 'fundi gari'],
    'Photography': ['photography', 'photographer', 'photo', 'photos', 'picha'],
    'Repair': ['repair', 'repairs', 'ukarabati'],
  };

  /// The category api key when [input] is just a category word, otherwise null.
  static String? match(String input) {
    final q = input.trim().toLowerCase();
    if (q.isEmpty) return null;
    for (final e in _keywords.entries) {
      if (e.value.contains(q)) return e.key;
    }
    return null;
  }

  /// Turns a free-text search into (category, text query):
  /// a pure category word becomes a category search, anything else stays a
  /// service-name search inside the chosen category.
  static ({String? category, String? query}) resolve(String text, String? category) {
    final q = text.trim();
    final hasCategory = category != null && category.isNotEmpty && category != 'All';
    if (!hasCategory) {
      final m = match(q);
      if (m != null) return (category: m, query: null);
    }
    return (category: hasCategory ? category : null, query: q.isEmpty ? null : q);
  }
}

/// Search results split into "near you" and "available elsewhere".
class ServiceSearchResult {
  final List<ServiceItem> nearby;
  final List<ServiceItem> elsewhere;
  const ServiceSearchResult(this.nearby, this.elsewhere);

  bool get isEmpty => nearby.isEmpty && elsewhere.isEmpty;
  bool get hasBoth => nearby.isNotEmpty && elsewhere.isNotEmpty;
  int get total => nearby.length + elsewhere.length;
}

class ServiceSearch {
  /// Radius used for "nearby" when the user did not pick one.
  static const double defaultNearbyKm = 20;

  /// Inside the radius when the distance is known; otherwise same city/region.
  static bool isNearby(ServiceItem s, {required double radiusKm, required String userCity}) {
    final d = s.distanceKm;
    if (d != null) return d <= radiusKm;
    final city = userCity.toLowerCase().trim();
    final c = (s.city ?? s.distance).toLowerCase().trim();
    return city.isNotEmpty && c.isNotEmpty && (c.contains(city) || city.contains(c));
  }

  /// Keeps the incoming order inside each group.
  static ServiceSearchResult split(
    List<ServiceItem> items, {
    required double radiusKm,
    required String userCity,
  }) {
    final near = <ServiceItem>[];
    final far = <ServiceItem>[];
    for (final s in items) {
      (isNearby(s, radiusKm: radiusKm, userCity: userCity) ? near : far).add(s);
    }
    return ServiceSearchResult(near, far);
  }

  /// [primary] first, then anything in [extra] not already present (by id).
  static List<ServiceItem> mergeById(List<ServiceItem> primary, List<ServiceItem> extra) {
    final seen = <String>{};
    final out = <ServiceItem>[];
    for (final s in [...primary, ...extra]) {
      if (seen.add(s.id)) out.add(s);
    }
    return out;
  }
}

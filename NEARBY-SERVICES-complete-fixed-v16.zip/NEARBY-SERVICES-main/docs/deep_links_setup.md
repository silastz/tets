# Deep links setup

Links the app understands (the app side is already done):

| Purpose | Web link | Fallback link |
|---|---|---|
| Accept an invitation | `https://nearbyservices.techwareafrica.tech/i/<code>` | `nearbyservices://invite/<code>` |
| Open a shared service | `https://nearbyservices.techwareafrica.tech/s/<id>` | `nearbyservices://service/<id>` |

Invite links open the accept screen with the code filled in (signed-out users are asked to sign in first, then it opens).
Service links load `GET /services/{id}` and open the service page.

## 1. Android (verified links)
Host this file at `https://nearbyservices.techwareafrica.tech/.well-known/assetlinks.json`
(HTTP 200, `application/json`, no redirects):

```json
[{
  "relation": ["delegate_permission/common.handle_all_urls"],
  "target": {
    "namespace": "android_app",
    "package_name": "com.unganalink.app",
    "sha256_cert_fingerprints": ["<RELEASE_SHA256>", "<PLAY_APP_SIGNING_SHA256>"]
  }
}]
```
- Get the SHA-256: `keytool -list -v -keystore <your.jks>`; if you use Play App Signing, copy the fingerprint from Play Console > App integrity.
- `com.unganalink.app` is the app's `applicationId` (set in `android/app/build.gradle.kts`, matching the Kotlin package). The `sha256_cert_fingerprints` value must be the fingerprint of your release signing key.
- Check: `adb shell pm get-app-links com.unganalink.app`.

## 2. iOS (universal links)
1. Host `https://nearbyservices.techwareafrica.tech/.well-known/apple-app-site-association` (no extension, `application/json`):
```json
{ "applinks": { "details": [{ "appIDs": ["<TEAMID>.com.unganalink.app"], "components": [{ "/": "/i/*" }, { "/": "/s/*" }] }] } }
```
2. In Xcode: Runner > Signing & Capabilities > + Capability > Associated Domains > add `applinks:nearbyservices.techwareafrica.tech`.
3. The `nearbyservices://` scheme is already in `Info.plist` and needs nothing else.

## 3. Server pages for people without the app
Make `/i/<code>` and `/s/<id>` return a small web page (not a 404): "Open in Nearby Services" (button to `nearbyservices://...`) and a Play Store / App Store link. Phones with the app and verified links skip this page.

## 4. After you publish the app
Put the store link in `ShareService.appLink` (`lib/services/share_service.dart`).

## Notes
- WhatsApp only makes `https://` links tappable, so the share messages use the web link. The custom scheme is a fallback for QR codes, SMS and browsers.
- Link handling is done by the `app_links` plugin; Flutter's built-in route deep linking is switched off (`flutter_deeplinking_enabled` / `FlutterDeepLinkingEnabled`) so the two do not fight.

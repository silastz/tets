import 'package:flutter_test/flutter_test.dart';
import 'package:latlong2/latlong.dart';
import 'package:jamiiapp/services/navigation_engine.dart';

Map<String, dynamic> _osrm() => {
      'distance': 400.0,
      'duration': 60.0,
      'geometry': {
        'coordinates': [
          [39.2000, -6.8000],
          [39.2000, -6.7980],
          [39.2000, -6.7964],
          [39.2020, -6.7964],
        ]
      },
      'legs': [
        {
          'steps': [
            {'distance': 380.0, 'name': 'Main Rd', 'maneuver': {'type': 'depart', 'location': [39.2000, -6.8000]}},
            {'distance': 200.0, 'name': 'Mandela Rd', 'maneuver': {'type': 'turn', 'modifier': 'right', 'location': [39.2000, -6.7964]}},
            {'distance': 0.0, 'name': '', 'maneuver': {'type': 'arrive', 'location': [39.2020, -6.7964]}},
          ]
        }
      ],
    };

void main() {
  test('parses steps and snaps manoeuvres to the route', () {
    final r = NavRoute.fromOsrm(_osrm())!;
    expect(r.steps.length, 3);
    expect(r.steps[1].polyIndex, 2);
    expect(r.steps[2].polyIndex, 3);
  });

  test('progress: on route, remaining shrinks and next step is the turn', () {
    final r = NavRoute.fromOsrm(_osrm())!;
    final p = r.progress(const LatLng(-6.7990, 39.2000));
    expect(p.offRouteM, lessThan(10));
    expect(r.nextStepIndex(p.index), 1);
    expect(r.metresToStep(p.index, 1), greaterThan(100));
    expect(p.remainingM, lessThan(r.cum.last));
  });

  test('off-route detection', () {
    final r = NavRoute.fromOsrm(_osrm())!;
    final p = r.progress(const LatLng(-6.7990, 39.2100)); // ~1 km east of the road
    expect(p.offRouteM, greaterThan(500));
  });

  test('instruction text in English and Swahili', () {
    final r = NavRoute.fromOsrm(_osrm())!;
    expect(NavText.instruction(r.steps[1], true), 'Turn right onto Mandela Rd');
    expect(NavText.instruction(r.steps[1], false), 'Geuka kulia kuingia Mandela Rd');
    expect(NavText.instruction(r.steps[2], true), 'You have arrived');
  });

  test('distance formatting', () {
    expect(NavText.distance(850, true), '850 m');
    expect(NavText.distance(1500, true), '1.5 km');
    expect(NavText.distance(12, true), '12 m');
  });
}

package com.example.jamiiapp

import io.flutter.embedding.android.FlutterFragmentActivity

// local_auth (biometrics) needs a FragmentActivity.
class MainActivity : FlutterFragmentActivity()

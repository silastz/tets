import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// On-device security preferences: App Lock (PIN), lock timeout, Remember Me,
/// Two-Factor preference and notification switches.
///
/// The PIN lives in encrypted storage (Keystore / Keychain); the rest are plain prefs.
class SecuritySettings {
  static const _kAppLock = 'sec_app_lock';
  static const _kTimeout = 'sec_lock_timeout';
  static const _kRemember = 'sec_remember_me';
  static const _kTwoFactor = 'sec_two_factor';
  static const _kPin = 'sec_app_lock_pin';
  static const _kBiometric = 'sec_biometric';
  static const _kProfileLocked = 'priv_profile_locked';
  static const _kAllowSensitive = 'priv_allow_sensitive';

  static SharedPreferences? _prefs;
  static const FlutterSecureStorage _secure = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );
  static String? _pin;

  /// Bumped whenever a setting changes so the lock gate / settings page can refresh.
  static final ValueNotifier<int> changed = ValueNotifier<int>(0);

  static Future<void> init() async {
    _prefs ??= await SharedPreferences.getInstance();
    try {
      _pin = await _secure.read(key: _kPin);
    } catch (e) {
      debugPrint('Secure storage unavailable: $e');
      _pin = null;
    }
  }

  static void _notify() => changed.value++;

  // ---- App Lock -----------------------------------------------------------
  static bool get appLockEnabled =>
      (_prefs?.getBool(_kAppLock) ?? false) && (_pin != null && _pin!.isNotEmpty);

  /// Seconds the app may stay in the background before it locks (0 = immediately).
  static int get lockTimeoutSeconds => _prefs?.getInt(_kTimeout) ?? 30;

  static Future<void> setLockTimeout(int seconds) async {
    await _prefs?.setInt(_kTimeout, seconds);
    _notify();
  }

  /// Fingerprint / Face unlock (only meaningful while App Lock is on).
  static bool get biometricEnabled => appLockEnabled && (_prefs?.getBool(_kBiometric) ?? false);
  static Future<void> setBiometricEnabled(bool v) async {
    await _prefs?.setBool(_kBiometric, v);
    _notify();
  }

  static bool verifyPin(String pin) => _pin != null && _pin == pin;

  /// Returns false when the PIN could not be stored safely.
  static Future<bool> enableAppLock(String pin) async {
    try {
      await _secure.write(key: _kPin, value: pin);
    } catch (e) {
      debugPrint('Could not store PIN: $e');
      return false;
    }
    _pin = pin;
    await _prefs?.setBool(_kAppLock, true);
    _notify();
    return true;
  }

  static Future<bool> changePin(String pin) => enableAppLock(pin);

  static Future<void> disableAppLock() async {
    _pin = null;
    try {
      await _secure.delete(key: _kPin);
    } catch (_) {}
    await _prefs?.setBool(_kAppLock, false);
    await _prefs?.setBool(_kBiometric, false);
    _notify();
  }

  // ---- Other switches -----------------------------------------------------
  static bool get rememberMe => _prefs?.getBool(_kRemember) ?? true;
  static Future<void> setRememberMe(bool v) async {
    await _prefs?.setBool(_kRemember, v);
    _notify();
  }

  static bool get twoFactor => _prefs?.getBool(_kTwoFactor) ?? false;
  static Future<void> setTwoFactor(bool v) async {
    await _prefs?.setBool(_kTwoFactor, v);
    _notify();
  }

  // ---- Privacy -------------------------------------------------------------
  /// Profile Locked (default) hides your contact number and social links on your
  /// profile; Unlocked shows them.
  static bool get profileLocked => _prefs?.getBool(_kProfileLocked) ?? true;
  static Future<void> setProfileLocked(bool v) async {
    await _prefs?.setBool(_kProfileLocked, v);
    _notify();
  }

  /// When on, sensitive (18+) services are shown on the landing page, categories,
  /// search and favorites. Off by default.
  static bool get allowSensitive => _prefs?.getBool(_kAllowSensitive) ?? false;
  static Future<void> setAllowSensitive(bool v) async {
    await _prefs?.setBool(_kAllowSensitive, v);
    _notify();
  }

  /// Generic boolean preference (used by notification switches).
  static bool flag(String key, {bool defaultValue = false}) => _prefs?.getBool('flag_$key') ?? defaultValue;
  static Future<void> setFlag(String key, bool v) async {
    await _prefs?.setBool('flag_$key', v);
    _notify();
  }
}

import 'dart:async';
import 'package:flutter/material.dart';
import '../widgets/verification_badge.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/models.dart';
import '../models/service_filters.dart';
import '../services/api_service.dart';
import '../services/session_manager.dart';
import '../services/location_service.dart';
import '../services/security_settings.dart';
import '../widgets/sensitive_tag.dart';
import '../widgets/skeleton_loader.dart';
import 'service_details_screen.dart';

class CategoryDetailScreen extends StatefulWidget {
  final String categoryTitle;
  final String? categoryApiKey;
  final String? searchQuery;
  final ServiceFilters? filters;
  final VoidCallback? onBackToHome;

  const CategoryDetailScreen({
    super.key,
    this.categoryTitle = 'Massage',
    this.categoryApiKey,
    this.searchQuery,
    this.filters,
    this.onBackToHome,
  });

  @override
  State<CategoryDetailScreen> createState() => _CategoryDetailScreenState();
}

class _CategoryDetailScreenState extends State<CategoryDetailScreen> {
  // 'ALL', 'NEARBY', 'TOP_RATED', 'VERIFIED'
  String _activeChip = 'ALL';
  late Future<List<ServiceItem>> _servicesFuture;

  // In-page search (searches inside the current category)
  late final TextEditingController _searchController;
  Timer? _searchDebounce;
  String _query = '';
  late ServiceFilters _filters;

  @override
  void initState() {
    super.initState();
    _query = (widget.searchQuery ?? '').trim();
    _filters = widget.filters ?? const ServiceFilters();
    _searchController = TextEditingController(text: _query);
    _loadCategoryServices();
    SessionManager.sessionNotifier.addListener(_onSessionChanged);
  }

  void _onSessionChanged() {
    if (mounted) setState(() {}); // favorites changed elsewhere
  }

  @override
  void dispose() {
    SessionManager.sessionNotifier.removeListener(_onSessionChanged);
    _searchDebounce?.cancel();
    _searchController.dispose();
    super.dispose();
  }

  void _loadCategoryServices() {
    final effectiveCategory = widget.categoryApiKey ?? _normalizeCategory(widget.categoryTitle);
    _servicesFuture = ApiService.fetchServices(
      category: (effectiveCategory == 'All' || effectiveCategory.isEmpty) ? null : effectiveCategory,
      query: _query.isEmpty ? null : _query,
      radiusKm: _filters.maxDistanceKm?.round(),
      // Filters run on the device, so fetch a bigger page when any are set.
      size: _filters.isActive ? 100 : 20,
    );
  }

  void _clearFilters() {
    setState(() {
      _filters = const ServiceFilters();
      _loadCategoryServices();
    });
  }

  List<String> _activeFilterLabels() {
    final en = AppStrings.isEnglish;
    final f = _filters;
    String tsh(int v) => v.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},');
    final out = <String>[];
    if (f.verifiedOnly) out.add(AppStrings.searchFilterVerifiedOnly);
    if (f.maxDistanceKm != null) out.add(en ? 'Within ${f.maxDistanceKm!.round()} km' : 'Ndani ya km ${f.maxDistanceKm!.round()}');
    if (f.minPrice != null && f.maxPrice != null) {
      out.add('TSh ${tsh(f.minPrice!)} - ${tsh(f.maxPrice!)}');
    } else if (f.maxPrice != null) {
      out.add(en ? 'Under TSh ${tsh(f.maxPrice!)}' : 'Chini ya TSh ${tsh(f.maxPrice!)}');
    } else if (f.minPrice != null) {
      out.add(en ? 'Above TSh ${tsh(f.minPrice!)}' : 'Zaidi ya TSh ${tsh(f.minPrice!)}');
    }
    if (f.minRating != null) out.add('${f.minRating!.toStringAsFixed(1)} ★+');
    switch (f.availability) {
      case AvailabilityFilter.any: break;
      case AvailabilityFilter.now: out.add(AppStrings.searchFilterAvailableNow); break;
      case AvailabilityFilter.today: out.add(en ? 'Today' : 'Leo'); break;
      case AvailabilityFilter.tomorrow: out.add(en ? 'Tomorrow' : 'Kesho'); break;
      case AvailabilityFilter.weekend: out.add(en ? 'Weekend' : 'Wikendi'); break;
    }
    if (f.serviceType == ServiceTypeFilter.customerComes) out.add(en ? 'Customer comes' : 'Mteja anakuja');
    if (f.serviceType == ServiceTypeFilter.iTravel) out.add(en ? 'Provider travels' : 'Mtoa huduma anasafiri');
    switch (f.sort) {
      case SortOption.nearest: break;
      case SortOption.lowestPrice: out.add(en ? 'Lowest price' : 'Bei ya chini'); break;
      case SortOption.highestRating: out.add(en ? 'Highest rating' : 'Ukadiriaji wa juu'); break;
      case SortOption.mostPopular: out.add(en ? 'Most popular' : 'Maarufu zaidi'); break;
    }
    return out;
  }

  void _onSearchChanged(String value) {
    setState(() {}); // refresh the clear (X) button
    _searchDebounce?.cancel();
    _searchDebounce = Timer(const Duration(milliseconds: 450), () => _runSearch(value));
  }

  void _runSearch(String value) {
    _searchDebounce?.cancel();
    final q = value.trim();
    if (!mounted || q == _query) return;
    setState(() {
      _query = q;
      _loadCategoryServices();
    });
  }

  String _normalizeCategory(String input) {
    final clean = input.trim().toLowerCase();
    if (clean.contains('massage') || clean.contains('masaji')) return 'Massage';
    if (clean.contains('beauty') || clean.contains('urembo') || clean.contains('saloon')) return 'Beauty';
    if (clean.contains('barber') || clean.contains('kinyozi')) return 'Barber';
    if (clean.contains('clean') || clean.contains('usafi')) return 'Cleaning';
    if (clean.contains('plumb') || clean.contains('bomba')) return 'Plumbing';
    if (clean.contains('elect') || clean.contains('umeme')) return 'Electrical';
    if (clean.contains('mech') || clean.contains('gereji') || clean.contains('fundi')) return 'Mechanic';
    if (clean.contains('photo') || clean.contains('picha')) return 'Photography';
    if (clean.contains('repair') || clean.contains('ukarabati')) return 'Repair';
    return input;
  }

  List<ServiceItem> _applyFilter(List<ServiceItem> items) {
    // 1) Everything chosen on the Search & Filter screen.
    items = _filters.apply(items);

    // 2) The quick chips on this page.
    final userCity = LocationService.currentCity.toLowerCase().trim();

    switch (_activeChip) {
      case 'NEARBY':
        final near = items.where((it) {
          final d = it.distanceKm;
          if (d != null) return d <= 20;
          final c = (it.city ?? it.distance).toLowerCase().trim();
          return userCity.isNotEmpty && c.isNotEmpty && (c.contains(userCity) || userCity.contains(c));
        }).toList();
        near.sort((a, b) => (a.distanceKm ?? double.infinity).compareTo(b.distanceKm ?? double.infinity));
        return near;

      case 'TOP_RATED':
        final sorted = List<ServiceItem>.from(items);
        sorted.sort((a, b) => b.rating.compareTo(a.rating));
        return sorted;

      case 'VERIFIED':
        // Strictly verified only (Green Badge or Blue Tick).
        return items.where((it) => it.isVerified).toList();

      case 'ALL':
      default:
        return items;
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppLanguage>(
      valueListenable: AppStrings.currentLanguage,
      builder: (context, _, child) {
        final filterChips = [
          {'key': 'ALL', 'label': AppStrings.chipAll},
          {'key': 'NEARBY', 'label': AppStrings.chipNearby},
          {'key': 'TOP_RATED', 'label': AppStrings.chipTopRated},
          {'key': 'VERIFIED', 'label': AppStrings.chipVerified},
        ];

        return Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            backgroundColor: AppColors.surface,
            elevation: 0,
            leading: (widget.onBackToHome != null || Navigator.canPop(context))
                ? IconButton(
                    icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
                    onPressed: () {
                      if (widget.onBackToHome != null) {
                        widget.onBackToHome!();
                      } else if (Navigator.canPop(context)) {
                        Navigator.pop(context);
                      }
                    },
                  )
                : null,
            title: Text(
              widget.categoryTitle == 'All' ? AppStrings.search : widget.categoryTitle,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: AppColors.textPrimary,
              ),
            ),
            bottom: PreferredSize(
              preferredSize: const Size.fromHeight(1),
              child: Container(color: AppColors.borderLight, height: 1),
            ),
          ),
          body: Column(
            children: [
              // Search box (searches within this category)
              Container(
                color: AppColors.surface,
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
                child: TextField(
                  controller: _searchController,
                  onChanged: _onSearchChanged,
                  onSubmitted: _runSearch,
                  textInputAction: TextInputAction.search,
                  style: const TextStyle(fontSize: 14, color: AppColors.textPrimary),
                  decoration: InputDecoration(
                    hintText: AppStrings.isEnglish
                        ? 'Search in ${widget.categoryTitle == 'All' ? 'services' : widget.categoryTitle}...'
                        : 'Tafuta ndani ya ${widget.categoryTitle == 'All' ? 'huduma' : widget.categoryTitle}...',
                    hintStyle: const TextStyle(fontSize: 13, color: AppColors.textMuted),
                    prefixIcon: const Icon(Icons.search_rounded, size: 20, color: AppColors.textSecondary),
                    suffixIcon: _searchController.text.isEmpty
                        ? null
                        : IconButton(
                            icon: const Icon(Icons.close_rounded, size: 18, color: AppColors.textSecondary),
                            onPressed: () {
                              _searchController.clear();
                              _runSearch('');
                              setState(() {});
                            },
                          ),
                    filled: true,
                    fillColor: AppColors.borderLight,
                    isDense: true,
                    contentPadding: const EdgeInsets.symmetric(vertical: 10),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),

              // Filter Chips Row (All, Nearby, Top Rated, Verified)
              Container(
                color: AppColors.surface,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                child: Row(
                  children: filterChips.map((chip) {
                    final chipKey = chip['key']!;
                    final chipLabel = chip['label']!;
                    final isSelected = _activeChip == chipKey;

                    return Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: GestureDetector(
                        onTap: () => setState(() => _activeChip = chipKey),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                          decoration: BoxDecoration(
                            color: isSelected ? AppColors.primary : AppColors.borderLight,
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Text(
                            chipLabel,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: isSelected ? Colors.white : AppColors.textSecondary,
                            ),
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
              const Divider(height: 1, color: AppColors.borderLight),

              // Filters chosen on the Search & Filter screen
              if (_filters.isActive)
                Container(
                  width: double.infinity,
                  color: AppColors.surface,
                  padding: const EdgeInsets.fromLTRB(16, 8, 8, 8),
                  child: Row(
                    children: [
                      Expanded(
                        child: Wrap(
                          spacing: 6,
                          runSpacing: 4,
                          children: _activeFilterLabels()
                              .map((l) => Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: AppColors.primary.withValues(alpha: 0.1),
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Text(
                                      l,
                                      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.primary),
                                    ),
                                  ))
                              .toList(),
                        ),
                      ),
                      TextButton(
                        onPressed: _clearFilters,
                        child: Text(
                          AppStrings.searchFilterReset,
                          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                        ),
                      ),
                    ],
                  ),
                ),
              if (_filters.isActive) const Divider(height: 1, color: AppColors.borderLight),

              // Vertical List of Service Cards
              Expanded(
                child: FutureBuilder<List<ServiceItem>>(
                  future: _servicesFuture,
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const VerticalListCardSkeleton();
                    }

                    final rawItems = (snapshot.hasData && snapshot.data!.isNotEmpty)
                        ? snapshot.data!
                        : <ServiceItem>[];

                    final filteredItems = _applyFilter(rawItems);

                    if (filteredItems.isEmpty) {
                      return Center(
                        child: Padding(
                          padding: const EdgeInsets.all(24.0),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.search_off_rounded, size: 40, color: AppColors.textSecondary),
                              const SizedBox(height: 12),
                              Text(
                                (rawItems.isNotEmpty && (_filters.isActive || _activeChip != 'ALL'))
                                    ? (AppStrings.isEnglish
                                        ? 'No services match your filters'
                                        : 'Hakuna huduma zinazolingana na vichujio vyako')
                                    : _query.isNotEmpty
                                    ? (AppStrings.isEnglish
                                        ? 'No results for "$_query"'
                                        : 'Hakuna matokeo ya "$_query"')
                                    : '${AppStrings.noServicesNearby} (${widget.categoryTitle})',
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.textSecondary,
                                ),
                              ),
                              if (!SecuritySettings.allowSensitive) ...[
                                const SizedBox(height: 6),
                                Text(
                                  AppStrings.isEnglish
                                      ? 'Sensitive (18+) services are hidden. You can allow them in Settings.'
                                      : 'Huduma nyeti (18+) zimefichwa. Unaweza kuziruhusu kwenye Mipangilio.',
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(fontSize: 11, color: AppColors.textMuted),
                                ),
                              ],
                            ],
                          ),
                        ),
                      );
                    }

                    return ListView.separated(
                      padding: const EdgeInsets.all(16),
                      itemCount: filteredItems.length,
                      separatorBuilder: (_, _) => const SizedBox(height: 14),
                      itemBuilder: (context, index) {
                        final item = filteredItems[index];
                        final isFav = SessionManager.isFavorite(item.id);
                        final imagePath = index % 2 == 0 ? 'assets/images/banner.jpg' : 'assets/images/provider1.jpg';

                        return GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ServiceDetailsScreen(service: item),
                              ),
                            );
                          },
                          child: Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: AppColors.surface,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: AppColors.border),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(10),
                                  child: SizedBox(
                                    width: 78,
                                    height: 78,
                                    child: Stack(
                                      fit: StackFit.expand,
                                      children: [
                                        Image.asset(
                                          imagePath,
                                          fit: BoxFit.cover,
                                          errorBuilder: (ctx, err, stack) => Container(
                                            color: item.themeColor.withValues(alpha: 0.15),
                                            child: Icon(item.icon, color: item.themeColor, size: 30),
                                          ),
                                        ),
                                        if (item.is18Plus)
                                          const Positioned(top: 4, right: 4, child: SensitiveTag(compact: true)),
                                        if (item.isVerified)
                                          Positioned(
                                            top: 4,
                                            left: 4,
                                            child: VerificationPill(
                                              level: item.verificationLevel,
                                              compact: true,
                                            ),
                                          ),
                                      ],
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Expanded(
                                            child: Text(
                                              item.title,
                                              style: const TextStyle(
                                                fontSize: 13,
                                                fontWeight: FontWeight.w800,
                                                color: AppColors.textPrimary,
                                              ),
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                          GestureDetector(
                                            onTap: () => SessionManager.toggleFavorite(item.id),
                                            child: Icon(
                                              isFav ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                                              size: 18,
                                              color: isFav ? AppColors.danger : AppColors.textMuted,
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 3),
                                      Text(
                                        item.stageName,
                                        style: const TextStyle(
                                          fontSize: 11,
                                          fontWeight: FontWeight.w600,
                                          color: AppColors.primary,
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      const SizedBox(height: 3),
                                      Row(
                                        children: [
                                          const Icon(Icons.star_rounded, size: 14, color: AppColors.warning),
                                          const SizedBox(width: 3),
                                          Text(
                                            '${item.rating}',
                                            style: const TextStyle(
                                              fontSize: 11,
                                              fontWeight: FontWeight.w700,
                                              color: AppColors.textPrimary,
                                            ),
                                          ),
                                          Text(
                                            ' (${item.reviewsCount})',
                                            style: const TextStyle(
                                              fontSize: 11,
                                              color: AppColors.textSecondary,
                                            ),
                                          ),
                                          const SizedBox(width: 8),
                                          const Icon(Icons.location_on_rounded, size: 12, color: AppColors.textSecondary),
                                          const SizedBox(width: 2),
                                          Flexible(
                                            child: Text(
                                              item.distance,
                                              style: const TextStyle(
                                                fontSize: 11,
                                                color: AppColors.textSecondary,
                                              ),
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 6),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            item.priceText,
                                            style: const TextStyle(
                                              fontSize: 12,
                                              fontWeight: FontWeight.w800,
                                              color: AppColors.textPrimary,
                                            ),
                                          ),
                                          Text(
                                            item.durationText,
                                            style: const TextStyle(
                                              fontSize: 11,
                                              color: AppColors.textSecondary,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

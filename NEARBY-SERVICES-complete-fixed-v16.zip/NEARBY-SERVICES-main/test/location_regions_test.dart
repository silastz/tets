import 'package:flutter_test/flutter_test.dart';
import 'package:jamiiapp/services/location_service.dart';

void main() {
  group('regions follow the detected country', () {
    test('each supported country has its own list, capital first', () {
      expect(LocationService.regionsFor('TZ').first, 'Dar es Salaam');
      expect(LocationService.regionsFor('KE').first, 'Nairobi');
      expect(LocationService.regionsFor('UG').first, 'Kampala');
      expect(LocationService.regionsFor('RW').first, 'Kigali');
      expect(LocationService.regionsFor('BI').first, 'Bujumbura');
      expect(LocationService.regionsFor('CD').first, 'Kinshasa');
    });

    test('lists are not mixed between countries', () {
      expect(LocationService.regionsFor('KE'), isNot(contains('Arusha')));
      expect(LocationService.regionsFor('TZ'), isNot(contains('Nairobi')));
    });

    test('unknown or empty country falls back to Tanzania', () {
      expect(LocationService.regionsFor(''), LocationService.regionsFor('TZ'));
      expect(LocationService.regionsFor('US'), LocationService.regionsFor('TZ'));
      expect(LocationService.regionsFor(null), LocationService.regionsFor('TZ'));
    });

    test('every list is non-empty with no duplicates', () {
      LocationService.regionsByCountry.forEach((iso, list) {
        expect(list, isNotEmpty, reason: iso);
        expect(list.toSet().length, list.length, reason: '$iso has duplicates');
      });
    });
  });

  group('resolveDetectedLocation', () {
    test('Tanzania city and region names match the list', () {
      expect(LocationService.resolveDetectedLocation(iso: 'TZ', city: 'Dar es Salaam'), 'Dar es Salaam');
      expect(LocationService.resolveDetectedLocation(iso: 'TZ', region: 'Arusha Region'), 'Arusha');
      expect(LocationService.resolveDetectedLocation(iso: 'TZ', city: 'Moshi'), 'Kilimanjaro (Moshi)');
    });

    test('Kenya counties and towns match', () {
      expect(LocationService.resolveDetectedLocation(iso: 'KE', city: 'Nairobi', region: 'Nairobi County'), 'Nairobi');
      expect(LocationService.resolveDetectedLocation(iso: 'KE', city: 'Eldoret'), 'Uasin Gishu (Eldoret)');
      expect(LocationService.resolveDetectedLocation(iso: 'KE', city: 'Unknown', region: 'Kisumu County'), 'Kisumu');
    });

    test('Uganda, Rwanda and DRC match (incl. accents and provinces)', () {
      expect(LocationService.resolveDetectedLocation(iso: 'UG', city: 'Entebbe'), 'Wakiso (Entebbe)');
      expect(LocationService.resolveDetectedLocation(iso: 'RW', region: 'Southern Province'), 'Huye (Butare)');
      expect(LocationService.resolveDetectedLocation(iso: 'CD', city: 'Goma'), 'Nord-Kivu (Goma)');
      expect(LocationService.resolveDetectedLocation(iso: 'CD', region: 'Kasai-Oriental'), 'Kasaï-Oriental (Mbuji-Mayi)');
    });

    test('unmatched place in a supported country keeps the raw name', () {
      expect(LocationService.resolveDetectedLocation(iso: 'KE', city: 'Zzyzx'), 'Zzyzx');
    });

    test('no place data gives the country capital', () {
      expect(LocationService.resolveDetectedLocation(iso: 'KE'), 'Nairobi');
      expect(LocationService.resolveDetectedLocation(iso: 'UG'), 'Kampala');
    });

    test('unsupported country becomes "City, Country"', () {
      expect(
        LocationService.resolveDetectedLocation(iso: 'US', city: 'Austin', countryName: 'United States'),
        'Austin, United States',
      );
    });
  });
}

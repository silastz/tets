import 'package:flutter/material.dart';

import 'device_integrity.dart';

/// Re-scans the device whenever the app returns to the foreground (someone could attach
/// Frida / a debugger after launch). Normal users never see anything: it only reacts to
/// root / hooks / debugger / repackaged app, never to VPN, developer options or USB debugging.
class IntegrityGuard extends StatefulWidget {
  final Widget child;
  const IntegrityGuard({super.key, required this.child});

  @override
  State<IntegrityGuard> createState() => _IntegrityGuardState();
}

class _IntegrityGuardState extends State<IntegrityGuard> with WidgetsBindingObserver {
  bool _blocked = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) return;
    DeviceIntegrity.scan().then((r) {
      if (mounted && r.mustBlock && !_blocked) setState(() => _blocked = true);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!_blocked) return widget.child;
    return const Scaffold(
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Text(
            'For your security, Ungana cannot run on this device.\n'
            'Kwa usalama wako, Ungana haiwezi kufanya kazi kwenye kifaa hiki.',
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}

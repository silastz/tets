/// OneSignal configuration.
///
/// 1. Create an app at https://onesignal.com (Android = FCM, iOS = APNs key).
/// 2. Paste the App ID below (App Settings -> Keys & IDs).
/// The REST API key must NEVER be put in the app - it stays on your server
/// (see docs/onesignal_send.php).
class NotificationConfig {
  static const String oneSignalAppId = 'YOUR_ONESIGNAL_APP_ID';

  static bool get isConfigured =>
      oneSignalAppId.isNotEmpty && oneSignalAppId != 'YOUR_ONESIGNAL_APP_ID';
}

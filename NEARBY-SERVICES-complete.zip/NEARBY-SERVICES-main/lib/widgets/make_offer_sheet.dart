import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/models.dart';
import '../services/api_service.dart';

/// Bottom sheet where a buyer proposes their own price for a service.
/// The offer is sent to the seller, who can accept, counter or reject it.
class MakeOfferSheet extends StatefulWidget {
  final ServiceItem service;

  const MakeOfferSheet({super.key, required this.service});

  /// Returns true when the offer was sent.
  static Future<bool?> show(BuildContext context, ServiceItem service) {
    return showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => MakeOfferSheet(service: service),
    );
  }

  @override
  State<MakeOfferSheet> createState() => _MakeOfferSheetState();
}

class _MakeOfferSheetState extends State<MakeOfferSheet> {
  final _amountController = TextEditingController();
  final _messageController = TextEditingController();
  bool _sending = false;
  String? _error;

  bool get _isEn => AppStrings.isEnglish;
  int get _listed => widget.service.priceAmount;

  @override
  void dispose() {
    _amountController.dispose();
    _messageController.dispose();
    super.dispose();
  }

  String _fmt(num v) => 'TSh ${v.toInt().toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]},')}';

  double? get _amount => double.tryParse(_amountController.text.replaceAll(',', '').trim());

  void _pickDiscount(int percent) {
    final v = (_listed * (100 - percent) / 100 / 500).round() * 500; // round to nearest 500
    setState(() {
      _amountController.text = v.toString();
      _error = null;
    });
  }

  Future<void> _send() async {
    final amount = _amount;
    if (amount == null || amount <= 0) {
      setState(() => _error = _isEn ? 'Enter your offer amount' : 'Weka kiasi cha ofa yako');
      return;
    }
    if (amount > _listed) {
      setState(() => _error = _isEn
          ? 'Your offer is higher than the listed price (${_fmt(_listed)})'
          : 'Ofa yako ni kubwa kuliko bei ya huduma (${_fmt(_listed)})');
      return;
    }
    if (_listed > 0 && amount < _listed * 0.3) {
      setState(() => _error = _isEn
          ? 'Offer is too low. Try at least 30% of the listed price.'
          : 'Ofa ni ndogo sana. Jaribu angalau 30% ya bei ya huduma.');
      return;
    }

    setState(() {
      _sending = true;
      _error = null;
    });
    final res = await ApiService.makeOffer(
      serviceId: int.tryParse(widget.service.id),
      sellerId: widget.service.sellerId,
      amount: amount,
      listedPrice: _listed.toDouble(),
      message: _messageController.text.trim(),
    );
    if (!mounted) return;
    if (res != null) {
      Navigator.pop(context, true);
    } else {
      setState(() {
        _sending = false;
        _error = _isEn ? 'Could not send your offer. Please try again.' : 'Imeshindikana kutuma ofa. Jaribu tena.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return Container(
      padding: EdgeInsets.fromLTRB(20, 14, 20, 20 + bottom),
      decoration: const BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: const BoxDecoration(color: AppColors.primaryLight, shape: BoxShape.circle),
                  child: const Icon(Icons.local_offer_rounded, color: AppColors.primary, size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _isEn ? 'Make an Offer' : 'Toa Ofa',
                        style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                      ),
                      Text(
                        widget.service.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: AppColors.background,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(_isEn ? 'Listed price' : 'Bei ya huduma',
                      style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
                  Text(_fmt(_listed),
                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Text(_isEn ? 'Your offer (TSh)' : 'Ofa yako (TSh)',
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
            const SizedBox(height: 6),
            TextField(
              controller: _amountController,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              onChanged: (_) => setState(() => _error = null),
              decoration: _decoration(hint: _isEn ? 'e.g. 40000' : 'Mfano: 40000', icon: Icons.payments_outlined),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              children: [5, 10, 15, 20]
                  .map((p) => ActionChip(
                        label: Text('-$p%', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.primary)),
                        onPressed: () => _pickDiscount(p),
                        backgroundColor: AppColors.primaryLight,
                        side: BorderSide.none,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                        visualDensity: VisualDensity.compact,
                      ))
                  .toList(),
            ),
            const SizedBox(height: 14),
            Text(_isEn ? 'Message to seller (optional)' : 'Ujumbe kwa muuzaji (si lazima)',
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
            const SizedBox(height: 6),
            TextField(
              controller: _messageController,
              maxLines: 3,
              maxLength: 300,
              decoration: _decoration(
                hint: _isEn ? 'e.g. Can you do it for this price? I can book today.' : 'Mfano: Naweza kulipa bei hii, nitaweka oda leo.',
                icon: Icons.notes_rounded,
              ),
            ),
            if (_error != null) ...[
              const SizedBox(height: 4),
              Text(_error!, style: const TextStyle(fontSize: 12, color: AppColors.danger, fontWeight: FontWeight.w600)),
            ],
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _sending ? null : _send,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: _sending
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : Text(_isEn ? 'Send Offer' : 'Tuma Ofa', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  InputDecoration _decoration({required String hint, required IconData icon}) {
    return InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(fontSize: 13, color: AppColors.textMuted),
      prefixIcon: Icon(icon, size: 18, color: AppColors.textSecondary),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      isDense: true,
    );
  }
}

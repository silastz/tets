import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart' show CameraDevice;
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/id_kinds.dart';
import '../security/password_policy.dart';
import '../security/input_validation.dart';
import '../services/api_service.dart';
import '../services/media_picker.dart';
import '../widgets/card_payment_dialog.dart';
import '../services/session_manager.dart';
import '../services/attempt_limiter.dart';
import 'registration_fee_screen.dart';
import '../widgets/app_ui.dart' show LoadingTextButton;
import '../widgets/resend_countdown.dart';
import '../widgets/whatsapp_text.dart';

/// RegisterProviderScreen implements the 4-step wizard design from IMG-20261018-WA0020.jpg:
/// 1. Basic Info (Full Name, Phone +255, Email, Password with visibility eye)
/// 2. Business Info (Business/Service Name, Category, Description, Location, Service Area radius)
/// 3. Documents (NIDA front photo, Business license optional, Profile photo)
/// 4. Registration Payment (One-time registration fee, payment method selection: Mobile Money, Card, Lipa Kwa Simu)
///
/// Supports two entry points:
/// - New guest user registering as a Service Provider
/// - Authenticated Buyer upgrading to a Service Provider (pre-fills basic info, allows skipping step 1)
class RegisterProviderScreen extends StatefulWidget {
  final bool isUpgradeFromBuyer;

  const RegisterProviderScreen({
    super.key,
    this.isUpgradeFromBuyer = false,
  });

  @override
  State<RegisterProviderScreen> createState() => _RegisterProviderScreenState();
}

class _RegisterProviderScreenState extends State<RegisterProviderScreen> with ResendCountdown<RegisterProviderScreen> {
  int _currentStep = 0; // 0: Basic Info, 1: Business Info, 2: Documents, 3: Payment
  bool _resending = false;
  bool _isLoading = false;
  String? _errorMessage;

  // Step 1 Controllers
  final TextEditingController _fullNameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _isPasswordVisible = false;

  // OTP state (Step 1): the account is created and the phone verified BEFORE
  // the provider can fill business info, documents or payment.
  bool _phoneVerified = false;
  bool _awaitingOtp = false;
  String _otpPhone = ''; // phone the current account/OTP was created for
  Map<String, dynamic>? _pendingAuthData;
  final TextEditingController _otpController = TextEditingController();

  // Step 2 Controllers
  final TextEditingController _businessNameController = TextEditingController();
  final TextEditingController _descController = TextEditingController();
  final TextEditingController _locationController = TextEditingController();
  String _selectedCategory = 'Massage';
  String _selectedRadius = '5 km';

  // Step 3 Upload states
  String _idKind = IdKinds.defaultId; // nida | voter | driving_licence | passport
  bool _hasUploadedIdFront = false;
  bool _hasUploadedIdBack = false;
  bool _hasUploadedSelfieId = false; // face next to the ID
  bool _hasUploadedFace = false; // live face photo
  final TextEditingController _ninController = TextEditingController();
  bool _hasUploadedLicense = false;
  bool _hasUploadedProfilePhoto = false;
  bool _cardPaid = false; // card fee already charged in step 4
  String? _uploadingType;

  // Step 4 Payment state
  String _selectedPaymentMethod = 'mobile_money'; // 'mobile_money', 'card', 'lipa'
  final TextEditingController _payPhoneController = TextEditingController(); // number to pay with (Mobile Money)
  /// One source of truth for the fee (also used by the payment screen); never a separate hard-coded copy.
  String get _registrationFee => SessionManager.registrationFee
      .toString()
      .replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},');

  final List<String> _categories = [
    'Massage',
    'Beauty',
    'Barber',
    'Cleaning',
    'Plumbing',
    'Electrical',
    'Repair',
    'Photography',
    'General',
  ];

  final List<String> _radiusOptions = [
    '2 km',
    '5 km',
    '10 km',
    '15 km',
    '20 km',
    'All Dar es Salaam',
  ];

  @override
  void initState() {
    super.initState();
    _initUserData();
  }

  void _initUserData() {
    if (widget.isUpgradeFromBuyer || SessionManager.isLoggedIn()) {
      _fullNameController.text = SessionManager.getStageName();
      _phoneController.text = SessionManager.getPhone();
      // If buyer is already authenticated, advance directly to Business Info step
      _phoneVerified = true;
      _currentStep = 1;
    }
    _locationController.text = 'Dar es Salaam, Tanzania';
  }

  @override
  void dispose() {
    disposeResend();
    _fullNameController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _businessNameController.dispose();
    _descController.dispose();
    _locationController.dispose();
    _payPhoneController.dispose();
    _otpController.dispose();
    _ninController.dispose();
    super.dispose();
  }

  String get _ninDigits => _ninController.text.replaceAll(RegExp(r'\D'), '');
  bool get _hasValidNin => _ninDigits.length == 20;

  /// Identity is satisfied by NIN number, NIDA photo, any other ID photo, or all.
  String? _identityError() {
    if (_ninController.text.trim().isNotEmpty && !_hasValidNin) {
      return AppStrings.isEnglish
          ? 'NIN must be 20 digits.'
          : 'Namba ya NIDA (NIN) lazima iwe na tarakimu 20.';
    }
    final kind = IdKinds.byId(_idKind);
    final idDone = _hasUploadedIdFront && (!kind.hasBack || _hasUploadedIdBack);
    if (!_hasValidNin && !idDone) {
      return AppStrings.isEnglish
          ? 'Provide your NIN, or upload your ID (${kind.hasBack ? 'front and back' : 'photo page'}).'
          : 'Weka namba ya NIDA (NIN), au pakia kitambulisho chako (${kind.hasBack ? 'mbele na nyuma' : 'ukurasa wa picha'}).';
    }
    return null;
  }

  /// Step 1 fields: name, phone, e-mail, password. Null when all are acceptable.
  String? _basicInfoError() {
    final nameErr = InputValidation.name(_fullNameController.text);
    if (nameErr != null) return nameErr;
    final phoneErr = InputValidation.phoneE164(_cleanPhone(_phoneController.text));
    if (phoneErr != null) return phoneErr;
    final emailErr = InputValidation.emailOptional(_emailController.text);
    if (emailErr != null) return emailErr;
    final pw = _passwordController.text;
    final shapeErr = InputValidation.passwordShape(pw);
    if (shapeErr != null) return shapeErr;
    return PasswordPolicy.validate(pw, phoneOrId: _cleanPhone(_phoneController.text));
  }

  /// Step 2 fields: business name, description, location.
  String? _businessInfoError() {
    final b = InputValidation.businessName(_businessNameController.text, AppStrings.regBusinessNameHint);
    if (b != null) return b;
    return InputValidation.description(_descController.text);
  }

  /// Returns an error message if [step] is not completely filled, else null.
  /// Used by the step indicator so the user cannot jump ahead of an incomplete step.
  String? _stepError(int step) {
    switch (step) {
      case 0:
        if (_phoneVerified) return null;
        final basic = _basicInfoError();
        if (basic != null) return basic;
        return AppStrings.authVerifyPhoneOtpTitle; // filled but OTP not verified yet
      case 1:
        return _businessInfoError();
      case 2:
        return _identityError();
      default:
        return null;
    }
  }

  /// Jump to [target] only if every step before it is fulfilled.
  void _goToStep(int target) {
    if (_awaitingOtp || target == _currentStep) return;
    if (target > _currentStep) {
      for (int i = 0; i < target; i++) {
        final err = _stepError(i);
        if (err != null) {
          setState(() {
            _currentStep = i; // take the user to the step that is incomplete
            _errorMessage = err;
          });
          return;
        }
      }
    }
    setState(() {
      _errorMessage = null;
      _currentStep = target;
    });
  }

  void _onStepContinue() async {
    // Ignore double taps while a request or an upload is running (would create two accounts / two payments).
    if (_isLoading || _uploadingType != null) return;
    setState(() => _errorMessage = null);

    // Step 0 Validation (Basic Info)
    if (_currentStep == 0) {
      // Already verified: just move on (fields are locked, nothing to re-check).
      if (_phoneVerified) {
        setState(() => _currentStep = 1);
        return;
      }

      // Waiting for the code: this button verifies it.
      if (_awaitingOtp) {
        await _verifyOtp();
        return;
      }

      final basicErr = _basicInfoError();
      if (basicErr != null) {
        setState(() => _errorMessage = basicErr);
        return;
      }

      await _createAccountAndSendOtp();
      return;
    }

    // Step 1 Validation (Business Info)
    if (_currentStep == 1) {
      final bizErr = _businessInfoError();
      if (bizErr != null) {
        setState(() => _errorMessage = bizErr);
        return;
      }
      setState(() => _currentStep = 2);
      return;
    }

    // Step 2 Validation (Documents)
    if (_currentStep == 2) {
      final idErr = _identityError();
      if (idErr != null) {
        setState(() => _errorMessage = idErr);
        return;
      }
      setState(() => _currentStep = 3);
      return;
    }

    // Step 3 (Payment Submission)
    if (_currentStep == 3) {
      if (_selectedPaymentMethod == 'mobile_money') {
        final payDigits = _payPhoneController.text.replaceAll(RegExp(r'\D'), '');
        final payOk = RegExp(r'^(0|255)?[67]\d{8}$').hasMatch(payDigits);
        if (!payOk) {
          setState(() => _errorMessage = AppStrings.isEnglish
              ? 'Enter the mobile number you will pay with.'
              : 'Weka namba ya simu utakayotumia kulipa.');
          return;
        }
      }
      if (_selectedPaymentMethod == 'card') {
        final phone = _cleanPhone(_phoneController.text.trim());
        setState(() => _isLoading = true);
        final paid = await CardPayment.pay(
          context,
          amount: SessionManager.registrationFee.toDouble(),
          purpose: 'PROVIDER_REGISTRATION',
          reference: 'REG-${phone.replaceAll(RegExp(r'\D'), '')}',
          description: 'Provider registration fee',
          phone: phone,
        );
        if (!mounted) return;
        setState(() => _isLoading = false);
        if (!paid) {
          setState(() => _errorMessage = AppStrings.isEnglish
              ? 'Card payment was not completed.'
              : 'Malipo ya kadi hayakukamilika.');
          return;
        }
        _cardPaid = true;
      }
      await _submitRegistrationAndPayment();
    }
  }

  /// Creates the seller account (server sends the SMS OTP) and shows the OTP box.
  Future<void> _createAccountAndSendOtp() async {
    final formattedPhone = _cleanPhone(_phoneController.text.trim());

    // Account for this number was already created in this session but not
    // verified yet (e.g. user edited something and pressed Continue again):
    // don't register twice, just resend the code.
    if (_otpPhone == formattedPhone && _pendingAuthData != null) {
      final cd = AttemptLimiter.cooldownLeft('resend:$formattedPhone');
      if (cd > 0) {
        // A code was sent a moment ago: go back to the code box instead of sending another SMS.
        setState(() {
          _awaitingOtp = true;
          _errorMessage = '${AppStrings.authTooManyAttempts} ${cd}s';
        });
        return;
      }
      setState(() => _isLoading = true);
      final sent = await ApiService.resendPhoneOtp(formattedPhone);
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _awaitingOtp = true;
        _otpController.clear();
        if (!sent) _errorMessage = ApiService.authProblemMessage();
      });
      if (sent) startResend(formattedPhone);
      return;
    }

    // Brake on repeated rejected sign-ups from this device.
    const regKey = 'register:device';
    final regWait = AttemptLimiter.secondsLocked(regKey);
    if (regWait > 0) {
      setState(() => _errorMessage = '${AppStrings.authTooManyAttempts} ${regWait}s');
      return;
    }

    setState(() => _isLoading = true);
    final cleanDigits = formattedPhone.replaceAll(RegExp(r'\D'), '');
    final uniqueUsername =
        'u_${cleanDigits.length >= 9 ? cleanDigits.substring(cleanDigits.length - 9) : cleanDigits}';

    final res = await ApiService.register(
      username: uniqueUsername,
      phone: formattedPhone,
      email: InputValidation.normalizeEmail(_emailController.text).isNotEmpty
          ? InputValidation.normalizeEmail(_emailController.text)
          : null,
      password: _passwordController.text,
      stageName: InputValidation.cleanText(_fullNameController.text),
      role: 'ROLE_SELLER',
    );
    if (!mounted) return;
    setState(() => _isLoading = false);

    if (res != null && res['success'] == true) {
      AttemptLimiter.recordSuccess(regKey);
      setState(() {
        _awaitingOtp = true;
        _otpPhone = formattedPhone;
        _pendingAuthData = (res['data'] is Map<String, dynamic>)
            ? res['data'] as Map<String, dynamic>
            : <String, dynamic>{};
        _otpController.clear();
        _errorMessage = null;
      });
      startResend(formattedPhone); // SMS just sent: count down before "Resend" unlocks
    } else {
      // Offline / server busy is not the user's fault: only real rejections count.
      if (res?['problem'] == null) AttemptLimiter.recordFailure(regKey);
      setState(() => _errorMessage = InputValidation.safeServerMessage(res?['error']));
    }
  }

  Future<void> _verifyOtp() async {
    final otp = _otpController.text.trim();
    final otpErr = InputValidation.otp(otp);
    if (otpErr != null) {
      setState(() => _errorMessage = otpErr);
      return;
    }

    final otpKey = 'otp:$_otpPhone';
    final wait = AttemptLimiter.secondsLocked(otpKey);
    if (wait > 0) {
      setState(() => _errorMessage = '${AppStrings.authTooManyAttempts} ${wait}s');
      return;
    }

    setState(() => _isLoading = true);
    final result = await ApiService.verifyPhoneOtp(_otpPhone, otp);
    if (!mounted) return;
    setState(() => _isLoading = false);

    if (result == null) {
      if (ApiService.lastAuthProblem != null) {
        // Offline / server busy: not a wrong code, so it must not count toward the lock-out.
        setState(() => _errorMessage = ApiService.authProblemMessage());
        return;
      }
      AttemptLimiter.recordFailure(otpKey);
      setState(() => _errorMessage = AppStrings.authInvalidOtpError);
      return;
    }
    AttemptLimiter.recordSuccess(otpKey);

    // Session is issued by the backend only after a successful OTP.
    final authData = (result['data'] is Map<String, dynamic>)
        ? result['data'] as Map<String, dynamic>
        : _pendingAuthData;
    if (authData != null && (authData['token'] ?? '').toString().isNotEmpty) {
      await SessionManager.saveSession(
        token: authData['token'] ?? '',
        userId: authData['id'] ?? 0,
        username: authData['username'] ?? '',
        stageName: authData['stageName'] ?? '',
        role: authData['role'] ?? 'ROLE_SELLER',
        badge: authData['verificationBadge'] ?? 'NONE',
      );
      // Account exists now but the one-time fee is still owed until step 4 is paid.
      await SessionManager.setRegFeePaid(false);
    }
    if (!mounted) return;

    setState(() {
      _phoneVerified = true;
      _awaitingOtp = false;
      _errorMessage = null;
      _currentStep = 1; // only now may the provider continue
    });
  }

  Future<void> _resendOtp() async {
    final wait = AttemptLimiter.cooldownLeft('resend:$_otpPhone');
    if (wait > 0) {
      setState(() => _errorMessage = '${AppStrings.authTooManyAttempts} ${wait}s');
      return;
    }
    setState(() {
      _resending = true;
      _errorMessage = null;
    });
    final sent = await ApiService.resendPhoneOtp(_otpPhone);
    if (!mounted) return;
    setState(() => _resending = false);
    if (sent) {
      startResend(_otpPhone);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: AppColors.primary,
          content: Text('${AppStrings.authPhoneOtpSentSubtitle} $_otpPhone'),
        ),
      );
    } else {
      setState(() => _errorMessage = ApiService.authProblemMessage());
    }
  }

  /// Really uploads a verification photo (same endpoint and ids as the
  /// Documents screen), so Profile and Documents show it as submitted.
  Future<void> _pickAndUpload(String type, VoidCallback onDone, {bool cameraOnly = false}) async {
    if (_uploadingType != null) return;
    if (!SessionManager.isLoggedIn()) {
      setState(() => _errorMessage = AppStrings.isEnglish
          ? 'Please verify your phone number first, then add your documents.'
          : 'Tafadhali thibitisha namba yako ya simu kwanza, kisha weka nyaraka zako.');
      return;
    }
    final isId = type == 'id_front' || type == 'id_back';
    final file = await MediaPicker.pickImage(
      context,
      title: AppStrings.isEnglish ? 'Add document photo' : 'Weka picha ya nyaraka',
      cameraOnly: cameraOnly,
      preferredCamera: cameraOnly ? CameraDevice.front : CameraDevice.rear,
      maxWidth: cameraOnly ? 1280 : 1800,
    );
    if (file == null || !mounted) return;
    setState(() => _uploadingType = type);
    final res = await ApiService.uploadVerificationDocument(
      type: type,
      filePath: file.path,
      idKind: isId ? _idKind : null,
    );
    if (res.ok) {
      await SessionManager.addSubmittedDoc(type);
      if (isId) await SessionManager.saveIdKind(_idKind);
    }
    _finishUpload(res, onDone);
  }

  /// Uploads the provider's profile photo (the picture customers see).
  Future<void> _pickAndUploadProfilePhoto() async {
    if (_uploadingType != null) return;
    if (!SessionManager.isLoggedIn()) {
      setState(() => _errorMessage = AppStrings.isEnglish
          ? 'Please verify your phone number first, then add your photo.'
          : 'Tafadhali thibitisha namba yako ya simu kwanza, kisha weka picha yako.');
      return;
    }
    final file = await MediaPicker.pickImage(
      context,
      title: AppStrings.regProfilePhotoTitle,
      maxWidth: 1024,
      preferredCamera: CameraDevice.front,
    );
    if (file == null || !mounted) return;
    setState(() => _uploadingType = 'profile_photo');
    final res = await ApiService.uploadAvatar(file.path);
    _finishUpload(res, () => _hasUploadedProfilePhoto = true);
  }

  /// Shared tail of every registration upload: clear the spinner, mark the
  /// card done on success, otherwise show the real reason (too large, offline...).
  void _finishUpload(UploadResult res, VoidCallback onDone) {
    if (!mounted) return;
    setState(() {
      _uploadingType = null;
      if (res.ok) {
        onDone();
        _errorMessage = null;
      } else {
        _errorMessage = res.error ??
            (AppStrings.isEnglish
                ? 'Upload failed. Check your connection and try again.'
                : 'Imeshindwa kupakia. Angalia mtandao kisha jaribu tena.');
      }
    });
  }

  Future<void> _submitRegistrationAndPayment() async {
    setState(() => _isLoading = true);

    // If upgrading from existing logged in buyer
    if (_phoneVerified || widget.isUpgradeFromBuyer || SessionManager.isLoggedIn()) {
      var paid = _cardPaid || SessionManager.getRegFeePaid() == true;
      if (!paid) {
        // Mobile money / Lipa: use the real payment flow, never a simulated one.
        setState(() => _isLoading = false);
        paid = await Navigator.push<bool>(
              context,
              MaterialPageRoute(builder: (_) => const RegistrationFeeScreen()),
            ) ??
            (SessionManager.getRegFeePaid() == true);
        if (!mounted) return;
        if (!paid) {
          setState(() => _errorMessage = AppStrings.isEnglish
              ? 'Payment was not completed.'
              : 'Malipo hayakukamilika.');
          return;
        }
        setState(() => _isLoading = true);
      }
      // The device flag alone is not proof of payment: ask the server. If it says
      // "not paid" (and is reachable), stop here; if it is unreachable, trust the
      // gateway result we already have.
      final feeStatus = await ApiService.getRegistrationFeeStatus();
      if (!mounted) return;
      if (feeStatus != null && feeStatus['paid'] == false) {
        await SessionManager.setRegFeePaid(false);
        _cardPaid = false;
        setState(() {
          _isLoading = false;
          _errorMessage = AppStrings.isEnglish
              ? 'We could not confirm your payment yet. If money was taken, wait a minute and try again.'
              : 'Hatujaweza kuthibitisha malipo yako bado. Kama pesa zimekatwa, subiri dakika moja kisha jaribu tena.';
        });
        return;
      }
      await SessionManager.updateRole('ROLE_SELLER');
      await SessionManager.setRegFeePaid(true);
      // Business city entered in the wizard feeds Home / Profile.
      final city = _locationController.text.split(',').first.trim();
      if (city.isNotEmpty) await SessionManager.saveUserCity(city);
      setState(() => _isLoading = false);

      if (mounted) {
        _showSuccessDialog();
      }
      return;
    }

    // Safety net: never submit without a verified phone.
    setState(() {
      _isLoading = false;
      _currentStep = 0;
      _errorMessage = AppStrings.authVerifyPhoneOtpTitle;
    });
  }

  /// Normalises what the user typed to +<country><number>. Handles 0712..., 712...,
  /// 255712... and +255712... (never produces +255255...).
  String _cleanPhone(String raw) {
    final trimmed = raw.trim();
    final d = trimmed.replaceAll(RegExp(r'\D'), '');
    if (d.isEmpty) return '';
    if (trimmed.startsWith('+')) return '+$d';
    if (d.startsWith('00')) return '+${d.substring(2)}';
    if (d.startsWith('255') && d.length == 12) return '+$d';
    if (d.startsWith('0')) return '+255${d.substring(1)}';
    return '+255$d';
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: const BoxDecoration(
                color: AppColors.successLight,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.check_circle_rounded, color: AppColors.success, size: 54),
            ),
            const SizedBox(height: 16),
            Text(
              AppStrings.regSuccessTitle,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              AppStrings.regSuccessMsg,
              style: const TextStyle(fontSize: 14, color: AppColors.textSecondary),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              height: 46,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pop(ctx); // Close dialog
                  Navigator.pop(context, true); // Return to previous screen with success
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: const Text('Sawa (OK)', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !_awaitingOtp && (_currentStep == 0 || (widget.isUpgradeFromBuyer && _currentStep == 1)),
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        if (_awaitingOtp) {
          setState(() {
            _awaitingOtp = false;
            _errorMessage = null;
          });
        } else if (_currentStep > 0) {
          setState(() => _currentStep--);
        }
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          centerTitle: false,
          titleSpacing: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18, color: AppColors.textPrimary),
            onPressed: () {
              if (_awaitingOtp) {
                setState(() {
                  _awaitingOtp = false;
                  _errorMessage = null;
                });
              } else if (_currentStep > 0 && !(widget.isUpgradeFromBuyer && _currentStep == 1)) {
                setState(() => _currentStep--);
              } else {
                Navigator.pop(context);
              }
            },
          ),
        title: Text(
          AppStrings.regProviderTitle,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: Column(
              children: [
                // Progress Step Indicators matching IMG-20261018-WA0020.jpg
                _buildStepIndicator(),

                if (widget.isUpgradeFromBuyer)
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: AppColors.primaryLight,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: AppColors.primary.withValues(alpha: 0.2)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.verified_user_rounded, color: AppColors.primary, size: 18),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            AppStrings.regUpgradeFromBuyerBanner,
                            style: const TextStyle(fontSize: 12, color: AppColors.primaryDark, fontWeight: FontWeight.w600),
                          ),
                        ),
                      ],
                    ),
                  ),

                if (_errorMessage != null)
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: AppColors.dangerLight,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: AppColors.danger.withValues(alpha: 0.3)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.error_outline_rounded, color: AppColors.danger, size: 18),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            _errorMessage!,
                            style: const TextStyle(fontSize: 12, color: AppColors.dangerDark, fontWeight: FontWeight.w600),
                          ),
                        ),
                      ],
                    ),
                  ),

                // Step Content
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                    child: _buildCurrentStepContent(),
                  ),
                ),

                // Bottom CTA Continue Button (Padded floating button with rounded corners matching mockup)
                Container(
                  padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    border: Border(top: BorderSide(color: AppColors.borderLight)),
                  ),
                  child: SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: _isLoading ? null : _onStepContinue,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        elevation: 0,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      child: _isLoading
                          ? const SizedBox(
                              width: 22,
                              height: 22,
                              child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.2),
                            )
                          : Text(
                              _currentStep == 3
                                  ? AppStrings.regBtnPayAndContinue
                                  : (_currentStep == 0 && _awaitingOtp && !_phoneVerified)
                                      ? AppStrings.authVerifyButton
                                      : AppStrings.regBtnContinue,
                              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: Colors.white),
                            ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    ),
  );
}

  // 4-Step Indicator matching mockup
  Widget _buildStepIndicator() {
    final steps = [
      {'num': 1, 'label': AppStrings.regStepBasic},
      {'num': 2, 'label': AppStrings.regStepBusiness},
      {'num': 3, 'label': AppStrings.regStepDocuments},
      {'num': 4, 'label': AppStrings.regStepPayment},
    ];

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: AppColors.borderLight)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: List.generate(steps.length, (index) {
          final isCompleted = _currentStep > index;
          final isCurrent = _currentStep == index;

          return Expanded(
            child: Row(
              children: [
                Expanded(
                  child: InkWell(
                    onTap: () => _goToStep(index),
                    borderRadius: BorderRadius.circular(8),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 28,
                          height: 28,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: (isCompleted || isCurrent) ? AppColors.primary : Colors.white,
                            border: Border.all(
                              color: (isCompleted || isCurrent) ? AppColors.primary : AppColors.border,
                              width: 1.5,
                            ),
                          ),
                          child: Center(
                            child: isCompleted
                                ? const Icon(Icons.check, size: 16, color: Colors.white)
                                : Text(
                                    '${steps[index]['num']}',
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      color: isCurrent ? Colors.white : AppColors.textMuted,
                                    ),
                                  ),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          steps[index]['label'] as String,
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: isCurrent ? FontWeight.w700 : FontWeight.w500,
                            color: isCurrent ? AppColors.primary : AppColors.textSecondary,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ),
                if (index < steps.length - 1)
                  Container(
                    width: 20,
                    height: 1.5,
                    color: _currentStep > index ? AppColors.primary : AppColors.border,
                  ),
              ],
            ),
          );
        }),
      ),
    );
  }

  Widget _buildCurrentStepContent() {
    switch (_currentStep) {
      case 0:
        return _buildStep1BasicInfo();
      case 1:
        return _buildStep2BusinessInfo();
      case 2:
        return _buildStep3Documents();
      case 3:
        return _buildStep4Payment();
      default:
        return const SizedBox.shrink();
    }
  }

  // 1. Basic Information
  Widget _buildStep1BasicInfo() {
    // OTP view: shown right after the account is created, blocks all other steps.
    if (_awaitingOtp && !_phoneVerified) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.successLight,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.success.withValues(alpha: 0.3)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.sms_outlined, color: AppColors.successDark, size: 22),
                    const SizedBox(width: 8),
                    Text(
                      AppStrings.authVerifyPhoneOtpTitle,
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: AppColors.successDark),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  '${AppStrings.authPhoneOtpSentSubtitle} $_otpPhone',
                  style: const TextStyle(fontSize: 12, color: AppColors.textPrimary),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _otpController,
            keyboardType: TextInputType.number,
            maxLength: 6,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            autofillHints: const [AutofillHints.oneTimeCode],
            autofocus: true,
            onChanged: (_) {
              if (_errorMessage != null) setState(() => _errorMessage = null);
            },
            decoration: InputDecoration(
              counterText: '',
              hintText: AppStrings.authOtpHint,
              hintStyle: const TextStyle(fontSize: 13, color: AppColors.textMuted),
              prefixIcon: const Icon(Icons.key_outlined, size: 18, color: AppColors.textSecondary),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              isDense: true,
            ),
          ),
          Align(
            alignment: Alignment.centerRight,
            child: LoadingTextButton(
              label: resendLabel(AppStrings.authResendOtp),
              loading: _resending,
              onPressed: (_isLoading || resendLeft > 0) ? null : _resendOtp,
            ),
          ),
        ],
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          AppStrings.regBasicTitle,
          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        const SizedBox(height: 4),
        Text(
          AppStrings.regBasicSubtitle,
          style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
        ),
        const SizedBox(height: 20),

        if (_phoneVerified) ...[
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: AppColors.successLight,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              children: [
                const Icon(Icons.verified_rounded, size: 18, color: AppColors.successDark),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _phoneController.text.trim(),
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.successDark),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
        ],

        // Fields are locked once the phone is verified (account already exists)
        AbsorbPointer(
          absorbing: _phoneVerified,
          child: Opacity(
            opacity: _phoneVerified ? 0.6 : 1,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildInputField(
                  controller: _fullNameController,
                  label: AppStrings.authFullNameLabel,
                  hint: AppStrings.regBusinessNameHint,
                  icon: Icons.person_outline_rounded,
                  maxLength: InputValidation.nameMax,
                ),
                const SizedBox(height: 14),
                _buildPhoneField(),
                const SizedBox(height: 14),
                _buildInputField(
                  controller: _emailController,
                  label: AppStrings.authEmailLabel,
                  hint: AppStrings.authEmailHint,
                  icon: Icons.email_outlined,
                  keyboardType: TextInputType.emailAddress,
                ),
                const SizedBox(height: 14),
                _buildPasswordField(),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // 2. Business Information
  Widget _buildStep2BusinessInfo() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          AppStrings.regBusinessTitle,
          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        const SizedBox(height: 4),
        Text(
          AppStrings.regBusinessSubtitle,
          style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
        ),
        const SizedBox(height: 20),

        // Business / Service Name
        _buildInputField(
          controller: _businessNameController,
          label: AppStrings.regBusinessNameLabel,
          hint: AppStrings.regBusinessNameHint,
          icon: Icons.storefront_outlined,
          maxLength: InputValidation.businessNameMax,
        ),
        const SizedBox(height: 14),

        // Service Category
        Text(
          AppStrings.regCategoryLabel,
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
        ),
        const SizedBox(height: 6),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.border),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              isExpanded: true,
              value: _selectedCategory,
              items: _categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
              onChanged: (val) {
                if (val != null) setState(() => _selectedCategory = val);
              },
            ),
          ),
        ),
        const SizedBox(height: 14),

        // Description with 0/500 counter
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              AppStrings.regDescLabel,
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
            ),
            Text(
              '${_descController.text.length}/500',
              style: const TextStyle(fontSize: 11, color: AppColors.textMuted),
            ),
          ],
        ),
        const SizedBox(height: 6),
        TextField(
          controller: _descController,
          maxLength: 500,
          maxLines: 4,
          buildCounter: (context, {required currentLength, required isFocused, maxLength}) => null,
          onChanged: (_) => setState(() {}),
          decoration: InputDecoration(
            hintText: AppStrings.regDescHint,
            hintStyle: const TextStyle(fontSize: 13, color: AppColors.textMuted),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
            contentPadding: const EdgeInsets.all(12),
          ),
        ),
        const FormatHint(),
        const SizedBox(height: 14),

        // Location
        _buildInputField(
          controller: _locationController,
          label: AppStrings.regLocationLabel,
          hint: AppStrings.regLocationHint,
          icon: Icons.location_on_outlined,
        ),
        const SizedBox(height: 14),

        // Service Area Radius
        Text(
          AppStrings.regRadiusLabel,
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
        ),
        const SizedBox(height: 6),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.border),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              isExpanded: true,
              value: _selectedRadius,
              items: _radiusOptions.map((r) => DropdownMenuItem(value: r, child: Text(r))).toList(),
              onChanged: (val) {
                if (val != null) setState(() => _selectedRadius = val);
              },
            ),
          ),
        ),
      ],
    );
  }

  // 3. Documents
  Widget _buildStep3Documents() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          AppStrings.regDocumentsTitle,
          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        const SizedBox(height: 4),
        Text(
          AppStrings.regDocumentsSubtitle,
          style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
        ),
        const SizedBox(height: 20),

        // Identity: NIN number, NIDA photo, other ID photo - any one is enough, all allowed
        Container(
          padding: const EdgeInsets.all(10),
          margin: const EdgeInsets.only(bottom: 14),
          decoration: BoxDecoration(
            color: AppColors.primaryLight,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            children: [
              const Icon(Icons.info_outline_rounded, size: 16, color: AppColors.primaryDark),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  AppStrings.isEnglish
                      ? 'Identity: provide your NIN, or upload your ID (front and back). A face photo with your ID helps you get verified.'
                      : 'Utambulisho: weka NIN, au pakia kitambulisho chako (mbele na nyuma). Picha ya uso na kitambulisho inakusaidia kuthibitishwa.',
                  style: const TextStyle(fontSize: 12, color: AppColors.primaryDark, fontWeight: FontWeight.w600),
                ),
              ),
            ],
          ),
        ),

        _buildInputField(
          controller: _ninController,
          label: AppStrings.isEnglish ? 'NIN (NIDA Number)' : 'Namba ya NIDA (NIN)',
          hint: AppStrings.isEnglish ? '20-digit NIN' : 'Tarakimu 20 za NIN',
          icon: Icons.numbers_rounded,
          keyboardType: TextInputType.number,
          maxLength: InputValidation.ninLength,
          formatters: [FilteringTextInputFormatter.digitsOnly],
        ),
        const SizedBox(height: 14),

        // Which ID the person has: NIDA, Voter ID, Driving licence, Passport
        _buildIdKindPicker(),
        const SizedBox(height: 14),

        // ID front (and back when the document has one)
        _buildDocumentUploadCard(
          icon: IdKinds.byId(_idKind).icon,
          title: IdKinds.byId(_idKind).hasBack
              ? '${IdKinds.byId(_idKind).title(AppStrings.isEnglish)} - ${AppStrings.isEnglish ? 'front' : 'mbele'}'
              : '${IdKinds.byId(_idKind).title(AppStrings.isEnglish)} - ${AppStrings.isEnglish ? 'photo page' : 'ukurasa wa picha'}',
          subtitle: AppStrings.isEnglish ? 'Clear photo, all four corners visible' : 'Picha wazi, pembe zote nne zionekane',
          isUploaded: _hasUploadedIdFront,
          busy: _uploadingType == 'id_front',
          buttonText: AppStrings.regUploadPhoto,
          onUpload: () => _pickAndUpload('id_front', () => _hasUploadedIdFront = true),
        ),
        if (IdKinds.byId(_idKind).hasBack) ...[
          const SizedBox(height: 14),
          _buildDocumentUploadCard(
            icon: IdKinds.byId(_idKind).icon,
            title: '${IdKinds.byId(_idKind).title(AppStrings.isEnglish)} - ${AppStrings.isEnglish ? 'back' : 'nyuma'}',
            subtitle: AppStrings.isEnglish ? 'Clear photo, no glare' : 'Picha wazi, bila mng\'ao',
            isUploaded: _hasUploadedIdBack,
            busy: _uploadingType == 'id_back',
            buttonText: AppStrings.regUploadPhoto,
            onUpload: () => _pickAndUpload('id_back', () => _hasUploadedIdBack = true),
          ),
        ],
        const SizedBox(height: 14),

        // Face verification: face next to the ID, taken live
        _buildDocumentUploadCard(
          icon: Icons.face_rounded,
          title: AppStrings.isEnglish ? 'Selfie holding your ID' : 'Picha yako ukishika kitambulisho',
          subtitle: AppStrings.isEnglish ? 'Your face and the ID must both be readable' : 'Uso wako na kitambulisho vionekane vizuri',
          isUploaded: _hasUploadedSelfieId,
          busy: _uploadingType == 'selfie_with_id',
          buttonText: AppStrings.isEnglish ? 'Take selfie' : 'Piga selfie',
          onUpload: () => _pickAndUpload('selfie_with_id', () => _hasUploadedSelfieId = true, cameraOnly: true),
        ),
        const SizedBox(height: 14),

        // Face verification: live face photo
        _buildDocumentUploadCard(
          icon: Icons.face_retouching_natural_rounded,
          title: AppStrings.isEnglish ? 'Face photo' : 'Picha ya uso',
          subtitle: AppStrings.isEnglish ? 'Look at the camera in good light, no hat or sunglasses' : 'Tazama kamera mwangaza mzuri, bila kofia au miwani',
          isUploaded: _hasUploadedFace,
          busy: _uploadingType == 'face_photo',
          buttonText: AppStrings.isEnglish ? 'Take photo' : 'Piga picha',
          onUpload: () => _pickAndUpload('face_photo', () => _hasUploadedFace = true, cameraOnly: true),
        ),
        const SizedBox(height: 14),

        // 2. Business License (Optional)
        _buildDocumentUploadCard(
          icon: Icons.badge_outlined,
          title: AppStrings.regLicenseDocTitle,
          subtitle: AppStrings.regLicenseDocSubtitle,
          isUploaded: _hasUploadedLicense,
          busy: _uploadingType == 'business_license',
          buttonText: AppStrings.regUploadDoc,
          onUpload: () => _pickAndUpload('business_license', () => _hasUploadedLicense = true),
        ),
        const SizedBox(height: 14),

        // 3. Profile Photo
        _buildDocumentUploadCard(
          icon: Icons.account_circle_outlined,
          title: AppStrings.regProfilePhotoTitle,
          subtitle: AppStrings.regProfilePhotoSubtitle,
          isUploaded: _hasUploadedProfilePhoto,
          busy: _uploadingType == 'profile_photo',
          buttonText: AppStrings.regUploadPhoto,
          onUpload: _pickAndUploadProfilePhoto,
        ),
        const SizedBox(height: 20),

        // Safe documents notice banner matching mockup
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppColors.primaryLight,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.primary.withValues(alpha: 0.15)),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.shield_outlined, size: 18, color: AppColors.primary),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  AppStrings.regDocSafeNotice,
                  style: const TextStyle(fontSize: 12, color: AppColors.primaryDark, height: 1.4),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // 4. Registration Payment
  Widget _buildStep4Payment() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          AppStrings.regPaymentTitle,
          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        const SizedBox(height: 4),
        Text(
          AppStrings.regPaymentSubtitle,
          style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
        ),
        const SizedBox(height: 20),

        // Registration Fee Card
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.background,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppColors.border),
          ),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: AppColors.primaryLight,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(Icons.receipt_rounded, color: AppColors.primary, size: 24),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      AppStrings.regFeeLabel,
                      style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontWeight: FontWeight.w500),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'TSh $_registrationFee',
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.successLight,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  AppStrings.regFeeOneTime,
                  style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.successDark),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),

        Text(
          AppStrings.regSelectPaymentMethod,
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
        ),
        const SizedBox(height: 12),

        // Payment methods: Mobile Money, Card, Lipa Kwa Simu
        _buildPaymentOption(
          id: 'mobile_money',
          title: AppStrings.isEnglish ? 'Mobile Money' : 'Pesa za Simu (Mobile Money)',
          subtitle: 'M-Pesa • Airtel Money • Tigo Pesa • Halopesa',
          logoColor: const Color(0xFF16A34A),
          icon: Icons.phone_android_rounded,
        ),
        // Mobile Money: number to pay with
        if (_selectedPaymentMethod == 'mobile_money') ...[
          const SizedBox(height: 12),
          _buildPayPhoneField(),
        ],
        const SizedBox(height: 10),

        _buildPaymentOption(
          id: 'card',
          title: AppStrings.isEnglish ? 'Card' : 'Kadi (Card)',
          subtitle: 'Visa • Mastercard',
          logoColor: const Color(0xFF1D4ED8),
          icon: Icons.credit_card_rounded,
        ),
        if (_selectedPaymentMethod == 'card') ...[
          const SizedBox(height: 10),
          _buildPaymentNote(AppStrings.isEnglish
              ? 'You will pay on a secure card page. We never see or store your card details.'
              : 'Utalipa kwenye ukurasa salama wa kadi. Hatuoni wala kuhifadhi taarifa za kadi yako.'),
        ],
        const SizedBox(height: 10),

        _buildPaymentOption(
          id: 'lipa',
          title: 'Lipa Kwa Simu',
          subtitle: AppStrings.isEnglish ? 'Pay with a Lipa Number' : 'Lipa kwa Namba ya Lipa',
          logoColor: const Color(0xFFEA580C),
          icon: Icons.dialpad_rounded,
        ),
        if (_selectedPaymentMethod == 'lipa') ...[
          const SizedBox(height: 10),
          _buildPaymentNote(AppStrings.isEnglish
              ? 'The Lipa Number and payment steps will be shown after you tap Continue.'
              : 'Namba ya Lipa na hatua za kulipa zitaonyeshwa baada ya kubonyeza Endelea.'),
        ],
        const SizedBox(height: 20),

        // Activation Notice
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppColors.primaryLight,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.primary.withValues(alpha: 0.15)),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.verified_rounded, size: 18, color: AppColors.primary),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  AppStrings.regPaymentActivationNotice,
                  style: const TextStyle(fontSize: 12, color: AppColors.primaryDark, height: 1.4),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // Helper: Document Upload Card
  /// NIDA / Voter ID / Driving licence / Passport. Locked once the front photo
  /// is uploaded so the kind always matches what was sent.
  Widget _buildIdKindPicker() {
    final en = AppStrings.isEnglish;
    final locked = _hasUploadedIdFront || _uploadingType != null;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          en ? 'Which ID will you use?' : 'Utatumia kitambulisho gani?',
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 4,
          children: [
            for (final k in IdKinds.all)
              ChoiceChip(
                label: Text(
                  k.title(en),
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: _idKind == k.id ? Colors.white : AppColors.textPrimary),
                ),
                selected: _idKind == k.id,
                selectedColor: AppColors.primary,
                showCheckmark: false,
                onSelected: locked ? null : (_) => setState(() => _idKind = k.id),
              ),
          ],
        ),
        if (_hasUploadedIdFront)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              en ? 'ID photo added, so the ID type is locked.' : 'Picha ya kitambulisho imewekwa, kwa hiyo aina imefungwa.',
              style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
            ),
          ),
      ],
    );
  }

  Widget _buildDocumentUploadCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool isUploaded,
    required String buttonText,
    required VoidCallback onUpload,
    bool busy = false,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: isUploaded ? AppColors.success : AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: isUploaded ? AppColors.successLight : AppColors.primaryLight,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  isUploaded ? Icons.check_circle_rounded : icon,
                  color: isUploaded ? AppColors.success : AppColors.primary,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      isUploaded ? 'Document Uploaded' : subtitle,
                      style: TextStyle(
                        fontSize: 12,
                        color: isUploaded ? AppColors.successDark : AppColors.textSecondary,
                        fontWeight: isUploaded ? FontWeight.w600 : FontWeight.normal,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 38,
            child: OutlinedButton.icon(
              // One upload at a time; the others wait until this one finishes.
              onPressed: _uploadingType == null ? onUpload : null,
              icon: busy
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.primary),
                    )
                  : Icon(
                      isUploaded ? Icons.check : Icons.file_upload_outlined,
                      size: 16,
                      color: isUploaded ? AppColors.success : AppColors.primary,
                    ),
              label: Text(
                busy
                    ? (AppStrings.isEnglish ? 'Uploading...' : 'Inapakia...')
                    : (isUploaded ? 'Change Document' : buttonText),
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: isUploaded ? AppColors.success : AppColors.primary,
                ),
              ),
              style: OutlinedButton.styleFrom(
                side: BorderSide(
                  color: isUploaded ? AppColors.success : AppColors.primary.withValues(alpha: 0.4),
                ),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Helper: Payment Option Row
  Widget _buildPaymentOption({
    required String id,
    required String title,
    String? subtitle,
    required Color logoColor,
    required IconData icon,
  }) {
    final isSelected = _selectedPaymentMethod == id;

    return InkWell(
      onTap: () => setState(() => _selectedPaymentMethod = id),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? AppColors.primary : AppColors.border,
            width: isSelected ? 1.6 : 1.0,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 22,
              height: 22,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: isSelected ? AppColors.primary : AppColors.border,
                  width: 2,
                ),
              ),
              child: isSelected
                  ? Center(
                      child: Container(
                        width: 10,
                        height: 10,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: AppColors.primary,
                        ),
                      ),
                    )
                  : null,
            ),
            const SizedBox(width: 14),
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: logoColor.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: logoColor, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                  ),
                  if (subtitle != null) ...[
                    const SizedBox(height: 2),
                    Text(subtitle, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Helper: mobile number to pay with (Mobile Money)
  Widget _buildPayPhoneField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          AppStrings.isEnglish ? 'Mobile Number to Pay' : 'Namba ya Simu ya Kulipia',
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
        ),
        const SizedBox(height: 6),
        TextField(
          controller: _payPhoneController,
          keyboardType: TextInputType.phone,
          inputFormatters: [
            FilteringTextInputFormatter.allow(RegExp(r'[0-9+ ]')),
            LengthLimitingTextInputFormatter(18),
          ],
          decoration: InputDecoration(
            hintText: '712 345 678',
            hintStyle: const TextStyle(fontSize: 13, color: AppColors.textMuted),
            prefixIcon: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(width: 12),
                const Icon(Icons.phone_outlined, size: 18, color: AppColors.textSecondary),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: AppColors.background,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: const Text('🇹🇿 +255', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                ),
                const SizedBox(width: 8),
                Container(height: 18, width: 1, color: AppColors.border),
                const SizedBox(width: 8),
              ],
            ),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            isDense: true,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          AppStrings.isEnglish
              ? 'You will get a payment prompt on this number (M-Pesa, Airtel Money, Tigo Pesa or Halopesa).'
              : 'Utapokea ombi la malipo kwenye namba hii (M-Pesa, Airtel Money, Tigo Pesa au Halopesa).',
          style: const TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.4),
        ),
      ],
    );
  }

  // Helper: small info note under a payment method
  Widget _buildPaymentNote(String text) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.background,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.info_outline_rounded, size: 16, color: AppColors.textSecondary),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, height: 1.4))),
        ],
      ),
    );
  }

  // Helper: Input field
  Widget _buildInputField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
    int maxLength = 120,
    List<TextInputFormatter>? formatters,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
        const SizedBox(height: 6),
        TextField(
          controller: controller,
          keyboardType: keyboardType,
          inputFormatters: [...?formatters, LengthLimitingTextInputFormatter(maxLength)],
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: const TextStyle(fontSize: 13, color: AppColors.textMuted),
            prefixIcon: Icon(icon, size: 18, color: AppColors.textSecondary),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            isDense: true,
          ),
        ),
      ],
    );
  }

  // Helper: Phone field with +255 flag
  Widget _buildPhoneField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(AppStrings.authPhoneLabel, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
        const SizedBox(height: 6),
        TextField(
          controller: _phoneController,
          keyboardType: TextInputType.phone,
          inputFormatters: [
            FilteringTextInputFormatter.allow(RegExp(r'[0-9+ ]')),
            LengthLimitingTextInputFormatter(18),
          ],
          decoration: InputDecoration(
            hintText: '678 364 343',
            hintStyle: const TextStyle(fontSize: 13, color: AppColors.textMuted),
            prefixIcon: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(width: 12),
                const Icon(Icons.phone_outlined, size: 18, color: AppColors.textSecondary),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: AppColors.background,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: const Text('🇹🇿 +255', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                ),
                const SizedBox(width: 8),
                Container(height: 18, width: 1, color: AppColors.border),
                const SizedBox(width: 8),
              ],
            ),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            isDense: true,
          ),
        ),
      ],
    );
  }

  // Helper: Password field with visibility toggle
  Widget _buildPasswordField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(AppStrings.authPasswordLabel, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
        const SizedBox(height: 6),
        TextField(
          controller: _passwordController,
          obscureText: !_isPasswordVisible,
          enableSuggestions: false,
          autocorrect: false,
          inputFormatters: [LengthLimitingTextInputFormatter(InputValidation.passwordMax)],
          autofillHints: const [AutofillHints.newPassword],
          decoration: InputDecoration(
            hintText: AppStrings.authPasswordHint,
            hintStyle: const TextStyle(fontSize: 13, color: AppColors.textMuted),
            prefixIcon: const Icon(Icons.lock_outline_rounded, size: 18, color: AppColors.textSecondary),
            suffixIcon: IconButton(
              icon: Icon(
                _isPasswordVisible ? Icons.visibility_rounded : Icons.visibility_off_rounded,
                size: 18,
                color: AppColors.textSecondary,
              ),
              onPressed: () => setState(() => _isPasswordVisible = !_isPasswordVisible),
            ),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            isDense: true,
          ),
        ),
      ],
    );
  }
}

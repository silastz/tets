import 'package:flutter/foundation.dart';
import 'package:permission_handler/permission_handler.dart';

/// Requests the real OS permission dialogs used by the first-launch prompt.
class PermissionService {
  /// Asks for location (while in use). Returns true when granted.
  static Future<bool> requestLocation() async {
    try {
      final status = await Permission.locationWhenInUse.request();
      return status.isGranted || status.isLimited;
    } catch (_) {
      return false;
    }
  }

  /// Asks for notifications (Android 13+ and iOS). Returns true when granted.
  static Future<bool> requestNotifications() async {
    try {
      final status = await Permission.notification.request();
      return status.isGranted || status.isProvisional;
    } catch (_) {
      return false;
    }
  }

  /// True when both location and notifications are already allowed.
  static Future<bool> allGranted() async {
    try {
      final loc = await Permission.locationWhenInUse.status;
      final notif = await Permission.notification.status;
      return (loc.isGranted || loc.isLimited) && (notif.isGranted || notif.isProvisional);
    } catch (_) {
      return false;
    }
  }

  /// True when the OS will no longer show its dialog for one of them
  /// (user denied "don't ask again"), so only the app settings can change it.
  static Future<bool> needsSettings() async {
    try {
      final loc = await Permission.locationWhenInUse.status;
      final notif = await Permission.notification.status;
      return loc.isPermanentlyDenied || notif.isPermanentlyDenied;
    } catch (_) {
      return false;
    }
  }

  /// Opens the app settings page (for users who permanently denied a permission).
  static Future<void> openSettings() async {
    await openAppSettings();
  }
}

enum MediaAccess { granted, denied, permanentlyDenied }

/// Camera / gallery / storage permissions for photo and video uploads.
/// Shows the real OS dialog when the permission has not been allowed yet.
class MediaPermissions {
  static bool _ok(PermissionStatus s) => s.isGranted || s.isLimited;

  static Future<MediaAccess> _result(Iterable<PermissionStatus> statuses) async {
    if (statuses.any(_ok)) return MediaAccess.granted;
    if (statuses.any((s) => s.isPermanentlyDenied || s.isRestricted)) return MediaAccess.permanentlyDenied;
    return MediaAccess.denied;
  }

  /// Camera (and the microphone when recording a video).
  static Future<MediaAccess> camera({bool recordVideo = false}) async {
    if (kIsWeb) return MediaAccess.granted; // the browser asks by itself
    try {
      final cam = await Permission.camera.request();
      if (!_ok(cam)) return _result([cam]);
      if (recordVideo) {
        final mic = await Permission.microphone.request();
        if (!_ok(mic)) return _result([mic]);
      }
      return MediaAccess.granted;
    } catch (_) {
      return MediaAccess.denied;
    }
  }

  /// Gallery / storage. Android 13+ uses READ_MEDIA_IMAGES / READ_MEDIA_VIDEO,
  /// Android 12 and below use the legacy storage permission, iOS uses Photos.
  static Future<MediaAccess> library({bool video = false}) async {
    if (kIsWeb) return MediaAccess.granted;
    try {
      if (defaultTargetPlatform == TargetPlatform.android) {
        final primary = video ? Permission.videos : Permission.photos;
        var s = await primary.status;
        if (_ok(s)) return MediaAccess.granted;
        s = await primary.request();
        if (_ok(s)) return MediaAccess.granted;
        // Older Android versions don't know READ_MEDIA_*: fall back to storage.
        final legacy = await Permission.storage.request();
        if (_ok(legacy)) return MediaAccess.granted;
        return _result([s, legacy]);
      }
      final s = await Permission.photos.request();
      return _result([s]);
    } catch (_) {
      return MediaAccess.denied;
    }
  }
}

import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/material.dart';
import 'package:jamiiapp/models/models.dart';
import 'package:jamiiapp/models/service_filters.dart';
import 'package:jamiiapp/models/service_search.dart';

ServiceItem _s(String id, {double? km, String? city}) => ServiceItem(
      id: id,
      title: id,
      subtitle: '',
      distance: city ?? '',
      rating: 4,
      reviewsCount: 1,
      priceText: 'TSh 1',
      isSponsored: false,
      themeColor: Colors.blue,
      icon: Icons.home,
      distanceKm: km,
      city: city,
    );

void main() {
  test('category word becomes a category search', () {
    expect(ServiceCategories.resolve('Plumber', null).category, 'Plumbing');
    expect(ServiceCategories.resolve('Plumber', null).query, isNull);
    expect(ServiceCategories.resolve('kinyozi', null).category, 'Barber');
    final r = ServiceCategories.resolve('bridal makeup', null);
    expect(r.category, isNull);
    expect(r.query, 'bridal makeup');
    expect(ServiceCategories.resolve('hair', 'Barber').category, 'Barber');
  });

  test('split by radius, falling back to city when distance unknown', () {
    final r = ServiceSearch.split(
      [_s('a', km: 3), _s('b', km: 80), _s('c', city: 'Arusha'), _s('d', city: 'Dar es Salaam')],
      radiusKm: 10,
      userCity: 'Dar es Salaam',
    );
    expect(r.nearby.map((e) => e.id), ['a', 'd']);
    expect(r.elsewhere.map((e) => e.id), ['b', 'c']);
  });

  test('distance filter is dropped so far results stay as "elsewhere"', () {
    const f = ServiceFilters(maxDistanceKm: 5, minRating: 3);
    final out = f.withoutDistance().apply([_s('a', km: 2), _s('b', km: 500)]);
    expect(out.length, 2);
  });
}

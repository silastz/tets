import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import 'package:url_launcher/url_launcher.dart';

import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/gps_service.dart';

/// Live map tracking: shows the user's position, the provider/booking location,
/// the route between them, distance and an estimated travel time.
///
/// Uses OpenStreetMap tiles (no API key). The route comes from the public OSRM
/// service and falls back to a straight line when offline / unavailable.
class MapTrackingScreen extends StatefulWidget {
  final String providerName;
  final String serviceTitle;
  final String address;
  final double? providerLat;
  final double? providerLng;

  const MapTrackingScreen({
    super.key,
    required this.providerName,
    required this.serviceTitle,
    required this.address,
    this.providerLat,
    this.providerLng,
  });

  @override
  State<MapTrackingScreen> createState() => _MapTrackingScreenState();
}

class _MapTrackingScreenState extends State<MapTrackingScreen> {
  // Dar es Salaam city centre, used only when no coordinates are known at all.
  static const LatLng _fallbackCenter = LatLng(-6.7924, 39.2083);

  final MapController _mapController = MapController();
  StreamSubscription<Position>? _posSub;

  LatLng? _me;
  List<LatLng> _route = const [];
  double? _routeKm;
  double? _routeMinutes;
  bool _loadingRoute = false;
  bool _locationDenied = false;
  bool _followMe = false;
  LatLng? _lastRouteFrom;

  bool get _isEn => AppStrings.isEnglish;

  LatLng? get _provider => (widget.providerLat != null && widget.providerLng != null)
      ? LatLng(widget.providerLat!, widget.providerLng!)
      : null;

  @override
  void initState() {
    super.initState();
    if (GpsService.hasFix) _me = LatLng(GpsService.lat!, GpsService.lng!);
    _startTracking();
  }

  @override
  void dispose() {
    _posSub?.cancel();
    super.dispose();
  }

  Future<void> _startTracking() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        if (mounted) setState(() => _locationDenied = true);
        return;
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        if (mounted) setState(() => _locationDenied = true);
        return;
      }

      _posSub = Geolocator.getPositionStream(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          distanceFilter: 15, // metres between updates
        ),
      ).listen(_onPosition, onError: (_) {});

      final first = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 12),
        ),
      );
      _onPosition(first);
    } catch (_) {
      // keep whatever fix we already have
    }
  }

  void _onPosition(Position p) {
    if (!mounted) return;
    final here = LatLng(p.latitude, p.longitude);
    setState(() {
      _me = here;
      _locationDenied = false;
    });
    if (_followMe) _mapController.move(here, _mapController.camera.zoom);
    _maybeRefreshRoute(here);
  }

  void _maybeRefreshRoute(LatLng from) {
    final to = _provider;
    if (to == null) return;
    final last = _lastRouteFrom;
    // Re-route only after moving ~100 m (or on the first fix).
    if (last != null && const Distance().as(LengthUnit.Meter, last, from) < 100) return;
    _lastRouteFrom = from;
    _fetchRoute(from, to);
  }

  Future<void> _fetchRoute(LatLng from, LatLng to) async {
    setState(() => _loadingRoute = true);
    final straightKm = const Distance().as(LengthUnit.Kilometer, from, to).toDouble();
    try {
      final uri = Uri.parse(
        'https://router.project-osrm.org/route/v1/driving/'
        '${from.longitude},${from.latitude};${to.longitude},${to.latitude}'
        '?overview=full&geometries=geojson',
      );
      final res = await http.get(uri).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = json.decode(res.body) as Map<String, dynamic>;
        final routes = data['routes'] as List?;
        if (routes != null && routes.isNotEmpty) {
          final r = routes.first as Map<String, dynamic>;
          final coords = (r['geometry']['coordinates'] as List)
              .map((c) => LatLng((c[1] as num).toDouble(), (c[0] as num).toDouble()))
              .toList();
          if (!mounted) return;
          setState(() {
            _route = coords;
            _routeKm = ((r['distance'] as num).toDouble()) / 1000.0;
            _routeMinutes = ((r['duration'] as num).toDouble()) / 60.0;
            _loadingRoute = false;
          });
          _fitBounds();
          return;
        }
      }
    } catch (_) {
      // fall through to straight line
    }
    if (!mounted) return;
    setState(() {
      _route = [from, to];
      _routeKm = straightKm;
      _routeMinutes = straightKm / 30 * 60; // rough 30 km/h city average
      _loadingRoute = false;
    });
    _fitBounds();
  }

  void _fitBounds() {
    final me = _me;
    final to = _provider;
    if (me == null || to == null) return;
    try {
      _mapController.fitCamera(
        CameraFit.bounds(
          bounds: LatLngBounds.fromPoints([me, to]),
          padding: const EdgeInsets.fromLTRB(48, 80, 48, 260),
          maxZoom: 17,
        ),
      );
    } catch (_) {}
  }

  void _recenter() {
    final me = _me;
    if (me == null) return;
    setState(() => _followMe = true);
    _mapController.move(me, 16);
  }

  Future<void> _openExternalMaps() async {
    final to = _provider;
    final Uri uri;
    if (to != null) {
      uri = Uri.parse(
        'https://www.google.com/maps/dir/?api=1&destination=${to.latitude},${to.longitude}&travelmode=driving',
      );
    } else {
      uri = Uri.parse(
        'https://www.google.com/maps/search/?api=1&query=${Uri.encodeComponent(widget.address)}',
      );
    }
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  String _fmtDistance(double km) =>
      km < 1 ? '${(km * 1000).round()} m' : '${km.toStringAsFixed(1)} km';

  String _fmtDuration(double min) {
    if (min < 1) return _isEn ? '< 1 min' : 'Chini ya dak 1';
    if (min < 60) return '${min.round()} ${_isEn ? 'min' : 'dak'}';
    final h = min ~/ 60;
    final m = (min % 60).round();
    return '$h h $m ${_isEn ? 'min' : 'dak'}';
  }

  @override
  Widget build(BuildContext context) {
    final provider = _provider;
    final center = provider ?? _me ?? _fallbackCenter;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        children: [
          FlutterMap(
            mapController: _mapController,
            options: MapOptions(
              initialCenter: center,
              initialZoom: 14,
              minZoom: 3,
              maxZoom: 19,
              onPositionChanged: (_, hasGesture) {
                if (hasGesture && _followMe) setState(() => _followMe = false);
              },
              onMapReady: _fitBounds,
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.example.jamiiapp',
              ),
              if (_route.length >= 2)
                PolylineLayer(
                  polylines: [
                    Polyline(
                      points: _route,
                      strokeWidth: 5,
                      color: AppColors.primary,
                      borderStrokeWidth: 2,
                      borderColor: Colors.white,
                    ),
                  ],
                ),
              MarkerLayer(
                markers: [
                  if (provider != null)
                    Marker(
                      point: provider,
                      width: 48,
                      height: 56,
                      alignment: Alignment.topCenter,
                      child: const Icon(Icons.location_on_rounded, size: 48, color: AppColors.danger),
                    ),
                  if (_me != null)
                    Marker(
                      point: _me!,
                      width: 28,
                      height: 28,
                      child: Container(
                        decoration: BoxDecoration(
                          color: AppColors.primary,
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 3),
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.primary.withValues(alpha: 0.35),
                              blurRadius: 10,
                              spreadRadius: 4,
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
              const SimpleAttributionWidget(
                source: Text('© OpenStreetMap contributors'),
              ),
            ],
          ),

          // Top bar
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
              child: Row(
                children: [
                  _roundButton(Icons.arrow_back_rounded, () => Navigator.pop(context)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(
                        color: AppColors.surface,
                        borderRadius: BorderRadius.circular(14),
                        boxShadow: _shadow,
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.map_rounded, size: 18, color: AppColors.primary),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              _isEn ? 'Map Tracking' : 'Ufuatiliaji wa Ramani',
                              style: const TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w800,
                                color: AppColors.textPrimary,
                              ),
                            ),
                          ),
                          if (_loadingRoute)
                            const SizedBox(
                              width: 14,
                              height: 14,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Recenter / fit buttons
          Positioned(
            right: 12,
            bottom: 250,
            child: Column(
              children: [
                _roundButton(Icons.alt_route_rounded, _fitBounds),
                const SizedBox(height: 10),
                _roundButton(
                  _followMe ? Icons.my_location_rounded : Icons.location_searching_rounded,
                  _recenter,
                  active: _followMe,
                ),
              ],
            ),
          ),

          // Bottom info card
          Positioned(left: 0, right: 0, bottom: 0, child: _buildInfoCard(provider)),
        ],
      ),
    );
  }

  Widget _buildInfoCard(LatLng? provider) {
    return Container(
      padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).padding.bottom),
      decoration: const BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
        boxShadow: [BoxShadow(color: Color(0x1F000000), blurRadius: 16, offset: Offset(0, -4))],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: const BoxDecoration(color: AppColors.primaryLight, shape: BoxShape.circle),
                child: const Icon(Icons.storefront_rounded, color: AppColors.primary, size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.providerName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    Text(
                      widget.serviceTitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              _stat(
                Icons.straighten_rounded,
                _isEn ? 'Distance' : 'Umbali',
                _routeKm != null ? _fmtDistance(_routeKm!) : '--',
              ),
              const SizedBox(width: 10),
              _stat(
                Icons.timer_outlined,
                _isEn ? 'ETA' : 'Muda',
                _routeMinutes != null ? _fmtDuration(_routeMinutes!) : '--',
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              const Icon(Icons.location_on_outlined, size: 16, color: AppColors.textSecondary),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  widget.address,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                ),
              ),
            ],
          ),
          if (provider == null) ...[
            const SizedBox(height: 10),
            _notice(
              _isEn
                  ? 'Exact provider location is not available yet. Use "Open in Maps" to search the address.'
                  : 'Eneo kamili la mtoa huduma bado halipatikani. Tumia "Fungua Ramani" kutafuta anwani.',
            ),
          ],
          if (_locationDenied) ...[
            const SizedBox(height: 10),
            _notice(
              _isEn
                  ? 'Turn on location to see your position and the route.'
                  : 'Washa eneo (location) ili uone nafasi yako na njia.',
              action: _isEn ? 'Enable' : 'Washa',
              onAction: () async {
                await Geolocator.openLocationSettings();
                _startTracking();
              },
            ),
          ],
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _openExternalMaps,
              icon: const Icon(Icons.navigation_rounded, size: 18),
              label: Text(
                _isEn ? 'Open in Maps' : 'Fungua Ramani',
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                foregroundColor: Colors.white,
                elevation: 0,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _stat(IconData icon, String label, String value) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: AppColors.background,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            Icon(icon, size: 18, color: AppColors.primary),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    color: AppColors.textPrimary,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _notice(String text, {String? action, VoidCallback? onAction}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.warningLight,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          const Icon(Icons.info_outline_rounded, size: 16, color: AppColors.warningDark),
          const SizedBox(width: 8),
          Expanded(
            child: Text(text, style: const TextStyle(fontSize: 12, color: AppColors.warningDark)),
          ),
          if (action != null)
            TextButton(
              onPressed: onAction,
              style: TextButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                minimumSize: const Size(0, 30),
              ),
              child: Text(action, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
            ),
        ],
      ),
    );
  }

  Widget _roundButton(IconData icon, VoidCallback onTap, {bool active = false}) {
    return Material(
      color: active ? AppColors.primary : AppColors.surface,
      shape: const CircleBorder(),
      elevation: 3,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(11),
          child: Icon(icon, size: 22, color: active ? Colors.white : AppColors.textPrimary),
        ),
      ),
    );
  }

  static const List<BoxShadow> _shadow = [
    BoxShadow(color: Color(0x1A000000), blurRadius: 10, offset: Offset(0, 3)),
  ];
}

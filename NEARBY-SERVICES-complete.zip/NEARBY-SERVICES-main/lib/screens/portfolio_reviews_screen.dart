import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

class PortfolioReviewsScreen extends StatefulWidget {
  final String providerName;
  const PortfolioReviewsScreen({
    super.key,
    this.providerName = 'Zeen Spa & Wellness',
  });

  @override
  State<PortfolioReviewsScreen> createState() => _PortfolioReviewsScreenState();
}

class _PortfolioReviewsScreenState extends State<PortfolioReviewsScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  final List<String> _portfolioImages = [
    'assets/images/banner.jpg',
    'assets/images/provider1.jpg',
    'assets/images/provider2.jpg',
    'assets/images/zeen_cover.jpg',
  ];

  final List<Map<String, dynamic>> _reviews = [
    {
      'name': 'Neema J.',
      'rating': 5.0,
      'date': 'Sep 20, 2025',
      'comment': 'Huduma ilikuwa nzuri na ya haraka. Asante sana!',
      'avatar': 'assets/images/provider1.jpg',
    },
    {
      'name': 'Fatuma S.',
      'rating': 4.8,
      'date': 'Sep 15, 2025',
      'comment': 'Mtaalamu sana, nakundhika kabisa.',
      'avatar': 'assets/images/zeen_avatar.jpg',
    },
    {
      'name': 'David M.',
      'rating': 5.0,
      'date': 'Sep 10, 2025',
      'comment': 'Professional service, will definitely book again!',
      'avatar': 'assets/images/provider2.jpg',
    },
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Portfolio & Reviews',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(48),
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                decoration: BoxDecoration(
                  color: AppColors.borderLight,
                  borderRadius: BorderRadius.circular(25),
                ),
                child: TabBar(
                  controller: _tabController,
                  indicator: BoxDecoration(
                    borderRadius: BorderRadius.circular(25),
                    color: AppColors.primary,
                  ),
                  labelColor: Colors.white,
                  unselectedLabelColor: AppColors.textSecondary,
                  labelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
                  dividerColor: Colors.transparent,
                  indicatorSize: TabBarIndicatorSize.tab,
                  tabs: const [
                    Tab(text: 'Portfolio'),
                    Tab(text: 'Reviews'),
                  ],
                ),
              ),
              const Divider(height: 1, color: AppColors.borderLight),
            ],
          ),
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // 1. Portfolio View matching Screen 8
          SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Top Banner Image & Small Grid
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      flex: 3,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(14),
                        child: Image.asset(
                          _portfolioImages[0],
                          height: 160,
                          fit: BoxFit.cover,
                          errorBuilder: (ctx, err, stack) => Container(
                            height: 160,
                            color: AppColors.borderLight,
                            child: const Icon(Icons.spa_rounded, color: AppColors.textMuted),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      flex: 2,
                      child: Column(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Image.asset(
                              _portfolioImages[1],
                              height: 76,
                              width: double.infinity,
                              fit: BoxFit.cover,
                              errorBuilder: (ctx, err, stack) => Container(height: 76, color: AppColors.borderLight),
                            ),
                          ),
                          const SizedBox(height: 8),
                          Stack(
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Image.asset(
                                  _portfolioImages[2],
                                  height: 76,
                                  width: double.infinity,
                                  fit: BoxFit.cover,
                                  errorBuilder: (ctx, err, stack) => Container(height: 76, color: AppColors.borderLight),
                                ),
                              ),
                              Positioned.fill(
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Colors.black.withValues(alpha: 0.5),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  alignment: Alignment.center,
                                  child: const Text(
                                    '+12',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),

                // Reviews Section Header in Portfolio Tab (Matches Screen 8)
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Reviews (124)',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    GestureDetector(
                      onTap: () => _tabController.animateTo(1),
                      child: const Text(
                        'See All',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: AppColors.primary,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                // Review Cards
                ..._reviews.map((r) => _buildReviewCard(r)),
              ],
            ),
          ),

          // 2. Reviews View
          ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: _reviews.length,
            separatorBuilder: (_, _) => const SizedBox(height: 12),
            itemBuilder: (context, index) {
              return _buildReviewCard(_reviews[index]);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildReviewCard(Map<String, dynamic> r) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 18,
                backgroundImage: AssetImage(r['avatar'] as String),
                backgroundColor: AppColors.borderLight,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      r['name'] as String,
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        ...List.generate(
                          5,
                          (i) => const Icon(Icons.star_rounded, size: 14, color: AppColors.goldStar),
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '${r['rating']}',
                          style: const TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            color: AppColors.textPrimary,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Text(
                r['date'] as String,
                style: const TextStyle(fontSize: 11, color: AppColors.textMuted),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            r['comment'] as String,
            style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textSecondary),
          ),
        ],
      ),
    );
  }
}

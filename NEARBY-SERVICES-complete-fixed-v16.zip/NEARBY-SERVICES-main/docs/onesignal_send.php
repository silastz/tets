<?php
/**
 * OneSignal sender for AUTO notifications (run on your server / backend).
 * Keep the REST API key here - never inside the mobile app.
 *
 * OneSignal dashboard -> Settings -> Keys & IDs: App ID + REST API Key.
 * MANUAL notifications need no code: Dashboard -> Messages -> New Push.
 */

const ONESIGNAL_APP_ID  = 'YOUR_ONESIGNAL_APP_ID';
const ONESIGNAL_API_KEY = 'YOUR_ONESIGNAL_REST_API_KEY';

function onesignal_send(array $target, string $title, string $message, array $data = []): array
{
    $payload = array_merge([
        'app_id'         => ONESIGNAL_APP_ID,
        'target_channel' => 'push',
        'headings'       => ['en' => $title, 'sw' => $title],
        'contents'       => ['en' => $message, 'sw' => $message],
        'data'           => $data,   // arrives in the app as additionalData
    ], $target);

    $ch = curl_init('https://api.onesignal.com/notifications?c=push');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json; charset=utf-8',
            'Authorization: Key ' . ONESIGNAL_API_KEY,
        ],
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_TIMEOUT        => 15,
    ]);
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return ['status' => $code, 'response' => json_decode((string)$body, true)];
}

/** One or more users (the app login() uses the app user id as external id). */
function notify_users(array $userIds, string $title, string $message, array $data = []): array
{
    return onesignal_send(
        ['include_aliases' => ['external_id' => array_map('strval', $userIds)]],
        $title, $message, $data
    );
}

/** Everyone who is subscribed. */
function notify_all(string $title, string $message, array $data = []): array
{
    return onesignal_send(['included_segments' => ['Subscribed Users']], $title, $message, $data);
}

/** Everyone with a tag, e.g. all sellers in Dar es Salaam. */
function notify_by_tag(string $key, string $value, string $title, string $message, array $data = []): array
{
    return onesignal_send(
        ['filters' => [['field' => 'tag', 'key' => $key, 'relation' => '=', 'value' => $value]]],
        $title, $message, $data
    );
}

/* ---- Examples (call these from your booking / payment / chat code) ----
notify_users([42], 'Ombi jipya', 'Una ombi jipya la huduma', ['type' => 'booking', 'id' => 12]);
notify_all('Karibu!', 'Huduma mpya karibu nawe');
notify_by_tag('role', 'ROLE_SELLER', 'Taarifa', 'Sasisha huduma zako leo');
notify_by_tag('city', 'Dar es Salaam', 'Offer', 'Punguzo la wiki hii');
*/

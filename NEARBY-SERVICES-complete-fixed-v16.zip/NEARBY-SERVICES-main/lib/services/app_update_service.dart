import 'dart:async';
import 'dart:convert';
import 'dart:io' show Platform;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../security/secure_http.dart';
import '../security/security_config.dart';
import '../widgets/update_dialog.dart';

/// What the backend says about the current app release.
/// See docs/app_version_api_contract.md.
class AppVersionInfo {
  final String latest; // newest released version, e.g. "1.2.0"
  final String? minSupported; // anything older must update
  final bool force; // backend switch: everyone must update now
  final String? storeUrl;
  final String? messageEn;
  final String? messageSw;

  const AppVersionInfo({
    required this.latest,
    this.minSupported,
    this.force = false,
    this.storeUrl,
    this.messageEn,
    this.messageSw,
  });

  static AppVersionInfo? fromJson(dynamic j) {
    if (j is! Map) return null;
    final d = j['data'] is Map ? j['data'] as Map : j; // accept {data:{...}} or {...}
    String? str(String k) {
      final v = d[k];
      return v == null || v.toString().trim().isEmpty ? null : v.toString().trim();
    }

    final latest = str('latestVersion');
    if (latest == null) return null;
    return AppVersionInfo(
      latest: latest,
      minSupported: str('minVersion'),
      force: d['forceUpdate'] == true,
      storeUrl: str('storeUrl'),
      messageEn: str('messageEn'),
      messageSw: str('messageSw'),
    );
  }
}

/// Shows an "Update available" dialog when the backend's app version is newer
/// than the installed one. Checks at start-up and every time the app returns to
/// the foreground (at most once every [_minGap]).
///
/// - Optional update: "Update" / "Later". "Later" is remembered for that version,
///   so the user is asked again only when the backend publishes a newer one.
/// - Required update (installed < minVersion, or forceUpdate = true): the dialog
///   cannot be closed and the back button is blocked.
class AppUpdateService with WidgetsBindingObserver {
  AppUpdateService._();
  static final AppUpdateService _i = AppUpdateService._();

  static const String _androidStore = 'https://play.google.com/store/apps/details?id=com.unganalink.app';
  static const String _skipKey = 'update_skipped_version';
  static const Duration _minGap = Duration(minutes: 30);

  static GlobalKey<NavigatorState>? _navKey;
  static DateTime? _lastCheck;
  static bool _showing = false;
  static bool _started = false;

  /// Call once after runApp.
  static void start(GlobalKey<NavigatorState> navKey) {
    _navKey = navKey;
    if (_started) return;
    _started = true;
    WidgetsBinding.instance.addObserver(_i);
    Future.delayed(const Duration(seconds: 2), check); // let the first screen settle
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) check();
  }

  // ---- version maths (pure, unit-tested) ----

  /// Compares dotted versions: 1 if a > b, -1 if a < b, 0 if equal.
  /// Ignores a "+build" or "-tag" suffix and a leading "v"; missing parts count as 0.
  static int compareVersions(String a, String b) {
    List<int> parts(String v) {
      final core = v.trim().replaceFirst(RegExp(r'^[vV]'), '').split(RegExp(r'[+\-]')).first;
      return core.split('.').map((e) => int.tryParse(e.trim()) ?? 0).toList();
    }

    final x = parts(a), y = parts(b);
    final n = x.length > y.length ? x.length : y.length;
    for (var i = 0; i < n; i++) {
      final p = i < x.length ? x[i] : 0;
      final q = i < y.length ? y[i] : 0;
      if (p != q) return p > q ? 1 : -1;
    }
    return 0;
  }

  /// null = no dialog; otherwise whether the update is required.
  @visibleForTesting
  static bool? decide({required String installed, required AppVersionInfo info, String? skipped}) {
    final newer = compareVersions(info.latest, installed) > 0;
    final belowMin = info.minSupported != null && compareVersions(installed, info.minSupported!) < 0;
    if (belowMin || (info.force && newer)) return true;
    if (!newer) return null;
    if (skipped != null && compareVersions(skipped, info.latest) >= 0) return null; // user said "Later" to this one
    return false;
  }

  // ---- network + dialog ----

  static Future<AppVersionInfo?> _fetch() async {
    final platform = kIsWeb ? 'web' : (Platform.isIOS ? 'ios' : 'android');
    try {
      final res = await SecureHttp.client
          .get(Uri.parse('${SecurityConfig.apiBase}/app/version?platform=$platform'))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode != 200) return null;
      return AppVersionInfo.fromJson(jsonDecode(res.body));
    } catch (_) {
      return null; // offline or endpoint missing: never bother the user
    }
  }

  /// Checks the backend and shows the dialog if needed. Safe to call any time.
  static Future<void> check({bool force = false}) async {
    if (_showing || kIsWeb) return;
    final now = DateTime.now();
    if (!force && _lastCheck != null && now.difference(_lastCheck!) < _minGap) return;
    _lastCheck = now;

    final info = await _fetch();
    if (info == null) return;
    final installed = (await PackageInfo.fromPlatform()).version;
    final prefs = await SharedPreferences.getInstance();
    final mustUpdate = decide(installed: installed, info: info, skipped: prefs.getString(_skipKey));
    if (mustUpdate == null) return;

    final ctx = _navKey?.currentContext;
    if (ctx == null || !ctx.mounted || _showing) return;
    _showing = true;
    try {
      final choice = await UpdateDialog.show(
        ctx,
        installed: installed,
        latest: info.latest,
        mustUpdate: mustUpdate,
        messageEn: info.messageEn,
        messageSw: info.messageSw,
      );
      if (choice == UpdateChoice.update) {
        await _openStore(info.storeUrl);
        if (mustUpdate) _lastCheck = null; // still outdated when they come back: ask again
      } else if (choice == UpdateChoice.later) {
        await prefs.setString(_skipKey, info.latest);
      }
    } finally {
      _showing = false;
    }
  }

  static Future<void> _openStore(String? url) async {
    final target = (url != null && url.startsWith('https://')) ? url : _androidStore;
    try {
      await launchUrl(Uri.parse(target), mode: LaunchMode.externalApplication);
    } catch (_) {}
  }
}

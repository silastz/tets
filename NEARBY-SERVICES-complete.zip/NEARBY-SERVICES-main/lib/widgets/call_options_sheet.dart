import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/models.dart';
import '../services/call_service.dart';

/// Pop-up with the call choices:
///  - In-app audio call (only when the provider is online)
///  - In-app video call (only when the provider is online and contacts are unlocked)
///  - Mobile call, with the number shown on the button (only when unlocked)
class CallOptionsSheet extends StatelessWidget {
  final ServiceItem service;

  const CallOptionsSheet({super.key, required this.service});

  static Future<void> show(BuildContext context, ServiceItem service) {
    return showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => CallOptionsSheet(service: service),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isEn = AppStrings.isEnglish;
    final locked = service.isContactLocked;
    final online = service.isOnline;
    final phone = (service.phone ?? '').trim();
    final showMobile = !locked && phone.isNotEmpty;
    // WhatsApp falls back to the phone number (which may come from the provider's profile).
    final wa = (service.whatsappPhone ?? '').trim().isNotEmpty ? service.whatsappPhone!.trim() : phone;
    final showWhatsApp = !locked && wa.isNotEmpty;
    final navQuery = [service.stageName, service.city ?? ''].where((e) => e.trim().isNotEmpty).join(', ');
    final showNavigate = !locked && (service.latitude != null || (service.city ?? '').trim().isNotEmpty);

    void run(Future<void> Function() action) {
      final nav = Navigator.of(context);
      nav.pop();
      action();
    }

    // Use the root context so snackbars/login still work after the sheet closes.
    final rootContext = Navigator.of(context, rootNavigator: true).context;

    return Container(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 24),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              locked ? '${isEn ? 'Call' : 'Piga simu kwa'} ${service.stageName}' : '${isEn ? 'Contact' : 'Wasiliana na'} ${service.stageName}',
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
            ),
            const SizedBox(height: 16),

            if (online)
            _option(
              icon: Icons.call_rounded,
              color: AppColors.primary,
              title: isEn ? 'In-app Audio Call' : 'Simu ya Sauti (ndani ya app)',
              subtitle: isEn ? 'Free voice call over the internet' : 'Simu ya sauti kupitia intaneti',
              onTap: () => run(() => CallService.inAppCall(
                    rootContext,
                    recipientId: service.sellerId,
                    name: service.stageName,
                    video: false,
                  )),
            ),

            if (online && !locked) ...[
              const SizedBox(height: 10),
              _option(
                icon: Icons.videocam_rounded,
                color: const Color(0xFF7C3AED),
                title: isEn ? 'In-app Video Call' : 'Simu ya Video (ndani ya app)',
                subtitle: isEn ? 'Face-to-face over the internet' : 'Ona uso kwa uso kupitia intaneti',
                onTap: () => run(() => CallService.inAppCall(
                      rootContext,
                      recipientId: service.sellerId,
                      name: service.stageName,
                      video: true,
                    )),
              ),
            ],

            if (showMobile) ...[
              if (online) const SizedBox(height: 10),
              _option(
                icon: Icons.phone_android_rounded,
                color: AppColors.success,
                title: isEn ? 'Mobile Call' : 'Piga Simu ya Kawaida',
                subtitle: phone, // the number is shown on the button
                onTap: () => run(() => CallService.mobileCall(rootContext, phone)),
              ),
            ],

            if (showWhatsApp) ...[
              if (online || showMobile) const SizedBox(height: 10),
              _option(
                icon: Icons.chat_rounded,
                color: const Color(0xFF25D366),
                title: 'WhatsApp',
                subtitle: wa,
                onTap: () => run(() => CallService.whatsapp(rootContext, wa)),
              ),
            ],

            if (showNavigate) ...[
              if (online || showMobile || showWhatsApp) const SizedBox(height: 10),
              _option(
                icon: Icons.navigation_rounded,
                color: AppColors.primary,
                title: isEn ? 'Navigate' : 'Elekea Mahali',
                subtitle: isEn ? 'Open directions in Maps' : 'Fungua maelekezo kwenye Ramani',
                onTap: () => run(() => CallService.navigate(
                      rootContext,
                      lat: service.latitude,
                      lng: service.longitude,
                      query: navQuery,
                    )),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _option({
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(12)),
              child: Icon(icon, color: color, size: 22),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                  const SizedBox(height: 2),
                  Text(subtitle, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted),
          ],
        ),
      ),
    );
  }
}

package com.unganalink.app

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.google.android.play.core.integrity.IntegrityManagerFactory
import com.google.android.play.core.integrity.IntegrityTokenRequest
import java.security.MessageDigest
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.os.Debug
import android.view.WindowManager
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.security.KeyStore

// local_auth (biometrics) needs a FragmentActivity.
class MainActivity : FlutterFragmentActivity() {

    private val isDebuggableBuild: Boolean
        get() = (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applySecureFlag(true)
    }

    // Blocks screenshots, screen recording and the recent-apps thumbnail (release only).
    private fun applySecureFlag(on: Boolean) {
        if (isDebuggableBuild) return
        if (on) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "ungana/security")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "scan" -> result.success(scan())
                    "signer" -> result.success(signerHashes())
                    "integrityToken" -> requestIntegrityToken(call.arguments as? String, result)
                    "setSecure" -> {
                        applySecureFlag(call.arguments as? Boolean ?: true)
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    // SHA-256 (hex, lowercase) of the certificate(s) this APK is signed with.
    // With Play App Signing this is Google's app-signing key (Play Console > App integrity).
    @Suppress("DEPRECATION")
    private fun signerHashes(): List<String> = try {
        val sigs = if (Build.VERSION.SDK_INT >= 28) {
            val info = packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNING_CERTIFICATES).signingInfo
            if (info.hasMultipleSigners()) info.apkContentsSigners else info.signingCertificateHistory
        } else {
            packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES).signatures
        }
        sigs.map { sig -> MessageDigest.getInstance("SHA-256").digest(sig.toByteArray()).joinToString("") { "%02x".format(it) } }
    } catch (_: Throwable) { emptyList() }

    // Google Play Integrity. Returns null (never an error) when Play Services is missing or fails,
    // so users without Google services are never locked out by the client; the server decides.
    private fun requestIntegrityToken(nonce: String?, result: MethodChannel.Result) {
        if (nonce.isNullOrBlank()) { result.success(null); return }
        try {
            IntegrityManagerFactory.create(applicationContext)
                .requestIntegrityToken(IntegrityTokenRequest.builder().setNonce(nonce).build())
                .addOnSuccessListener { result.success(it.token()) }
                .addOnFailureListener { result.success(null) }
        } catch (_: Throwable) { result.success(null) }
    }

    private fun scan(): Map<String, Boolean> = mapOf(
        "rooted" to safe { isRooted() },
        "debugger" to safe { isDebugged() },
        "hooking" to safe { hasHooking() },
        "proxy" to safe { hasProxy() },
        "vpn" to safe { hasVpn() },
        "userCa" to safe { hasUserCa() },
    )

    private inline fun safe(block: () -> Boolean): Boolean = try { block() } catch (_: Throwable) { false }

    private fun isRooted(): Boolean {
        if (Build.TAGS?.contains("test-keys") == true) return true
        val paths = arrayOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su", "/system/su", "/vendor/bin/su",
            "/su/bin/su", "/data/local/su", "/data/local/bin/su", "/data/local/xbin/su",
            "/system/app/Superuser.apk", "/sbin/.magisk", "/data/adb/magisk", "/data/adb/modules",
        )
        return paths.any { File(it).exists() }
    }

    private fun isDebugged(): Boolean {
        if (isDebuggableBuild) return true
        if (Debug.isDebuggerConnected() || Debug.waitingForDebugger()) return true
        // A non-zero TracerPid means another process (gdb, strace, frida...) is attached.
        File("/proc/self/status").useLines { lines ->
            lines.firstOrNull { it.startsWith("TracerPid:") }?.let {
                if (it.substringAfter(":").trim() != "0") return true
            }
        }
        return false
    }

    private fun hasHooking(): Boolean {
        try {
            Class.forName("de.robv.android.xposed.XposedBridge")
            return true
        } catch (_: Throwable) { }
        val needles = listOf("frida", "gum-js-loop", "xposed", "substrate", "lsposed")
        File("/proc/self/maps").useLines { lines ->
            if (lines.any { l -> needles.any { n -> l.contains(n, ignoreCase = true) } }) return true
        }
        // frida-server default port
        return try {
            Socket().use { it.connect(InetSocketAddress("127.0.0.1", 27042), 120); true }
        } catch (_: Throwable) { false }
    }

    private fun hasProxy(): Boolean {
        val h = System.getProperty("http.proxyHost") ?: System.getProperty("https.proxyHost")
        return !h.isNullOrBlank()
    }

    private fun hasVpn(): Boolean {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
    }

    // User-installed CA certificates are how sniffers (HttpCanary, mitmproxy...) decrypt HTTPS.
    private fun hasUserCa(): Boolean {
        val ks = KeyStore.getInstance("AndroidCAStore").apply { load(null, null) }
        val aliases = ks.aliases()
        while (aliases.hasMoreElements()) if (aliases.nextElement().startsWith("user:")) return true
        return false
    }
}

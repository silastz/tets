import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';

enum BiometricResult { success, failed, lockedOut, unavailable }

/// Fingerprint / Face unlock helper. Every call is defensive: devices without
/// hardware, without an enrolled fingerprint/face, or with a locked-out sensor
/// simply report "not available" so the app can fall back to the PIN.
class BiometricService {
  static final LocalAuthentication _auth = LocalAuthentication();

  static bool _busy = false;
  static DateTime _busyUntil = DateTime.fromMillisecondsSinceEpoch(0);

  /// True while the system prompt is showing (and briefly after), so the App Lock
  /// gate does not mistake the prompt for the app going to the background.
  static bool get isBusy => _busy || DateTime.now().isBefore(_busyUntil);

  /// True only when the phone has biometric hardware AND at least one enrolled
  /// fingerprint / face.
  static Future<bool> isAvailable() async {
    try {
      if (!await _auth.isDeviceSupported()) return false;
      final types = await _auth.getAvailableBiometrics();
      return types.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  static Future<BiometricResult> authenticate(String reason) async {
    _busy = true;
    try {
      if (!await isAvailable()) return BiometricResult.unavailable;
      final ok = await _auth.authenticate(
        localizedReason: reason,
        options: const AuthenticationOptions(biometricOnly: true, stickyAuth: true),
      );
      return ok ? BiometricResult.success : BiometricResult.failed;
    } on PlatformException catch (e) {
      final code = e.code.toLowerCase();
      if (code.contains('lockedout')) return BiometricResult.lockedOut;
      if (code.contains('notavailable') || code.contains('notenrolled') || code.contains('passcodenotset')) {
        return BiometricResult.unavailable;
      }
      return BiometricResult.failed;
    } catch (_) {
      return BiometricResult.failed;
    } finally {
      _busy = false;
      _busyUntil = DateTime.now().add(const Duration(seconds: 2));
    }
  }
}

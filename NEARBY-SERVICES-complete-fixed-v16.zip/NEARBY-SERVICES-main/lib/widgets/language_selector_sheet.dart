import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';

class LanguageSelectorSheet {
  static void show(BuildContext context) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (ctx) => Scaffold(
        backgroundColor: AppColors.surface,
        appBar: AppBar(
          backgroundColor: AppColors.surface,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
            onPressed: () => Navigator.pop(ctx),
          ),
          title: Text(
            AppStrings.profileLanguageTitle,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
          ),
        ),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            children: [
              ListTile(
                leading: const Text('🇬🇧', style: TextStyle(fontSize: 22)),
                title: const Text('English (Default)'),
                trailing: AppStrings.isEnglish
                    ? const Icon(Icons.check_circle_rounded, color: AppColors.primary)
                    : null,
                onTap: () {
                  AppStrings.setLanguage(AppLanguage.english);
                  Navigator.pop(ctx);
                },
              ),
              ListTile(
                leading: const Text('🇹🇿', style: TextStyle(fontSize: 22)),
                title: const Text('Kiswahili'),
                trailing: !AppStrings.isEnglish
                    ? const Icon(Icons.check_circle_rounded, color: AppColors.primary)
                    : null,
                onTap: () {
                  AppStrings.setLanguage(AppLanguage.swahili);
                  Navigator.pop(ctx);
                },
              ),
            ],
          ),
        ),
      ),
    ));
  }
}

import 'package:flutter/material.dart';

enum VerificationLevel {
  none,
  greenNidaNumber,       // Nida Number tu (Green verified badge)
  blueNidaPhotoWithId,   // Nida ID + Picture with ID au invited na Blue Verified user (Blue tick badge)
}

enum EscrowPaymentStatus {
  pendingPayment,
  fundsHeldInEscrow,     // Fedha zimeshikiliwa (Buyer amelipa Direct au Pocket Fund)
  buyerSatisfiedReleased,// Buyer karidhika, pesa imeenda kwa Seller
  disputed,
}

class ServiceItem {
  final String id;
  final String title;
  final String subtitle;
  final String category;
  final String distance;
  final double rating;
  final int reviewsCount;
  final String priceText;
  final int priceAmount;
  final String durationText;
  final String stageName;        // SELLER STAGE NAME TU (Official NIDA name is strictly private)
  final VerificationLevel verificationLevel;
  /// Provider paid to boost this service (server flag; see [isBoosted] for the time-aware answer).
  final bool isSponsored;

  /// When the current boost ends (null = not boosted, or the server only sent a flag).
  final DateTime? boostedUntil;
  final Color themeColor;
  final IconData icon;

  final int? sellerId;
  final String? sellerAvatar;

  // Locked vs Unlocked contact rules:
  // If isInfoLocked is true, contacts are hidden until request accepted
  final bool isInfoLocked;
  final bool contactsVisible;

  /// Provider has set their whole profile to Locked in Settings (server-provided).
  final bool profileLocked;

  /// True while the provider's phone, socials and direct calls must stay hidden.
  bool get isContactLocked => (isInfoLocked || profileLocked) && !contactsVisible;
  final String? phone;
  final String? whatsappPhone;
  final String? email;
  final String? instagramUsername;
  final String? facebookUsername;
  final String? xUsername;
  final String? tiktokUsername;
  final String? youtubeUsername;

  final List<String> videoUrls;
  final List<String> imageUrls;
  final bool is18Plus;

  /// What the service offers / includes (e.g. Soup, Pizza, Eggs, Sandwich).
  final List<String> features;

  /// The featured (cover) photo: the first image, or null when there are none.
  String? get featuredImage => imageUrls.isNotEmpty ? imageUrls.first : null;

  /// Provider location for directions (optional; city name is used when missing).
  final double? latitude;
  final double? longitude;

  /// Distance from the user's GPS in km (null when unknown).
  final double? distanceKm;
  final String? city;

  /// True when the provider is currently online (in-app calls are only offered then).
  final bool isOnline;

  /// Working schedule from the provider ('Mon'..'Sun', 'HH:mm'); empty/null = not set.
  final List<String> availableDays;
  final String? availableFrom;
  final String? availableTo;

  /// 'customer_comes', 'provider_travels', 'both', or null when the server doesn't say.
  final String? serviceMode;

  /// Provider details for the profile page (all null when the server doesn't send them).
  final DateTime? sellerSince;
  final String? sellerBio;
  final int? completedJobs;
  final int? totalBookings;

  /// Discount / negotiation (all optional; the server sends them only when the seller set them).
  /// [priceAmount] is always the price the buyer pays today (already discounted).
  /// [listedPriceAmount] is the normal price before the discount (0 = no discount running).
  final int listedPriceAmount;
  final int discountPercent;
  final DateTime? discountEndsAt;

  /// Seller allows buyers to send price offers on this service.
  final bool allowOffers;

  ServiceItem({
    required this.id,
    this.sellerId,
    this.sellerAvatar,
    required this.title,
    required this.subtitle,
    this.category = 'General',
    required this.distance,
    required this.rating,
    required this.reviewsCount,
    required this.priceText,
    this.priceAmount = 50000,
    this.durationText = '', // '' = price only, no duration
    String? stageName,
    String? providerName,
    VerificationLevel? verificationLevel,
    bool? isVerified,
    required this.isSponsored,
    this.boostedUntil,
    required this.themeColor,
    required this.icon,
    this.isInfoLocked = false,
    this.profileLocked = false,
    this.contactsVisible = true,
    this.phone,
    this.whatsappPhone,
    this.email,
    this.instagramUsername,
    this.facebookUsername,
    this.xUsername,
    this.tiktokUsername,
    this.youtubeUsername,
    this.videoUrls = const [],
    this.imageUrls = const [],
    this.is18Plus = false,
    this.features = const [],
    this.isOnline = false,
    this.availableDays = const [],
    this.availableFrom,
    this.availableTo,
    this.serviceMode,
    this.sellerSince,
    this.sellerBio,
    this.completedJobs,
    this.totalBookings,
    this.listedPriceAmount = 0,
    this.discountPercent = 0,
    this.discountEndsAt,
    this.allowOffers = true,
    this.latitude,
    this.longitude,
    this.distanceKm,
    this.city,
  })  : stageName = stageName ?? providerName ?? 'Service Pro',
        verificationLevel = verificationLevel ??
            (isVerified == true ? VerificationLevel.blueNidaPhotoWithId : VerificationLevel.none);

  String get providerName => stageName;

  /// Boosted right now: the end time decides when the server sent one, else the flag.
  bool get isBoosted => boostedUntil != null ? boostedUntil!.isAfter(DateTime.now()) : isSponsored;

  /// A discount is running right now (price below the normal price and not expired).
  bool get hasDiscount =>
      listedPriceAmount > priceAmount &&
      (discountEndsAt == null || discountEndsAt!.isAfter(DateTime.now()));

  /// 'TSh 50,000' for the normal price (shown struck through next to the discounted one).
  String get listedPriceText =>
      'TSh ${listedPriceAmount.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]},')}';

  /// Percent off, from the server or worked out from the two prices.
  int get discountPercentShown {
    if (!hasDiscount) return 0;
    if (discountPercent > 0) return discountPercent;
    return (((listedPriceAmount - priceAmount) * 100) / listedPriceAmount).round();
  }

  /// The provider priced this service for a set time (e.g. '1 hr'). False = price only.
  bool get hasDuration => durationText.trim().isNotEmpty;

  /// 'TSh 50,000 • 1 hr' with a duration, just 'TSh 50,000' without.
  String get priceWithDuration => hasDuration ? '$priceText • $durationText' : priceText;
  /// True only when real reviews back the rating (the server sent a count above zero).
  bool get hasReviews => reviewsCount > 0 && rating > 0;

  /// '4.9' once reviewed, 'New' before the first review (never an invented number).
  String get ratingText => hasReviews ? rating.toStringAsFixed(1) : 'New';

  /// '(38 reviews)' once reviewed, empty before.
  String get reviewsLabel => hasReviews ? '($reviewsCount ${reviewsCount == 1 ? 'review' : 'reviews'})' : '';

  /// Where the service is: its own city when the server gave one, else the distance text.
  String get locationLabel {
    final c = (city ?? '').trim();
    if (c.isEmpty) return distance;
    return distance.trim().isEmpty || distance == c ? c : '$c  •  $distance';
  }

  bool get isVerified => verificationLevel != VerificationLevel.none;
  bool get hasBlueTick => verificationLevel == VerificationLevel.blueNidaPhotoWithId;
  bool get hasGreenBadge => verificationLevel == VerificationLevel.greenNidaNumber;
}

class ChatMessage {
  final String id;
  final String stageName;        // Stage name tu
  final String lastMessage;
  final String timestamp;
  final int unreadCount;
  final bool isVoiceNote;
  final String? audioDuration;
  final VerificationLevel verificationLevel;
  final String? otherUserId; // user id of the person on the other side
  final bool isOnline;       // other side is currently online

  ChatMessage({
    required this.id,
    this.otherUserId,
    this.isOnline = false,
    String? stageName,
    String? senderName,
    required this.lastMessage,
    required this.timestamp,
    this.unreadCount = 0,
    this.isVoiceNote = false,
    this.audioDuration,
    VerificationLevel? verificationLevel,
    bool? isVerified,
  })  : stageName = stageName ?? senderName ?? 'User',
        verificationLevel = verificationLevel ??
            (isVerified == true ? VerificationLevel.blueNidaPhotoWithId : VerificationLevel.none);

  String get senderName => stageName;
  bool get isVerified => verificationLevel != VerificationLevel.none;
}

class ServiceRequest {
  final String id;
  final String buyerStageName;   // Mnunuzi naye anaonekana kwa Stage Name au alias tu
  final String serviceTitle;
  final String priceText;
  final int priceAmount;
  final String durationText;
  final String scheduleDateTime;
  final String distance;
  final String status;           // 'New', 'Pending', 'Accepted', 'Rejected'
  final EscrowPaymentStatus escrowStatus;
  final String paymentMethod;    // 'Pocket Fund' au 'Direct Online'

  ServiceRequest({
    required this.id,
    required this.buyerStageName,
    required this.serviceTitle,
    required this.priceText,
    required this.priceAmount,
    required this.durationText,
    required this.scheduleDateTime,
    required this.distance,
    required this.status,
    this.escrowStatus = EscrowPaymentStatus.fundsHeldInEscrow,
    this.paymentMethod = 'Pocket Fund',
  });
}

class ManagedService {
  final String id;
  final String title;
  final String priceText;
  final String durationText;
  final String status;           // 'Active', 'Pending', 'Inactive'
  final Color color;
  final IconData icon;

  ManagedService({
    required this.id,
    required this.title,
    required this.priceText,
    required this.durationText,
    required this.status,
    required this.color,
    required this.icon,
  });
}

class PocketFundWallet {
  final double availableBalance;
  final double heldInEscrowBalance;
  final List<WalletTransaction> transactions;

  PocketFundWallet({
    required this.availableBalance,
    required this.heldInEscrowBalance,
    required this.transactions,
  });
}

class WalletTransaction {
  final String id;
  final String title;
  final String date;
  final double amount;
  final bool isCredit;
  final String status;

  WalletTransaction({
    required this.id,
    required this.title,
    required this.date,
    required this.amount,
    required this.isCredit,
    required this.status,
  });
}

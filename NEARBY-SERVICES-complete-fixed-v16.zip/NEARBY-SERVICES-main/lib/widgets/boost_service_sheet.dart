import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/boost.dart';
import '../services/api_service.dart';
import '../services/payment_methods_service.dart';
import '../services/session_manager.dart';
import 'app_ui.dart';
import 'card_payment_dialog.dart';
import '../screens/registration_fee_screen.dart' show MobileWaitDialog, MaskedPhone;

/// A payment that went through but whose boost could not be started yet
/// (network drop, server hiccup). Kept so the provider can retry without paying twice.
class _PendingActivation {
  final BoostPlan plan;
  final String method; // MOBILE_MONEY | CARD
  final String reference;
  const _PendingActivation(this.plan, this.method, this.reference);
}

/// Short bottom sheet: the provider picks a boost package for one service, pays
/// (Mobile Money, Card or Pocket Fund) and the service is promoted.
/// Resolves to `true` when a boost started.
class BoostServiceSheet extends StatefulWidget {
  final String serviceId;
  final String title;

  /// End of the boost already running on this service (null = not boosted).
  final DateTime? boostedUntil;

  const BoostServiceSheet({
    super.key,
    required this.serviceId,
    required this.title,
    this.boostedUntil,
  });

  static Future<bool?> show(
    BuildContext context, {
    required String serviceId,
    required String title,
    DateTime? boostedUntil,
  }) {
    return showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      enableDrag: false, // a swipe must not close the sheet in the middle of a payment
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        final media = MediaQuery.of(ctx);
        return Padding(
          padding: EdgeInsets.only(bottom: media.viewInsets.bottom),
          child: Container(
            constraints: BoxConstraints(maxHeight: media.size.height * 0.92),
            decoration: const BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
            ),
            child: SafeArea(
              top: false,
              child: BoostServiceSheet(serviceId: serviceId, title: title, boostedUntil: boostedUntil),
            ),
          ),
        );
      },
    );
  }

  @override
  State<BoostServiceSheet> createState() => _BoostServiceSheetState();
}

class _BoostServiceSheetState extends State<BoostServiceSheet> {
  List<BoostPlan> _plans = BoostPlan.defaults;
  BoostPlan _plan = BoostPlan.defaults[1];
  String _method = 'mobile_money'; // mobile_money | card | pocket_fund
  final TextEditingController _phoneCtrl = TextEditingController();
  String? _phoneError;
  bool _busy = false;
  bool _loading = true;
  double? _walletBalance;
  DateTime? _until;
  bool _changed = false; // a boost was started on this screen
  bool _justBoosted = false;
  _PendingActivation? _pending;

  bool get _isEn => AppStrings.isEnglish;
  bool get _isBoosted => _until != null && _until!.isAfter(DateTime.now());

  @override
  void initState() {
    super.initState();
    _until = widget.boostedUntil;
    _phoneCtrl.text = SessionManager.getPhone();
    _load();
  }

  @override
  void dispose() {
    _phoneCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final plans = await ApiService.fetchBoostPlans();
    final wallet = await ApiService.getWallet();
    if (!mounted) return;
    setState(() {
      if (plans != null && plans.isNotEmpty) {
        _plans = plans;
        _plan = plans.length > 1 ? plans[1] : plans.first;
      }
      final bal = wallet == null ? null : (wallet['balance'] as num?)?.toDouble();
      _walletBalance = bal;
      _loading = false;
    });
  }

  String _money(num v) => BoostPlan.formatTzs(v);

  String _when(DateTime d) {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    final l = d.toLocal();
    final hh = l.hour.toString().padLeft(2, '0');
    final mm = l.minute.toString().padLeft(2, '0');
    return '${l.day} ${months[l.month - 1]} ${l.year}, $hh:$mm';
  }

  // Shown inside the sheet: a SnackBar would sit behind the sheet and not be seen.
  String? _notice;
  Color _noticeColor = AppColors.warningDark;

  void _snack(String text, {Color? color}) {
    if (!mounted) return;
    setState(() {
      _notice = text;
      _noticeColor = color ?? AppColors.warningDark;
    });
  }

  Future<void> _payNow() async {
    final plan = _plan;
    if (_notice != null) setState(() => _notice = null);

    // Pocket Fund: no outside payment, the server takes it from the wallet.
    if (_method == 'pocket_fund') {
      final bal = _walletBalance;
      if (bal != null && bal < plan.price) {
        _snack(
          _isEn
              ? 'Your Pocket Fund balance (${_money(bal)}) is less than ${_money(plan.price)}.'
              : 'Salio la Pocket Fund (${_money(bal)}) ni chini ya ${_money(plan.price)}.',
          color: AppColors.warningDark,
        );
        return;
      }
      await _activate(plan, 'POCKET_FUND', null);
      return;
    }

    final userId = SessionManager.getUserIdValue();
    String reference = 'BOOST-${widget.serviceId}-$userId-${DateTime.now().millisecondsSinceEpoch}';
    bool paid = false;

    if (_method == 'mobile_money') {
      final normalized = PaymentMethodsService.normalizeTzNumber(_phoneCtrl.text);
      if (normalized == null) {
        setState(() => _phoneError = _isEn ? 'Enter a valid Tanzanian number' : 'Weka namba sahihi ya Tanzania');
        return;
      }
      setState(() {
        _phoneError = null;
        _busy = true;
      });
      final res = await ApiService.requestMobilePayment(
        amount: plan.price.toDouble(),
        purpose: 'SERVICE_BOOST',
        reference: reference,
        phone: '+$normalized',
      );
      if (!mounted) return;
      if (res == null) {
        setState(() => _busy = false);
        _snack(
          _isEn ? 'Could not send the payment request. Try again.' : 'Imeshindwa kutuma ombi la malipo. Jaribu tena.',
          color: AppColors.danger,
        );
        return;
      }
      reference = (res['reference'] ?? reference).toString();
      paid = await showDialog<bool>(
            context: context,
            barrierDismissible: false,
            builder: (_) => MobileWaitDialog(reference: reference, phone: MaskedPhone.of(normalized)),
          ) ??
          false;
    } else {
      setState(() => _busy = true);
      paid = await CardPayment.pay(
        context,
        amount: plan.price.toDouble(),
        purpose: 'SERVICE_BOOST',
        reference: reference,
        description: 'Service boost: ${widget.title}',
        phone: SessionManager.getPhone().isEmpty ? null : SessionManager.getPhone(),
      );
    }

    if (!mounted) return;
    if (!paid) {
      setState(() => _busy = false);
      _snack(_isEn ? 'Payment was not completed.' : 'Malipo hayakukamilika.', color: AppColors.warningDark);
      return;
    }
    await _activate(plan, _method == 'card' ? 'CARD' : 'MOBILE_MONEY', reference);
  }

  /// Tells the server to start the boost (payment is already confirmed for mobile/card,
  /// or taken from the wallet by the server for Pocket Fund).
  Future<void> _activate(BoostPlan plan, String method, String? reference) async {
    setState(() => _busy = true);
    final res = await ApiService.activateBoost(
      serviceId: widget.serviceId,
      plan: plan,
      paymentMethod: method,
      reference: reference,
    );
    if (!mounted) return;

    if (res == null) {
      final reason = ApiService.lastBoostError;
      setState(() {
        _busy = false;
        _pending = reference != null ? _PendingActivation(plan, method, reference) : null;
      });
      if (reference != null) {
        _snack(
          _isEn
              ? 'Payment received, but the boost could not be started yet. Tap "Finish activating" to retry. You will not be charged again.'
              : 'Malipo yamepokelewa, lakini boost haijaanza bado. Bonyeza "Kamilisha" kujaribu tena. Hutakatwa mara ya pili.',
          color: AppColors.warningDark,
        );
      } else {
        _snack(
          (reason != null && reason.trim().isNotEmpty)
              ? reason
              : (_isEn ? 'Could not boost this service. Try again.' : 'Imeshindwa kutangaza huduma hii. Jaribu tena.'),
          color: AppColors.danger,
        );
      }
      return;
    }

    final raw = res['boostedUntil'] ?? res['boostEndsAt'] ?? res['boostExpiresAt'];
    final base = _isBoosted ? _until! : DateTime.now();
    final until = (raw == null ? null : DateTime.tryParse(raw.toString())) ?? base.add(Duration(days: plan.days));
    setState(() {
      _busy = false;
      _pending = null;
      _notice = null;
      _until = until;
      _changed = true;
      _justBoosted = true;
      if (method == 'POCKET_FUND' && _walletBalance != null) {
        _walletBalance = (_walletBalance! - plan.price).clamp(0, double.infinity).toDouble();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    // While a payment is running the sheet cannot be closed (back button / barrier).
    return PopScope(
      canPop: !_busy,
      onPopInvokedWithResult: (didPop, _) {},
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)),
              ),
            ),
            const SizedBox(height: 14),
            _header(),
            const SizedBox(height: 16),
            if (_justBoosted)
              _successState()
            else ...[
              if (_pending != null) ...[
                _pendingCard(),
                const SizedBox(height: 16),
              ],
              _label(_isEn ? 'How long' : 'Muda'),
              const SizedBox(height: 8),
              _planPicker(),
              const SizedBox(height: 16),
              _label(_isEn ? 'Pay with' : 'Lipa kwa'),
              const SizedBox(height: 8),
              _methodPicker(),
              const SizedBox(height: 12),
              _methodDetail(),
              if (_notice != null) ...[
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: _noticeColor.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    _notice!,
                    style: TextStyle(fontSize: 12, height: 1.4, fontWeight: FontWeight.w600, color: _noticeColor),
                  ),
                ),
              ],
              const SizedBox(height: 16),
              AppButton.primary(
                label: _isEn ? 'Pay ${_plan.priceText}' : 'Lipa ${_plan.priceText}',
                loading: _busy || _loading,
                onPressed: _busy || _loading ? null : _payNow,
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _label(String t) => Text(
        t,
        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
      );

  Widget _header() {
    final boosted = _isBoosted;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(color: AppColors.warningLight, borderRadius: BorderRadius.circular(10)),
          child: const Icon(Icons.bolt_rounded, color: AppColors.warningDark, size: 24),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _isEn ? 'Boost service' : 'Tangaza huduma',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
              ),
              const SizedBox(height: 2),
              Text(
                widget.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
              ),
              if (boosted) ...[
                const SizedBox(height: 4),
                Text(
                  _isEn ? 'Boosted until ${_when(_until!)}. New days are added after it.' : 'Imetangazwa hadi ${_when(_until!)}. Siku mpya zinaongezwa baada yake.',
                  style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.warningDark),
                ),
              ] else ...[
                const SizedBox(height: 4),
                Text(
                  _isEn
                      ? 'Shown first in Home, Categories and Search, with a Boosted tag.'
                      : 'Inaonekana kwanza kwenye Mwanzo, Kategoria na Utafutaji, ikiwa na alama ya Imetangazwa.',
                  style: const TextStyle(fontSize: 11, height: 1.35, color: AppColors.textSecondary),
                ),
              ],
            ],
          ),
        ),
        InkResponse(
          onTap: _busy ? null : () => Navigator.pop(context, _changed),
          radius: 20,
          child: Padding(
            padding: const EdgeInsets.all(4),
            child: Icon(Icons.close_rounded, color: _busy ? AppColors.textDisabled : AppColors.textSecondary, size: 22),
          ),
        ),
      ],
    );
  }

  Widget _pendingCard() {
    final p = _pending!;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.successLight,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.success.withValues(alpha: 0.4)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.check_circle_rounded, color: AppColors.successDark, size: 18),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  _isEn
                      ? 'Payment received: ${_money(p.plan.price)} for ${p.plan.label(true)}'
                      : 'Malipo yamepokelewa: ${_money(p.plan.price)} kwa ${p.plan.label(false)}',
                  style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            _isEn
                ? 'The boost has not started yet. Retry below. You will not be charged again.'
                : 'Boost haijaanza bado. Jaribu tena hapa chini. Hutakatwa mara ya pili.',
            style: const TextStyle(fontSize: 11.5, color: AppColors.textSecondary, height: 1.4),
          ),
          const SizedBox(height: 10),
          AppButton.primary(
            label: _isEn ? 'Finish activating' : 'Kamilisha',
            loading: _busy,
            onPressed: _busy ? null : () => _activate(p.plan, p.method, p.reference),
          ),
        ],
      ),
    );
  }

  Widget _successState() {
    return Column(
      children: [
        const SizedBox(height: 4),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: const BoxDecoration(color: AppColors.warningLight, shape: BoxShape.circle),
          child: const Icon(Icons.bolt_rounded, color: AppColors.warning, size: 44),
        ),
        const SizedBox(height: 12),
        Text(
          _isEn ? 'Your service is boosted' : 'Huduma yako imetangazwa',
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        const SizedBox(height: 4),
        if (_until != null)
          Text(
            _isEn ? 'Active until ${_when(_until!)}.' : 'Inafanya kazi hadi ${_when(_until!)}.',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 12.5, color: AppColors.textSecondary),
          ),
        const SizedBox(height: 18),
        AppButton.primary(label: _isEn ? 'Done' : 'Sawa', onPressed: () => Navigator.pop(context, true)),
      ],
    );
  }

  /// Packages side by side (up to 3 per row), so the choice fits without scrolling.
  Widget _planPicker() {
    if (_loading) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 18),
        child: Center(child: SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))),
      );
    }
    return LayoutBuilder(
      builder: (context, c) {
        const gap = 8.0;
        final perRow = _plans.length < 3 ? _plans.length : 3;
        final w = (c.maxWidth - gap * (perRow - 1)) / perRow;
        return Wrap(
          spacing: gap,
          runSpacing: gap,
          children: [for (final p in _plans) SizedBox(width: w, child: _planTile(p))],
        );
      },
    );
  }

  Widget _planTile(BoostPlan p) {
    final selected = p.id == _plan.id;
    return InkWell(
      onTap: _busy ? null : () => setState(() => _plan = p),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 12),
        decoration: BoxDecoration(
          color: selected ? AppColors.primaryLight : AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: selected ? AppColors.primary : AppColors.border, width: selected ? 1.5 : 1),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              p.label(_isEn),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w800,
                color: selected ? AppColors.primary : AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              p.priceText,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.textSecondary),
            ),
          ],
        ),
      ),
    );
  }

  /// Three methods in one row (icon over name) instead of three tall list rows.
  Widget _methodPicker() {
    return Row(
      children: [
        Expanded(
          child: _methodTile('mobile_money', Icons.phone_android_rounded, AppColors.successDark, _isEn ? 'Mobile Money' : 'Pesa za Simu'),
        ),
        const SizedBox(width: 8),
        Expanded(child: _methodTile('card', Icons.credit_card_rounded, const Color(0xFF1D4ED8), _isEn ? 'Card' : 'Kadi')),
        const SizedBox(width: 8),
        Expanded(child: _methodTile('pocket_fund', Icons.account_balance_wallet_rounded, AppColors.primary, 'Pocket Fund')),
      ],
    );
  }

  Widget _methodTile(String id, IconData icon, Color color, String label) {
    final selected = _method == id;
    return InkWell(
      onTap: _busy ? null : () => setState(() => _method = id),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 10),
        decoration: BoxDecoration(
          color: selected ? AppColors.primaryLight : AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: selected ? AppColors.primary : AppColors.border, width: selected ? 1.5 : 1),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 22),
            const SizedBox(height: 4),
            Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 11.5,
                fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                color: selected ? AppColors.primary : AppColors.textPrimary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// The one field / hint that belongs to the chosen method.
  Widget _methodDetail() {
    switch (_method) {
      case 'card':
        return Text(
          _isEn
              ? 'Visa or Mastercard on a secure page. We never see or store your card details.'
              : 'Visa au Mastercard kwenye ukurasa salama. Hatuoni wala kuhifadhi taarifa za kadi yako.',
          style: const TextStyle(fontSize: 11.5, height: 1.4, color: AppColors.textSecondary),
        );
      case 'pocket_fund':
        return Text(
          _walletBalance == null
              ? (_isEn ? 'The amount is taken from your Pocket Fund wallet.' : 'Kiasi kinakatwa kutoka kwenye wallet yako ya Pocket Fund.')
              : (_isEn ? 'Available: ${_money(_walletBalance!)}' : 'Salio: ${_money(_walletBalance!)}'),
          style: TextStyle(
            fontSize: 11.5,
            height: 1.4,
            fontWeight: FontWeight.w600,
            color: (_walletBalance != null && _walletBalance! < _plan.price) ? AppColors.danger : AppColors.textSecondary,
          ),
        );
      default:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AppTextField(
              controller: _phoneCtrl,
              icon: Icons.phone_outlined,
              keyboardType: TextInputType.phone,
              hint: '07XX XXX XXX',
              label: _isEn ? 'Number to pay with' : 'Namba ya kulipia',
              errorText: _phoneError,
              enabled: !_busy,
            ),
            const SizedBox(height: 6),
            Text(
              _isEn
                  ? 'M-Pesa, Airtel Money, Tigo Pesa or Halopesa. You will get a prompt to confirm with your PIN.'
                  : 'M-Pesa, Airtel Money, Tigo Pesa au Halopesa. Utapata ujumbe kuthibitisha kwa PIN yako.',
              style: const TextStyle(fontSize: 11, height: 1.4, color: AppColors.textSecondary),
            ),
          ],
        );
    }
  }
}

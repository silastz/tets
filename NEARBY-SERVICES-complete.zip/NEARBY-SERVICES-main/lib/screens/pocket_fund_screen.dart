import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../services/api_service.dart';
import '../widgets/app_ui.dart';
import '../widgets/skeleton_loader.dart';
import '../services/data_sync.dart';

class PocketFundScreen extends StatefulWidget {
  final bool showBackButton;
  const PocketFundScreen({super.key, this.showBackButton = true});

  @override
  State<PocketFundScreen> createState() => _PocketFundScreenState();
}

class _PocketFundScreenState extends State<PocketFundScreen> {
  double _balance = 125000.0;
  bool _isLoading = false;
  String _selectedPaymentMethod = 'Mpesa';

  final List<Map<String, dynamic>> _paymentMethods = [
    {
      'id': 'Mpesa',
      'title': 'Mpesa',
      'subtitle': 'Connected • ********1234',
      'icon': Icons.phone_android_rounded,
      'color': const Color(0xFF10B981),
      'connected': true,
    },
    {
      'id': 'Airtel',
      'title': 'Airtel Money',
      'subtitle': 'Not Connected',
      'icon': Icons.sim_card_outlined,
      'color': const Color(0xFFEF4444),
      'connected': false,
    },
    {
      'id': 'Tigo',
      'title': 'Tigo Pesa',
      'subtitle': 'Not Connected',
      'icon': Icons.swap_horiz_rounded,
      'color': const Color(0xFF3B82F6),
      'connected': false,
    },
    {
      'id': 'Card',
      'title': 'Card',
      'subtitle': 'Not Connected',
      'icon': Icons.credit_card_rounded,
      'color': const Color(0xFF6B7280),
      'connected': false,
    },
  ];

  List<Map<String, dynamic>> _recentTransactions = [];

  final List<Map<String, dynamic>> _defaultTransactions = [
    {
      'title': 'Payment to Asha Wellness',
      'amount': '- TSh 50,000',
      'date': 'Sep 24, 2025',
      'avatar': 'assets/images/banner.jpg',
      'status': 'Paid',
    },
    {
      'title': 'Top Up via M-Pesa',
      'amount': '+ TSh 100,000',
      'date': 'Sep 20, 2025',
      'avatar': 'assets/images/provider1.jpg',
      'status': 'Completed',
    },
    {
      'title': 'Payment to King Barber',
      'amount': '- TSh 30,000',
      'date': 'Sep 18, 2025',
      'avatar': 'assets/images/provider2.jpg',
      'status': 'Paid',
    },
  ];

  // Something was written to the server elsewhere (booking, accept, wallet, review...): re-fetch.
  void _onDataChanged() {
    if (mounted) _loadWalletData();
  }

  @override
  void dispose() {
    DataSync.changed.removeListener(_onDataChanged);
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    DataSync.changed.addListener(_onDataChanged);
    _recentTransactions = List.from(_defaultTransactions);
    _loadWalletData();
  }

  Future<void> _loadWalletData() async {
    setState(() => _isLoading = true);
    final walletFuture = ApiService.getWallet();
    final txFuture = ApiService.fetchBuyerTransactions();

    final results = await Future.wait([walletFuture, txFuture]);
    final wallet = results[0] as Map<String, dynamic>?;
    final txList = results[1] as List<dynamic>?;

    if (mounted) {
      setState(() {
        if (wallet != null) {
          final bal = (wallet['balance'] as num?)?.toDouble() ?? 0.0;
          if (bal > 0) _balance = bal;
        }
        if (txList != null && txList.isNotEmpty) {
          _recentTransactions = txList.map((tx) {
            final amt = (tx['amount'] as num?)?.toInt() ?? 0;
            final seller = tx['seller'] ?? {};
            final sellerName = seller['stageName'] ?? seller['username'] ?? 'Service Provider';
            final status = (tx['status'] ?? 'COMPLETED').toString();
            return {
              'title': 'Booking: $sellerName',
              'amount': '- TSh $amt',
              'date': (tx['createdAt'] != null ? tx['createdAt'].toString().substring(0, 10) : 'Recent'),
              'avatar': 'assets/images/banner.jpg',
              'status': status == 'COMPLETED' ? 'Paid' : status,
            };
          }).toList();
        }
        _isLoading = false;
      });
    }
  }

  String _money(num v) => 'TSh ${v.toInt().toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},')}';

  void _showWithdrawDialog(BuildContext context) {
    final amountCtrl = TextEditingController();
    final phoneCtrl = TextEditingController();
    bool busy = false;
    String? amountError;
    String? phoneError;

    AppSheet.show<void>(
      context,
      title: 'Withdraw',
      subtitle: 'Available: ${_money(_balance)}',
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AppTextField(
              controller: amountCtrl,
              icon: Icons.payments_outlined,
              keyboardType: TextInputType.number,
              hint: 'Amount (TSh)',
              errorText: amountError,
            ),
            const SizedBox(height: 12),
            AppTextField(
              controller: phoneCtrl,
              icon: Icons.phone_outlined,
              keyboardType: TextInputType.phone,
              hint: 'Mobile money number',
              errorText: phoneError,
            ),
            const SizedBox(height: 20),
            AppButton.primary(
              label: 'Withdraw',
              loading: busy,
              onPressed: () async {
                final amt = double.tryParse(amountCtrl.text.trim()) ?? 0;
                final phone = phoneCtrl.text.trim();
                final badAmount = amt <= 0 ? 'Enter an amount' : (amt > _balance ? 'More than your available balance' : null);
                final badPhone = phone.replaceAll(RegExp(r'[^0-9]'), '').length < 9 ? 'Enter a valid phone number' : null;
                if (badAmount != null || badPhone != null) {
                  setD(() {
                    amountError = badAmount;
                    phoneError = badPhone;
                  });
                  return;
                }
                setD(() {
                  busy = true;
                  amountError = null;
                  phoneError = null;
                });
                final messenger = ScaffoldMessenger.of(context);
                final res = await ApiService.withdrawWallet(amt, phone);
                if (!ctx.mounted) return;
                Navigator.pop(ctx);
                messenger.showSnackBar(SnackBar(
                  backgroundColor: res != null ? AppColors.success : AppColors.danger,
                  content: Text(res != null ? 'Withdrawal requested' : 'Withdrawal failed. Try again.'),
                ));
                if (res != null && mounted) _loadWalletData();
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showHistorySheet(BuildContext context) {
    final items = _recentTransactions.isNotEmpty ? _recentTransactions : _defaultTransactions;
    AppSheet.show<void>(
      context,
      title: 'Transaction History',
      builder: (ctx) => items.isEmpty
          ? const Padding(
              padding: EdgeInsets.symmetric(vertical: 24),
              child: Center(child: Text('No transactions yet', style: TextStyle(fontSize: 13, color: AppColors.textSecondary))),
            )
          : Column(
              children: [
                for (final tx in items)
                  Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 20,
                          backgroundImage: AssetImage(tx['avatar'] as String),
                          backgroundColor: AppColors.borderLight,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('${tx['title']}',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                              const SizedBox(height: 2),
                              Text('${tx['date']}  •  ${tx['status']}',
                                  style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          '${tx['amount']}',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                            color: ('${tx['amount']}').startsWith('-') ? AppColors.danger : AppColors.successDark,
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
    );
  }

  void _showTopUpDialog(BuildContext context) {
    final amountController = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Top Up Wallet', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: amountController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Amount (TSh)',
                hintText: 'e.g. 50000',
                filled: true,
                fillColor: AppColors.surface,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              final amt = double.tryParse(amountController.text) ?? 50000.0;
              setState(() {
                _balance += amt;
              });
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  backgroundColor: AppColors.success,
                  content: Text('Successfully topped up TSh ${amt.toInt()}'),
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
            ),
            child: const Text('Top Up'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: widget.showBackButton && Navigator.canPop(context)
            ? IconButton(
                icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
                onPressed: () => Navigator.pop(context),
              )
            : null,
        title: const Text(
          'Payment & Wallet',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: _isLoading
          ? const Padding(
              padding: EdgeInsets.all(16),
              child: VerticalListCardSkeleton(),
            )
          : RefreshIndicator(
              onRefresh: _loadWalletData,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Blue Wallet Card (Screen 6 100% fidelity)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: AppColors.primary,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.primary.withValues(alpha: 0.25),
                            blurRadius: 16,
                            offset: const Offset(0, 6),
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: const [
                                  Icon(Icons.account_balance_wallet_outlined, color: Colors.white70, size: 16),
                                  SizedBox(width: 6),
                                  Text(
                                    'Wallet Balance',
                                    style: TextStyle(color: Colors.white70, fontSize: 13, fontWeight: FontWeight.w500),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 6),
                              Text(
                                'TSh ${_balance.toInt().toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},')}',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 26,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: -0.5,
                                ),
                              ),
                            ],
                          ),
                          ElevatedButton(
                            onPressed: () => _showTopUpDialog(context),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white,
                              foregroundColor: AppColors.primary,
                              elevation: 0,
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                            ),
                            child: const Text('Top Up', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Quick Actions Row: Withdraw, History
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _buildQuickAction(
                          icon: Icons.account_balance_outlined,
                          label: 'Withdraw',
                          onTap: () => _showWithdrawDialog(context),
                        ),
                        _buildQuickAction(
                          icon: Icons.history_rounded,
                          label: 'History',
                          onTap: () => _showHistorySheet(context),
                        ),
                      ],
                    ),
                    const SizedBox(height: 26),

                    // Payment Methods Section
                    const Text(
                      'Payment Methods',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Container(
                      decoration: BoxDecoration(
                        color: AppColors.surface,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: AppColors.border),
                      ),
                      child: Column(
                        children: _paymentMethods.asMap().entries.map((entry) {
                          final idx = entry.key;
                          final m = entry.value;
                          final isSelected = _selectedPaymentMethod == m['id'];

                          return Column(
                            children: [
                              ListTile(
                                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
                                leading: Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: (m['color'] as Color).withValues(alpha: 0.12),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Icon(m['icon'] as IconData, color: m['color'] as Color, size: 22),
                                ),
                                title: Text(
                                  m['title'] as String,
                                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                                ),
                                subtitle: Text(
                                  m['subtitle'] as String,
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: m['connected'] == true ? AppColors.textSecondary : AppColors.textMuted,
                                  ),
                                ),
                                trailing: Container(
                                  width: 20,
                                  height: 20,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: isSelected ? AppColors.primary : AppColors.border,
                                      width: isSelected ? 6 : 2,
                                    ),
                                  ),
                                ),
                                onTap: () => setState(() => _selectedPaymentMethod = m['id'] as String),
                              ),
                              if (idx < _paymentMethods.length - 1)
                                const Divider(height: 1, indent: 64, color: AppColors.borderLight),
                            ],
                          );
                        }).toList(),
                      ),
                    ),
                    const SizedBox(height: 26),

                    // Recent Transactions Section Header
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Recent Transactions',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        GestureDetector(
                          onTap: () => _showHistorySheet(context),
                          child: const Text(
                            'View All',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: AppColors.primary,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),

                    // Recent Transactions List
                    ..._recentTransactions.map((tx) {
                      final isDebit = (tx['amount'] as String).startsWith('-');
                      return Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: AppColors.surface,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: AppColors.border),
                        ),
                        child: Row(
                          children: [
                            CircleAvatar(
                              radius: 20,
                              backgroundImage: AssetImage(tx['avatar'] as String),
                              backgroundColor: AppColors.borderLight,
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    tx['title'] as String,
                                    style: const TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w700,
                                      color: AppColors.textPrimary,
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    '${tx['amount']} • ${tx['date']}',
                                    style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              width: 8,
                              height: 8,
                              decoration: BoxDecoration(
                                color: isDebit ? AppColors.danger : AppColors.success,
                                shape: BoxShape.circle,
                              ),
                            ),
                          ],
                        ),
                      );
                    }),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _buildQuickAction({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: AppColors.surface,
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.border),
            ),
            child: Icon(icon, color: AppColors.primary, size: 22),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: AppColors.textPrimary,
            ),
          ),
        ],
      ),
    );
  }
}

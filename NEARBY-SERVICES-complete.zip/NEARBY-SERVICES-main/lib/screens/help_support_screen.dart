import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../constants/app_colors.dart';

class HelpSupportScreen extends StatelessWidget {
  const HelpSupportScreen({super.key});

  static const String _supportPhone = '+255712345678';
  static const String _supportWhatsapp = '255712345678';
  static const String _supportEmail = 'support@nearbyservices.techwareafrica.tech';

  Future<void> _makePhoneCall(String phone) async {
    final uri = Uri.parse('tel:$phone');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  Future<void> _openWhatsApp(String phone) async {
    final uri = Uri.parse('https://wa.me/$phone?text=Habari%20NearByServices%20Support,%20ninahitaji%20msaada.');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> _sendEmail(String email) async {
    final uri = Uri.parse('mailto:$email?subject=NearByServices%20Customer%20Support');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Help & Support',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // List of Support Options matching Screen 12
            Container(
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                children: [
                  _buildHelpItem(
                    icon: Icons.chat_bubble_outline_rounded,
                    title: 'FAQs',
                    subtitle: 'Find answers to common questions',
                    onTap: () => _showFaqSheet(context),
                  ),
                  _buildDivider(),
                  _buildHelpItem(
                    icon: Icons.headset_mic_outlined,
                    title: 'Contact Support',
                    subtitle: 'Chat via WhatsApp or send an Email',
                    onTap: () => _showContactOptionsSheet(context),
                  ),
                  _buildDivider(),
                  _buildHelpItem(
                    icon: Icons.report_problem_outlined,
                    title: 'Report a Problem',
                    subtitle: 'Report bugs or suspicious services',
                    onTap: () => _showReportSheet(context),
                  ),
                  _buildDivider(),
                  _buildHelpItem(
                    icon: Icons.security_rounded,
                    title: 'Safety Tips',
                    subtitle: 'Escrow protection and security guidelines',
                    onTap: () => _showSafetyTipsSheet(context),
                  ),
                  _buildDivider(),
                  _buildHelpItem(
                    icon: Icons.description_outlined,
                    title: 'Terms & Conditions',
                    subtitle: 'Platform rules and policies',
                    onTap: () => _showTermsSheet(context),
                  ),
                  _buildDivider(),
                  _buildHelpItem(
                    icon: Icons.privacy_tip_outlined,
                    title: 'Privacy Policy',
                    subtitle: 'How we protect your data',
                    onTap: () => _showPrivacySheet(context),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Call Us Banner Card matching Screen 12
            InkWell(
              onTap: () => _makePhoneCall(_supportPhone),
              borderRadius: BorderRadius.circular(16),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.primaryLight.withValues(alpha: 0.6),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.primary.withValues(alpha: 0.2)),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: const BoxDecoration(
                        color: AppColors.primary,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.phone_rounded, color: Colors.white, size: 20),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text(
                            'Need immediate help?',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: AppColors.textSecondary,
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            'Call us: +255 712 345 678',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w800,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            'Available 8:00 AM - 10:00 PM • Tap to Call',
                            style: TextStyle(
                              fontSize: 11,
                              color: AppColors.textMuted,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHelpItem({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: AppColors.borderLight,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: AppColors.primary, size: 20),
      ),
      title: Text(
        title,
        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
      ),
      subtitle: Text(
        subtitle,
        style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
      ),
      trailing: const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted, size: 20),
    );
  }

  Widget _buildDivider() {
    return const Divider(height: 1, indent: 64, color: AppColors.borderLight);
  }

  void _showContactOptionsSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Contact NearByServices Support', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              const SizedBox(height: 16),
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: const BoxDecoration(color: Color(0xFF25D366), shape: BoxShape.circle),
                  child: const Icon(Icons.chat_rounded, color: Colors.white, size: 20),
                ),
                title: const Text('Chat on WhatsApp', style: TextStyle(fontWeight: FontWeight.w700)),
                subtitle: const Text('Instant answers & chat assistance'),
                onTap: () {
                  Navigator.pop(ctx);
                  _openWhatsApp(_supportWhatsapp);
                },
              ),
              const Divider(height: 1),
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle),
                  child: const Icon(Icons.email_rounded, color: Colors.white, size: 20),
                ),
                title: const Text('Send an Email', style: TextStyle(fontWeight: FontWeight.w700)),
                subtitle: const Text('support@nearbyservices.techwareafrica.tech'),
                onTap: () {
                  Navigator.pop(ctx);
                  _sendEmail(_supportEmail);
                },
              ),
              const Divider(height: 1),
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: const BoxDecoration(color: AppColors.onlineGreen, shape: BoxShape.circle),
                  child: const Icon(Icons.phone_rounded, color: Colors.white, size: 20),
                ),
                title: const Text('Call Direct Support', style: TextStyle(fontWeight: FontWeight.w700)),
                subtitle: const Text('+255 712 345 678'),
                onTap: () {
                  Navigator.pop(ctx);
                  _makePhoneCall(_supportPhone);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showFaqSheet(BuildContext context) {
    final faqs = [
      {
        'q': 'How does Escrow Payment protection work?',
        'a': 'When you book a service, your funds are safely locked in Escrow. The service provider will not receive payment until you confirm complete satisfaction with the service.',
      },
      {
        'q': 'What happens if a provider cancels or does not arrive?',
        'a': 'If the booking is rejected by the provider or cancelled, 100% of your payment is immediately refunded back to your Pocket Fund wallet.',
      },
      {
        'q': 'How do I become a verified Seller (Blue Tick)?',
        'a': 'Go to the Sell tab or your Profile, tap "Apply for Blue Tick", enter your 20-digit NIDA number, and upload your ID verification photos. No ID photo? Ask a provider who already has a Blue Tick and knows you to invite you, then tap "I have an invitation" and enter the code with your 20-digit NIN.',
      },
      {
        'q': 'Why are contact details hidden on some services?',
        'a': 'To prevent fraud and protect your privacy, direct phone numbers and addresses remain locked until the booking is confirmed and accepted by the seller.',
      },
    ];

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => SafeArea(
        child: Container(
          height: MediaQuery.of(context).size.height * 0.75,
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Frequently Asked Questions', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                  IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(ctx)),
                ],
              ),
              const Divider(),
              Expanded(
                child: ListView.builder(
                  itemCount: faqs.length,
                  itemBuilder: (_, i) => ExpansionTile(
                    title: Text(faqs[i]['q']!, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                        child: Text(faqs[i]['a']!, style: const TextStyle(fontSize: 12, height: 1.5, color: AppColors.textSecondary)),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showReportSheet(BuildContext context) {
    final reportController = TextEditingController();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: EdgeInsets.fromLTRB(16, 20, 16, MediaQuery.of(ctx).viewInsets.bottom + 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Report a Problem or Abuse', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              const Text('Please describe the problem you experienced with a service or provider:', style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
              const SizedBox(height: 12),
              TextField(
                controller: reportController,
                maxLines: 4,
                decoration: InputDecoration(
                  hintText: 'Enter details here...',
                  filled: true,
                  fillColor: AppColors.background,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(ctx);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        backgroundColor: AppColors.success,
                        content: Text('Report submitted. Our safety team will review it promptly.'),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text('Submit Report', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showSafetyTipsSheet(BuildContext context) {
    _showTextContentSheet(
      context: context,
      title: 'Safety Guidelines & Tips',
      content: '1. Always keep payments within NearByServices Escrow to guarantee your funds are protected.\n\n'
          '2. Never release Escrow funds before the provider has fully completed the requested work.\n\n'
          '3. Check for the Green Badge (NIDA verified) or Blue Tick on provider profiles for highest trust.\n\n'
          '4. Report any provider asking for direct cash offline to bypass Escrow protection.',
    );
  }

  void _showTermsSheet(BuildContext context) {
    _showTextContentSheet(
      context: context,
      title: 'Terms & Conditions',
      content: 'By using NearByServices, you agree that providers on the platform are independent contractors. '
          'Transactions conducted through our platform are protected under the Escrow Guarantee. '
          'Misrepresentation of NIDA identities or abusive communication will result in immediate permanent account suspension.',
    );
  }

  void _showPrivacySheet(BuildContext context) {
    _showTextContentSheet(
      context: context,
      title: 'Privacy Policy',
      content: 'NearByServices is dedicated to safeguarding your personal data. '
          'Your phone number, exact location address, and WhatsApp contact are kept private until a booking is accepted. '
          'NIDA verification documents are encrypted and only used to establish platform identity authenticity.',
    );
  }

  void _showTextContentSheet({
    required BuildContext context,
    required String title,
    required String content,
  }) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                  IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(ctx)),
                ],
              ),
              const Divider(),
              const SizedBox(height: 8),
              Text(content, style: const TextStyle(fontSize: 13, height: 1.5, color: AppColors.textSecondary)),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }
}

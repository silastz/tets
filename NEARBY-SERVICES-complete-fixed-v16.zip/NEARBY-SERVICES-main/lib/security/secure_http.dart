import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:http/http.dart' as http;
import 'package:http/io_client.dart';

import 'security_config.dart';

/// One HTTP client for the whole app. Anti-sniffing rules:
///  * HTTPS only. Plain http:// requests are refused (no cleartext to sniff).
///  * Ignores the system/Wi-Fi proxy, so Burp / Charles / mitmproxy / Fiddler
///    set as a proxy never see the traffic.
///  * Own server: certificate PINNING. Only the CA(s) bundled in
///    assets/certs/pinned_ca.pem are trusted, so a user-installed "sniffer"
///    certificate (HttpCanary, mitmproxy, corporate MITM...) is rejected.
///  * Other hosts (IP lookup, routing): HTTPS + no proxy, system trust.
class SecureHttp extends http.BaseClient {
  SecureHttp._(this._pinned, this._open, this.pinningActive);

  final http.Client? _pinned;
  final http.Client _open;

  /// True when a pinned CA was loaded.
  final bool pinningActive;

  static SecureHttp? _instance;

  /// The shared client. Call [init] once in main() before using it.
  static SecureHttp get client => _instance ??= SecureHttp._(null, _plain(), false);

  static HttpClient _raw(SecurityContext? ctx) {
    final c = HttpClient(context: ctx);
    c.findProxy = (_) => 'DIRECT'; // never go through a system proxy
    c.connectionTimeout = const Duration(seconds: 20);
    // Never accept a bad certificate, whatever the reason.
    c.badCertificateCallback = (_, __, ___) => false;
    return c;
  }

  static http.Client _plain() => IOClient(_raw(null));

  static Future<void> init() async {
    http.Client? pinned;
    try {
      final data = await rootBundle.load('assets/certs/pinned_ca.pem');
      final ctx = SecurityContext(withTrustedRoots: false)
        ..setTrustedCertificatesBytes(data.buffer.asUint8List());
      pinned = IOClient(_raw(ctx));
    } catch (e) {
      if (kDebugMode) debugPrint('[Security] No pinned certificate bundled (assets/certs/pinned_ca.pem): $e');
    }
    _instance = SecureHttp._(pinned, _plain(), pinned != null);
  }

  @override
  Future<http.StreamedResponse> send(http.BaseRequest request) {
    final url = request.url;
    if (url.scheme != 'https') {
      throw const SocketException('Blocked: cleartext HTTP is not allowed');
    }
    final isOwn = url.host == SecurityConfig.host;
    if (isOwn) {
      if (_pinned != null) return _pinned!.send(request);
      if (SecurityConfig.enforce && SecurityConfig.requirePinning) {
        throw const SocketException('Blocked: pinned certificate missing');
      }
    }
    return _open.send(request);
  }

  @override
  void close() {
    _pinned?.close();
    _open.close();
  }
}

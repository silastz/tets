import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/location_service.dart';
import '../services/session_manager.dart';
import '../widgets/app_ui.dart';

/// Short bottom sheet for the service type and how far the provider covers.
/// Open it with [LocationServiceRadiusSheet.show].
class LocationServiceRadiusSheet extends StatefulWidget {
  const LocationServiceRadiusSheet({super.key});

  static Future<void> show(BuildContext context) {
    return AppSheet.show<void>(
      context,
      title: AppStrings.locationRadiusTitle,
      builder: (_) => const LocationServiceRadiusSheet(),
    );
  }

  @override
  State<LocationServiceRadiusSheet> createState() => _LocationServiceRadiusSheetState();
}

class _LocationServiceRadiusSheetState extends State<LocationServiceRadiusSheet> {
  String _selectedServiceType = 'Customer Comes to Me';
  double _radiusKm = 5.0;
  late String _serviceArea;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    // Start from what the user saved before; first time: the city the app already uses.
    final saved = SessionManager.getServiceCoverage();
    _serviceArea = saved?.area ?? LocationService.currentCity;
    if (saved != null) {
      const types = ['Customer Comes to Me', 'I Travel to Customer', 'Both'];
      if (types.contains(saved.type)) _selectedServiceType = saved.type;
      _radiusKm = saved.radiusKm.clamp(1.0, 25.0).toDouble();
    }
  }

  Future<void> _save() async {
    if (_saving) return;
    setState(() => _saving = true);
    final messenger = ScaffoldMessenger.of(context);
    final km = _radiusKm.toInt();
    await SessionManager.saveServiceCoverage(type: _selectedServiceType, radiusKm: _radiusKm, area: _serviceArea);
    if (!mounted) return;
    Navigator.pop(context);
    messenger.showSnackBar(
      SnackBar(
        content: Text(_isEn ? 'Service location saved: $km km radius' : 'Eneo la huduma limehifadhiwa: kilomita $km'),
      ),
    );
  }

  bool get _isEn => AppStrings.isEnglish;

  String _typeLabel(String value) {
    if (_isEn) return value;
    switch (value) {
      case 'Customer Comes to Me':
        return 'Mteja Anakuja Kwangu';
      case 'I Travel to Customer':
        return 'Nasafiri Kwa Mteja';
      default:
        return 'Zote Mbili';
    }
  }

  Widget _heading(String text, {String? trailing}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(text, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
        if (trailing != null)
          Text(trailing, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.primary)),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    // The supported regions, plus the saved/detected area when it is somewhere else (e.g. abroad).
    final regions = LocationService.supportedRegions.contains(_serviceArea)
        ? LocationService.supportedRegions
        : [...LocationService.supportedRegions, _serviceArea];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _heading(_isEn ? 'Service type' : 'Aina ya huduma'),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            children: [
              _buildRadioOption('Customer Comes to Me', Icons.person_pin_circle_outlined),
              const Divider(height: 1, color: AppColors.borderLight),
              _buildRadioOption('I Travel to Customer', Icons.directions_car_outlined),
              const Divider(height: 1, color: AppColors.borderLight),
              _buildRadioOption('Both', Icons.sync_alt_rounded),
            ],
          ),
        ),
        const SizedBox(height: 16),
        _heading(AppStrings.locationRadiusKm, trailing: '${_radiusKm.toInt()} km'),
        const SizedBox(height: 4),
        Slider(
          value: _radiusKm,
          min: 1.0,
          max: 25.0,
          divisions: 24,
          activeColor: AppColors.primary,
          inactiveColor: AppColors.border,
          label: '${_radiusKm.toInt()} km',
          onChanged: (val) => setState(() => _radiusKm = val),
        ),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('1 km', style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
              Text('5 km', style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
              Text('10 km', style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
              Text('25 km', style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
            ],
          ),
        ),
        const SizedBox(height: 16),
        _heading(_isEn ? 'Service area' : 'Eneo la huduma'),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: regions.contains(_serviceArea) ? _serviceArea : null,
              isExpanded: true,
              icon: const Icon(Icons.keyboard_arrow_down_rounded, color: AppColors.textSecondary),
              items: regions
                  .map((c) => DropdownMenuItem(
                        value: c,
                        child: Row(
                          children: [
                            const Icon(Icons.location_on_rounded, size: 16, color: AppColors.primary),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                c,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                              ),
                            ),
                          ],
                        ),
                      ))
                  .toList(),
              onChanged: (v) {
                if (v != null) setState(() => _serviceArea = v);
              },
            ),
          ),
        ),
        const SizedBox(height: 20),
        AppButton.primary(
          label: AppStrings.locationSaveButton,
          loading: _saving,
          onPressed: _save,
        ),
      ],
    );
  }

  Widget _buildRadioOption(String value, IconData icon) {
    final isSelected = _selectedServiceType == value;
    return InkWell(
      onTap: () => setState(() => _selectedServiceType = value),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        child: Row(
          children: [
            Icon(icon, size: 20, color: isSelected ? AppColors.primary : AppColors.textSecondary),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                _typeLabel(value),
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                  color: isSelected ? AppColors.primary : AppColors.textPrimary,
                ),
              ),
            ),
            Icon(
              isSelected ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded,
              size: 20,
              color: isSelected ? AppColors.primary : AppColors.textDisabled,
            ),
          ],
        ),
      ),
    );
  }
}

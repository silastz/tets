/// Client-side brute-force brake for login / OTP / password-reset and resend.
/// After [maxFailures] wrong attempts for the same key, further attempts are
/// blocked with an escalating cool-down (30s, 60s, 2m ... up to 15m).
/// This only slows down casual abuse; the server must still enforce its own limits.
class AttemptLimiter {
  static const int maxFailures = 5;
  static final Map<String, int> _failures = {};
  static final Map<String, DateTime> _lockedUntil = {};
  static final Map<String, DateTime> _cooldowns = {};

  /// Seconds the caller must still wait, or 0 if the attempt may proceed.
  static int secondsLocked(String key) {
    final until = _lockedUntil[key];
    if (until == null) return 0;
    final left = until.difference(DateTime.now()).inSeconds + 1;
    if (left <= 0) {
      _lockedUntil.remove(key);
      return 0;
    }
    return left;
  }

  static void recordFailure(String key) {
    final n = (_failures[key] ?? 0) + 1;
    _failures[key] = n;
    if (n >= maxFailures) {
      final step = n - maxFailures; // 0,1,2...
      final seconds = (30 * (1 << (step > 5 ? 5 : step))).clamp(30, 900);
      _lockedUntil[key] = DateTime.now().add(Duration(seconds: seconds));
    }
  }

  static void recordSuccess(String key) {
    _failures.remove(key);
    _lockedUntil.remove(key);
  }

  /// Simple cool-down between sends (e.g. OTP resend). Returns seconds left, or 0
  /// and starts a new cool-down when the action is allowed.
  static int cooldown(String key, {int seconds = 30}) {
    final until = _cooldowns[key];
    if (until != null) {
      final left = until.difference(DateTime.now()).inSeconds + 1;
      if (left > 0) return left;
    }
    _cooldowns[key] = DateTime.now().add(Duration(seconds: seconds));
    return 0;
  }
}

import 'dart:async';
import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/payment_methods_service.dart';
import '../services/session_manager.dart';
import '../widgets/app_ui.dart';
import '../widgets/card_payment_dialog.dart';

/// "Pay Now" page for the provider's one-time registration fee.
/// Pops with `true` once the fee is paid.
class RegistrationFeeScreen extends StatefulWidget {
  const RegistrationFeeScreen({super.key});

  @override
  State<RegistrationFeeScreen> createState() => _RegistrationFeeScreenState();
}

class _RegistrationFeeScreenState extends State<RegistrationFeeScreen> {
  String _method = 'mobile_money'; // mobile_money | card
  final TextEditingController _phoneCtrl = TextEditingController();
  String? _phoneError;
  bool _busy = false;
  bool _checking = true;
  bool _paid = false;
  double _amount = SessionManager.registrationFee.toDouble();

  bool get _isEn => AppStrings.isEnglish;

  @override
  void initState() {
    super.initState();
    _paid = SessionManager.getRegFeePaid() == true;
    _phoneCtrl.text = SessionManager.getPhone();
    _loadStatus();
  }

  @override
  void dispose() {
    _phoneCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadStatus() async {
    final res = await ApiService.getRegistrationFeeStatus();
    if (!mounted) return;
    if (res != null) {
      final amount = (res['amount'] as num?)?.toDouble();
      if (res['paid'] is bool) {
        await SessionManager.setRegFeePaid(res['paid'] as bool);
      }
      setState(() {
        if (amount != null && amount > 0) _amount = amount;
        _paid = SessionManager.getRegFeePaid() == true;
      });
    }
    if (mounted) setState(() => _checking = false);
  }

  String _money(num v) =>
      'TSh ${v.toInt().toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},')}';

  Future<void> _payNow() async {
    final messenger = ScaffoldMessenger.of(context);
    final userId = SessionManager.getUserIdValue();
    final reference = 'REGFEE-$userId-${DateTime.now().millisecondsSinceEpoch}';
    bool paid = false;

    if (_method == 'mobile_money') {
      final normalized = PaymentMethodsService.normalizeTzNumber(_phoneCtrl.text);
      if (normalized == null) {
        setState(() => _phoneError = _isEn ? 'Enter a valid Tanzanian number' : 'Weka namba sahihi ya Tanzania');
        return;
      }
      setState(() {
        _phoneError = null;
        _busy = true;
      });
      final res = await ApiService.requestMobilePayment(
        amount: _amount,
        purpose: 'PROVIDER_REGISTRATION',
        reference: reference,
        phone: '+$normalized',
      );
      if (!mounted) return;
      if (res == null) {
        setState(() => _busy = false);
        messenger.showSnackBar(SnackBar(
          backgroundColor: AppColors.danger,
          content: Text(_isEn
              ? 'Could not send the payment request. Try again.'
              : 'Imeshindwa kutuma ombi la malipo. Jaribu tena.'),
        ));
        return;
      }
      final ref = (res['reference'] ?? reference).toString();
      paid = await showDialog<bool>(
            context: context,
            barrierDismissible: false,
            builder: (_) => MobileWaitDialog(reference: ref, phone: MaskedPhone.of(normalized)),
          ) ??
          false;
    } else {
      setState(() => _busy = true);
      paid = await CardPayment.pay(
        context,
        amount: _amount,
        purpose: 'PROVIDER_REGISTRATION',
        reference: reference,
        description: 'Provider registration fee',
        phone: SessionManager.getPhone().isEmpty ? null : SessionManager.getPhone(),
      );
    }

    if (!mounted) return;
    setState(() => _busy = false);
    if (paid) {
      await SessionManager.setRegFeePaid(true);
      if (!mounted) return;
      setState(() => _paid = true);
    } else {
      messenger.showSnackBar(SnackBar(
        backgroundColor: AppColors.warningDark,
        content: Text(_isEn ? 'Payment was not completed.' : 'Malipo hayakukamilika.'),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context, _paid),
        ),
        title: Text(
          _isEn ? 'One-time fee' : 'Ada ya mara moja',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: PopScope(
        canPop: false,
        onPopInvokedWithResult: (didPop, _) {
          if (!didPop) Navigator.pop(context, _paid);
        },
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _feeCard(),
            const SizedBox(height: 20),
            if (_paid) _paidState() else ..._payForm(),
          ],
        ),
      ),
    );
  }

  Widget _feeCard() {
    final color = _paid ? AppColors.successDark : AppColors.warningDark;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(color: AppColors.primaryLight, borderRadius: BorderRadius.circular(10)),
            child: const Icon(Icons.receipt_rounded, color: AppColors.primary, size: 24),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(AppStrings.regFeeLabel,
                    style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontWeight: FontWeight.w500)),
                const SizedBox(height: 2),
                Text(_money(_amount),
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppColors.textPrimary)),
                const SizedBox(height: 2),
                Text(AppStrings.regFeeOneTime, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
              ],
            ),
          ),
          StatusPill(
            text: _paid ? (_isEn ? 'Paid' : 'Imelipwa') : (_isEn ? 'Unpaid' : 'Haijalipwa'),
            color: color,
          ),
        ],
      ),
    );
  }

  Widget _paidState() {
    return Column(
      children: [
        const SizedBox(height: 24),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: const BoxDecoration(color: AppColors.successLight, shape: BoxShape.circle),
          child: const Icon(Icons.check_circle_rounded, color: AppColors.success, size: 54),
        ),
        const SizedBox(height: 14),
        Text(_isEn ? 'Fee paid' : 'Ada imelipwa',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
        const SizedBox(height: 6),
        Text(
          _isEn ? 'Thank you. Your provider account is active.' : 'Asante. Akaunti yako ya mtoa huduma iko hai.',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
        ),
        const SizedBox(height: 24),
        AppButton.primary(label: _isEn ? 'Done' : 'Sawa', onPressed: () => Navigator.pop(context, true)),
      ],
    );
  }

  List<Widget> _payForm() {
    return [
      Text(
        _isEn ? 'Choose how to pay' : 'Chagua njia ya kulipa',
        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
      ),
      const SizedBox(height: 12),
      _option(
        id: 'mobile_money',
        icon: Icons.phone_android_rounded,
        color: AppColors.successDark,
        title: _isEn ? 'Mobile Money' : 'Pesa za Simu (Mobile Money)',
        subtitle: 'M-Pesa • Airtel Money • Tigo Pesa • Halopesa',
      ),
      if (_method == 'mobile_money') ...[
        const SizedBox(height: 12),
        AppTextField(
          controller: _phoneCtrl,
          icon: Icons.phone_outlined,
          keyboardType: TextInputType.phone,
          hint: '07XX XXX XXX',
          label: _isEn ? 'Number to pay with' : 'Namba ya kulipia',
          errorText: _phoneError,
        ),
        const SizedBox(height: 6),
        Text(
          _isEn
              ? 'You will get a prompt on this phone to confirm with your PIN.'
              : 'Utapata ujumbe kwenye simu hii kuthibitisha kwa PIN yako.',
          style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
        ),
      ],
      const SizedBox(height: 10),
      _option(
        id: 'card',
        icon: Icons.credit_card_rounded,
        color: const Color(0xFF1D4ED8),
        title: _isEn ? 'Card' : 'Kadi (Card)',
        subtitle: 'Visa • Mastercard',
      ),
      if (_method == 'card') ...[
        const SizedBox(height: 8),
        Text(
          _isEn
              ? 'You will pay on a secure card page. We never see or store your card details.'
              : 'Utalipa kwenye ukurasa salama wa kadi. Hatuoni wala kuhifadhi taarifa za kadi yako.',
          style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
        ),
      ],
      const SizedBox(height: 20),
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.primaryLight,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppColors.primary.withValues(alpha: 0.15)),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(Icons.verified_rounded, size: 18, color: AppColors.primary),
            const SizedBox(width: 10),
            Expanded(
              child: Text(AppStrings.regPaymentActivationNotice,
                  style: const TextStyle(fontSize: 12, color: AppColors.primaryDark, height: 1.4)),
            ),
          ],
        ),
      ),
      const SizedBox(height: 20),
      AppButton.primary(
        label: _isEn ? 'Pay ${_money(_amount)}' : 'Lipa ${_money(_amount)}',
        loading: _busy || _checking,
        onPressed: _busy || _checking ? null : _payNow,
      ),
    ];
  }

  Widget _option({
    required String id,
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
  }) {
    final selected = _method == id;
    return InkWell(
      onTap: _busy ? null : () => setState(() => _method = id),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: selected ? AppColors.primary : AppColors.border, width: selected ? 1.5 : 1),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10)),
              child: Icon(icon, color: color, size: 22),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                  const SizedBox(height: 2),
                  Text(subtitle, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                ],
              ),
            ),
            Container(
              width: 20,
              height: 20,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: selected ? AppColors.primary : AppColors.border, width: selected ? 6 : 2),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Helper so the full number is never shown in the waiting dialog.
class MaskedPhone {
  static String of(String normalized) => PaymentMethodsService.mask(normalized);
}

class MobileWaitDialog extends StatefulWidget {
  final String reference;
  final String phone;
  const MobileWaitDialog({required this.reference, required this.phone});

  @override
  State<MobileWaitDialog> createState() => MobileWaitDialogState();
}

class MobileWaitDialogState extends State<MobileWaitDialog> {
  Timer? _timer;
  bool _checking = false;
  String? _message;
  int _ticks = 0;

  bool get _isEn => AppStrings.isEnglish;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 4), (_) {
      _ticks++;
      if (_ticks > 45) {
        // ~3 minutes: stop waiting, the user can retry.
        _timer?.cancel();
        if (mounted) Navigator.of(context).pop(false);
        return;
      }
      _check(auto: true);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _check({bool auto = false}) async {
    if (_checking) return;
    setState(() => _checking = true);
    final status = await ApiService.getPaymentStatus(widget.reference);
    if (!mounted) return;
    setState(() => _checking = false);
    if (status == 'PAID') {
      _timer?.cancel();
      Navigator.of(context).pop(true);
    } else if (status == 'FAILED' || status == 'CANCELLED') {
      _timer?.cancel();
      Navigator.of(context).pop(false);
    } else if (!auto) {
      setState(() => _message = _isEn
          ? 'Not confirmed yet. Approve the prompt on your phone, then try again.'
          : 'Bado haijathibitishwa. Kubali ujumbe kwenye simu yako, kisha jaribu tena.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Row(
        children: [
          const Icon(Icons.phone_android_rounded, color: AppColors.primary),
          const SizedBox(width: 8),
          Expanded(child: Text(_isEn ? 'Approve on your phone' : 'Kubali kwenye simu yako')),
        ],
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(_isEn
              ? 'We sent a payment prompt to ${widget.phone}. Enter your PIN to confirm.'
              : 'Tumetuma ombi la malipo kwa ${widget.phone}. Weka PIN yako kuthibitisha.'),
          const SizedBox(height: 12),
          Row(
            children: [
              const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)),
              const SizedBox(width: 10),
              Text(_isEn ? 'Waiting for confirmation...' : 'Inasubiri uthibitisho...',
                  style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
            ],
          ),
          if (_message != null) ...[
            const SizedBox(height: 10),
            Text(_message!, style: const TextStyle(fontSize: 12, color: AppColors.warningDark)),
          ],
        ],
      ),
      actions: [
        TextButton(
          onPressed: () {
            _timer?.cancel();
            Navigator.of(context).pop(false);
          },
          child: Text(_isEn ? 'Cancel' : 'Ghairi'),
        ),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: AppColors.primary),
          onPressed: _checking ? null : () => _check(),
          child: Text(_isEn ? "I've paid" : 'Nimelipa'),
        ),
      ],
    );
  }
}

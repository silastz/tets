import 'base_strings.dart';

/// Swahili Dictionary (sw.dart)
class SwStrings implements BaseStrings {
  const SwStrings();

  // 1. Common / Global
  @override String get appName => 'Nearby Services';
  @override String get cancel => 'Ghairi';
  @override String get close => 'Funga';
  @override String get save => 'Hifadhi';
  @override String get submit => 'Wasilisha';
  @override String get confirm => 'Thibitisha';
  @override String get back => 'Rudi';
  @override String get retry => 'Jaribu Tena';
  @override String get search => 'Tafuta';
  @override String get loading => 'Inapakia...';
  @override String get success => 'Imefanikiwa';
  @override String get error => 'Hitilafu';
  @override String get guest => 'Mgeni';
  @override String get active => 'Inatumika';
  @override String get pending => 'Inasubiri';
  @override String get completed => 'Imekamilika';
  @override String get currency => 'TSh';
  @override String get viewAll => 'Ona Zote';

  // 2. Navigation Bar
  @override String get navHome => 'Nyumbani';
  @override String get authNumberNotVerifiedNotice => 'Namba hii bado haijathibitishwa. Tumekutumia msimbo - ithibitishe kwanza, kisha utaweza kuingia au kubadilisha nenosiri.';
  @override String get authTooManyAttempts => 'Majaribio mengi mno. Tafadhali subiri kabla ya kujaribu tena:';
  @override String get exitAppTitle => 'Toka kwenye app?';
  @override String get exitAppMessage => 'Una uhakika unataka kutoka kwenye Nearby Services?';
  @override String get exitAppCancel => 'Baki';
  @override String get exitAppConfirm => 'Toka';
  @override String get exitAppPressAgain => 'Bonyeza tena kurudi nyuma ili kutoka';
  @override String get loadingServices => 'Inapakia huduma zilizo karibu nawe...';
  @override String get navChats => 'Ujumbe';
  @override String get navRequests => 'Maombi';
  @override String get navSell => 'Uza';
  @override String get navServices => 'Huduma';
  @override String get navEarnings => 'Mauzo & Mapato';
  @override String get navProfile => 'Wasifu';
  @override String get navSearch => 'Tafuta';

  // 3. Home Screen
  @override String get homeHeaderLocationTitle => 'ENEO LAKO';
  @override String get homeGreeting => 'Hujambo, Karibu!';
  @override String get homeGreetingSubtitle => 'Tafuta huduma za kuaminika zilizo karibu nawe';
  @override String get homeSearchPlaceholder => 'Unahitaji huduma gani leo?';
  @override String get homeChangeLocation => 'Badili eneo';
  @override String get selectRegionTitle => 'Chagua Mkoa Wako';
  @override String get detectingLocation => 'Inatambua eneo ulilopo...';
  @override String get searchRegionHint => 'Tafuta mkoa au mji...';
  @override String get nearYouRadius => 'Karibu nawe • Ndani ya km 5';
  @override String get noServicesNearby => 'Hakuna watoa huduma waliopatikana mkoa huu kwa sasa.';
  @override String get bookNow => 'Omba Huduma';
  @override String get bannerRelaxTitle => 'Huduma za Kitaalamu\nZilizo Karibu Nawe';
  @override String get bannerRelaxSubtitle => 'Ubora • Uaminifu • Nafuu';
  @override String get bannerExploreNow => 'Angalia Sasa';
  @override String get chipAll => 'Yote';
  @override String get chipNearby => 'Karibu';
  @override String get chipTopRated => 'Bora Zaidi';
  @override String get chipVerified => 'Waliothibitishwa';
  @override String get homeCategoriesTitle => 'Makundi ya Huduma';
  @override String get homePopularServices => 'Huduma Zinazopendwa';
  @override String get homeNearbyProviders => 'Huduma za Karibu';
  @override String get homeFeaturedProviders => 'Watoa Huduma Bora';
  @override String get homeVerifiedBadge => 'Imethibitishwa';
  @override String get homeStartingFrom => 'Kuanzia';
  @override String get homeAllServicesSeen => 'Umeona huduma zote zilizopo karibu nawe';

  // Categories
  @override String get catMassage => 'Massage';
  @override String get catBeauty => 'Urembo';
  @override String get catBarber => 'Kinyozi';
  @override String get catCleaning => 'Usafi';
  @override String get catPlumbing => 'Mabomba';
  @override String get catElectrical => 'Umeme';
  @override String get catMechanic => 'Makanika';
  @override String get catPhotography => 'Upigaji Picha';
  @override String get catRepair => 'Ukarabati';
  @override String get catGeneral => 'Jumla';

  // 4. Auth & Login / Registration Modal
  @override String get authWelcomeBack => 'Karibu Tena!';
  @override String get authWelcomeSubtitle => 'Ingia ili uweke maombi ya escrow na usimamie huduma';
  @override String get authCreateAccount => 'Unda Akaunti Mpya';
  @override String get authCreateSubtitle => 'Jiunge na jumuiya ya wateja na watoa huduma walioidhinishwa';
  @override String get authLoginTab => 'Ingia';
  @override String get authRegisterTab => 'Jisajili';
  @override String get authFullNameLabel => 'Jina Kamili / Jina la Kazi';
  @override String get authFullNameHint => 'Mfano: John Doe / Mtaalamu';
  @override String get authPhoneLabel => 'Namba ya Simu';
  @override String get authPhoneHint => 'Mfano: 0712345678';
  @override String get authEmailLabel => 'Barua Pepe (Email)';
  @override String get authEmailHint => 'jina@mfano.com';
  @override String get authPasswordLabel => 'Nenosiri';
  @override String get authPasswordHint => 'Kuanzia herufi 6';
  @override String get authSellerAccountSwitch => 'Jisajili kama Mtoa Huduma (Seller)';
  @override String get authSellerSubtitle => 'Inakuwezesha kuchapisha huduma na kupokea maombi';
  @override String get authSignInButton => 'Ingia Kwenye Akaunti';
  @override String get authRegisterButton => 'Kamilisha Usajili';
  @override String get authVerifyOtpTitle => 'Thibitisha Barua Pepe';
  @override String get authVerifyPhoneOtpTitle => 'Thibitisha Nambari ya Simu';
  @override String get authOtpSentSubtitle => 'Tumetuma nambari 6 za siri (OTP) kwenye barua pepe: ';
  @override String get authPhoneOtpSentSubtitle => 'Tumetuma nambari 6 za siri (OTP) kwa SMS kwenye nambari: ';
  @override String get authOtpHint => 'Nambari 6 za OTP';
  @override String get authVerifyButton => 'Thibitisha OTP';
  @override String get authResendOtp => 'Tuma OTP Upya';
  @override String get authInvalidOtpError => 'OTP si sahihi au muda wake umekwisha';
  @override String get authLoginSuccess => 'Karibu tena, ';
  @override String get authRegisterSuccess => 'Akaunti imefanikiwa kuundwa!';
  @override String get authAlreadyHaveAccount => 'Tayari una akaunti? Ingia hapa';
  @override String get authDontHaveAccount => 'Huna akaunti? Jisajili sasa';

  // Multi-step Service Provider Registration
  @override String get regProviderTitle => 'Jisajili kama Mtoa Huduma';
  @override String get regStepBasic => 'Taarifa Binafsi';
  @override String get regStepBusiness => 'Taarifa za Kazi';
  @override String get regStepDocuments => 'Nyaraka';
  @override String get regStepPayment => 'Malipo';
  @override String get regBasicTitle => '1. Taarifa Binafsi';
  @override String get regBasicSubtitle => 'Tueleze kukuhusu wewe';
  @override String get regBusinessTitle => '2. Taarifa za Kazi / Biashara';
  @override String get regBusinessSubtitle => 'Maelezo kuhusu huduma zako na ujuzi wako';
  @override String get regBusinessNameLabel => 'Jina la Biashara / Huduma';
  @override String get regBusinessNameHint => 'mfano. Gloria Massage Spa';
  @override String get regCategoryLabel => 'Kundi la Huduma';
  @override String get regCategoryHint => 'Chagua kundi';
  @override String get regDescLabel => 'Maelezo ya Huduma';
  @override String get regDescHint => 'Eleza huduma unazotoa, uzoefu na ubora unaowapa wateja...';
  @override String get regLocationLabel => 'Eneo la Huduma';
  @override String get regLocationHint => 'Dar es Salaam, Tanzania';
  @override String get regRadiusLabel => 'Umbali wa Kuhudumia (Radius)';
  @override String get regRadiusHint => 'mfano. 5 km';
  @override String get regDocumentsTitle => '3. Nyaraka';
  @override String get regDocumentsSubtitle => 'Pakia nyaraka zinazohitajika kwa ajili ya uthibitishaji';
  @override String get regNidaDocTitle => 'Kitambulisho cha NIDA';
  @override String get regNidaDocSubtitle => 'Picha ya mbele ya kitambulisho';
  @override String get regLicenseDocTitle => 'Leseni ya Biashara (Si lazima)';
  @override String get regLicenseDocSubtitle => 'Cheti cha usajili au leseni ya biashara';
  @override String get regProfilePhotoTitle => 'Picha ya Wasifu';
  @override String get regProfilePhotoSubtitle => 'Picha yako halisi na iliyo wazi';
  @override String get regUploadPhoto => 'Pakia Picha';
  @override String get regUploadDoc => 'Pakia Waraka';
  @override String get regDocSafeNotice => 'Nyaraka zako ziko salama na zitatumika kwa ajili ya uthibitishaji pekee.';
  @override String get regPaymentTitle => '4. Malipo ya Usajili';
  @override String get regPaymentSubtitle => 'Kamilisha usajili wako kwa kulipa ada ya mara moja tu.';
  @override String get regFeeLabel => 'Ada ya Usajili';
  @override String get regFeeOneTime => 'Mara moja tu';
  @override String get regSelectPaymentMethod => 'Chagua Njia ya Malipo';
  @override String get regPaymentActivationNotice => 'Baada ya malipo kukamilika, akaunti yako itawashwa mara moja na utaanza kuweka huduma.';
  @override String get regBtnContinue => 'Endelea';
  @override String get regBtnPayAndContinue => 'Lipa na Ukamilishe';
  @override String get regUpgradeFromBuyerBanner => 'Kuhuisha akaunti ya mnunuzi kuwa Mtoa Huduma';
  @override String get regSuccessTitle => 'Hongera Sana!';
  @override String get regSuccessMsg => 'Akaunti yako ya Utoaji Huduma imewashwa kikamilifu!';
  @override String get profileBecomeSeller => 'Kuwa Mtoa Huduma (Seller)';
  @override String get profileBecomeSellerSubtitle => 'Jisajili ili uweze kuchapisha huduma, kupata oda na kupokea malipo';
  @override String get authForgotPasswordLink => 'Umesahau nenosiri?';
  @override String get authForgotPasswordTitle => 'Rudisha Nenosiri';
  @override String get authForgotPasswordSubtitle => 'Weka nambari yako ya simu au barua pepe ili kupokea nambari ya siri (OTP)';
  @override String get authSendResetCodeButton => 'Tuma Nambari ya Siri (OTP)';
  @override String get authResetPasswordTitle => 'Weka Nenosiri Jipya';
  @override String get authNewPasswordLabel => 'Nenosiri Jipya';
  @override String get authResetPasswordButton => 'Hifadhi Nenosiri Jipya';
  @override String get authBackToLogin => 'Rudi kwenye Kuingia';
  @override String get authAccountNotVerifiedError => 'Akaunti haijathibitishwa kwa OTP ya simu. Tafadhali thibitisha kwanza kabla ya kuingia.';
  @override String get authInvalidCredentialsError => 'Taarifa za kuingilia si sahihi. Tafadhali hakiki na ujaribu tena.';
  @override String get authPhoneExistsError => 'Nambari hii ya simu tayari imesajiliwa. Tafadhali ingia badala yake.';
  @override String get authEmailExistsError => 'Barua pepe tayari imesajiliwa. Tafadhali tumia nyingine.';
  @override String get authUsernameExistsError => 'Jina hili la mtumiaji tayari limetumika.';
  @override String get authUserNotFoundError => 'Akaunti ya mtumiaji haikupatikana kwa maelezo haya.';
  @override String get authInvalidPhoneError => 'Tafadhali weka nambari sahihi ya simu.';
  @override String get authNetworkError => 'Haikuweza kuunganisha na seva. Tafadhali angalia mtandao wako.';

  // Guest Access State
  @override String get guestTitle => 'Ingia kwenye Akaunti Yako';
  @override String get guestSubtitle => 'Tafadhali ingia au jisajili ili uweze kutumia sehemu hii na kufikia taarifa zako zote.';
  @override String get guestAction => 'Ingia au Jisajili Sasa';
  @override String get guestChatsDesc => 'Fungua mawasiliano na watoa huduma, tuma ujumbe na pokea majibu moja kwa moja.';
  @override String get guestRequestsDesc => 'Fuatilia maombi yako ya huduma, mikataba na malipo yaliyolindwa kwa escrow.';
  @override String get guestSellDesc => 'Chapisha huduma unazotoa na uanze kupokea maombi ya kazi kutoka kwa wateja walio karibu.';

  // 5. Profile Screen
  @override String get profileTitle => 'Wasifu';
  @override String get profileGuestTitle => 'Mgeni (Guest)';
  @override String get profileGuestSubtitle => 'Bofya hapa chini ili uingie';
  @override String get profileSignInAction => 'Ingia';
  @override String get profileSignOutAction => 'Ondoka';
  @override String get profileWalletTitle => 'Mkoba wa Huduma (Wallet)';
  @override String get profileWalletSubtitle => 'Salio lililolindwa kwa escrow, kuweka na kutoa';
  @override String get profileNidaTitle => 'Uhakiki wa NIDA na Mdhamini';
  @override String get profileNidaSubtitle => 'Green Badge, Blue Tick, au msimbo wa mwaliko';
  @override String get profileLocationTitle => 'Eneo na Umbali wa Huduma';
  @override String get profileLocationSubtitle => 'Panga umbali na eneo unalotoa huduma';
  @override String get profileFavoritesTitle => 'Huduma Unazopenda';
  @override String get profileFavoritesSubtitle => 'Huduma zilizohifadhiwa';
  @override String get profilePrivacyTitle => 'Ulinzi na Faragha';
  @override String get profilePrivacySubtitle => 'Majina rasmi ya NIDA yanalindwa kwa faragha';
  @override String get profileHelpTitle => 'Msaada na Huduma';
  @override String get profileHelpSubtitle => 'Maswali na usaidizi';
  @override String get profileLanguageTitle => 'Lugha ya Programu';

  // Badges
  @override String get badgeBlueTick => 'Blue Tick Imethibitishwa';
  @override String get badgeGreenBadge => 'Green Badge (NIDA)';
  @override String get badgeUnverified => 'Hujathibitishwa';

  // 6. Sell & Manage Services Screen
  @override String get sellMyServicesTitle => 'Huduma Zangu';
  @override String get sellAddService => 'Weka Huduma';
  @override String get sellTabActive => 'Zinazofanya Kazi';
  @override String get sellTabPending => 'Zinasubiri';
  @override String get sellTabInactive => 'Zilizositishwa';
  @override String get sellNoServicesTitle => 'Hakuna huduma zilizopatikana';
  @override String get sellNoServicesSubtitle => 'Chapisha huduma yako ya kwanza ili uanze kupokea maombi ya wateja.';
  @override String get sellPostNewTitle => 'Chapisha Huduma Mpya';
  @override String get sellServiceTitleLabel => 'Jina la Huduma *';
  @override String get sellServiceTitleHint => 'Mfano: Kunyoa na Kubana Nywele';
  @override String get sellDescLabel => 'Maelezo ya Huduma';
  @override String get sellDescHint => 'Eleza kwa kifupi huduma unazotoa...';
  @override String get sellCategoryLabel => 'Kundi la Huduma';
  @override String get sellPriceLabel => 'Bei / Kianzio (TSh) *';
  @override String get sellPriceHint => 'Mfano: 25000';
  @override String get sellPhoneLabel => 'Namba ya Simu ya Huduma (Hiari)';
  @override String get sellPrivacyLockTitle => 'Ficha Mawasiliano (Privacy Lock)';
  @override String get sellPrivacyLockSubtitle => 'Mteja ataona namba zako baada tu ya ombi kukubaliwa';
  @override String get sellPublishButton => 'Chapisha Huduma';
  @override String get sellPublishSuccess => 'Hongera! Huduma imechapishwa kikamilifu.';
  @override String get sellPublishError => 'Kuchapisha huduma kumeshindikana. Hakikisha wewe ni Seller.';
  @override String get sellContactsLockedBadge => 'Namba Zimefichwa';

  // 7. Requests & Bookings Screen
  @override String get requestsTitle => 'Maombi & Uhifadhi';
  @override String get requestsTabIncoming => 'Maombi Yaliyoingia (Seller)';
  @override String get requestsTabOutgoing => 'Maombi Uliyotuma (Buyer)';
  @override String get requestsNoRequests => 'Hakuna maombi au uhifadhi uliopatikana';
  @override String get requestsAcceptButton => 'Kubali & Fungua Mawasiliano';
  @override String get requestsRejectButton => 'Kataa Ombi';
  @override String get requestsReleaseButton => 'Umeridhika? Toa Malipo';
  @override String get requestsAcceptedNotice => 'Ombi limekubaliwa! Mawasiliano yamefunguliwa.';
  @override String get requestsReleasedNotice => 'Malipo yametolewa kikamilifu kutoka escrow kwenda kwa mtoa huduma!';
  @override String get requestsRejectedNotice => 'Ombi limekataliwa. Pesa zimerudishwa kwa mnunuzi.';
  @override String get requestsEscrowSecured => 'Imelindwa na Escrow';

  // 8. Pocket Fund (Wallet) Screen
  @override String get walletTitle => 'Mkoba wa Huduma (Pocket Fund)';
  @override String get walletAvailableBalance => 'SALIO LINALOPATIKANA';
  @override String get walletLockedEscrow => 'ZILIZOFUNGWA ESCROW';
  @override String get walletDepositAction => 'Weka Pesa';
  @override String get walletWithdrawAction => 'Toa Pesa';
  @override String get walletHistoryTitle => 'Miamala ya Hivi Karibuni';
  @override String get walletNoTransactions => 'Hakuna miamala ya hivi karibuni kwenye Wallet yako.';
  @override String get walletTopUpSheetTitle => 'Ongeza Salio la Pocket Fund';
  @override String get walletTopUpPhoneHint => 'Namba ya Simu (M-Pesa / Tigo / Airtel)';
  @override String get walletTopUpAmountHint => 'Ingiza kiasi (TSh):';
  @override String get walletWithdrawSheetTitle => 'Kutoa Salio';
  @override String get walletWithdrawSuccess => 'Salio limetolewa kikamilifu!';
  @override String get walletDepositSuccess => 'Salio limeongezwa kikamilifu kwenye Pocket Fund!';
  @override String get walletEscrowPolicy => 'Ulinzi wa Mnunuzi na Mtoa Huduma:\nFedha zako hulindwa kwenye Escrow. Seller hapokei pesa hadi pale utakaporidhika 100% na huduma na kuthibitisha.';
  @override String get walletSelectPaymentNetwork => 'Chagua mtandao wa malipo:';
  @override String get walletWithdrawPhonePrompt => 'Namba ya simu ya kupokelea:';
  @override String get walletWithdrawAmountPrompt => 'Ingiza kiasi cha kutoa (TSh):';
  @override String get walletWithdrawFailed => 'Kutoa salio kumeshindikana. Hakikisha una salio la kutosha.';
  @override String get walletDepositFailed => 'Kuongeza salio kumeshindikana. Jaribu tena.';
  @override String get walletConfirmWithdraw => 'Thibitisha Kutoa';

  // 9. NIDA Verification Screen
  @override String get nidaScreenTitle => 'Uhakiki wa Utambulisho';
  @override String get nidaHeaderTitle => 'Uaminifu & Uhakiki';
  @override String get nidaHeaderSubtitle => 'Pata Beji ya Kijani (NIDA) au Blue Tick kupitia mdhamini ili kujenga uaminifu na wateja.';
  @override String get nidaNumberLabel => 'Nambari 20 za NIDA';
  @override String get nidaFirstNameLabel => 'Jina la Kwanza la NIDA';
  @override String get nidaLastNameLabel => 'Jina la Ukoo la NIDA';
  @override String get nidaGuarantorCodeLabel => 'Msimbo wa Mdhamini (Inviter Code)';
  @override String get nidaUploadIdPhoto => 'Pakia Picha ya Kitambulisho';
  @override String get nidaUploadSelfie => 'Pakia Picha ya Uso na Kitambulisho';
  @override String get nidaSubmitButton => 'Wasilisha kwa Uhakiki';
  @override String get nidaSuccessGreen => 'Hongera! Umethibitishwa na Green Badge.';
  @override String get nidaSuccessBlue => 'Hongera! Umepata Blue Tick Rasmi!';

  // 10. Booking Request Screen
  @override String get bookingTitle => 'Omba Huduma';
  @override String get bookingSummaryTitle => 'Muhtasari wa Huduma';
  @override String get bookingEscrowGuarantee => 'Ulinzi wa 100% wa Escrow: Pesa zinabaki salama zikiwa zimefungwa mpaka utakapokagua na kuridhika na huduma.';
  @override String get bookingSelectDate => 'Chagua Tarehe na Muda';
  @override String get bookingSelectTime => 'Muda';
  @override String get bookingNotesLabel => 'Maelekezo Maalumu';
  @override String get bookingNotesHint => 'Eleza eneo au maelezo ya ziada...';
  @override String get bookingConfirmButton => 'Tuma Ombi';
  @override String get bookingSuccessTitle => 'Ombi Limetumwa!';
  @override String get bookingSuccessSubtitle => 'Malipo yako yamelindwa na escrow. Mtoa huduma atapitia ombi lako hivi punde.';

  // 11. Chats Screen
  @override String get chatsTitle => 'Ujumbe & Mawasiliano';
  @override String get chatsNoMessages => 'Hakuna jumbe bado';
  @override String get chatsTypePlaceholder => 'Andika ujumbe hapa...';
  @override String get chatsOnline => 'Yupo Hewani';
  @override String get chatsSearchHint => 'Tafuta mazungumzo...';
  @override String get chatsTabAll => 'Yote';
  @override String get chatsTabBookings => 'Oda za Huduma';
  @override String get chatsTabRequests => 'Maombi';

  // 12. Notifications Screen
  @override String get notificationsTitle => 'Taarifa';
  @override String get notificationsNoItems => 'Hakuna taarifa mpya';
  @override String get notificationsMarkAllRead => 'Weka zote zimesomwa';

  // 13. Search & Filter Screen
  @override String get searchFilterTitle => 'Tafuta Huduma';
  @override String get searchFilterRadius => 'Umbali wa Eneo';
  @override String get searchFilterRating => 'Kiwango cha Chini';
  @override String get searchFilterApply => 'Tumia Vichungi';
  @override String get searchFilterReset => 'Rudisha Awali';
  @override String get searchFilterBy => 'Chuja kwa';
  @override String get searchFilterAll => 'Zote';
  @override String get searchFilterAvailableNow => 'Inapatikana Sasa';
  @override String get searchFilterVerifiedOnly => 'Iliyothibitishwa Tu';
  @override String get searchFilterDistance => 'Umbali';
  @override String get searchFilterAnyDistance => 'Umbali wowote';
  @override String get searchFilterPriceRange => 'Kiwango cha Bei';
  @override String get searchFilterAnyPrice => 'Bei yoyote';
  @override String get searchFilterAnyRating => 'Kiwango chochote';
  @override String get searchFilterCategory => 'Aina ya Huduma';
  @override String get searchFilterAvailability => 'Upatikanaji';
  @override String get searchFilterAnyTime => 'Wakati wowote';
  @override String get searchFilterServiceType => 'Aina ya Utoaji';
  @override String get searchFilterServiceTypeBoth => 'Mteja anakuja / Ninasafiri / Zote';
  @override String get searchFilterSortBy => 'Panga kwa';
  @override String get searchFilterNearestFirst => 'Iliyo karibu zaidi';

  // 14. Location & Radius Screen
  @override String get locationRadiusTitle => 'Umbali wa Huduma';
  @override String get locationRadiusSubtitle => 'Weka umbali ambao uko tayari kusafiri kutoa au kupata huduma.';
  @override String get locationRadiusKm => 'km kipenyo';
  @override String get locationSaveButton => 'Hifadhi Umbali';

  // Startup Permissions Modal
  @override String get permWelcomeTitle => 'Karibu NearByServices';
  @override String get permWelcomeSubtitle => 'Ili kugundua huduma bora karibu nawe na kupata taarifa za papo hapo za maombi yako, tafadhali ruhusu yafuatayo:';
  @override String get permLocationTitle => 'Upatikanaji wa Mahali (Location)';
  @override String get permLocationDesc => 'Hutumika kutambua jiji/eneo lako, kupima umbali halisi na kukuonyesha watoa huduma walio karibu zaidi.';
  @override String get permNotificationTitle => 'Taarifa na Ujumbe (Notifications)';
  @override String get permNotificationDesc => 'Pata taarifa za haraka kuhusu maombi mapya ya kazi, jumbe za wateja na uthibitisho wa malipo ya escrow.';
  @override String get permAllowButton => 'Ruhusu & Endelea';
  @override String get permMaybeLaterButton => 'Baadaye Kidogo';

  // 15. Favorites Screen
  @override String get favoritesTitle => 'Huduma Pendwa';
  @override String get favoritesNoItems => 'Hujachagua huduma yoyote bado';

  // 16. Service Details & Seller Profile Screen
  @override String get detailsAboutService => 'Kuhusu Huduma Hii';
  @override String get detailsPricingOptions => 'Vifurushi na Muda';
  @override String get detailsCustomerReviews => 'Maoni ya Wateja';
  @override String get detailsBookNow => 'Omba Huduma';
  @override String get detailsCallNow => 'Piga Simu';
  @override String get detailsWhatsApp => 'Tuma WhatsApp';
  @override String get detailsSellerProfile => 'Wasifu wa Mtoa Huduma';
  @override String get detailsExperience => 'Uzoefu';
  @override String get detailsTotalOrders => 'Kazi Zilizokamilika';
  @override String get detailsVerifiedProvider => 'Mtoa Huduma Aliyethibitishwa';
  @override String get detailsPerSession => 'kwa kipindi';
  @override String get detailsProfessional => 'Mtaalamu';
  @override String get detailsCleanSafe => 'Safi & Salama';
  @override String get detailsAvailableNow => 'Yupo Tayari';
  @override String get detailsMemberSince => 'Mwanachama tangu';
  @override String get detailsViewProfile => 'Tazama Wasifu';
  @override String get detailsTabOverview => 'Maelezo';
  @override String get detailsTabPortfolio => 'Kazi Zake';
  @override String get detailsTabReviews => 'Tathmini';
  @override String get detailsTabAvailability => 'Upatikanaji';
  @override String get detailsTabLocation => 'Eneo';
  @override String get detailsServiceDurationPrice => 'Muda wa Huduma na Bei';
  @override String get detailsChat => 'Ujumbe';
  @override String get detailsLocked => 'Imefungwa';
  @override String get detailsContactLockedAlert => 'Mtoa huduma amefunga mawasiliano ya moja kwa moja. Tafadhali tuma ombi kwanza.';
  @override String get nidaPrivacyGuarantee => 'Hakikisho Rasmi la Usiri: Majina yako ya NIDA na Namba ya NIDA ni PRIVATE 100%. Wateja wataona Stage Name yako pekee.';
  @override String get nidaOption1Title => '1. Namba ya NIDA (Green Badge)';
  @override String get nidaOption1Subtitle => 'Weka namba yako ya NIDA yenye tarakimu 20 kupata beji ya kijani.';
  @override String get nidaOption2Title => '2. Kitambulisho cha NIDA + Selfie (Blue Tick)';
  @override String get nidaOption2Subtitle => 'Pata Blue Tick kwa kupakia picha ya kitambulisho na picha ya selfie umekishikilia.';
  @override String get nidaOption3Title => '3. Mfumo wa Mdhamini (Auto Blue Tick)';
  @override String get nidaOption3Subtitle => 'Huna kitambulisho cha kimwili? Umealikwa na mtumiaji mwenye Blue Tick? Weka msimbo wake kupata Blue Tick papo hapo.';
  @override String get nidaIdPhotoCard => 'Picha ya NIDA ID';
  @override String get nidaSelfieCard => 'Selfie na ID';
  @override String get nidaUploaded => 'Imepakiwa!';
  @override String get nidaGuarantorHint => 'Weka Msimbo wa Mdhamini (Mf: NEARBY-9921)';
  @override String get nidaFailedGreen => 'Uhakiki wa NIDA umeshindikana. Hakikisha namba ina tarakimu 20 na haijatumika.';
  @override String get nidaFailedBlue => 'Uhakiki wa Blue Tick umeshindikana. Hakikisha taarifa au msimbo wa mdhamini ni sahihi.';
}
